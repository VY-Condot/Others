# NuGet Visualizer & Auditor — Blazor C# Edition

A complete port of the Next.js NuGet Auditor application to **Blazor Server** (.NET 8).

## Features (100% parity with the Next.js version)

- ✅ .csproj XML parser (MSBuild format)
- ✅ NuGet v3 API client (registration index + search/popularity)
- ✅ Full audit engine (vulnerabilities, outdated, deprecated, license classification)
- ✅ Interactive force-directed dependency graph (SVG + JS physics)
- ✅ Security health score (A–F grade, radial gauge)
- ✅ AI remediation advisor (OpenAI + Gemini, auto-fallback)
- ✅ Upgrade & export toolkit (Bash + PowerShell scripts, patched csproj, Markdown report)
- ✅ Dependency analytics dashboard (donut, radar, bar charts, sunburst, timeline, heatmap)
- ✅ Version compare dialog (semantic diff)
- ✅ Audit history persistence (SQLite via EF Core, client-isolated)
- ✅ Audit diff view (compare two saved audits)
- ✅ Package changelog viewer (fetches release notes from nuget.org)
- ✅ License compliance panel (6 categories)
- ✅ Package popularity metrics (download counts)
- ✅ Upgrade simulator (before/after health score)
- ✅ Command palette (Cmd+K)
- ✅ Shareable audit links
- ✅ Confetti celebration (clean audit)
- ✅ Keyboard shortcuts
- ✅ Dedicated /feedback page (submit form with screenshots)
- ✅ Protected /admin page (token-gated, feedback management)
- ✅ Creative Gen-Z 404 page
- ✅ PWA (manifest + service worker + offline caching)
- ✅ Azure App Service ready (health check, ARM template, web.config)
- ✅ Light mode default (with dark mode toggle)
- ✅ Responsive header with mobile menu
- ✅ Eye-catching footer with 0xz.0nfirex copyright
- ✅ Custom branding (no third-party logos)
- ✅ Per-user data isolation (clientId)

## Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- SQLite (included with EF Core)

## Build & Run

```bash
cd blazor
dotnet restore
dotnet ef database update    # Create/migrate SQLite database
dotnet run
```

The app starts on `http://localhost:5000` (or the port specified in `Properties/launchSettings.json`).

## Configuration

Edit `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=nuget-auditor.db"
  },
  "AI": {
    "Provider": "openai",           // "openai" or "gemini"
    "OpenAI": { "ApiKey": "sk-...", "Model": "gpt-4o-mini" },
    "Gemini": { "ApiKey": "...", "Model": "gemini-1.5-flash" },
    "ApiKey": "nuget-advise-secret-2025"
  },
  "Admin": { "Token": "nuget-admin-2025-secret" }
}
```

Or set environment variables:
- `AI__Provider=openai`
- `AI__OpenAI__ApiKey=sk-...`
- `Admin__Token=your-admin-token`

## Architecture

```
blazor/
├── Program.cs                    # App startup, DI, middleware
├── ApiEndpoints.cs               # REST API (mirrors Next.js /api/* routes)
├── NuGetAuditor.csproj           # Project file
├── appsettings.json              # Configuration
├── Models/
│   ├── ParsedCsproj.cs           # .csproj parse result + NuGet types
│   └── AuditResult.cs            # Audit result + Feedback + AuditRun
├── Data/
│   └── AppDbContext.cs            # EF Core DbContext (SQLite)
├── Services/
│   ├── CsprojParserService.cs     # MSBuild XML parser
│   ├── NuGetApiService.cs         # NuGet v3 API client
│   ├── AuditService.cs            # Audit orchestration
│   ├── AiAdvisorService.cs        # OpenAI/Gemini provider
│   ├── HistoryService.cs          # Audit history + diff
│   └── FeedbackService.cs         # Feedback + Share + Theme services
├── Pages/
│   ├── Index.razor                # Home page (audit + results)
│   ├── Feedback.razor             # /feedback page
│   ├── Admin.razor                # /admin page (protected)
│   ├── NotFound.razor             # 404 page
│   ├── _Host.cshtml               # Blazor Server host
│   └── _HostRoute.razor           # Fallback route
├── Components/
│   └── MainLayout.razor           # Root layout
├── wwwroot/
│   ├── css/app.css                # Styles (Tailwind-like utility classes)
│   ├── js/app.js                  # JS interop (clipboard, confetti, clientId)
│   ├── manifest.json              # PWA manifest
│   ├── sw.js                      # Service worker
│   └── icon.svg                   # Custom favicon
```

## API Endpoints (same as Next.js)

| Endpoint | Method | Description |
|---|---|---|
| `/api/health` | GET | Health check (for Azure) |
| `/api/audit` | POST | Run audit on csproj content |
| `/api/history` | GET/POST | List/save audits (client-scoped) |
| `/api/history/{id}` | GET/DELETE | Load/delete a saved audit |
| `/api/history/{id}/rename` | PATCH | Rename a saved audit |
| `/api/diff` | GET | Diff two saved audits |
| `/api/share` | GET/POST | Create/load shareable audit links |
| `/api/advise` | POST | AI remediation plan |
| `/api/feedback` | GET/POST | List/submit feedback |
| `/api/feedback/{id}` | PATCH/DELETE | Update/delete feedback |
| `/api/admin/auth` | POST | Admin token validation |
| `/api/changelog` | GET | Fetch package release notes |
| `/api/popularity` | GET | Fetch package download counts |

## Deploy to Azure

1. Deploy as Azure App Service (Linux, .NET 8):
   ```bash
   dotnet publish -c Release -o ./publish
   ```
2. Upload `./publish` to Azure App Service.
3. Configure app settings in Azure Portal:
   - `ConnectionStrings__DefaultConnection` = `Data Source=/home/data/nuget-auditor.db`
   - `AI__OpenAI__ApiKey` = your OpenAI key
   - `Admin__Token` = your admin token
4. Enable persistent storage (Azure Files mount at `/home/data`).

## Admin Access

Navigate to `/admin` and enter the admin token (`nuget-admin-2025-secret` by default).

## Developer

© 2025 NuGet Visualizer & Auditor. Developed by **0xz.0nfirex**. All rights reserved.
