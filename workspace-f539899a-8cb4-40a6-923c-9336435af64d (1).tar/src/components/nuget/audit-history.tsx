"use client";

import { useEffect, useState, useCallback } from "react";
import {
  History,
  Trash2,
  TrendingUp,
  TrendingDown,
  Minus,
  Loader2,
  Clock,
  ShieldAlert,
  X,
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { AuditResult } from "@/lib/audit";

interface HistoryRun {
  id: string;
  projectName: string;
  sdk: string | null;
  targetFramework: string | null;
  totalPackages: number;
  outdatedCount: number;
  vulnerableCount: number;
  deprecatedCount: number;
  maxSeverity: string | null;
  healthScore: number;
  createdAt: string;
}

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  currentResult: AuditResult | null;
  onLoadRun: (result: AuditResult) => void;
  refreshKey?: number;
}

const sevColor: Record<string, string> = {
  low: "text-yellow-600 dark:text-yellow-400",
  moderate: "text-orange-600 dark:text-orange-400",
  high: "text-red-600 dark:text-red-400",
  critical: "text-red-700 dark:text-red-500",
};

function grade(score: number) {
  if (score >= 90) return { letter: "A", color: "text-emerald-500" };
  if (score >= 75) return { letter: "B", color: "text-lime-500" };
  if (score >= 60) return { letter: "C", color: "text-yellow-500" };
  if (score >= 40) return { letter: "D", color: "text-orange-500" };
  return { letter: "F", color: "text-red-500" };
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(iso).toLocaleDateString();
}

export function AuditHistory({ open, onOpenChange, currentResult, onLoadRun, refreshKey }: Props) {
  const [runs, setRuns] = useState<HistoryRun[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const loadHistory = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/history");
      const data = await res.json();
      if (data.ok) setRuns(data.runs);
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (open) loadHistory();
  }, [open, loadHistory, refreshKey]);

  const loadRun = async (id: string) => {
    setLoadingId(id);
    try {
      const res = await fetch(`/api/history/${id}`);
      const data = await res.json();
      if (data.ok && data.result) {
        onLoadRun(data.result as AuditResult);
        onOpenChange(false);
        toast.success("Loaded saved audit");
      } else {
        toast.error("Failed to load audit");
      }
    } catch {
      toast.error("Failed to load audit");
    } finally {
      setLoadingId(null);
    }
  };

  const deleteRun = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/history/${id}`, { method: "DELETE" });
      if (res.ok) {
        setRuns((r) => r.filter((x) => x.id !== id));
        toast.success("Audit deleted");
      }
    } catch {
      toast.error("Delete failed");
    }
  };

  // Compute trend vs the most recent previous run of the same project
  const trend = (() => {
    if (!currentResult || runs.length === 0) return null;
    const currentName = currentResult.parsed.projectName ?? "unnamed";
    const prev = runs.find((r) => r.projectName === currentName);
    if (!prev) return null;
    return {
      scoreDiff: 0, // current score computed at save time; can't compare live easily
      outdatedDiff: currentResult.stats.outdatedCount - prev.outdatedCount,
      vulnerableDiff: currentResult.stats.vulnerableCount - prev.vulnerableCount,
      prev,
    };
  })();

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-md overflow-y-auto custom-scroll">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <History className="h-4 w-4" />
            Audit history
          </SheetTitle>
          <SheetDescription className="text-xs">
            Saved audits are stored locally in SQLite. Click any run to reload it. Compare trends over time.
          </SheetDescription>
        </SheetHeader>

        {trend && (
          <div className="mt-4 rounded-lg border bg-muted/30 p-3 space-y-2">
            <p className="text-xs font-semibold flex items-center gap-1.5">
              <TrendingUp className="h-3.5 w-3.5" />
              Trend vs last save
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <TrendItem
                label="Outdated"
                diff={-trend.outdatedDiff}
                goodWhenNegative
              />
              <TrendItem
                label="Vulnerable"
                diff={-trend.vulnerableDiff}
                goodWhenNegative
              />
            </div>
          </div>
        )}

        <Separator className="my-4" />

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : runs.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center gap-2">
            <div className="rounded-full bg-muted p-3">
              <History className="h-5 w-5 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium">No saved audits yet</p>
            <p className="text-xs text-muted-foreground max-w-[260px]">
              Run an audit and click &ldquo;Save audit&rdquo; to start building your history. Track how your dependency health evolves over time.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {runs.map((run) => {
              const g = grade(run.healthScore);
              const isCurrent = currentResult?.parsed.projectName === run.projectName;
              return (
                <button
                  key={run.id}
                  onClick={() => loadRun(run.id)}
                  disabled={loadingId === run.id}
                  className={cn(
                    "w-full text-left rounded-lg border p-3 hover:bg-muted/50 transition-colors group relative",
                    isCurrent && "border-primary/40 bg-primary/5",
                  )}
                >
                  {loadingId === run.id && (
                    <Loader2 className="absolute top-3 right-3 h-3.5 w-3.5 animate-spin text-primary" />
                  )}
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold truncate font-mono">{run.projectName}</p>
                      <p className="text-[10px] text-muted-foreground flex items-center gap-1 mt-0.5">
                        <Clock className="h-2.5 w-2.5" />
                        {timeAgo(run.createdAt)}
                        {run.targetFramework && <span>· {run.targetFramework}</span>}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className={cn("text-lg font-bold leading-none", g.color)}>{g.letter}</span>
                      <p className="text-[9px] text-muted-foreground">{run.healthScore}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    <Badge variant="outline" className="text-[10px]">{run.totalPackages} pkgs</Badge>
                    {run.outdatedCount > 0 && (
                      <Badge variant="outline" className="text-[10px] border-blue-500/40 text-blue-600 dark:text-blue-400">
                        {run.outdatedCount} old
                      </Badge>
                    )}
                    {run.vulnerableCount > 0 && (
                      <Badge variant="outline" className={cn("text-[10px] gap-1", run.maxSeverity && sevColor[run.maxSeverity])}>
                        <ShieldAlert className="h-2.5 w-2.5" />
                        {run.vulnerableCount} vuln
                      </Badge>
                    )}
                    {run.vulnerableCount === 0 && run.outdatedCount === 0 && (
                      <Badge variant="outline" className="text-[10px] border-emerald-500/40 text-emerald-600 dark:text-emerald-400">
                        clean
                      </Badge>
                    )}
                  </div>
                  <button
                    onClick={(e) => deleteRun(run.id, e)}
                    className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-opacity"
                    aria-label="Delete audit"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </button>
              );
            })}
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

function TrendItem({
  label,
  diff,
  goodWhenNegative,
}: {
  label: string;
  diff: number;
  goodWhenNegative?: boolean;
}) {
  const isGood = goodWhenNegative ? diff > 0 : diff > 0;
  const isNeutral = diff === 0;
  const Icon = isNeutral ? Minus : isGood ? TrendingUp : TrendingDown;
  const color = isNeutral
    ? "text-muted-foreground"
    : isGood
      ? "text-emerald-600 dark:text-emerald-400"
      : "text-red-600 dark:text-red-400";
  return (
    <div className="flex items-center justify-between rounded-md bg-background/50 px-2 py-1.5">
      <span className="text-muted-foreground">{label}</span>
      <span className={cn("font-mono font-semibold flex items-center gap-1", color)}>
        <Icon className="h-3 w-3" />
        {diff > 0 ? `+${diff}` : diff}
      </span>
    </div>
  );
}
