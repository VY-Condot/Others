"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Wand2, ArrowRight, TrendingUp, RotateCcw, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

const sevPenalty: Record<string, number> = { low: 8, moderate: 18, high: 35, critical: 60 };

function computeScore(stats: {
  totalPackages: number;
  outdatedCount: number;
  vulnerableCount: number;
  deprecatedCount: number;
  maxSeverity: string | null;
}): number {
  let s = 100;
  if (stats.maxSeverity) s -= sevPenalty[stats.maxSeverity] ?? 0;
  s -= Math.max(0, stats.vulnerableCount - 1) * 6;
  if (stats.totalPackages > 0) {
    s -= Math.round((stats.outdatedCount / stats.totalPackages) * 25);
  }
  s -= stats.deprecatedCount * 4;
  return Math.max(0, Math.min(100, s));
}

function grade(score: number) {
  if (score >= 90) return { letter: "A", color: "text-emerald-500" };
  if (score >= 75) return { letter: "B", color: "text-lime-500" };
  if (score >= 60) return { letter: "C", color: "text-yellow-500" };
  if (score >= 40) return { letter: "D", color: "text-orange-500" };
  return { letter: "F", color: "text-red-500" };
}

export function UpgradeSimulator({ result }: Props) {
  const [simulated, setSimulated] = useState(false);

  const currentScore = computeScore(result.stats);

  // Simulated stats: upgrade all outdated to latest stable (vulnerabilities fixed too)
  const simulatedStats = useMemo(() => {
    return {
      totalPackages: result.stats.totalPackages,
      outdatedCount: 0,
      vulnerableCount: 0,
      deprecatedCount: result.stats.deprecatedCount,
      maxSeverity: null as string | null,
    };
  }, [result]);

  const simulatedScore = computeScore(simulatedStats);
  const scoreDelta = simulatedScore - currentScore;
  const currentGrade = grade(currentScore);
  const simulatedGrade = grade(simulatedScore);

  const affectedPackages = result.packages.filter((p) => p.isOutdated || p.isVulnerable);

  return (
    <Card className={cn(
      "relative overflow-hidden transition-all",
      simulated && "border-emerald-500/30 bg-gradient-to-br from-emerald-500/5 via-transparent to-transparent",
    )}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Wand2 className="h-4 w-4" />
              Upgrade simulator
            </CardTitle>
            <CardDescription className="text-xs mt-1">
              Preview your health score if all {affectedPackages.length} flagged packages were upgraded to latest stable.
            </CardDescription>
          </div>
          <Button
            variant={simulated ? "outline" : "default"}
            size="sm"
            onClick={() => setSimulated((s) => !s)}
          >
            {simulated ? (
              <><RotateCcw className="h-3.5 w-3.5" /> Reset</>
            ) : (
              <><Wand2 className="h-3.5 w-3.5" /> Simulate</>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center gap-6 py-2">
          {/* Current */}
          <div className="text-center">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Current</p>
            <p className={cn("text-4xl font-bold", currentGrade.color)}>{currentGrade.letter}</p>
            <p className="text-xs font-mono text-muted-foreground mt-1">{currentScore}/100</p>
          </div>

          {/* Arrow + delta */}
          <div className="flex flex-col items-center gap-1">
            <ArrowRight className={cn("h-6 w-6 transition-colors", simulated ? "text-emerald-500" : "text-muted-foreground")} />
            {simulated && scoreDelta !== 0 && (
              <Badge className="text-[10px] gap-1 bg-emerald-500 text-white border-0">
                <TrendingUp className="h-2.5 w-2.5" />
                +{scoreDelta}
              </Badge>
            )}
          </div>

          {/* Simulated */}
          <div className={cn("text-center transition-all", !simulated && "opacity-40")}>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">After upgrade</p>
            <p className={cn("text-4xl font-bold transition-all", simulatedGrade.color)}>
              {simulated ? simulatedGrade.letter : "—"}
            </p>
            <p className="text-xs font-mono text-muted-foreground mt-1">
              {simulated ? `${simulatedScore}/100` : "—"}
            </p>
          </div>
        </div>

        {/* Progress bars */}
        <div className="space-y-2 mt-4">
          <ScoreBar label="Current" score={currentScore} color="bg-primary" />
          {simulated && (
            <ScoreBar label="Simulated" score={simulatedScore} color="bg-emerald-500" animated />
          )}
        </div>

        {/* What changes */}
        {simulated && (
          <div className="mt-4 space-y-2 animate-fade-up">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">What changes</p>
            <div className="grid grid-cols-3 gap-2 text-center">
              <Stat label="Outdated" from={result.stats.outdatedCount} to={0} good={result.stats.outdatedCount > 0} />
              <Stat label="Vulnerable" from={result.stats.vulnerableCount} to={0} good={result.stats.vulnerableCount > 0} />
              <Stat label="Grade" from={currentGrade.letter} to={simulatedGrade.letter} good={scoreDelta > 0} isString />
            </div>
            {affectedPackages.length > 0 && (
              <div className="rounded-md border bg-muted/30 p-2.5 mt-2">
                <p className="text-[10px] text-muted-foreground mb-1.5">
                  {affectedPackages.length} packages would be upgraded:
                </p>
                <div className="flex flex-wrap gap-1">
                  {affectedPackages.slice(0, 10).map((p) => (
                    <span key={p.id} className="inline-flex items-center gap-1 rounded bg-background px-1.5 py-0.5 text-[10px] font-mono">
                      {p.id}
                      <ArrowRight className="h-2 w-2 opacity-50" />
                      <span className="text-emerald-600 dark:text-emerald-400">{p.latestStableVersion ?? "?"}</span>
                    </span>
                  ))}
                  {affectedPackages.length > 10 && (
                    <span className="text-[10px] text-muted-foreground self-center">
                      +{affectedPackages.length - 10} more
                    </span>
                  )}
                </div>
              </div>
            )}
            {scoreDelta === 0 && (
              <div className="flex items-center gap-2 rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2.5 text-xs">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>Your project is already at its best possible score — no upgrades would improve it.</span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ScoreBar({ label, score, color, animated }: { label: string; score: number; color: string; animated?: boolean }) {
  return (
    <div>
      <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
        <span>{label}</span>
        <span className="font-mono">{score}/100</span>
      </div>
      <Progress value={score} className={cn("h-2", animated && "transition-all duration-700")} />
    </div>
  );
}

function Stat({ label, from, to, good, isString }: { label: string; from: number | string; to: number | string; good: boolean; isString?: boolean }) {
  return (
    <div className="rounded-md border bg-card p-2">
      <p className="text-[9px] text-muted-foreground uppercase">{label}</p>
      <p className="text-xs font-mono mt-0.5">
        <span className="text-muted-foreground">{from}</span>
        <ArrowRight className="inline h-2.5 w-2.5 mx-0.5 opacity-50" />
        <span className={cn("font-semibold", isString && good ? "text-emerald-600 dark:text-emerald-400" : !isString && good ? "text-emerald-600 dark:text-emerald-400" : "text-foreground")}>{to}</span>
      </p>
    </div>
  );
}
