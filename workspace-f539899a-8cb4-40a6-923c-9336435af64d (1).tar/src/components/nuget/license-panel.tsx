"use client";

import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollText, ShieldCheck, AlertTriangle, Scale, FileQuestion } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AuditResult, LicenseCategory } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

const CATEGORY_META: Record<LicenseCategory, { label: string; color: string; bg: string; icon: React.ComponentType<{ className?: string }>; desc: string }> = {
  permissive: {
    label: "Permissive",
    color: "text-emerald-600 dark:text-emerald-400",
    bg: "bg-emerald-500/10 border-emerald-500/30",
    icon: ShieldCheck,
    desc: "MIT, Apache, BSD — safe for commercial use with attribution",
  },
  copyleft: {
    label: "Weak copyleft",
    color: "text-yellow-600 dark:text-yellow-400",
    bg: "bg-yellow-500/10 border-yellow-500/30",
    icon: Scale,
    desc: "LGPL, MPL — modifications to the library must be shared, but your app is unaffected",
  },
  "copyleft-strong": {
    label: "Strong copyleft",
    color: "text-orange-600 dark:text-orange-400",
    bg: "bg-orange-500/10 border-orange-500/30",
    icon: AlertTriangle,
    desc: "GPL, AGPL — derivative works must be open-sourced under the same license",
  },
  restrictive: {
    label: "Restrictive",
    color: "text-red-600 dark:text-red-400",
    bg: "bg-red-500/10 border-red-500/30",
    icon: AlertTriangle,
    desc: "Proprietary or commercial — may require a paid license or restrict redistribution",
  },
  unknown: {
    label: "Unknown",
    color: "text-muted-foreground",
    bg: "bg-muted/30 border-border",
    icon: FileQuestion,
    desc: "License could not be automatically classified — review manually",
  },
  none: {
    label: "No license",
    color: "text-red-600 dark:text-red-400",
    bg: "bg-red-500/10 border-red-500/30",
    icon: AlertTriangle,
    desc: "No license declared — default copyright applies (all rights reserved)",
  },
};

export function LicensePanel({ result }: Props) {
  const { byCategory, packagesByCategory, total } = useMemo(() => {
    const byCategory = new Map<LicenseCategory, number>();
    const packagesByCategory = new Map<LicenseCategory, typeof result.packages>();

    for (const cat of Object.keys(CATEGORY_META) as LicenseCategory[]) {
      byCategory.set(cat, 0);
      packagesByCategory.set(cat, []);
    }

    for (const p of result.packages) {
      const cat = p.licenseCategory ?? "unknown";
      byCategory.set(cat, (byCategory.get(cat) ?? 0) + 1);
      packagesByCategory.get(cat)?.push(p);
    }

    return { byCategory, packagesByCategory, total: result.packages.length };
  }, [result]);

  const riskyCount = (["copyleft-strong", "restrictive", "none"] as LicenseCategory[])
    .reduce((acc, cat) => acc + (byCategory.get(cat) ?? 0), 0);

  const sortedCategories = (Object.keys(CATEGORY_META) as LicenseCategory[])
    .filter((cat) => (byCategory.get(cat) ?? 0) > 0)
    .sort((a, b) => {
      // Sort by risk: none > restrictive > copyleft-strong > copyleft > unknown > permissive
      const order: Record<LicenseCategory, number> = {
        none: 0,
        restrictive: 1,
        "copyleft-strong": 2,
        copyleft: 3,
        unknown: 4,
        permissive: 5,
      };
      return order[a] - order[b];
    });

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <ScrollText className="h-4 w-4" />
              License compliance
            </CardTitle>
            <CardDescription className="text-xs mt-1">
              {total} packages classified by license type · {riskyCount} require review
            </CardDescription>
          </div>
          {riskyCount > 0 ? (
            <Badge variant="outline" className="text-[10px] gap-1 border-red-500/40 text-red-600 dark:text-red-400 bg-red-500/10">
              <AlertTriangle className="h-3 w-3" />
              {riskyCount} risky
            </Badge>
          ) : (
            <Badge variant="outline" className="text-[10px] gap-1 border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10">
              <ShieldCheck className="h-3 w-3" />
              All clear
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Category breakdown bar */}
        <div className="flex h-3 w-full rounded-full overflow-hidden border">
          {sortedCategories.map((cat) => {
            const count = byCategory.get(cat) ?? 0;
            const pct = (count / total) * 100;
            if (count === 0) return null;
            const colors: Record<LicenseCategory, string> = {
              permissive: "bg-emerald-500",
              copyleft: "bg-yellow-500",
              "copyleft-strong": "bg-orange-500",
              restrictive: "bg-red-500",
              unknown: "bg-muted-foreground/30",
              none: "bg-red-600",
            };
            return (
              <div
                key={cat}
                className={cn("h-full transition-all", colors[cat])}
                style={{ width: `${pct}%` }}
                title={`${CATEGORY_META[cat].label}: ${count} (${pct.toFixed(0)}%)`}
              />
            );
          })}
        </div>

        {/* Category list */}
        <div className="space-y-2">
          {sortedCategories.map((cat) => {
            const meta = CATEGORY_META[cat];
            const count = byCategory.get(cat) ?? 0;
            const pkgs = packagesByCategory.get(cat) ?? [];
            const Icon = meta.icon;
            return (
              <div key={cat} className={cn("rounded-lg border p-3", meta.bg)}>
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <Icon className={cn("h-4 w-4 shrink-0", meta.color)} />
                    <div className="min-w-0">
                      <p className={cn("text-sm font-semibold", meta.color)}>
                        {meta.label}{" "}
                        <span className="font-mono text-xs opacity-70">({count})</span>
                      </p>
                      <p className="text-[10px] text-muted-foreground truncate">{meta.desc}</p>
                    </div>
                  </div>
                  <span className={cn("text-lg font-bold tabular-nums shrink-0", meta.color)}>
                    {Math.round((count / total) * 100)}%
                  </span>
                </div>
                {pkgs.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {pkgs.slice(0, 8).map((p) => (
                      <span
                        key={p.id}
                        className="inline-flex items-center gap-1 rounded-md bg-background/60 px-1.5 py-0.5 text-[10px] font-mono"
                        title={p.licenseExpression || p.licenseUrl || "No license"}
                      >
                        {p.id}
                        {p.licenseExpression && (
                          <span className="text-muted-foreground">· {p.licenseExpression}</span>
                        )}
                      </span>
                    ))}
                    {pkgs.length > 8 && (
                      <span className="text-[10px] text-muted-foreground self-center">
                        +{pkgs.length - 8} more
                      </span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <p className="text-[10px] text-muted-foreground pt-1">
          Classification is heuristic — always verify the actual license text before commercial use.
        </p>
      </CardContent>
    </Card>
  );
}
