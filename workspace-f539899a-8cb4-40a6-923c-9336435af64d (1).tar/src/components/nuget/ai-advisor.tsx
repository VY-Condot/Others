"use client";

import { useState, useCallback, useRef } from "react";
import { Sparkles, Loader2, Bot, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

export function AiAdvisor({ result }: Props) {
  const [advice, setAdvice] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const fetchAdvice = useCallback(async () => {
    setLoading(true);
    setError(null);
    setAdvice("");
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    try {
      const payload = {
        projectName: result.parsed.projectName,
        targetFrameworks: result.parsed.targetFrameworks,
        sdk: result.parsed.sdk,
        packages: result.packages.map((p) => ({
          id: p.id,
          declaredVersion: p.declaredVersion,
          latestStableVersion: p.latestStableVersion,
          isOutdated: p.isOutdated,
          isVulnerable: p.isVulnerable,
          isDeprecated: p.isDeprecated,
          maxSeverity: p.maxSeverity,
          vulnerabilities: p.vulnerabilities.map((v) => ({
            severity: v.severity,
            advisoryTitle: v.advisoryTitle,
            range: v.range,
          })),
        })),
      };

      const res = await fetch("/api/advise", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: ctrl.signal,
      });

      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || `HTTP ${res.status}`);
      }

      const reader = res.body?.getReader();
      if (!reader) throw new Error("No response stream");
      const decoder = new TextDecoder();
      let acc = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += decoder.decode(value, { stream: true });
        setAdvice(acc);
      }
      toast.success("AI remediation plan ready");
    } catch (err) {
      if ((err as Error).name === "AbortError") return;
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
      toast.error("AI advisor failed", { description: msg });
    } finally {
      setLoading(false);
    }
  }, [result]);

  const interestingCount =
    result.stats.vulnerableCount + result.stats.outdatedCount + result.stats.deprecatedCount;

  return (
    <Card className="relative overflow-hidden border-purple-500/20 bg-gradient-to-br from-purple-500/5 via-transparent to-pink-500/5">
      {/* animated gradient accent line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-500/40 to-transparent" />
      <CardHeader className="pb-3">
        <div className="flex items-start gap-4">
          {/* Pulsing icon */}
          <div className="relative shrink-0 hidden sm:block">
            <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 blur-md opacity-50 animate-pulse" />
            <div className="relative rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 p-3">
              <Bot className="h-6 w-6 text-white" />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <CardTitle className="text-base flex items-center gap-2 flex-wrap">
              <div className="rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 p-1.5 sm:hidden">
                <Bot className="h-4 w-4 text-white" />
              </div>
              AI Remediation Advisor
              <Badge variant="outline" className="text-[10px] gap-1 border-purple-500/30 text-purple-600 dark:text-purple-400 bg-purple-500/5">
                <span className="h-1.5 w-1.5 rounded-full bg-purple-500 animate-pulse" />
                powered by GLM
              </Badge>
            </CardTitle>
            <CardDescription className="text-xs mt-1.5">
              A senior .NET security advisor reviews your audit and writes a prioritized upgrade plan with copy-ready{" "}
              <code className="font-mono">dotnet add package</code> commands and breaking-change callouts.
            </CardDescription>
          </div>
          <Button
            onClick={fetchAdvice}
            disabled={loading}
            className="shrink-0 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white border-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            {loading ? "Thinking…" : advice ? "Regenerate" : "Get AI plan"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {!advice && !loading && !error && (
          <div className="flex flex-col items-center justify-center py-10 text-center gap-3">
            <div className="rounded-full bg-gradient-to-br from-purple-500/15 to-pink-500/15 p-4">
              <Bot className="h-8 w-8 text-purple-500" />
            </div>
            <div>
              <p className="text-sm font-medium">Get a human-readable remediation plan</p>
              <p className="text-xs text-muted-foreground mt-1 max-w-md">
                The advisor will analyze your{" "}
                <Badge variant="secondary" className="text-[10px]">{result.stats.totalPackages} packages</Badge>{" "}
                {interestingCount > 0 ? (
                  <>
                    — including{" "}
                    {result.stats.vulnerableCount > 0 && (
                      <Badge variant="outline" className="text-[10px] border-red-500/40 text-red-600 dark:text-red-400">
                                        {result.stats.vulnerableCount} vulnerable
                      </Badge>
                    )}{" "}
                    {result.stats.outdatedCount > 0 && (
                      <Badge variant="outline" className="text-[10px] border-blue-500/40 text-blue-600 dark:text-blue-400">
                        {result.stats.outdatedCount} outdated
                      </Badge>
                    )}{" "}
                    — and tell you exactly what to upgrade first.
                  </>
                ) : (
                  <span>— everything looks healthy, but ask the advisor to confirm.</span>
                )}
              </p>
            </div>
          </div>
        )}

        {loading && !advice && (
          <div className="flex flex-col items-center justify-center py-10 gap-3">
            <div className="relative">
              <div className="rounded-full bg-gradient-to-br from-purple-500 to-pink-500 p-3">
                <Bot className="h-6 w-6 text-white animate-pulse" />
              </div>
              <Loader2 className="absolute -bottom-1 -right-1 h-5 w-5 animate-spin text-foreground" />
            </div>
            <p className="text-xs text-muted-foreground">Analyzing {result.stats.totalPackages} packages for upgrade risks…</p>
          </div>
        )}

        {error && (
          <div className="rounded-md border border-red-500/40 bg-red-500/10 p-3 flex items-start gap-2 text-xs">
            <AlertCircle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-red-700 dark:text-red-300">Advisor error</p>
              <p className="text-muted-foreground font-mono mt-0.5 break-all">{error}</p>
            </div>
          </div>
        )}

        {advice && (
          <div className="rounded-md border bg-muted/30 p-4 custom-scroll max-h-[520px] overflow-y-auto">
            <article className="prose prose-sm dark:prose-invert max-w-none text-sm leading-relaxed [&_code]:text-xs [&_code]:font-mono [&_code]:bg-muted [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded [&_pre]:bg-muted [&_pre]:p-3 [&_pre]:rounded-md [&_pre]:overflow-x-auto [&_h1]:text-base [&_h1]:font-semibold [&_h1]:mt-4 [&_h1]:mb-2 [&_h2]:text-sm [&_h2]:font-semibold [&_h2]:mt-3 [&_h2]:mb-1.5 [&_h3]:text-sm [&_h3]:font-semibold [&_ul]:list-disc [&_ul]:pl-5 [&_ul]:my-2 [&_li]:my-0.5 [&_a]:text-primary [&_a]:underline [&_strong]:font-semibold">
              <ReactMarkdown>{advice}</ReactMarkdown>
            </article>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
