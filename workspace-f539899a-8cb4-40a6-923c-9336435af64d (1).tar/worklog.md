# NuGet Visualizer & Auditor — Worklog

## Project Status (as of 2025-07-23, Phase 7)

**Status: ✅ Stable & feature-rich (Phase 1-7 done)**

A lightweight web app that parses a user's `.csproj` file, maps out the dependency tree visually, and highlights outdated or insecure NuGet packages. Built on Next.js 16 + TypeScript.

---

## Current goals / completed modifications

### Phase 1-6 (DONE — see previous worklog entries)
Core auditor, standout features (force graph, AI advisor, health score, upgrade toolkit), analytics dashboard, version compare, audit history persistence, keyboard shortcuts, audit diff view, changelog viewer, license compliance panel, popularity metrics.

### Phase 7 — Landing page, bug fix, new visualizations (DONE this round)

**BUG FIX: "View details" button in force graph did nothing**
- **Root cause**: The `onTreeNodeSelect` handler in `page.tsx` only opened the detail dialog if it found a matching audited package by ID. For transitive dependencies (whose IDs aren't in `result.packages`), `match` was `undefined` and the handler silently did nothing.
- **Fix**: When no match is found, construct a minimal `AuditedPackage` from the node info and open the dialog anyway, with an error note explaining it's a transitive dependency with limited metadata.
- Also added `e.stopPropagation()` to the "View details" button in `force-graph.tsx` to prevent the click from re-selecting the node.
- **Verified**: Clicking a force-graph node then "View details" now opens the package detail dialog (tested with Microsoft.Extensions.Configuration).

**NEW: Eye-catching landing page (`landing-page.tsx`)**
- Full-screen hero with animated gradient headline ("See your dependencies, catch the vulnerable ones"), hand-drawn SVG underline accent, floating decorative orbs (slow-spin + float animations), live status badge with ping animation.
- Two CTA buttons: "Start auditing" (scrolls to upload section) and "Try with sample" (loads sample csproj + scrolls).
- Stats bar (nuget.org v3 API, 0 data stored, 7 audit views, 100% client-parsed).
- Features grid: 6 feature cards with gradient icons, hover lift + scale, badge labels.
- "How it works" 3-step section with numbered cards and connector lines.
- CTA section with gradient background card + floating orbs.
- Footer with links.
- Staggered fade-up entrance animations throughout.
- VLM rated **9/10** — "production-quality design comparable to Vercel, Linear, or Stripe".

**NEW: Upgrade Simulator (`upgrade-simulator.tsx`)**
- "What if I upgrade all flagged packages?" — preview the resulting health score.
- Before/after grade comparison (B → A) with arrow and +delta badge.
- Animated progress bars for current vs simulated scores.
- "What changes" section: 3 stat cards (Outdated, Vulnerable, Grade) with from→to values, plus a list of packages that would be upgraded with their target versions.
- "No improvement possible" message when score is already maxed.
- VLM rated **9/10**.

**NEW: Dependency Sunburst Chart (`sunburst-chart.tsx`)**
- Dual-ring pie chart: outer ring = packages grouped by namespace prefix, inner ring = overall status mix (ok/outdated/vulnerable/deprecated).
- Rich tooltip showing namespace name, package count, and individual package list with status dots.
- Legend with namespace colors + status mix.
- 12-color palette for namespace slices.

**STYLING: Animated health score**
- Health score now counts up from 0 to the final score using `useCountUp` hook (1000ms ease-out cubic).
- Both the gauge center text and the breakdown table final score use the animated value.

### Verification results (agent-browser end-to-end, this round)
- Landing page: HTTP 200, hero with gradient headline + animated orbs, "Start auditing" + "Try with sample" buttons work, features grid (6 cards), how-it-works (3 steps), CTA section all render. VLM 9/10.
- "Try with sample" button: loads sample csproj (2,477 chars) into textarea + scrolls to uploader. Verified.
- "Start auditing" button: scrolls to upload section. Verified.
- "View details" button fix: clicked force-graph node (Microsoft.Extensions.Configuration) → "View details" → dialog opened with Declared/Latest stable/Authors/License fields. Verified fixed.
- Upgrade Simulator: "Simulate" button shows B→A grade, +11 delta, progress bars (89→100), "8 packages would be upgraded" list. VLM 9/10.
- Sunburst Chart: renders in Analytics tab with dual-ring pie + legend.
- Lint: `bun run lint` passes clean (0 errors, 0 warnings).
- Dev server: running on port 3000, no runtime errors.

## Unresolved issues / risks
- Force graph physics takes 1-2s to settle (acceptable).
- NuGet API depends on outbound network; bundled fallback covers ~18 common packages.
- License classification is heuristic — may misclassify unusual licenses.
- Popularity API makes individual search requests per package (no batch endpoint) — capped at 30 with concurrency 6.
- The "N" badge in screenshots is Next.js Dev Tools (not our app).

## Priority recommendations for next phase
1. **Multi-csproj support**: upload a `.sln` or multiple `.csproj` files, show cross-project dependency overlap.
2. **Historical vulnerability timeline**: chart when CVEs were disclosed vs when the declared version was released.
3. **Watch mode**: re-audit on file change with a WebSocket mini-service.
4. **Export to PDF**: one-click PDF report generation for compliance sharing.
5. **Graph node keyboard navigation**: arrow-key navigation between force-graph nodes for accessibility.
6. **Audit scheduling**: schedule recurring audits via cron, email/notify on new vulnerabilities.
7. **Package dependency graph minimap**: zoomed-out overview for large dependency webs.
8. **Dark/light graph theme tuning**: make force-graph node colors fully theme-aware.
