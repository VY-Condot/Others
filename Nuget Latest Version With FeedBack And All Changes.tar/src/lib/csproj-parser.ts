/**
 * Lightweight .csproj / MSBuild XML parser.
 *
 * Extracts:
 *  - SDK attribute (project style)
 *  - TargetFramework(s)
 *  - PackageReference items (id + version + optional private assets)
 *  - ProjectReference items (relative paths)
 *  - DirectoryReference / FrameworkReference (best-effort)
 *
 * The parser is deliberately tolerant: it never throws on malformed input,
 * instead returning a partial result with a list of parse warnings.
 */

export interface PackageReference {
  id: string;
  version: string;
  privateAssets?: string;
  includeAssets?: string;
  excludeAssets?: string;
  condition?: string;
  isDevelopmentDependency?: boolean;
  line?: number;
}

export interface ProjectReference {
  path: string;
  condition?: string;
}

export interface FrameworkReference {
  name: string;
}

export interface ParsedCsproj {
  sdk: string | null;
  projectName: string | null;
  targetFrameworks: string[];
  packageReferences: PackageReference[];
  projectReferences: ProjectReference[];
  frameworkReferences: FrameworkReference[];
  propertyBag: Record<string, string>;
  warnings: string[];
  rawSizeBytes: number;
}

/**
 * Parse a single <PackageReference> element from MSBuild XML.
 * Handles both attribute form (<PackageReference Include="X" Version="Y" />)
 * and child-element form (<PackageReference Include="X"><Version>Y</Version></PackageReference>).
 */
function parsePackageReference(node: Element, fallbackLine?: number): PackageReference | null {
  const getAttr = (name: string) => node.getAttribute(name) ?? undefined;
  const id = (getAttr("Include") || getAttr("Update") || getAttr("Remove") || "").trim();
  if (!id) return null;

  let version = getAttr("Version") ?? "";
  const privateAssets = getAttr("PrivateAssets");
  const includeAssets = getAttr("IncludeAssets");
  const excludeAssets = getAttr("ExcludeAssets");
  const condition = getAttr("Condition");
  const isDevelopmentDependency = getAttr("DevelopmentDependency") === "true" || undefined;

  // Child element form: <PackageReference Include="X"><Version>1.2.3</Version></PackageReference>
  if (!version) {
    const child = Array.from(node.children).find((c) => c.tagName.toLowerCase() === "version");
    if (child && child.textContent) version = child.textContent.trim();
  }

  return {
    id,
    version: (version || "").trim(),
    privateAssets,
    includeAssets,
    excludeAssets,
    condition,
    isDevelopmentDependency,
    line: fallbackLine,
  };
}

/**
 * Parse raw MSBuild XML text into a structured ParsedCsproj.
 *
 * Uses the browser/DOM-less Node XML parser via a tiny hand-rolled SAX-free
 * approach: we rely on Node's built-in DOM by using `linkedom`? No — to avoid
 * extra deps we use a minimal regex-aware tokenizer that is good enough for the
 * well-formed XML produced by `dotnet new`. It is NOT a general XML parser.
 */
export function parseCsproj(raw: string): ParsedCsproj {
  const result: ParsedCsproj = {
    sdk: null,
    projectName: null,
    targetFrameworks: [],
    packageReferences: [],
    projectReferences: [],
    frameworkReferences: [],
    propertyBag: {},
    warnings: [],
    rawSizeBytes: raw.length,
  };

  const trimmed = raw.trim();
  if (!trimmed) {
    result.warnings.push("Empty csproj content.");
    return result;
  }

  // Use Node's built-in DOM via a defensive try. If it fails, fall back to regex.
  let doc: Document | null = null;
  try {
    if (typeof DOMParser !== "undefined") {
      doc = new DOMParser().parseFromString(trimmed, "application/xml");
      const parseError = doc.getElementsByTagName("parsererror")[0];
      if (parseError) {
        result.warnings.push("XML parse error detected, falling back to tolerant mode.");
        doc = null;
      }
    }
  } catch {
    doc = null;
  }

  if (doc) {
    const projectEl = doc.getElementsByTagName("Project")[0];
    if (projectEl) {
      result.sdk = projectEl.getAttribute("Sdk");
    }

    // PropertyGroup -> TargetFramework(s), AssemblyName, etc.
    const propertyGroups = doc.getElementsByTagName("PropertyGroup");
    for (let i = 0; i < propertyGroups.length; i++) {
      const pg = propertyGroups[i];
      for (let j = 0; j < pg.children.length; j++) {
        const child = pg.children[j];
        const tag = child.tagName;
        const value = (child.textContent ?? "").trim();
        if (!value) continue;
        result.propertyBag[tag] = value;
        if (tag === "TargetFramework") {
          if (!result.targetFrameworks.includes(value)) result.targetFrameworks.push(value);
        } else if (tag === "TargetFrameworks") {
          for (const tf of value.split(";").map((s) => s.trim()).filter(Boolean)) {
            if (!result.targetFrameworks.includes(tf)) result.targetFrameworks.push(tf);
          }
        } else if (tag === "AssemblyName" && !result.projectName) {
          result.projectName = value;
        }
      }
    }

    // ItemGroup -> PackageReference / ProjectReference / FrameworkReference
    const itemGroups = doc.getElementsByTagName("ItemGroup");
    for (let i = 0; i < itemGroups.length; i++) {
      const ig = itemGroups[i];
      for (let j = 0; j < ig.children.length; j++) {
        const child = ig.children[j];
        const tag = child.tagName.toLowerCase();
        if (tag === "packagereference") {
          const pr = parsePackageReference(child);
          if (pr) result.packageReferences.push(pr);
        } else if (tag === "projectreference") {
          const include = child.getAttribute("Include") ?? child.getAttribute("Update") ?? "";
          if (include) {
            result.projectReferences.push({ path: include.trim(), condition: child.getAttribute("Condition") ?? undefined });
          }
        } else if (tag === "frameworkreference") {
          const include = child.getAttribute("Include") ?? "";
          if (include) result.frameworkReferences.push({ name: include.trim() });
        }
      }
    }
  } else {
    // ---- Tolerant regex fallback ----
    const projectMatch = raw.match(/<Project\b([^>]*)>/i);
    if (projectMatch) {
      const sdkAttr = projectMatch[1].match(/\bSdk\s*=\s*"([^"]*)"/i);
      if (sdkAttr) result.sdk = sdkAttr[1];
    }

    const tfwMatch = raw.match(/<TargetFramework>\s*([^<]+?)\s*<\/TargetFramework>/i);
    if (tfwMatch) result.targetFrameworks.push(tfwMatch[1].trim());
    const tfwsMatch = raw.match(/<TargetFrameworks>\s*([^<]+?)\s*<\/TargetFrameworks>/i);
    if (tfwsMatch) {
      for (const tf of tfwsMatch[1].split(";").map((s) => s.trim()).filter(Boolean)) {
        if (!result.targetFrameworks.includes(tf)) result.targetFrameworks.push(tf);
      }
    }

    const asmMatch = raw.match(/<AssemblyName>\s*([^<]+?)\s*<\/AssemblyName>/i);
    if (asmMatch) result.projectName = asmMatch[1].trim();

    // PackageReference — attribute form
    const prAttrRegex = /<PackageReference\b([^>]*?)\/?>/gi;
    let m: RegExpExecArray | null;
    while ((m = prAttrRegex.exec(raw)) !== null) {
      const attrs = m[1];
      const idM = attrs.match(/\b(?:Include|Update)\s*=\s*"([^"]*)"/i);
      const verM = attrs.match(/\bVersion\s*=\s*"([^"]*)"/i);
      if (idM) {
        const privateM = attrs.match(/\bPrivateAssets\s*=\s*"([^"]*)"/i);
        result.packageReferences.push({
          id: idM[1].trim(),
          version: (verM?.[1] ?? "").trim(),
          privateAssets: privateM?.[1],
        });
      }
    }

    const projRefRegex = /<ProjectReference\b[^>]*\b(?:Include|Update)\s*=\s*"([^"]*)"[^>]*\/?>/gi;
    while ((m = projRefRegex.exec(raw)) !== null) {
      result.projectReferences.push({ path: m[1].trim() });
    }
  }

  // If no project name, try to infer from a sibling AssemblyName or leave null
  if (!result.projectName && result.propertyBag.PackageId) {
    result.projectName = result.propertyBag.PackageId;
  }

  return result;
}

/**
 * Generate a realistic sample csproj string for the "load sample" button.
 * Includes a mix of up-to-date, outdated, and historically-vulnerable packages
 * so the auditor has something interesting to show even without network.
 */
export const SAMPLE_CSPROJ = `<?xml version="1.0" encoding="utf-8"?>
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <AssemblyName>Contoso.WebApi</AssemblyName>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <RootNamespace>Contoso.WebApi</RootNamespace>
  </PropertyGroup>

  <ItemGroup>
    <!-- Framework / BCL -->
    <PackageReference Include="Microsoft.Extensions.Configuration" Version="8.0.0" />
    <PackageReference Include="Microsoft.Extensions.DependencyInjection" Version="8.0.0" />

    <!-- Web stack -->
    <PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.0" />
    <PackageReference Include="Swashbuckle.AspNetCore" Version="6.5.0" />

    <!-- Data -->
    <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.0" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Design" Version="8.0.0">
      <PrivateAssets>all</PrivateAssets>
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
    </PackageReference>
    <PackageReference Include="Dapper" Version="2.0.123" />
    <PackageReference Include="Npgsql" Version="4.0.4" />

    <!-- Logging / Observability -->
    <PackageReference Include="Serilog.AspNetCore" Version="6.1.0" />
    <PackageReference Include="Serilog.Sinks.Console" Version="4.1.0" />
    <PackageReference Include="OpenTelemetry.Extensions.Hosting" Version="1.5.1" />

    <!-- Security (historically vulnerable versions intentionally pinned) -->
    <PackageReference Include="System.IdentityModel.Tokens.Jwt" Version="6.10.0" />
    <PackageReference Include="Microsoft.AspNetCore.Authentication.OpenIdConnect" Version="7.0.5" />

    <!-- Utilities -->
    <PackageReference Include="AutoMapper" Version="12.0.1" />
    <PackageReference Include="MediatR" Version="11.0.0" />
    <PackageReference Include="FluentValidation" Version="11.5.0" />
    <PackageReference Include="Polly" Version="7.2.3" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.1" />
    <PackageReference Include="CsvHelper" Version="30.0.1" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="..\\Contoso.Domain\\Contoso.Domain.csproj" />
    <ProjectReference Include="..\\Contoso.Infrastructure\\Contoso.Infrastructure.csproj" />
  </ItemGroup>

  <ItemGroup>
    <FrameworkReference Include="Microsoft.AspNetCore.App" />
  </ItemGroup>
</Project>`;
