/**
 * Audit orchestration: combines csproj parsing + NuGet data + SemVer range
 * matching to produce the final audit result consumed by the UI.
 */

import semver from "semver";
import {
  type ParsedCsproj,
  type PackageReference,
  parseCsproj,
} from "@/lib/csproj-parser";
import {
  type NuGetPackageInfo,
  type NuGetSeverity,
  type NuGetVulnerability,
  getPackageInfo,
} from "@/lib/nuget";

export type AuditSeverity = NuGetSeverity;

export type LicenseCategory =
  | "permissive"
  | "copyleft"
  | "copyleft-strong"
  | "restrictive"
  | "unknown"
  | "none";

/**
 * Classify a NuGet license expression or URL into a broad category.
 * Based on common SPDX identifiers and license URL patterns.
 */
const RESTRICTIVE_LICENSES = ["GPL", "AGPL", "LGPL", "GPLv3", "GPLv2", "Affero"];
const STRONG_COPYLEFT = ["AGPL", "Affero", "GPL-3.0", "GPL-2.0"];
const WEAK_COPYLEFT = ["LGPL", "MPL", "CDDL", "EPL", "EUPL"];

function classifyLicense(expr?: string, url?: string): LicenseCategory {
  const raw = `${expr ?? ""} ${url ?? ""}`.toUpperCase();
  if (!raw.trim()) return "none";

  // Check for restrictive licenses first (most important to flag)
  if (STRONG_COPYLEFT.some((l) => raw.includes(l))) return "copyleft-strong";
  if (WEAK_COPYLEFT.some((l) => raw.includes(l))) return "copyleft";

  // Permissive licenses
  if (
    raw.includes("MIT") ||
    raw.includes("APACHE") ||
    raw.includes("BSD") ||
    raw.includes("ISC") ||
    raw.includes("MS-PL") ||
    raw.includes("MICROSOFT") ||
    raw.includes("UNLICENSE")
  ) {
    return "permissive";
  }

  // Restrictive / proprietary indicators
  if (
    raw.includes("PROPRIETARY") ||
    raw.includes("COMMERCIAL") ||
    raw.includes("ALL RIGHTS RESERVED") ||
    raw.includes("EULA")
  ) {
    return "restrictive";
  }

  // General copyleft fallback
  if (RESTRICTIVE_LICENSES.some((l) => raw.includes(l))) return "copyleft-strong";

  return "unknown";
}

export interface AuditedVulnerability {
  severity: AuditSeverity;
  advisoryUrl: string;
  range: string;
  advisoryTitle?: string;
  matchedVersion: string;
}

export interface AuditedPackage {
  id: string;
  declaredVersion: string;
  resolvedVersion: string | null; // coerced semver or null if unparseable
  latestStableVersion: string | null;
  latestVersion: string | null;
  isOutdated: boolean;
  isPrerelease: boolean;
  isVulnerable: boolean;
  isDeprecated: boolean;
  deprecationReasons: string[];
  vulnerabilities: AuditedVulnerability[];
  maxSeverity: AuditSeverity | null;
  transitiveDependencies: { id: string; range: string }[];
  description?: string;
  authors?: string[];
  projectUrl?: string;
  licenseUrl?: string;
  licenseExpression?: string;
  licenseCategory?: LicenseCategory;
  iconUrl?: string;
  privateAssets?: string;
  source: "live" | "fallback" | "error";
  error?: string;
}

export interface DependencyTreeNode {
  id: string;
  label: string;
  version: string; // declared or range
  kind: "root" | "direct" | "transitive";
  children: DependencyTreeNode[];
  isVulnerable: boolean;
  isOutdated: boolean;
  maxSeverity: AuditSeverity | null;
}

export interface AuditResult {
  parsed: ParsedCsproj;
  packages: AuditedPackage[];
  tree: DependencyTreeNode;
  stats: {
    totalPackages: number;
    outdatedCount: number;
    vulnerableCount: number;
    deprecatedCount: number;
    prereleaseCount: number;
    maxSeverity: AuditSeverity | null;
    sources: { live: number; fallback: number; error: number };
  };
  generatedAt: string;
  durationMs: number;
  rawCsproj: string;
}

const SEVERITY_RANK: Record<AuditSeverity, number> = {
  low: 1,
  moderate: 2,
  high: 3,
  critical: 4,
};

function maxSev(list: AuditedVulnerability[]): AuditSeverity | null {
  if (list.length === 0) return null;
  return list.reduce<AuditSeverity | null>((acc, v) => {
    if (!acc) return v.severity;
    return SEVERITY_RANK[v.severity] > SEVERITY_RANK[acc] ? v.severity : acc;
  }, null);
}

/**
 * Check whether a concrete declared version satisfies a NuGet vulnerability range.
 * NuGet uses NuGet-version-range syntax (e.g. "[,6.35.0)" or "[1.0.0,2.0.0)").
 * semver.satisfies understands the same bracket syntax for the most part.
 */
function versionMatchesRange(version: string, range: string): boolean {
  const coerced = semver.coerce(version);
  if (!coerced) return false;
  try {
    // NuGet ranges like "[,6.35.0)" — semver handles "[" and "(", but the empty
    // lower bound needs normalization to ">=0.0.0".
    let r = range.trim();
    if (r === "" || r === "*") return true;
    if (r.startsWith("[,") || r.startsWith("(,")) {
      r = `${r[0]}0.0.0,${r.slice(2)}`;
    }
    if (semver.validRange(r)) {
      return semver.satisfies(coerced, r, { includePrerelease: false });
    }
    return false;
  } catch {
    return false;
  }
}

function pickDeclaredEntry(info: NuGetPackageInfo, declaredVersion: string) {
  if (!info.versions.length) return undefined;
  // exact match first
  const exact = info.versions.find((v) => v.version === declaredVersion);
  if (exact) return exact;
  // coerced match
  const coerced = semver.coerce(declaredVersion);
  if (coerced) {
    const c = info.versions.find((v) => {
      const cc = semver.coerce(v.version);
      return cc && semver.eq(cc, coerced);
    });
    if (c) return c;
  }
  return undefined;
}

/**
 * Audit a single declared package reference.
 */
async function auditPackage(pr: PackageReference): Promise<AuditedPackage> {
  const info = await getPackageInfo(pr.id);
  const declaredVersion = (pr.version || "").trim();
  const coerced = semver.coerce(declaredVersion);
  const resolvedVersion = coerced ? coerced.version : null;

  const declaredEntry = pickDeclaredEntry(info, declaredVersion);

  const matchedVulns: AuditedVulnerability[] = info.vulnerabilities
    .filter((v: NuGetVulnerability) => versionMatchesRange(declaredVersion || "0.0.0", v.range))
    .map((v) => ({
      severity: v.severity,
      advisoryUrl: v.advisoryUrl,
      range: v.range,
      advisoryTitle: v.advisoryTitle,
      matchedVersion: declaredVersion,
    }));

  const isPrerelease = /-[0-9A-Za-z.-]+/.test(declaredVersion);
  const latestStable = info.latestStableVersion;
  let isOutdated = false;
  if (latestStable && coerced) {
    const latestCoerced = semver.coerce(latestStable);
    if (latestCoerced && semver.lt(coerced, latestCoerced)) {
      isOutdated = true;
    }
  }

  const isDeprecated = !!declaredEntry?.deprecation;
  const deprecationReasons = declaredEntry?.deprecation?.reasons ?? [];

  const authors = Array.isArray(declaredEntry?.authors)
    ? (declaredEntry!.authors as string[])
    : typeof declaredEntry?.authors === "string"
      ? [declaredEntry.authors as string]
      : undefined;

  return {
    id: pr.id,
    declaredVersion,
    resolvedVersion,
    latestStableVersion: latestStable,
    latestVersion: info.latestVersion,
    isOutdated,
    isPrerelease,
    isVulnerable: matchedVulns.length > 0,
    isDeprecated,
    deprecationReasons,
    vulnerabilities: matchedVulns,
    maxSeverity: maxSev(matchedVulns),
    transitiveDependencies: declaredEntry?.dependencies ?? [],
    description: declaredEntry?.description,
    authors,
    projectUrl: declaredEntry?.projectUrl,
    licenseUrl: declaredEntry?.licenseUrl,
    licenseExpression: declaredEntry?.licenseExpression,
    licenseCategory: classifyLicense(declaredEntry?.licenseExpression, declaredEntry?.licenseUrl),
    iconUrl: declaredEntry?.iconUrl,
    privateAssets: pr.privateAssets,
    source: info.source,
    error: info.error,
  };
}

/**
 * Build a dependency tree, fetching one level of transitive dependencies so
 * the tree visualization shows the project -> direct deps -> transitive deps
 * structure. To avoid an explosion of API calls, transitive deps are only
 * resolved for direct packages and not recursively.
 */
async function buildTree(
  parsed: ParsedCsproj,
  audited: AuditedPackage[],
): Promise<DependencyTreeNode> {
  const byId = new Map(audited.map((p) => [p.id.toLowerCase(), p]));

  const root: DependencyTreeNode = {
    id: "root",
    label: parsed.projectName ?? "Project",
    version: parsed.targetFrameworks.join(", ") || "—",
    kind: "root",
    children: [],
    isVulnerable: false,
    isOutdated: false,
    maxSeverity: null,
  };

  // Direct package references
  for (const pr of parsed.packageReferences) {
    const audit = byId.get(pr.id.toLowerCase());
    const node: DependencyTreeNode = {
      id: pr.id,
      label: pr.id,
      version: pr.version || "(unspecified)",
      kind: "direct",
      children: [],
      isVulnerable: audit?.isVulnerable ?? false,
      isOutdated: audit?.isOutdated ?? false,
      maxSeverity: audit?.maxSeverity ?? null,
    };

    // One level of transitive deps (resolve ranges to nothing deeper — they are leaf nodes)
    if (audit && audit.transitiveDependencies.length > 0) {
      for (const dep of audit.transitiveDependencies.slice(0, 25)) {
        const depAudit = byId.get(dep.id.toLowerCase());
        node.children.push({
          id: dep.id,
          label: dep.id,
          version: dep.range,
          kind: "transitive",
          children: [],
          isVulnerable: depAudit?.isVulnerable ?? false,
          isOutdated: depAudit?.isOutdated ?? false,
          maxSeverity: depAudit?.maxSeverity ?? null,
        });
      }
    }
    root.children.push(node);
  }

  // Project references (shown as a special kind)
  for (const projRef of parsed.projectReferences) {
    root.children.push({
      id: projRef.path,
      label: projRef.path.split(/[\\/]/).pop() ?? projRef.path,
      version: "project",
      kind: "transitive",
      children: [],
      isVulnerable: false,
      isOutdated: false,
      maxSeverity: null,
    });
  }

  return root;
}

/**
 * Run a full audit on raw csproj content.
 */
export async function auditCsproj(raw: string): Promise<AuditResult> {
  const start = Date.now();
  const parsed = parseCsproj(raw);

  // Audit all packages in parallel with limited concurrency (NuGet is rate-limited)
  const packages: AuditedPackage[] = [];
  const concurrency = 6;
  const queue = [...parsed.packageReferences];
  const workers: Promise<void>[] = [];

  const runWorker = async () => {
    while (queue.length > 0) {
      const pr = queue.shift();
      if (!pr) break;
      try {
        packages.push(await auditPackage(pr));
      } catch (err) {
        packages.push({
          id: pr.id,
          declaredVersion: pr.version || "",
          resolvedVersion: null,
          latestStableVersion: null,
          latestVersion: null,
          isOutdated: false,
          isPrerelease: false,
          isVulnerable: false,
          isDeprecated: false,
          deprecationReasons: [],
          vulnerabilities: [],
          maxSeverity: null,
          transitiveDependencies: [],
          source: "error",
          error: err instanceof Error ? err.message : "audit error",
        });
      }
    }
  };

  for (let i = 0; i < concurrency; i++) workers.push(runWorker());
  await Promise.all(workers);

  // Deduplicate packages by ID (case-insensitive) — a csproj may declare the
  // same package in multiple ItemGroups or with conditions. Keep the first
  // occurrence to avoid React duplicate-key warnings and inflated counts.
  const seenIds = new Set<string>();
  const dedupedPackages = packages.filter((p) => {
    const key = p.id.toLowerCase();
    if (seenIds.has(key)) return false;
    seenIds.add(key);
    return true;
  });
  packages.length = 0;
  packages.push(...dedupedPackages);

  // Preserve declared order
  const orderMap = new Map(parsed.packageReferences.map((p, i) => [p.id.toLowerCase(), i]));
  packages.sort((a, b) => {
    const ai = orderMap.get(a.id.toLowerCase()) ?? 9999;
    const bi = orderMap.get(b.id.toLowerCase()) ?? 9999;
    return ai - bi;
  });

  const tree = await buildTree(parsed, packages);

  const stats = {
    totalPackages: packages.length,
    outdatedCount: packages.filter((p) => p.isOutdated).length,
    vulnerableCount: packages.filter((p) => p.isVulnerable).length,
    deprecatedCount: packages.filter((p) => p.isDeprecated).length,
    prereleaseCount: packages.filter((p) => p.isPrerelease).length,
    maxSeverity: packages.reduce<AuditSeverity | null>((acc, p) => {
      if (!p.maxSeverity) return acc;
      if (!acc) return p.maxSeverity;
      return SEVERITY_RANK[p.maxSeverity] > SEVERITY_RANK[acc] ? p.maxSeverity : acc;
    }, null),
    sources: {
      live: packages.filter((p) => p.source === "live").length,
      fallback: packages.filter((p) => p.source === "fallback").length,
      error: packages.filter((p) => p.source === "error").length,
    },
  };

  return {
    parsed,
    packages,
    tree,
    stats,
    generatedAt: new Date().toISOString(),
    durationMs: Date.now() - start,
    rawCsproj: raw,
  };
}
