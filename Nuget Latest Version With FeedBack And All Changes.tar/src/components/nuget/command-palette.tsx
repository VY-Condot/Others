"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from "@/components/ui/dialog";
import { Command as CommandPrimitive } from "cmdk";
import {
  GitGraph,
  Network,
  ShieldCheck,
  Zap,
  BarChart3,
  PackageSearch,
  Terminal,
  History,
  Save,
  Sparkles,
  Bot,
  Sun,
  Moon,
  Keyboard,
  Search,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Action {
  id: string;
  label: string;
  group: string;
  icon: React.ComponentType<{ className?: string }>;
  shortcut?: string;
  action: () => void;
}

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onNavigate: (tab: string) => void;
  onSave: () => void;
  onOpenHistory: () => void;
  onOpenShortcuts: () => void;
  onToggleTheme: () => void;
  onLoadSample: () => void;
  hasResult: boolean;
}

export function CommandPalette({
  open,
  onOpenChange,
  onNavigate,
  onSave,
  onOpenHistory,
  onOpenShortcuts,
  onToggleTheme,
  onLoadSample,
  hasResult,
}: Props) {
  const [query, setQuery] = useState("");

  const actions = useMemo<Action[]>(() => {
    const base: Action[] = [
      {
        id: "sample",
        label: "Load sample project",
        group: "Actions",
        icon: Sparkles,
        action: () => {
          onLoadSample();
        },
      },
      {
        id: "history",
        label: "Open audit history",
        group: "Actions",
        icon: History,
        shortcut: "H",
        action: onOpenHistory,
      },
      {
        id: "shortcuts",
        label: "Show keyboard shortcuts",
        group: "Actions",
        icon: Keyboard,
        shortcut: "?",
        action: onOpenShortcuts,
      },
      {
        id: "theme",
        label: "Toggle theme",
        group: "Actions",
        icon: Sun,
        action: onToggleTheme,
      },
    ];

    if (hasResult) {
      base.push({
        id: "save",
        label: "Save current audit",
        group: "Actions",
        icon: Save,
        shortcut: "S",
        action: onSave,
      });

      const tabs: Array<{ id: string; label: string; icon: React.ComponentType<{ className?: string }>; shortcut: string }> = [
        { id: "graph", label: "Force graph", icon: GitGraph, shortcut: "G F" },
        { id: "tree", label: "Dependency tree", icon: Network, shortcut: "G T" },
        { id: "vulns", label: "Vulnerabilities", icon: ShieldCheck, shortcut: "G V" },
        { id: "outdated", label: "Outdated packages", icon: Zap, shortcut: "G O" },
        { id: "analytics", label: "Analytics dashboard", icon: BarChart3, shortcut: "G A" },
        { id: "all", label: "All packages", icon: PackageSearch, shortcut: "G P" },
        { id: "upgrade", label: "Upgrade & export", icon: Terminal, shortcut: "G U" },
      ];

      for (const t of tabs) {
        base.push({
          id: `tab-${t.id}`,
          label: `Go to ${t.label}`,
          group: "Navigate",
          icon: t.icon,
          shortcut: t.shortcut,
          action: () => onNavigate(t.id),
        });
      }
    }

    return base;
  }, [hasResult, onLoadSample, onOpenHistory, onOpenShortcuts, onToggleTheme, onSave, onNavigate]);

  const grouped = useMemo(() => {
    const filtered = actions.filter((a) =>
      a.label.toLowerCase().includes(query.toLowerCase()),
    );
    const groups = new Map<string, Action[]>();
    for (const a of filtered) {
      if (!groups.has(a.group)) groups.set(a.group, []);
      groups.get(a.group)!.push(a);
    }
    return Array.from(groups.entries());
  }, [actions, query]);

  const runAction = useCallback(
    (a: Action) => {
      a.action();
      onOpenChange(false);
      setQuery("");
    },
    [onOpenChange],
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="p-0 overflow-hidden max-w-xl gap-0" showCloseButton={false}>
        <DialogTitle className="sr-only">Command palette</DialogTitle>
        <CommandPrimitive className="flex flex-col" loop>
          <div className="flex items-center gap-2 border-b px-3">
            <Search className="h-4 w-4 text-muted-foreground shrink-0" />
            <CommandPrimitive.Input
              placeholder="Type a command or search…"
              value={query}
              onValueChange={setQuery}
              className="flex h-12 w-full bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
              autoFocus
            />
            <kbd className="hidden sm:inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] text-muted-foreground">
              ESC
            </kbd>
          </div>
          <CommandPrimitive.List className="max-h-[360px] overflow-y-auto custom-scroll p-2">
            <CommandPrimitive.Empty>
              <div className="py-8 text-center text-sm text-muted-foreground">
                No commands found for &ldquo;{query}&rdquo;
              </div>
            </CommandPrimitive.Empty>
            {grouped.map(([group, items]) => (
              <CommandPrimitive.Group
                key={group}
                heading={group}
                className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-1"
              >
                {items.map((a) => (
                  <CommandPrimitive.Item
                    key={a.id}
                    value={a.label}
                    onSelect={() => runAction(a)}
                    className="flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm cursor-pointer aria-selected:bg-primary/10 aria-selected:text-primary transition-colors"
                  >
                    <a.icon className="h-4 w-4 shrink-0 text-muted-foreground" />
                    <span className="flex-1">{a.label}</span>
                    {a.shortcut && (
                      <kbd className="hidden sm:inline-flex h-5 select-none items-center gap-0.5 rounded border bg-muted px-1.5 font-mono text-[10px] text-muted-foreground">
                        {a.shortcut}
                      </kbd>
                    )}
                  </CommandPrimitive.Item>
                ))}
              </CommandPrimitive.Group>
            ))}
          </CommandPrimitive.List>
          <div className="border-t px-3 py-1.5 flex items-center justify-between text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <Sparkles className="h-2.5 w-2.5" />
              Command palette
            </span>
            <span>↑↓ navigate · ↵ select</span>
          </div>
        </CommandPrimitive>
      </DialogContent>
    </Dialog>
  );
}
