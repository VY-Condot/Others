"use client";

import { useState, useCallback, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Bug,
  Lightbulb,
  MessageSquare,
  HelpCircle,
  Loader2,
  Send,
  Camera,
  X,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

type FeedbackType = "bug" | "feature" | "feedback" | "question";
type Severity = "low" | "medium" | "high" | "critical";

const TYPE_OPTIONS: Array<{ value: FeedbackType; label: string; icon: React.ComponentType<{ className?: string }>; color: string }> = [
  { value: "bug", label: "Bug report", icon: Bug, color: "text-red-500" },
  { value: "feature", label: "Feature request", icon: Lightbulb, color: "text-yellow-500" },
  { value: "feedback", label: "General feedback", icon: MessageSquare, color: "text-blue-500" },
  { value: "question", label: "Question", icon: HelpCircle, color: "text-purple-500" },
];

const SEVERITY_OPTIONS: Array<{ value: Severity; label: string; color: string }> = [
  { value: "low", label: "Low", color: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10" },
  { value: "medium", label: "Medium", color: "border-yellow-500/40 text-yellow-600 dark:text-yellow-400 bg-yellow-500/10" },
  { value: "high", label: "High", color: "border-orange-500/40 text-orange-600 dark:text-orange-400 bg-orange-500/10" },
  { value: "critical", label: "Critical", color: "border-red-500/40 text-red-600 dark:text-red-400 bg-red-500/10" },
];

export function FeedbackDialog({ open, onOpenChange }: Props) {
  const [type, setType] = useState<FeedbackType>("bug");
  const [severity, setSeverity] = useState<Severity>("medium");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [reporterName, setReporterName] = useState("");
  const [reporterEmail, setReporterEmail] = useState("");
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleScreenshot = useCallback((file: File) => {
    if (file.size > 2_000_000) {
      toast.error("Screenshot too large", { description: "Max 2MB. Please crop or compress." });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setScreenshot(reader.result as string);
    reader.readAsDataURL(file);
  }, []);

  const onPaste = useCallback((e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (item.type.startsWith("image/")) {
        const file = item.getAsFile();
        if (file) {
          handleScreenshot(file);
          toast.success("Screenshot captured from clipboard");
        }
      }
    }
  }, [handleScreenshot]);

  const submit = async () => {
    if (!title.trim() || !description.trim()) {
      toast.error("Title and description are required");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type,
          severity,
          title,
          description,
          screenshot,
          reporterName: reporterName || undefined,
          reporterEmail: reporterEmail || undefined,
          page: window.location.pathname + window.location.search,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setSubmitted(true);
        toast.success("Feedback submitted — thank you!");
        // Reset form after a delay
        setTimeout(() => {
          reset();
          onOpenChange(false);
        }, 1800);
      } else {
        toast.error("Submission failed", { description: data.error });
      }
    } catch (err) {
      toast.error("Submission failed", { description: String(err) });
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => {
    setType("bug");
    setSeverity("medium");
    setTitle("");
    setDescription("");
    setReporterName("");
    setReporterEmail("");
    setScreenshot(null);
    setSubmitted(false);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) reset(); onOpenChange(o); }}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto custom-scroll" onPaste={onPaste}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            Feedback &amp; Bug Reports
          </DialogTitle>
          <DialogDescription>
            Help us improve the NuGet Auditor. Report bugs, request features, or share your thoughts. You can paste screenshots directly (Ctrl+V).
          </DialogDescription>
        </DialogHeader>

        {submitted ? (
          <div className="flex flex-col items-center justify-center py-10 gap-3 animate-fade-up">
            <div className="rounded-full bg-emerald-500/10 p-4">
              <CheckCircle2 className="h-8 w-8 text-emerald-500" />
            </div>
            <p className="text-sm font-medium">Thank you for your feedback!</p>
            <p className="text-xs text-muted-foreground">We&apos;ll review it shortly.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Type selector */}
            <div>
              <Label className="text-xs mb-1.5 block">Type</Label>
              <div className="grid grid-cols-2 gap-2">
                {TYPE_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setType(opt.value)}
                    className={cn(
                      "flex items-center gap-2 rounded-lg border p-2.5 text-xs transition-all",
                      type === opt.value
                        ? "border-primary bg-primary/5 ring-1 ring-primary/20"
                        : "border-border hover:bg-muted/40",
                    )}
                  >
                    <opt.icon className={cn("h-4 w-4", opt.color)} />
                    <span className="font-medium">{opt.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Severity selector */}
            <div>
              <Label className="text-xs mb-1.5 block">Severity</Label>
              <div className="flex gap-1.5">
                {SEVERITY_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setSeverity(opt.value)}
                    className={cn(
                      "flex-1 rounded-md border px-2 py-1.5 text-[11px] font-medium transition-all",
                      severity === opt.value ? opt.color : "border-border text-muted-foreground hover:bg-muted/40",
                    )}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Title */}
            <div>
              <Label htmlFor="fb-title" className="text-xs mb-1.5 block">Title *</Label>
              <Input
                id="fb-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Brief summary of the issue or suggestion"
                maxLength={200}
                className="text-sm"
              />
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="fb-desc" className="text-xs mb-1.5 block">Description *</Label>
              <Textarea
                id="fb-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe what happened, what you expected, and steps to reproduce (if applicable)…"
                className="text-sm min-h-[100px] resize-y"
                maxLength={5000}
              />
              <p className="text-[10px] text-muted-foreground mt-1">{description.length}/5000</p>
            </div>

            {/* Screenshot */}
            <div>
              <Label className="text-xs mb-1.5 block">Screenshot (optional)</Label>
              {screenshot ? (
                <div className="relative rounded-lg border overflow-hidden">
                  <img src={screenshot} alt="Screenshot" className="w-full max-h-40 object-contain bg-muted/20" />
                  <button
                    onClick={() => setScreenshot(null)}
                    className="absolute top-1.5 right-1.5 rounded-md bg-background/80 backdrop-blur p-1 hover:bg-background"
                    aria-label="Remove screenshot"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => fileRef.current?.click()}
                  className="w-full rounded-lg border-2 border-dashed border-border p-3 text-xs text-muted-foreground hover:border-primary/50 hover:bg-muted/30 transition-all flex items-center justify-center gap-1.5"
                >
                  <Camera className="h-3.5 w-3.5" />
                  Click to upload or paste (Ctrl+V)
                </button>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleScreenshot(f);
                }}
              />
            </div>

            {/* Contact info */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="fb-name" className="text-xs mb-1.5 block">Name (optional)</Label>
                <Input id="fb-name" value={reporterName} onChange={(e) => setReporterName(e.target.value)} placeholder="Anonymous" className="text-sm" maxLength={100} />
              </div>
              <div>
                <Label htmlFor="fb-email" className="text-xs mb-1.5 block">Email (optional)</Label>
                <Input id="fb-email" type="email" value={reporterEmail} onChange={(e) => setReporterEmail(e.target.value)} placeholder="for follow-up" className="text-sm" maxLength={200} />
              </div>
            </div>

            {/* Submit */}
            <div className="flex items-center justify-between gap-2 pt-2 border-t">
              <p className="text-[10px] text-muted-foreground">
                <Badge variant="outline" className="text-[9px] mr-1">{type}</Badge>
                <Badge variant="outline" className="text-[9px]">{severity}</Badge>
              </p>
              <Button onClick={submit} disabled={submitting || !title.trim() || !description.trim()}>
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                {submitting ? "Submitting…" : "Submit"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
