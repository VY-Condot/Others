"use client";

import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { ZoomIn, ZoomOut, Maximize2, Pause, Play, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { DependencyTreeNode, AuditSeverity } from "@/lib/audit";

interface Props {
  tree: DependencyTreeNode;
  onSelect?: (node: DependencyTreeNode) => void;
}

interface SimNode {
  id: string;
  label: string;
  version: string;
  kind: "root" | "direct" | "transitive";
  x: number;
  y: number;
  vx: number;
  vy: number;
  fx?: number;
  fy?: number;
  isVulnerable: boolean;
  isOutdated: boolean;
  maxSeverity: AuditSeverity | null;
  r: number;
}

interface SimEdge {
  source: string;
  target: string;
}

const sevFill: Record<AuditSeverity, string> = {
  low: "#eab308",
  moderate: "#f97316",
  high: "#ef4444",
  critical: "#dc2626",
};

const KIND_RADIUS = { root: 22, direct: 12, transitive: 7 };
const KIND_FILL = {
  root: "var(--primary)",
  direct: "var(--card)",
  transitive: "var(--muted)",
};

/**
 * Flatten the tree into nodes + edges for the force simulation.
 */
function flatten(tree: DependencyTreeNode): { nodes: SimNode[]; edges: SimEdge[] } {
  const nodes: SimNode[] = [];
  const edges: SimEdge[] = [];
  const seen = new Set<string>();

  const W = 760;
  const H = 460;
  const cx = W / 2;
  const cy = H / 2;

  const pushNode = (n: DependencyTreeNode, depth: number, index: number, total: number) => {
    const key = n.kind === "root" ? "root" : `${n.id}::${n.version}`;
    if (seen.has(key)) return key;
    seen.add(key);

    // initial position: root at center, direct deps on a ring, transitive on outer ring
    let x = cx;
    let y = cy;
    if (depth === 1) {
      const angle = (index / Math.max(total, 1)) * Math.PI * 2;
      const radius = 160;
      x = cx + Math.cos(angle) * radius;
      y = cy + Math.sin(angle) * radius;
    } else if (depth >= 2) {
      x = cx + (Math.random() - 0.5) * 320;
      y = cy + (Math.random() - 0.5) * 240;
    }

    nodes.push({
      id: key,
      label: n.label,
      version: n.version,
      kind: n.kind,
      x,
      y,
      vx: 0,
      vy: 0,
      isVulnerable: n.isVulnerable,
      isOutdated: n.isOutdated,
      maxSeverity: n.maxSeverity,
      r: KIND_RADIUS[n.kind],
    });
    return key;
  };

  const walk = (n: DependencyTreeNode, depth: number, parentId: string | null, idx: number, total: number) => {
    const myId = pushNode(n, depth, idx, total);
    if (parentId) edges.push({ source: parentId, target: myId });
    const childTotal = n.children.length;
    n.children.forEach((c, i) => walk(c, depth + 1, myId, i, childTotal));
  };

  walk(tree, 0, null, 0, 1);
  return { nodes, edges };
}

/**
 * Custom force-directed graph renderer with:
 *  - repulsion (Coulomb) between all nodes
 *  - spring attraction along edges
 *  - centering force
 *  - velocity damping
 *  - drag, zoom, pan
 */
export function ForceGraph({ tree, onSelect }: Props) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [running, setRunning] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [frame, setFrame] = useState<{ nodes: SimNode[]; edges: SimEdge[] }>({ nodes: [], edges: [] });

  const stateRef = useRef<{
    nodes: SimNode[];
    edges: SimEdge[];
    byId: Map<string, SimNode>;
  }>({ nodes: [], edges: [], byId: new Map() });

  // Re-init on tree change
  useEffect(() => {
    const { nodes, edges } = flatten(tree);
    stateRef.current = {
      nodes,
      edges,
      byId: new Map(nodes.map((n) => [n.id, n])),
    };
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setFrame({ nodes: [...nodes], edges: [...edges] });
  }, [tree]);

  // Physics loop
  useEffect(() => {
    if (!running) return;
    let raf = 0;
    const W = 760;
    const H = 460;
    const cx = W / 2;
    const cy = H / 2;

    const step = () => {
      const { nodes, edges, byId } = stateRef.current;
      const repulsion = 1400;
      const springLength = 70;
      const springK = 0.04;
      const centerK = 0.015;
      const damping = 0.82;

      // Repulsion
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i];
          const b = nodes[j];
          let dx = a.x - b.x;
          let dy = a.y - b.y;
          let d2 = dx * dx + dy * dy;
          if (d2 < 1) d2 = 1;
          const d = Math.sqrt(d2);
          const f = repulsion / d2;
          const fx = (dx / d) * f;
          const fy = (dy / d) * f;
          a.vx += fx;
          a.vy += fy;
          b.vx -= fx;
          b.vy -= fy;
        }
      }

      // Collision detection — push overlapping nodes apart (prevents label overlap)
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i];
          const b = nodes[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const d = Math.sqrt(dx * dx + dy * dy) || 0.01;
          const minDist = a.r + b.r + 8; // padding for labels
          if (d < minDist) {
            const push = (minDist - d) / 2;
            const nx = dx / d;
            const ny = dy / d;
            a.x += nx * push;
            a.y += ny * push;
            b.x -= nx * push;
            b.y -= ny * push;
          }
        }
      }

      // Spring attraction
      for (const e of edges) {
        const a = byId.get(e.source);
        const b = byId.get(e.target);
        if (!a || !b) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (d - springLength) * springK;
        const fx = (dx / d) * f;
        const fy = (dy / d) * f;
        a.vx += fx;
        a.vy += fy;
        b.vx -= fx;
        b.vy -= fy;
      }

      // Centering + integrate
      for (const n of nodes) {
        if (n.fx !== undefined && n.fy !== undefined) {
          n.x = n.fx;
          n.y = n.fy;
          n.vx = 0;
          n.vy = 0;
          continue;
        }
        n.vx += (cx - n.x) * centerK;
        n.vy += (cy - n.y) * centerK;
        n.vx *= damping;
        n.vy *= damping;
        n.x += n.vx;
        n.y += n.vy;
        // keep in bounds
        n.x = Math.max(20, Math.min(W - 20, n.x));
        n.y = Math.max(20, Math.min(H - 20, n.y));
      }

      setFrame({ nodes: [...nodes], edges });
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [running]);

  // Drag handling
  const draggingRef = useRef<string | null>(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });

  const onPointerDown = useCallback(
    (e: React.PointerEvent, nodeId: string) => {
      e.stopPropagation();
      const node = stateRef.current.byId.get(nodeId);
      if (!node) return;
      const svg = svgRef.current;
      if (!svg) return;
      const pt = svg.createSVGPoint();
      pt.x = e.clientX;
      pt.y = e.clientY;
      const ctm = svg.getScreenCTM();
      if (!ctm) return;
      const loc = pt.matrixTransform(ctm.inverse());
      draggingRef.current = nodeId;
      dragOffsetRef.current = { x: loc.x - node.x, y: loc.y - node.y };
      node.fx = node.x;
      node.fy = node.y;
      (e.target as Element).setPointerCapture(e.pointerId);
      setSelected(nodeId);
    },
    [],
  );

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    if (!draggingRef.current) return;
    const node = stateRef.current.byId.get(draggingRef.current);
    if (!node) return;
    const svg = svgRef.current;
    if (!svg) return;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX;
    pt.y = e.clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return;
    const loc = pt.matrixTransform(ctm.inverse());
    node.fx = loc.x - dragOffsetRef.current.x;
    node.fy = loc.y - dragOffsetRef.current.y;
  }, []);

  const onPointerUp = useCallback((e: React.PointerEvent) => {
    if (draggingRef.current) {
      const node = stateRef.current.byId.get(draggingRef.current);
      if (node) {
        node.fx = undefined;
        node.fy = undefined;
      }
      draggingRef.current = null;
    }
  }, []);

  // Pan + wheel zoom
  const panningRef = useRef<{ x: number; y: number } | null>(null);
  const onSvgPointerDown = useCallback((e: React.PointerEvent) => {
    if (e.target === svgRef.current) {
      panningRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
      setSelected(null);
    }
  }, [pan]);

  const onSvgPointerMove = useCallback((e: React.PointerEvent) => {
    if (!panningRef.current) return;
    setPan({ x: e.clientX - panningRef.current.x, y: e.clientY - panningRef.current.y });
  }, []);

  const onSvgPointerUp = useCallback(() => {
    panningRef.current = null;
  }, []);

  const onWheel = useCallback((e: React.WheelEvent) => {
    const delta = -e.deltaY * 0.0015;
    setZoom((z) => Math.max(0.3, Math.min(3, z + delta)));
  }, []);

  const { nodes, edges } = frame;
  const nodeMap = useMemo(() => new Map(nodes.map((n) => [n.id, n])), [nodes]);
  const hoveredNode = hovered ? nodeMap.get(hovered) ?? null : null;
  const selectedNode = selected ? nodeMap.get(selected) ?? null : null;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => setRunning((r) => !r)}>
          {running ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          {running ? "Pause" : "Play"}
        </Button>
        <Button variant="outline" size="sm" onClick={() => setZoom((z) => Math.min(3, z + 0.2))}>
          <ZoomIn className="h-3.5 w-3.5" />
        </Button>
        <Button variant="outline" size="sm" onClick={() => setZoom((z) => Math.max(0.3, z - 0.2))}>
          <ZoomOut className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setZoom(1);
            setPan({ x: 0, y: 0 });
          }}
        >
          <Maximize2 className="h-3.5 w-3.5" />
          Reset view
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const { nodes: ns, edges: es } = flatten(tree);
            stateRef.current = { nodes: ns, edges: es, byId: new Map(ns.map((n) => [n.id, n])) };
            setFrame({ nodes: [...ns], edges: [...es] });
          }}
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Re-layout
        </Button>
        <div className="ml-auto flex items-center gap-3 text-[11px] text-muted-foreground">
          <Legend color="#10b981" label="OK" />
          <Legend color="#3b82f6" label="Outdated" />
          <Legend color="#ef4444" label="Vulnerable" />
          <span className="hidden sm:inline">· drag nodes · scroll to zoom · {nodes.length} nodes</span>
        </div>
      </div>

      <div className="relative rounded-lg border bg-gradient-to-br from-muted/30 to-background overflow-hidden">
        <svg
          ref={svgRef}
          viewBox="0 0 760 460"
          className="w-full h-[460px] touch-none cursor-grab active:cursor-grabbing"
          onPointerDown={onSvgPointerDown}
          onPointerMove={(e) => {
            onSvgPointerMove(e);
            onPointerMove(e);
          }}
          onPointerUp={(e) => {
            onSvgPointerUp();
            onPointerUp(e);
          }}
          onPointerLeave={() => {
            onSvgPointerUp();
            onPointerUp({} as React.PointerEvent);
          }}
          onWheel={onWheel}
        >
          <g transform={`translate(${pan.x} ${pan.y}) scale(${zoom})`}>
            {/* Edges */}
            <g stroke="currentColor" className="text-muted-foreground/30">
              {edges.map((e, i) => {
                const a = nodeMap.get(e.source);
                const b = nodeMap.get(e.target);
                if (!a || !b) return null;
                return (
                  <line
                    key={i}
                    x1={a.x}
                    y1={a.y}
                    x2={b.x}
                    y2={b.y}
                    strokeWidth={1}
                  />
                );
              })}
            </g>

            {/* Nodes */}
            {nodes.map((n) => {
              const fill =
                n.isVulnerable && n.maxSeverity
                  ? sevFill[n.maxSeverity]
                  : n.kind === "root"
                    ? "var(--primary)"
                    : n.isOutdated
                      ? "#3b82f6"
                      : n.kind === "direct"
                        ? "var(--card)"
                        : "var(--muted-foreground)";
              const stroke =
                n.kind === "root"
                  ? "var(--primary-foreground)"
                  : n.isVulnerable || n.isOutdated
                    ? fill
                    : "var(--border)";
              const isHovered = hovered === n.id;
              const isSelected = selected === n.id;
              return (
                <g
                  key={n.id}
                  transform={`translate(${n.x} ${n.y})`}
                  onPointerDown={(e) => onPointerDown(e, n.id)}
                  onPointerEnter={() => setHovered(n.id)}
                  onPointerLeave={() => setHovered(null)}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelected(n.id);
                  }}
                  style={{ cursor: "pointer" }}
                >
                  {(isHovered || isSelected) && (
                    <circle r={n.r + 4} fill="none" stroke="currentColor" className="text-primary/40" strokeWidth={1.5} />
                  )}
                  <circle
                    r={n.r}
                    fill={fill}
                    stroke={stroke}
                    strokeWidth={n.kind === "root" ? 2 : 1.5}
                  />
                  {n.kind !== "transitive" && (
                    <text
                      textAnchor="middle"
                      dy={n.r + 12}
                      className="fill-foreground pointer-events-none select-none"
                      style={{ fontSize: n.kind === "root" ? 11 : 9, fontWeight: n.kind === "root" ? 600 : 400 }}
                    >
                      {n.label.length > 22 ? n.label.slice(0, 21) + "…" : n.label}
                    </text>
                  )}
                </g>
              );
            })}
          </g>
        </svg>

        {/* Hover tooltip */}
        {hoveredNode && (
          <div className="absolute top-2 left-2 rounded-md border bg-popover/95 backdrop-blur px-3 py-2 text-xs shadow-lg pointer-events-none max-w-[260px]">
            <div className="font-mono font-semibold">{hoveredNode.label}</div>
            <div className="text-muted-foreground font-mono">{hoveredNode.version}</div>
            <div className="flex gap-1 mt-1 flex-wrap">
              <Badge variant="outline" className="text-[10px]">{hoveredNode.kind}</Badge>
              {hoveredNode.isVulnerable && hoveredNode.maxSeverity && (
                <Badge variant="outline" className="text-[10px] border-red-500/40 text-red-600 dark:text-red-400">
                  {hoveredNode.maxSeverity}
                </Badge>
              )}
              {hoveredNode.isOutdated && (
                <Badge variant="outline" className="text-[10px] border-blue-500/40 text-blue-600 dark:text-blue-400">
                  outdated
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Selected detail card */}
        {selectedNode && (
          <div className="absolute bottom-2 right-2 rounded-md border bg-popover/95 backdrop-blur px-3 py-2 text-xs shadow-lg max-w-[240px]">
            <div className="font-mono font-semibold truncate">{selectedNode.label}</div>
            <div className="text-muted-foreground font-mono text-[10px] mb-1">{selectedNode.version}</div>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 text-[11px] px-2 w-full justify-center"
              onClick={(e) => {
                e.stopPropagation();
                const fakeNode: DependencyTreeNode = {
                  id: selectedNode.id,
                  label: selectedNode.label,
                  version: selectedNode.version,
                  kind: selectedNode.kind,
                  children: [],
                  isVulnerable: selectedNode.isVulnerable,
                  isOutdated: selectedNode.isOutdated,
                  maxSeverity: selectedNode.maxSeverity,
                };
                onSelect?.(fakeNode);
              }}
            >
              View details →
            </Button>
          </div>
        )}
      </div>
      <p className="text-[11px] text-muted-foreground text-center">
        Physics-based force simulation · drag nodes to pin them · zoom with scroll ·{" "}
        <span className="text-foreground/70">{nodes.length} live nodes</span>
      </p>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1">
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
    </span>
  );
}
