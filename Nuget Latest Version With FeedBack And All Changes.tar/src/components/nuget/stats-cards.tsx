"use client";

import {
  Boxes,
  AlertTriangle,
  ArrowUpCircle,
  ShieldAlert,
  Clock,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useCountUp } from "@/hooks/use-count-up";
import type { AuditSeverity } from "@/lib/audit";

interface Stats {
  totalPackages: number;
  outdatedCount: number;
  vulnerableCount: number;
  deprecatedCount: number;
  prereleaseCount: number;
  maxSeverity: AuditSeverity | null;
  sources: { live: number; fallback: number; error: number };
}

interface Props {
  stats: Stats;
  durationMs: number;
}

const sevColor: Record<AuditSeverity, string> = {
  low: "text-yellow-600 dark:text-yellow-400",
  moderate: "text-orange-600 dark:text-orange-400",
  high: "text-red-600 dark:text-red-400",
  critical: "text-red-700 dark:text-red-500",
};

const sevBg: Record<AuditSeverity, string> = {
  low: "bg-yellow-500/10",
  moderate: "bg-orange-500/10",
  high: "bg-red-500/10",
  critical: "bg-red-600/15",
};

export function StatsCards({ stats, durationMs }: Props) {
  const cards = [
    {
      label: "Total packages",
      value: stats.totalPackages,
      icon: Boxes,
      tint: "text-primary",
      bg: "bg-primary/10",
      hint: stats.sources.error > 0 ? `${stats.sources.error} not found` : undefined,
    },
    {
      label: "Outdated",
      value: stats.outdatedCount,
      icon: ArrowUpCircle,
      tint: "text-blue-600 dark:text-blue-400",
      bg: "bg-blue-500/10",
      hint: stats.totalPackages > 0 ? `${Math.round((stats.outdatedCount / stats.totalPackages) * 100)}% of deps` : undefined,
    },
    {
      label: "Vulnerable",
      value: stats.vulnerableCount,
      icon: ShieldAlert,
      tint: stats.maxSeverity
        ? sevColor[stats.maxSeverity]
        : "text-emerald-600 dark:text-emerald-400",
      bg: stats.maxSeverity ? sevBg[stats.maxSeverity] : "bg-emerald-500/10",
      hint: stats.maxSeverity ? `Max severity: ${stats.maxSeverity}` : "No known CVEs",
    },
    {
      label: "Deprecated",
      value: stats.deprecatedCount,
      icon: AlertTriangle,
      tint: "text-amber-600 dark:text-amber-400",
      bg: "bg-amber-500/10",
      hint: undefined,
    },
    {
      label: "Prerelease",
      value: stats.prereleaseCount,
      icon: Clock,
      tint: "text-purple-600 dark:text-purple-400",
      bg: "bg-purple-500/10",
      hint: undefined,
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
      {cards.map((c, i) => (
        <StatCard key={c.label} {...c} delay={i * 60} />
      ))}
      <div className="col-span-2 md:col-span-3 lg:col-span-5 flex items-center justify-between text-xs text-muted-foreground px-1">
        <span>
          Sources — <span className="text-emerald-600 dark:text-emerald-400">live: {stats.sources.live}</span>{" "}
          · <span className="text-amber-600 dark:text-amber-400">fallback: {stats.sources.fallback}</span>{" "}
          · <span className="text-red-600 dark:text-red-400">error: {stats.sources.error}</span>
        </span>
        <span>Audit took {(durationMs / 1000).toFixed(2)}s</span>
      </div>
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  tint: string;
  bg: string;
  hint?: string;
  delay: number;
}

function StatCard({ label, value, icon: Icon, tint, bg, hint, delay }: StatCardProps) {
  const animated = useCountUp(value, 900, true);
  return (
    <div
      className={cn(
        "rounded-xl border bg-card p-4 transition-all hover:shadow-md hover:-translate-y-0.5 animate-fade-up group relative overflow-hidden",
      )}
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* shimmer accent on hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
      <div className="flex items-start justify-between relative">
        <div>
          <p className="text-xs font-medium text-muted-foreground">{label}</p>
          <p className={cn("text-2xl font-bold mt-1 tabular-nums", tint)}>
            {animated}
          </p>
          {hint && (
            <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{hint}</p>
          )}
        </div>
        <div className={cn("rounded-lg p-2 transition-transform group-hover:scale-110", bg)}>
          <Icon className={cn("h-4 w-4", tint)} />
        </div>
      </div>
    </div>
  );
}
