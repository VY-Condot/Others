"use client";

import { useState, useMemo } from "react";
import {
  ChevronRight,
  ChevronDown,
  ShieldAlert,
  ArrowUpCircle,
  Package,
  Folder,
  Boxes,
  Search,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import type { DependencyTreeNode, AuditSeverity } from "@/lib/audit";

interface Props {
  tree: DependencyTreeNode;
  onSelect?: (node: DependencyTreeNode) => void;
}

const sevDot: Record<AuditSeverity, string> = {
  low: "bg-yellow-500",
  moderate: "bg-orange-500",
  high: "bg-red-500",
  critical: "bg-red-600",
};

function TreeNodeRow({
  node,
  depth,
  onSelect,
}: {
  node: DependencyTreeNode;
  depth: number;
  onSelect?: (n: DependencyTreeNode) => void;
}) {
  const [open, setOpen] = useState(depth < 1);
  const hasChildren = node.children.length > 0;

  const Icon =
    node.kind === "root" ? Boxes : node.kind === "direct" ? Package : Folder;

  return (
    <div>
      <div
        className={cn(
          "group flex items-center gap-1.5 rounded-md px-2 py-1.5 hover:bg-muted/60 cursor-pointer transition-colors",
          node.isVulnerable && "bg-red-500/5 hover:bg-red-500/10",
        )}
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
        onClick={() => onSelect?.(node)}
        role="treeitem"
        aria-expanded={hasChildren ? open : undefined}
        aria-selected={false}
      >
        {hasChildren ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setOpen((o) => !o);
            }}
            className="text-muted-foreground hover:text-foreground shrink-0"
            aria-label={open ? "Collapse" : "Expand"}
          >
            {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
          </button>
        ) : (
          <span className="w-3.5 shrink-0" />
        )}

        <Icon
          className={cn(
            "h-4 w-4 shrink-0",
            node.kind === "root"
              ? "text-primary"
              : node.isVulnerable
                ? "text-red-500"
                : node.isOutdated
                  ? "text-blue-500"
                  : "text-muted-foreground",
          )}
        />

        <span
          className={cn(
            "text-sm font-medium truncate",
            node.kind === "root" && "font-semibold",
          )}
        >
          {node.label}
        </span>

        <span className="text-xs text-muted-foreground font-mono truncate">
          {node.version}
        </span>

        <div className="ml-auto flex items-center gap-1 shrink-0">
          {node.isVulnerable && node.maxSeverity && (
            <Badge
              variant="outline"
              className={cn(
                "text-[10px] gap-1 border-0",
                sevDot[node.maxSeverity] && "text-white",
              )}
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", sevDot[node.maxSeverity])} />
              {node.maxSeverity}
            </Badge>
          )}
          {node.isOutdated && node.kind === "direct" && (
            <Badge variant="outline" className="text-[10px] gap-1 border-0 text-blue-600 dark:text-blue-400">
              <ArrowUpCircle className="h-3 w-3" />
              outdated
            </Badge>
          )}
          {node.isVulnerable && (
            <ShieldAlert className="h-3.5 w-3.5 text-red-500" />
          )}
        </div>
      </div>

      {open && hasChildren && (
        <div role="group">
          {node.children.map((child, i) => (
            <TreeNodeRow
              key={`${child.id}-${i}`}
              node={child}
              depth={depth + 1}
              onSelect={onSelect}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function DependencyTree({ tree, onSelect }: Props) {
  const [query, setQuery] = useState("");

  // Build a flat searchable list for the filter summary
  const flat = useMemo(() => {
    const out: DependencyTreeNode[] = [];
    const walk = (n: DependencyTreeNode) => {
      out.push(n);
      n.children.forEach(walk);
    };
    walk(tree);
    return out;
  }, [tree]);

  const matches = useMemo(() => {
    if (!query.trim()) return null;
    const q = query.toLowerCase();
    return flat.filter(
      (n) =>
        n.id.toLowerCase().includes(q) ||
        n.label.toLowerCase().includes(q) ||
        n.version.toLowerCase().includes(q),
    );
  }, [query, flat]);

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
        <Input
          placeholder="Filter tree by name or version…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-8 h-8 text-sm"
        />
      </div>

      {matches ? (
        <div className="rounded-md border max-h-[420px] overflow-y-auto custom-scroll divide-y">
          {matches.length === 0 ? (
            <div className="p-4 text-sm text-muted-foreground text-center">No matches for &ldquo;{query}&rdquo;</div>
          ) : (
            matches.map((n, i) => (
              <div
                key={i}
                className="flex items-center gap-2 px-3 py-1.5 hover:bg-muted/60 cursor-pointer text-sm"
                onClick={() => onSelect?.(n)}
              >
                {n.kind === "root" ? (
                  <Boxes className="h-3.5 w-3.5 text-primary" />
                ) : n.kind === "direct" ? (
                  <Package className="h-3.5 w-3.5 text-muted-foreground" />
                ) : (
                  <Folder className="h-3.5 w-3.5 text-muted-foreground/70" />
                )}
                <span className="font-medium">{n.label}</span>
                <span className="font-mono text-xs text-muted-foreground">{n.version}</span>
                {n.isVulnerable && (
                  <Badge variant="outline" className="ml-auto text-[10px] border-red-500/40 text-red-600 dark:text-red-400">
                    {n.maxSeverity}
                  </Badge>
                )}
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="rounded-md border max-h-[420px] overflow-y-auto custom-scroll">
          <TreeNodeRow node={tree} depth={0} onSelect={onSelect} />
        </div>
      )}
    </div>
  );
}
