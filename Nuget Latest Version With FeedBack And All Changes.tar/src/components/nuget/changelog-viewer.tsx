"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { BookOpen, Loader2, ExternalLink, Calendar } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Release {
  version: string;
  releaseNotes: string | null;
  published: string | null;
}

interface Props {
  packageId: string | null;
  version: string | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

export function ChangelogViewer({ packageId, version, open, onOpenChange }: Props) {
  const [releases, setReleases] = useState<Release[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedVersion, setSelectedVersion] = useState<string | null>(null);

  const fetchChangelog = useCallback(async () => {
    if (!packageId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/changelog?id=${encodeURIComponent(packageId)}`);
      const data = await res.json();
      if (data.ok) {
        setReleases(data.releases ?? []);
        setSelectedVersion(data.releases?.[0]?.version ?? version);
      } else {
        setError(data.error || "Failed to load changelog");
      }
    } catch (err) {
      setError(String(err));
    } finally {
      setLoading(false);
    }
  }, [packageId, version]);

  useEffect(() => {
    if (open && packageId) {
      fetchChangelog();
    }
  }, [open, packageId, fetchChangelog]);

  const selected = releases.find((r) => r.version === selectedVersion);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Release notes: <span className="font-mono">{packageId}</span>
          </DialogTitle>
          <DialogDescription>
            Recent versions from nuget.org. Click a version to read its release notes.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col md:flex-row gap-3 flex-1 min-h-0">
          {/* Version list */}
          <div className="md:w-48 shrink-0 rounded-md border overflow-hidden">
            <ScrollArea className="h-[300px] md:h-[420px]">
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                </div>
              ) : releases.length === 0 ? (
                <div className="p-4 text-xs text-muted-foreground text-center">
                  {error ?? "No releases found."}
                </div>
              ) : (
                <div className="divide-y">
                  {releases.map((r) => (
                    <button
                      key={r.version}
                      onClick={() => setSelectedVersion(r.version)}
                      className={cn(
                        "w-full text-left px-3 py-2 hover:bg-muted/50 transition-colors",
                        selectedVersion === r.version && "bg-primary/10",
                      )}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-xs font-semibold truncate">{r.version}</span>
                        {r.releaseNotes && (
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 shrink-0" />
                        )}
                      </div>
                      {r.published && (
                        <p className="text-[10px] text-muted-foreground flex items-center gap-0.5 mt-0.5">
                          <Calendar className="h-2.5 w-2.5" />
                          {new Date(r.published).toLocaleDateString()}
                        </p>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>

          {/* Notes panel */}
          <div className="flex-1 min-w-0 rounded-md border bg-muted/20 overflow-hidden">
            <ScrollArea className="h-[300px] md:h-[420px]">
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                </div>
              ) : selected ? (
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    <Badge variant="secondary" className="font-mono text-xs">{selected.version}</Badge>
                    {selected.published && (
                      <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                        <Calendar className="h-2.5 w-2.5" />
                        {new Date(selected.published).toLocaleDateString()}
                      </span>
                    )}
                    <Button asChild variant="ghost" size="sm" className="ml-auto h-7 text-xs">
                      <a
                        href={`https://www.nuget.org/packages/${encodeURIComponent(packageId ?? "")}/${selected.version}`}
                        target="_blank"
                        rel="noreferrer noopener"
                      >
                        <ExternalLink className="h-3 w-3" /> nuget.org
                      </a>
                    </Button>
                  </div>
                  {selected.releaseNotes ? (
                    <article className="prose prose-sm dark:prose-invert max-w-none text-xs leading-relaxed [&_a]:text-primary [&_a]:underline [&_code]:text-[10px] [&_code]:bg-muted [&_code]:px-1 [&_code]:rounded [&_ul]:list-disc [&_ul]:pl-4 [&_li]:my-0.5 [&_h1]:text-sm [&_h2]:text-sm [&_h3]:text-xs">
                      <ReactMarkdown>{selected.releaseNotes}</ReactMarkdown>
                    </article>
                  ) : (
                    <p className="text-xs text-muted-foreground italic">
                      No release notes published for this version. Check the project repository for details.
                    </p>
                  )}
                </div>
              ) : (
                <div className="p-8 text-center text-xs text-muted-foreground">
                  Select a version to view its release notes.
                </div>
              )}
            </ScrollArea>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
