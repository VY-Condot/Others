"use client";

import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Grid3x3, Info } from "lucide-react";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

// Risk dimensions: each is scored 0-3 for every package
const DIMENSIONS = [
  { key: "vuln", label: "Vuln", short: "V" },
  { key: "outdated", label: "Outdated", short: "O" },
  { key: "major", label: "Major gap", short: "M" },
  { key: "deprecated", label: "Deprecated", short: "D" },
  { key: "pre", label: "Pre-release", short: "P" },
  { key: "license", label: "License risk", short: "L" },
] as const;

type DimKey = (typeof DIMENSIONS)[number]["key"];

function scoreFor(pkg: AuditResult["packages"][number], dim: DimKey): number {
  switch (dim) {
    case "vuln":
      if (!pkg.isVulnerable) return 0;
      return { low: 1, moderate: 2, high: 3, critical: 3 }[pkg.maxSeverity ?? "low"] ?? 1;
    case "outdated":
      return pkg.isOutdated ? 2 : 0;
    case "major": {
      if (!pkg.isOutdated || !pkg.latestStableVersion) return 0;
      const m = pkg.declaredVersion.match(/^(\d+)/);
      const m2 = pkg.latestStableVersion.match(/^(\d+)/);
      if (m && m2) return parseInt(m2[1]) - parseInt(m[1]) >= 2 ? 3 : parseInt(m2[1]) - parseInt(m[1]) >= 1 ? 1 : 0;
      return 0;
    }
    case "deprecated":
      return pkg.isDeprecated ? 2 : 0;
    case "pre":
      return /-[0-9A-Za-z.-]/.test(pkg.declaredVersion) ? 1 : 0;
    case "license":
      return pkg.licenseCategory === "copyleft-strong" || pkg.licenseCategory === "restrictive" || pkg.licenseCategory === "none"
        ? 3
        : pkg.licenseCategory === "copyleft" || pkg.licenseCategory === "unknown"
          ? 1
          : 0;
    default:
      return 0;
  }
}

const HEAT_COLORS = [
  "#10b981", // 0 — ok (green)
  "#eab308", // 1 — low (yellow)
  "#f97316", // 2 — medium (orange)
  "#ef4444", // 3 — high (red)
];

export function RiskHeatmap({ result }: Props) {
  const rows = useMemo(() => {
    return result.packages
      .map((p) => ({
        pkg: p,
        scores: DIMENSIONS.map((d) => scoreFor(p, d.key)),
        total: DIMENSIONS.reduce((acc, d) => acc + scoreFor(p, d.key), 0),
      }))
      .sort((a, b) => b.total - a.total);
  }, [result]);

  const maxTotal = Math.max(...rows.map((r) => r.total), 1);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Grid3x3 className="h-4 w-4" />
              Risk heatmap
            </CardTitle>
            <CardDescription className="text-xs mt-1">
              Each row is a package, each column a risk dimension. Color intensity = risk level.
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b">
              <th className="text-left py-1.5 pr-2 font-medium text-muted-foreground sticky left-0 bg-card z-10 min-w-[140px]">
                Package
              </th>
              {DIMENSIONS.map((d) => (
                <th key={d.key} className="px-1 py-1.5 text-center font-medium text-muted-foreground" title={d.label}>
                  <span className="hidden md:inline">{d.label}</span>
                  <span className="md:hidden">{d.short}</span>
                </th>
              ))}
              <th className="pl-2 py-1.5 text-right font-medium text-muted-foreground">Score</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ pkg, scores, total }, idx) => (
              <tr key={`${pkg.id}-${idx}`} className="border-b last:border-b-0 hover:bg-muted/20">
                <td className="py-1.5 pr-2 font-mono truncate max-w-[140px] sticky left-0 bg-card z-10" title={pkg.id}>
                  {pkg.id}
                </td>
                {scores.map((s, i) => (
                  <td key={i} className="px-1 py-1.5 text-center">
                    <div
                      className="h-5 w-5 rounded-sm mx-auto flex items-center justify-center text-[9px] font-bold text-white"
                      style={{ background: HEAT_COLORS[s], opacity: s === 0 ? 0.15 : 0.85 }}
                      title={`${DIMENSIONS[i].label}: ${["none", "low", "medium", "high"][s]}`}
                    >
                      {s > 0 ? s : ""}
                    </div>
                  </td>
                ))}
                <td className="pl-2 py-1.5 text-right">
                  <div className="flex items-center justify-end gap-1.5">
                    <div className="h-1.5 w-12 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${(total / maxTotal) * 100}%`,
                          background: total > 6 ? "#ef4444" : total > 3 ? "#f97316" : total > 0 ? "#eab308" : "#10b981",
                        }}
                      />
                    </div>
                    <span className="font-mono font-semibold tabular-nums w-5 text-right">{total}</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex items-center gap-3 mt-3 pt-2 border-t text-[10px] text-muted-foreground">
          <span>Risk level:</span>
          {[0, 1, 2, 3].map((s) => (
            <span key={s} className="flex items-center gap-1">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: HEAT_COLORS[s], opacity: s === 0 ? 0.15 : 0.85 }} />
              {["none", "low", "medium", "high"][s]}
            </span>
          ))}
          <span className="ml-auto flex items-center gap-1">
            <Info className="h-2.5 w-2.5" />
            Sorted by total risk score
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
