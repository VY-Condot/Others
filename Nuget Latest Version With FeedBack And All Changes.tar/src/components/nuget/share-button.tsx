"use client";

import { useState } from "react";
import { Share2, Copy, Check, Loader2, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

export function ShareButton({ result }: Props) {
  const [sharing, setSharing] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const share = async () => {
    setSharing(true);
    setShareUrl(null);
    try {
      const res = await fetch("/api/share", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result }),
      });
      const data = await res.json();
      if (data.ok) {
        const url = `${window.location.origin}/?share=${data.id}`;
        setShareUrl(url);
        toast.success("Share link created — copy it to share your audit");
      } else {
        toast.error("Share failed", { description: data.error });
      }
    } catch (err) {
      toast.error("Share failed", { description: String(err) });
    } finally {
      setSharing(false);
    }
  };

  const copy = async () => {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Copy failed");
    }
  };

  return (
    <div className="flex items-center gap-1.5">
      {shareUrl ? (
        <>
          <div className="flex items-center gap-1.5 rounded-md border bg-muted/40 px-2 py-1 max-w-[200px]">
            <input
              readOnly
              value={shareUrl}
              className="text-[10px] font-mono bg-transparent outline-none w-full truncate"
              onClick={(e) => (e.target as HTMLInputElement).select()}
            />
          </div>
          <Button variant="outline" size="icon" className="h-7 w-7 shrink-0" onClick={copy} aria-label="Copy share link">
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
        </>
      ) : (
        <Button
          variant="outline"
          size="sm"
          className="text-xs gap-1.5"
          onClick={share}
          disabled={sharing}
        >
          {sharing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Share2 className="h-3.5 w-3.5" />}
          <span className="hidden sm:inline">Share</span>
        </Button>
      )}
    </div>
  );
}
