"use client";

import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { PieChart as PieChartIcon, Info } from "lucide-react";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

interface Slice {
  name: string;
  value: number;
  color: string;
  packages: { id: string; status: string }[];
}

const PALETTE = [
  "#3b82f6", // blue
  "#8b5cf6", // purple
  "#ec4899", // pink
  "#f59e0b", // amber
  "#10b981", // emerald
  "#06b6d4", // cyan
  "#f97316", // orange
  "#84cc16", // lime
  "#a855f7", // violet
  "#14b8a6", // teal
  "#ef4444", // red
  "#6366f1", // indigo
];

const STATUS_COLOR: Record<string, string> = {
  ok: "#10b981",
  outdated: "#3b82f6",
  vulnerable: "#ef4444",
  deprecated: "#f59e0b",
};

function statusOf(p: { isVulnerable: boolean; isOutdated: boolean; isDeprecated: boolean }): string {
  if (p.isVulnerable) return "vulnerable";
  if (p.isOutdated) return "outdated";
  if (p.isDeprecated) return "deprecated";
  return "ok";
}

function namespaceOf(id: string): string {
  if (id.startsWith("Microsoft.AspNetCore.")) return "AspNetCore";
  if (id.startsWith("Microsoft.Extensions.")) return "Extensions";
  if (id.startsWith("Microsoft.EntityFrameworkCore.")) return "EFCore";
  if (id.startsWith("Microsoft.")) return "Microsoft (other)";
  if (id.startsWith("System.")) return "System";
  if (id.startsWith("Serilog")) return "Serilog";
  if (id.startsWith("OpenTelemetry")) return "OpenTelemetry";
  if (id.startsWith("Swashbuckle")) return "Swashbuckle";
  if (id.startsWith("AutoMapper")) return "AutoMapper";
  if (id.startsWith("MediatR")) return "MediatR";
  if (id.startsWith("FluentValidation")) return "FluentValidation";
  if (id.startsWith("Polly")) return "Polly";
  if (id.startsWith("Newtonsoft")) return "Newtonsoft";
  if (id.startsWith("CsvHelper")) return "CsvHelper";
  if (id.startsWith("Dapper")) return "Dapper";
  if (id.startsWith("Npgsql")) return "Npgsql";
  return "Other";
}

export function SunburstChart({ result }: Props) {
  const slices = useMemo<Slice[]>(() => {
    const buckets = new Map<string, { id: string; status: string }[]>();
    for (const p of result.packages) {
      const ns = namespaceOf(p.id);
      if (!buckets.has(ns)) buckets.set(ns, []);
      buckets.get(ns)!.push({ id: p.id, status: statusOf(p) });
    }
    return Array.from(buckets.entries())
      .map(([name, packages], i) => ({
        name,
        value: packages.length,
        color: PALETTE[i % PALETTE.length],
        packages,
      }))
      .sort((a, b) => b.value - a.value);
  }, [result]);

  // Inner ring = aggregated status (ok/outdated/vulnerable/deprecated)
  const innerRing = useMemo(() => {
    const counts: Record<string, number> = { ok: 0, outdated: 0, vulnerable: 0, deprecated: 0 };
    for (const p of result.packages) {
      counts[statusOf(p)]++;
    }
    return Object.entries(counts)
      .filter(([, v]) => v > 0)
      .map(([name, value]) => ({ name, value, color: STATUS_COLOR[name] }));
  }, [result]);

  const total = result.packages.length;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <PieChartIcon className="h-4 w-4" />
          Dependency sunburst
        </CardTitle>
        <CardDescription className="text-xs">
          Outer ring: packages grouped by namespace. Inner ring: overall status mix.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row items-center gap-4">
          <ResponsiveContainer width="100%" minWidth={220} height={240} className="max-w-[280px]">
            <PieChart>
              {/* Outer ring: by namespace */}
              <Pie
                data={slices}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={70}
                outerRadius={105}
                paddingAngle={1}
                stroke="var(--background)"
                strokeWidth={2}
              >
                {slices.map((s, i) => (
                  <Cell key={i} fill={s.color} fillOpacity={0.85} />
                ))}
              </Pie>
              {/* Inner ring: by status */}
              <Pie
                data={innerRing}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={38}
                outerRadius={66}
                paddingAngle={1}
                stroke="var(--background)"
                strokeWidth={2}
              >
                {innerRing.map((s, i) => (
                  <Cell key={i} fill={s.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: "8px",
                  fontSize: "11px",
                }}
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const p = payload[0].payload as Slice;
                  return (
                    <div className="rounded-md border bg-popover px-2.5 py-1.5 text-xs shadow-lg max-w-[200px]">
                      <p className="font-semibold" style={{ color: p.color }}>
                        {p.name}
                      </p>
                      <p className="text-muted-foreground">{p.value} package{p.value === 1 ? "" : "s"}</p>
                      {p.packages && (
                        <div className="mt-1 space-y-0.5">
                          {p.packages.slice(0, 5).map((pkg, pidx) => (
                            <div key={`${pkg.id}-${pidx}`} className="flex items-center gap-1 text-[10px] font-mono">
                              <span
                                className="h-1.5 w-1.5 rounded-full shrink-0"
                                style={{ background: STATUS_COLOR[pkg.status] }}
                              />
                              <span className="truncate">{pkg.id}</span>
                            </div>
                          ))}
                          {p.packages.length > 5 && (
                            <p className="text-[10px] text-muted-foreground">+{p.packages.length - 5} more</p>
                          )}
                        </div>
                      )}
                    </div>
                  );
                }}
              />
            </PieChart>
          </ResponsiveContainer>

          {/* Legend */}
          <div className="flex-1 min-w-0 space-y-2 w-full">
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">Namespaces</p>
              <div className="space-y-1 max-h-[120px] overflow-y-auto custom-scroll pr-1">
                {slices.map((s) => (
                  <div key={s.name} className="flex items-center gap-2 text-xs">
                    <span className="h-2.5 w-2.5 rounded-sm shrink-0" style={{ background: s.color }} />
                    <span className="font-mono truncate flex-1">{s.name}</span>
                    <span className="font-mono font-semibold tabular-nums text-muted-foreground">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="border-t pt-2">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">Status mix</p>
              <div className="flex flex-wrap gap-2">
                {innerRing.map((s) => (
                  <div key={s.name} className="flex items-center gap-1.5 text-xs">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                    <span className="capitalize">{s.name}</span>
                    <span className="font-mono font-semibold tabular-nums">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex items-start gap-1.5 text-[10px] text-muted-foreground pt-1 border-t">
              <Info className="h-3 w-3 shrink-0 mt-0.5" />
              <span>Hover any slice to see its packages. {total} packages total across {slices.length} namespaces.</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
