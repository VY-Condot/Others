"use client";

import { useMemo } from "react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { TrendingUp, PieChart as PieIcon, Radar as RadarIcon, Activity } from "lucide-react";
import type { AuditResult } from "@/lib/audit";
import semver from "semver";

interface Props {
  result: AuditResult;
}

const STATUS_COLORS = {
  ok: "#10b981",
  outdated: "#3b82f6",
  vulnerable: "#ef4444",
  deprecated: "#f59e0b",
  prerelease: "#a855f7",
};

/**
 * Dependency analytics dashboard with four visualizations:
 *  1. Status donut — distribution of ok / outdated / vulnerable / deprecated
 *  2. Version-age bar — how many major versions behind each outdated package is
 *  3. Risk radar — 5-axis health assessment (freshness, security, stability, compliance, modernity)
 *  4. Category breakdown — packages grouped by namespace prefix (Microsoft.*, System.*, etc.)
 */
export function AnalyticsDashboard({ result }: Props) {
  const statusData = useMemo(() => {
    const ok = result.packages.filter((p) => !p.isOutdated && !p.isVulnerable && !p.isDeprecated).length;
    const outdated = result.packages.filter((p) => p.isOutdated && !p.isVulnerable).length;
    const vulnerable = result.packages.filter((p) => p.isVulnerable).length;
    const deprecated = result.packages.filter((p) => p.isDeprecated && !p.isVulnerable).length;
    return [
      { name: "Up to date", value: ok, color: STATUS_COLORS.ok },
      { name: "Outdated", value: outdated, color: STATUS_COLORS.outdated },
      { name: "Vulnerable", value: vulnerable, color: STATUS_COLORS.vulnerable },
      { name: "Deprecated", value: deprecated, color: STATUS_COLORS.deprecated },
    ].filter((d) => d.value > 0);
  }, [result]);

  const versionGapData = useMemo(() => {
    return result.packages
      .filter((p) => p.isOutdated && p.latestStableVersion && p.declaredVersion)
      .map((p) => {
        const declared = semver.coerce(p.declaredVersion);
        const latest = semver.coerce(p.latestStableVersion!);
        // Compute a numeric "versions behind" that includes minor gaps.
        // major * 100 + minor gives a sortable integer where 1.17 > 1.5.
        const behind = declared && latest
          ? Math.max(0, (latest.major * 100 + latest.minor) - (declared.major * 100 + declared.minor))
          : 0;
        return {
          name: p.id.length > 18 ? p.id.slice(0, 17) + "…" : p.id,
          fullName: p.id,
          behind,
          declared: p.declaredVersion,
          latest: p.latestStableVersion,
        };
      })
      .sort((a, b) => b.behind - a.behind)
      .slice(0, 12);
  }, [result]);

  const radarData = useMemo(() => {
    const total = result.stats.totalPackages || 1;
    // Freshness: % up-to-date
    const freshness = Math.round(((total - result.stats.outdatedCount) / total) * 100);
    // Security: % non-vulnerable, weighted by severity
    const vulnPenalty = result.packages.reduce((acc, p) => {
      if (!p.maxSeverity) return acc;
      const w = { low: 5, moderate: 15, high: 35, critical: 60 }[p.maxSeverity] ?? 15;
      return acc + w;
    }, 0);
    const security = Math.max(0, 100 - vulnPenalty);
    // Stability: % non-deprecated
    const stability = Math.round(((total - result.stats.deprecatedCount) / total) * 100);
    // Compliance: % resolved from live source (not fallback/error)
    const compliance = Math.round((result.stats.sources.live / total) * 100);
    // Modernity: % on latest major (declared major == latest major)
    const modern = result.packages.filter((p) => {
      const d = semver.coerce(p.declaredVersion);
      const l = p.latestStableVersion ? semver.coerce(p.latestStableVersion) : null;
      return d && l && d.major >= l.major;
    }).length;
    const modernity = Math.round((modern / total) * 100);
    return [
      { axis: "Freshness", value: Math.max(freshness, 2) },
      { axis: "Security", value: Math.max(security, 2) },
      { axis: "Stability", value: Math.max(stability, 2) },
      { axis: "Compliance", value: Math.max(compliance, 2) },
      { axis: "Modernity", value: Math.max(modernity, 2) },
    ];
  }, [result]);

  const categoryData = useMemo(() => {
    const buckets: Record<string, number> = {};
    for (const p of result.packages) {
      let cat = "Other";
      if (p.id.startsWith("Microsoft.")) cat = "Microsoft.*";
      else if (p.id.startsWith("System.")) cat = "System.*";
      else if (p.id.startsWith("Serilog")) cat = "Serilog";
      else if (p.id.startsWith("Microsoft.AspNetCore")) cat = "AspNetCore";
      else if (p.id.startsWith("OpenTelemetry")) cat = "OpenTelemetry";
      buckets[cat] = (buckets[cat] || 0) + 1;
    }
    return Object.entries(buckets)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [result]);

  const avgBehind = versionGapData.length > 0
    ? (versionGapData.reduce((a, b) => a + b.behind, 0) / versionGapData.length).toFixed(1)
    : "0";

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Status donut */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <PieIcon className="h-4 w-4 text-primary" />
              Package status distribution
            </CardTitle>
            <CardDescription className="text-xs">
              {result.stats.totalPackages} packages categorized by audit outcome
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <ResponsiveContainer width="50%" height={180}>
                <PieChart>
                  <Pie
                    data={statusData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={2}
                    stroke="none"
                  >
                    {statusData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-1.5">
                {statusData.map((d) => (
                  <div key={d.name} className="flex items-center gap-2 text-xs">
                    <span className="h-2.5 w-2.5 rounded-sm" style={{ background: d.color }} />
                    <span className="flex-1">{d.name}</span>
                    <span className="font-mono font-semibold tabular-nums">{d.value}</span>
                    <span className="text-muted-foreground tabular-nums">
                      {Math.round((d.value / result.stats.totalPackages) * 100)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk radar */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <RadarIcon className="h-4 w-4 text-primary" />
              Health radar
            </CardTitle>
            <CardDescription className="text-xs">
              5-axis assessment — higher is better
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="72%">
                <PolarGrid stroke="var(--border)" />
                <PolarAngleAxis dataKey="axis" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} />
                <PolarRadiusAxis domain={[0, 100]} tick={{ fill: "var(--muted-foreground)", fontSize: 9 }} angle={90} />
                <Radar
                  name="Score"
                  dataKey="value"
                  stroke="var(--primary)"
                  fill="var(--primary)"
                  fillOpacity={0.35}
                  strokeWidth={2}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Version gap bar */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Major versions behind
            </CardTitle>
            <CardDescription className="text-xs">
              Outdated packages ranked by major-version gap · avg {avgBehind} major behind
            </CardDescription>
          </CardHeader>
          <CardContent>
            {versionGapData.length === 0 ? (
              <div className="h-[200px] flex items-center justify-center text-xs text-muted-foreground">
                All packages are on their latest major version 🎉
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={versionGapData} layout="vertical" margin={{ left: 10, right: 10 }}>
                  <XAxis type="number" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} stroke="var(--border)" />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={110}
                    tick={{ fill: "var(--muted-foreground)", fontSize: 10 }}
                    stroke="var(--border)"
                  />
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                    formatter={(v: number) => [`${v} major version(s) behind`, "Gap"]}
                  />
                  <Bar dataKey="behind" radius={[0, 4, 4, 0]} fill="var(--primary)" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Category breakdown */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              Namespace categories
            </CardTitle>
            <CardDescription className="text-xs">
              Packages grouped by publisher namespace prefix
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={categoryData} margin={{ left: 0, right: 10, top: 5 }}>
                <XAxis dataKey="name" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} stroke="var(--border)" />
                <YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} stroke="var(--border)" allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                  cursor={{ fill: "var(--muted)", opacity: 0.3 }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]} fill="var(--chart-2)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Insight strip */}
      <Card className="bg-gradient-to-r from-primary/5 via-transparent to-purple-500/5 border-primary/20">
        <CardContent className="pt-4 pb-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
            <Insight label="Avg versions behind" value={avgBehind} suffix="major" />
            <Insight
              label="Freshness"
              value={`${radarData[0].value}%`}
              suffix="up-to-date"
            />
            <Insight
              label="Security"
              value={`${radarData[1].value}/100`}
              suffix={result.stats.vulnerableCount === 0 ? "clean" : `${result.stats.vulnerableCount} vuln`}
            />
            <Insight
              label="Data source"
              value={`${result.stats.sources.live}/${result.stats.totalPackages}`}
              suffix="live"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function Insight({ label, value, suffix }: { label: string; value: string; suffix: string }) {
  return (
    <div>
      <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
      <p className="text-xl font-bold tabular-nums mt-0.5">{value}</p>
      <p className="text-[10px] text-muted-foreground">{suffix}</p>
    </div>
  );
}
