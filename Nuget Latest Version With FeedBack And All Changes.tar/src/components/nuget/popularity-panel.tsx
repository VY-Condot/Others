"use client";

import { useEffect, useState, useMemo } from "react";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Loader2, Users, Award } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

interface PopData {
  totalDownloads: number;
  verified: boolean;
  latestVersion: string | null;
}

interface Point {
  id: string;
  x: number; // log10(downloads)
  y: number; // risk score (0=ok, 4=critical)
  z: number; // downloads (for bubble size)
  downloads: number;
  isVulnerable: boolean;
  isOutdated: boolean;
  maxSeverity: string | null;
  verified: boolean;
}

const RISK_SCORE: Record<string, number> = {
  low: 1,
  moderate: 2,
  high: 3,
  critical: 4,
};

export function PopularityPanel({ result }: Props) {
  const [popularity, setPopularity] = useState<Record<string, PopData>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const ids = result.packages.map((p) => p.id).join(",");
    if (!ids) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setLoading(false);
      return;
    }
    setLoading(true);
    fetch(`/api/popularity?ids=${encodeURIComponent(ids)}`)
      .then((r) => r.json())
      .then((data) => {
        if (!cancelled && data.ok) {
          setPopularity(data.popularity ?? {});
        }
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [result]);

  const points: Point[] = useMemo(() => {
    return result.packages
      .map((p) => {
        const pop = popularity[p.id.toLowerCase()];
        if (!pop || pop.totalDownloads === 0) return null;
        const risk = p.isVulnerable && p.maxSeverity
          ? RISK_SCORE[p.maxSeverity] ?? 1
          : p.isOutdated
            ? 0.5
            : 0;
        return {
          id: p.id,
          x: Math.log10(pop.totalDownloads),
          y: risk,
          z: Math.max(4, Math.min(40, Math.log10(pop.totalDownloads) * 4)),
          downloads: pop.totalDownloads,
          isVulnerable: p.isVulnerable,
          isOutdated: p.isOutdated,
          maxSeverity: p.maxSeverity,
          verified: pop.verified,
        };
      })
      .filter((p): p is Point => p !== null);
  }, [result, popularity]);

  const topPackages = useMemo(() => {
    return [...points].sort((a, b) => b.downloads - a.downloads).slice(0, 8);
  }, [points]);

  const totalDownloads = useMemo(
    () => points.reduce((acc, p) => acc + p.downloads, 0),
    [points],
  );

  const verifiedCount = points.filter((p) => p.verified).length;

  const colorFor = (p: Point) => {
    if (p.isVulnerable) return "#ef4444";
    if (p.isOutdated) return "#3b82f6";
    return "#10b981";
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Package popularity
            </CardTitle>
            <CardDescription className="text-xs mt-1">
              Download counts from nuget.org · {points.length} packages with data
            </CardDescription>
          </div>
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          ) : (
            <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1">
                <Users className="h-3 w-3" />
                {(totalDownloads / 1_000_000).toFixed(1)}M total
              </span>
              <span className="flex items-center gap-1">
                <Award className="h-3 w-3 text-emerald-500" />
                {verifiedCount} verified
              </span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading ? (
          <div className="h-[200px] flex items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : points.length === 0 ? (
          <div className="h-[200px] flex items-center justify-center text-xs text-muted-foreground">
            No download data available.
          </div>
        ) : (
          <>
            {/* Scatter: popularity vs risk */}
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-2">
                Downloads vs risk
              </p>
              <ResponsiveContainer width="100%" height={220}>
                <ScatterChart margin={{ left: 0, right: 16, top: 5, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.4} />
                  <XAxis
                    type="number"
                    dataKey="x"
                    name="Downloads (log)"
                    tick={{ fill: "var(--muted-foreground)", fontSize: 10 }}
                    stroke="var(--border)"
                    tickFormatter={(v) => formatLogDownloads(v)}
                    label={{ value: "Downloads (log scale)", position: "insideBottom", offset: -2, style: { fill: "var(--muted-foreground)", fontSize: 10 } }}
                  />
                  <YAxis
                    type="number"
                    dataKey="y"
                    name="Risk"
                    domain={[-0.5, 4.5]}
                    ticks={[0, 1, 2, 3, 4]}
                    tickFormatter={(v) => ["ok", "low", "mod", "high", "crit"][v] ?? ""}
                    tick={{ fill: "var(--muted-foreground)", fontSize: 10 }}
                    stroke="var(--border)"
                    width={36}
                  />
                  <ZAxis type="number" dataKey="z" range={[20, 400]} />
                  <Tooltip
                    cursor={{ strokeDasharray: "3 3" }}
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                      fontSize: "11px",
                    }}
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      const p = payload[0].payload as Point;
                      return (
                        <div className="rounded-md border bg-popover px-2.5 py-1.5 text-xs shadow-lg">
                          <p className="font-mono font-semibold">{p.id}</p>
                          <p className="text-muted-foreground">{formatDownloads(p.downloads)} downloads</p>
                          <p className="text-muted-foreground">
                            Risk: {p.isVulnerable ? `${p.maxSeverity} vulnerability` : p.isOutdated ? "outdated" : "ok"}
                          </p>
                          {p.verified && (
                            <p className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                              <Award className="h-2.5 w-2.5" /> verified
                            </p>
                          )}
                        </div>
                      );
                    }}
                  />
                  <Scatter data={points}>
                    {points.map((p, i) => (
                      <Cell key={i} fill={colorFor(p)} fillOpacity={0.7} stroke={colorFor(p)} />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
            </div>

            {/* Top packages list */}
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-2">
                Most downloaded in your project
              </p>
              <div className="space-y-1">
                {topPackages.map((p, i) => (
                  <div
                    key={`${p.id}-${i}`}
                    className="flex items-center gap-2 rounded-md border bg-card px-2.5 py-1.5 text-xs hover:bg-muted/30 transition-colors"
                  >
                    <span className="font-mono font-bold text-muted-foreground w-5 shrink-0">{i + 1}</span>
                    <span className="font-mono font-medium truncate flex-1">{p.id}</span>
                    {p.verified && (
                      <Award className="h-3 w-3 text-emerald-500 shrink-0" />
                    )}
                    {p.isVulnerable && (
                      <Badge variant="outline" className="text-[9px] border-red-500/40 text-red-600 dark:text-red-400 bg-red-500/10 shrink-0">
                        {p.maxSeverity}
                      </Badge>
                    )}
                    {p.isOutdated && !p.isVulnerable && (
                      <Badge variant="outline" className="text-[9px] border-blue-500/40 text-blue-600 dark:text-blue-400 bg-blue-500/10 shrink-0">
                        old
                      </Badge>
                    )}
                    <span className="font-mono text-muted-foreground tabular-nums shrink-0">
                      {formatDownloads(p.downloads)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3 text-[10px] text-muted-foreground pt-1 border-t">
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-emerald-500" /> ok
              </span>
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-blue-500" /> outdated
              </span>
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-red-500" /> vulnerable
              </span>
              <span className="ml-auto">Bubble size ∝ log(downloads)</span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function formatDownloads(n: number): string {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(1)}B`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
  return String(n);
}

function formatLogDownloads(v: number): string {
  const n = Math.pow(10, v);
  return formatDownloads(n);
}
