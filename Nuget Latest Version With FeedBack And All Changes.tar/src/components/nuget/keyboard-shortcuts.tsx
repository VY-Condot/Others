"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Keyboard, CornerDownLeft } from "lucide-react";

interface Shortcuts {
  [key: string]: { desc: string; group: string };
}

const SHORTCUTS: Shortcuts = {
  "?": { desc: "Show this help", group: "Global" },
  "/": { desc: "Focus the package filter", group: "Global" },
  "h": { desc: "Open audit history", group: "Global" },
  "s": { desc: "Save current audit", group: "Global" },
  "n": { desc: "Start a new audit", group: "Global" },
  "g t": { desc: "Go to Tree tab", group: "Navigation" },
  "g v": { desc: "Go to Vulnerabilities tab", group: "Navigation" },
  "g o": { desc: "Go to Outdated tab", group: "Navigation" },
  "g a": { desc: "Go to Analytics tab", group: "Navigation" },
  "g p": { desc: "Go to All packages tab", group: "Navigation" },
  "g u": { desc: "Go to Upgrade & export tab", group: "Navigation" },
  "g f": { desc: "Go to Force graph tab", group: "Navigation" },
  "Escape": { desc: "Close dialogs / panels", group: "Global" },
};

interface Props {
  onShortcut: (key: string) => void;
}

export function KeyboardShortcuts({ onShortcut }: Props) {
  const [helpOpen, setHelpOpen] = useState(false);
  // Track multi-key sequences (e.g. "g t")
  const sequenceRef = useState(() => ({ current: "", timer: null as NodeJS.Timeout | null }))[0];

  const handleKey = useCallback(
    (e: KeyboardEvent) => {
      // Don't intercept when typing in inputs/textareas
      const target = e.target as HTMLElement;
      if (
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.isContentEditable
      ) {
        // Only allow Escape to blur
        if (e.key === "Escape") {
          target.blur();
        }
        return;
      }

      const key = e.key.toLowerCase();

      // Handle multi-key sequence "g X"
      if (sequenceRef.current === "g" && ["t", "v", "o", "a", "p", "u", "f"].includes(key)) {
        e.preventDefault();
        onShortcut(`g ${key}`);
        sequenceRef.current = "";
        if (sequenceRef.timer) clearTimeout(sequenceRef.timer);
        return;
      }

      // Start "g" sequence
      if (key === "g" && !e.metaKey && !e.ctrlKey) {
        sequenceRef.current = "g";
        if (sequenceRef.timer) clearTimeout(sequenceRef.timer);
        sequenceRef.timer = setTimeout(() => {
          sequenceRef.current = "";
        }, 800);
        e.preventDefault();
        return;
      }

      // Single-key shortcuts
      if (SHORTCUTS[key] || SHORTCUTS[e.key]) {
        e.preventDefault();
        const k = SHORTCUTS[key] ? key : e.key;
        if (k === "?") {
          setHelpOpen((o) => !o);
        } else {
          onShortcut(k);
        }
      }
    },
    [onShortcut, sequenceRef],
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [handleKey]);

  // Group shortcuts for display
  const groups = Object.entries(SHORTCUTS).reduce(
    (acc, [key, val]) => {
      if (!acc[val.group]) acc[val.group] = [];
      acc[val.group].push({ key, ...val });
      return acc;
    },
    {} as Record<string, Array<{ key: string; desc: string }>>,
  );

  return (
    <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Keyboard className="h-4 w-4" />
            Keyboard shortcuts
          </DialogTitle>
          <DialogDescription>
            Navigate the auditor faster without leaving your keyboard.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          {Object.entries(groups).map(([group, items]) => (
            <div key={group}>
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                {group}
              </p>
              <div className="space-y-1.5">
                {items.map(({ key, desc }) => (
                  <div key={key} className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{desc}</span>
                    <div className="flex items-center gap-1">
                      {key.includes(" ") ? (
                        key.split(" ").map((part, i) => (
                          <kbd
                            key={i}
                            className="min-w-[24px] h-6 px-1.5 inline-flex items-center justify-center rounded border bg-muted font-mono text-[10px] font-semibold"
                          >
                            {part}
                          </kbd>
                        ))
                      ) : (
                        <kbd className="min-w-[24px] h-6 px-1.5 inline-flex items-center justify-center rounded border bg-muted font-mono text-[10px] font-semibold">
                          {key === " " ? "Space" : key === "?" ? "?" : key.toUpperCase()}
                        </kbd>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground pt-2 border-t">
            <CornerDownLeft className="h-3 w-3" />
            Press <kbd className="px-1 rounded border bg-muted font-mono text-[10px]">?</kbd> anywhere to toggle this help.
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
