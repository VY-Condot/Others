"use client";

import { useMemo } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, GitCompare, ShieldAlert, ArrowUpCircle, CheckCircle2 } from "lucide-react";
import semver from "semver";
import { cn } from "@/lib/utils";
import type { AuditedPackage } from "@/lib/audit";

interface Props {
  pkg: AuditedPackage | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

interface DiffRow {
  label: string;
  declared: string;
  latest: string;
  status: "same" | "improved" | "changed" | "worse" | "n/a";
}

/**
 * Side-by-side version comparison dialog.
 * Shows declared vs latest-stable with a semantic diff (major/minor/patch),
 * vulnerability status change, and a one-line recommendation.
 */
export function VersionCompareDialog({ pkg, open, onOpenChange }: Props) {
  const diff = useMemo(() => {
    if (!pkg || !pkg.latestStableVersion) return null;
    const declared = semver.coerce(pkg.declaredVersion);
    const latest = semver.coerce(pkg.latestStableVersion);
    if (!declared || !latest) return null;

    const rows: DiffRow[] = [
      {
        label: "Major",
        declared: String(declared.major),
        latest: String(latest.major),
        status: latest.major > declared.major ? "changed" : latest.major < declared.major ? "worse" : "same",
      },
      {
        label: "Minor",
        declared: String(declared.minor),
        latest: String(latest.minor),
        status: latest.major !== declared.major ? "n/a" : latest.minor > declared.minor ? "improved" : latest.minor < declared.minor ? "worse" : "same",
      },
      {
        label: "Patch",
        declared: String(declared.patch),
        latest: String(latest.patch),
        status: latest.major !== declared.major || latest.minor !== declared.minor ? "n/a" : latest.patch > declared.patch ? "improved" : latest.patch < declared.patch ? "worse" : "same",
      },
      {
        label: "Pre-release",
        declared: declared.prerelease.length ? declared.prerelease.join(".") : "stable",
        latest: latest.prerelease.length ? latest.prerelease.join(".") : "stable",
        status: declared.prerelease.length > 0 && latest.prerelease.length === 0 ? "improved" : "same",
      },
      {
        label: "Vulnerabilities",
        declared: pkg.isVulnerable ? `${pkg.vulnerabilities.length} found` : "none",
        latest: pkg.vulnerabilities.length > 0 ? `${pkg.vulnerabilities.length} found` : "none",
        status: pkg.isVulnerable ? "worse" : "same",
      },
    ];

    const majorBump = latest.major > declared.major;
    const minorBump = latest.major === declared.major && latest.minor > declared.minor;
    const patchBump = latest.major === declared.major && latest.minor === declared.minor && latest.patch > declared.patch;

    let recommendation = "";
    let riskLevel: "low" | "medium" | "high" = "low";
    if (pkg.isVulnerable) {
      recommendation = "Upgrade immediately — this version has known security advisories.";
      riskLevel = "high";
    } else if (majorBump) {
      recommendation = `Major version bump (${declared.major}→${latest.major}). Review the changelog for breaking API changes before upgrading.`;
      riskLevel = "medium";
    } else if (minorBump) {
      recommendation = "Minor version bump — generally safe (backward compatible features).";
      riskLevel = "low";
    } else if (patchBump) {
      recommendation = "Patch bump — safe to upgrade (bug fixes only).";
      riskLevel = "low";
    } else {
      recommendation = "Already on the latest version — no action needed.";
      riskLevel = "low";
    }

    return { rows, majorBump, minorBump, patchBump, recommendation, riskLevel, declared, latest };
  }, [pkg]);

  if (!pkg) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitCompare className="h-4 w-4" />
            Version comparison:{" "}
            <span className="font-mono">{pkg.id}</span>
          </DialogTitle>
          <DialogDescription>
            Semantic diff between your declared version and the latest stable release.
          </DialogDescription>
        </DialogHeader>

        {!diff ? (
          <div className="py-8 text-center text-sm text-muted-foreground">
            {pkg.latestStableVersion ? "Unable to parse versions for comparison." : "No latest stable version available from nuget.org."}
          </div>
        ) : (
          <div className="space-y-4">
            {/* Version flow */}
            <div className="flex items-center justify-center gap-3 py-3 rounded-lg bg-muted/40">
              <div className="text-center">
                <p className="text-[10px] text-muted-foreground uppercase">Declared</p>
                <p className="font-mono font-bold text-lg">{pkg.declaredVersion}</p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
              <div className="text-center">
                <p className="text-[10px] text-muted-foreground uppercase">Latest stable</p>
                <p className="font-mono font-bold text-lg text-emerald-600 dark:text-emerald-400">
                  {pkg.latestStableVersion}
                </p>
              </div>
            </div>

            {/* Bump badges */}
            <div className="flex items-center justify-center gap-2 flex-wrap">
              {diff.majorBump && (
                <Badge variant="outline" className="border-orange-500/40 text-orange-700 dark:text-orange-300 bg-orange-500/10">
                  <ArrowUpCircle className="h-3 w-3 mr-1" /> Major bump
                </Badge>
              )}
              {diff.minorBump && (
                <Badge variant="outline" className="border-blue-500/40 text-blue-700 dark:text-blue-300 bg-blue-500/10">
                  <ArrowUpCircle className="h-3 w-3 mr-1" /> Minor bump
                </Badge>
              )}
              {diff.patchBump && (
                <Badge variant="outline" className="border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10">
                  <ArrowUpCircle className="h-3 w-3 mr-1" /> Patch bump
                </Badge>
              )}
              {pkg.isVulnerable && (
                <Badge variant="outline" className="border-red-500/40 text-red-700 dark:text-red-300 bg-red-500/10">
                  <ShieldAlert className="h-3 w-3 mr-1" /> Vulnerable
                </Badge>
              )}
              {!diff.majorBump && !diff.minorBump && !diff.patchBump && !pkg.isVulnerable && (
                <Badge variant="outline" className="border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10">
                  <CheckCircle2 className="h-3 w-3 mr-1" /> Up to date
                </Badge>
              )}
            </div>

            {/* Semantic diff table */}
            <div className="rounded-md border overflow-hidden">
              <table className="w-full text-xs">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left p-2 font-medium text-muted-foreground">Component</th>
                    <th className="text-center p-2 font-medium text-muted-foreground">Declared</th>
                    <th className="text-center p-2 font-medium text-muted-foreground">Latest</th>
                    <th className="text-center p-2 font-medium text-muted-foreground">Change</th>
                  </tr>
                </thead>
                <tbody>
                  {diff.rows.map((row, i) => (
                    <tr key={i} className="border-t">
                      <td className="p-2 font-medium">{row.label}</td>
                      <td className="p-2 text-center font-mono">{row.declared}</td>
                      <td className="p-2 text-center font-mono">{row.latest}</td>
                      <td className="p-2 text-center">
                        <ChangeBadge status={row.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Recommendation */}
            <div
              className={cn(
                "rounded-md border p-3 text-xs space-y-1",
                diff.riskLevel === "high"
                  ? "border-red-500/40 bg-red-500/10"
                  : diff.riskLevel === "medium"
                    ? "border-orange-500/40 bg-orange-500/10"
                    : "border-emerald-500/40 bg-emerald-500/10",
              )}
            >
              <p className="font-semibold flex items-center gap-1.5">
                {diff.riskLevel === "high" ? (
                  <ShieldAlert className="h-4 w-4 text-red-500" />
                ) : diff.riskLevel === "medium" ? (
                  <ArrowUpCircle className="h-4 w-4 text-orange-500" />
                ) : (
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                )}
                {diff.riskLevel === "high" ? "Action required" : diff.riskLevel === "medium" ? "Review recommended" : "Safe to upgrade"}
              </p>
              <p className="text-muted-foreground">{diff.recommendation}</p>
            </div>

            {/* Copy command */}
            <div className="rounded-md border bg-muted/40 p-2.5 flex items-center justify-between gap-2">
              <code className="text-xs font-mono flex-1 truncate">
                dotnet add package {pkg.id} --version {pkg.latestStableVersion}
              </code>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(
                    `dotnet add package ${pkg.id} --version ${pkg.latestStableVersion}`,
                  );
                }}
                className="text-xs text-primary hover:underline shrink-0"
              >
                Copy
              </button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function ChangeBadge({ status }: { status: DiffRow["status"] }) {
  const styles = {
    same: { label: "=", cls: "text-muted-foreground" },
    improved: { label: "↑", cls: "text-emerald-600 dark:text-emerald-400" },
    changed: { label: "↑↑", cls: "text-orange-600 dark:text-orange-400 font-bold" },
    worse: { label: "↓", cls: "text-red-600 dark:text-red-400" },
    "n/a": { label: "—", cls: "text-muted-foreground/50" },
  };
  const s = styles[status];
  return <span className={cn("font-mono font-bold", s.cls)}>{s.label}</span>;
}
