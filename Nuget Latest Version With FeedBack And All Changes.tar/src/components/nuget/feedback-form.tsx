"use client";

import { useState, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Bug,
  Lightbulb,
  MessageSquare,
  HelpCircle,
  Loader2,
  Send,
  Camera,
  X,
  CheckCircle2,
  ArrowLeft,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

type FeedbackType = "bug" | "feature" | "feedback" | "question";
type Severity = "low" | "medium" | "high" | "critical";

const TYPE_OPTIONS: Array<{ value: FeedbackType; label: string; icon: React.ComponentType<{ className?: string }>; color: string; desc: string }> = [
  { value: "bug", label: "Bug report", icon: Bug, color: "text-red-500", desc: "Something isn't working correctly" },
  { value: "feature", label: "Feature request", icon: Lightbulb, color: "text-yellow-500", desc: "Suggest a new feature or improvement" },
  { value: "feedback", label: "General feedback", icon: MessageSquare, color: "text-blue-500", desc: "Share your thoughts or suggestions" },
  { value: "question", label: "Question", icon: HelpCircle, color: "text-purple-500", desc: "Ask about how something works" },
];

const SEVERITY_OPTIONS: Array<{ value: Severity; label: string; color: string }> = [
  { value: "low", label: "Low", color: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10" },
  { value: "medium", label: "Medium", color: "border-yellow-500/40 text-yellow-600 dark:text-yellow-400 bg-yellow-500/10" },
  { value: "high", label: "High", color: "border-orange-500/40 text-orange-600 dark:text-orange-400 bg-orange-500/10" },
  { value: "critical", label: "Critical", color: "border-red-500/40 text-red-600 dark:text-red-400 bg-red-500/10" },
];

export function FeedbackForm({ onSuccess }: { onSuccess?: () => void }) {
  const router = useRouter();
  const [type, setType] = useState<FeedbackType>("bug");
  const [severity, setSeverity] = useState<Severity>("medium");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [reporterName, setReporterName] = useState("");
  const [reporterEmail, setReporterEmail] = useState("");
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleScreenshot = useCallback((file: File) => {
    if (file.size > 2_000_000) {
      toast.error("Screenshot too large", { description: "Max 2MB. Please crop or compress." });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setScreenshot(reader.result as string);
    reader.readAsDataURL(file);
  }, []);

  const onPaste = useCallback((e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (item.type.startsWith("image/")) {
        const file = item.getAsFile();
        if (file) {
          handleScreenshot(file);
          toast.success("Screenshot captured from clipboard");
        }
      }
    }
  }, [handleScreenshot]);

  const submit = async () => {
    if (!title.trim() || !description.trim()) {
      toast.error("Title and description are required");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type,
          severity,
          title,
          description,
          screenshot,
          reporterName: reporterName || undefined,
          reporterEmail: reporterEmail || undefined,
          page: typeof window !== "undefined" ? window.location.pathname + window.location.search : null,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setSubmitted(true);
        toast.success("Feedback submitted — thank you!");
        if (onSuccess) {
          setTimeout(onSuccess, 1800);
        }
      } else {
        toast.error("Submission failed", { description: data.error });
      }
    } catch (err) {
      toast.error("Submission failed", { description: String(err) });
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4 animate-fade-up">
        <div className="rounded-full bg-emerald-500/10 p-6">
          <CheckCircle2 className="h-12 w-12 text-emerald-500" />
        </div>
        <h2 className="text-xl font-semibold">Thank you for your feedback!</h2>
        <p className="text-sm text-muted-foreground max-w-md text-center">
          We appreciate you taking the time to help us improve. Our team will review your submission shortly.
        </p>
        <Button variant="outline" onClick={() => router.push("/")} className="mt-2">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to auditor
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8" onPaste={onPaste}>
      <div className="mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <MessageSquare className="h-6 w-6 text-primary" />
          Send Feedback
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Report bugs, request features, or share your thoughts. You can paste screenshots directly (Ctrl+V).
        </p>
      </div>

      <div className="space-y-6">
        {/* Type selector */}
        <div>
          <Label className="text-sm mb-2 block font-medium">What kind of feedback?</Label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {TYPE_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setType(opt.value)}
                className={cn(
                  "flex items-start gap-2.5 rounded-lg border p-3 text-left transition-all",
                  type === opt.value
                    ? "border-primary bg-primary/5 ring-1 ring-primary/20"
                    : "border-border hover:bg-muted/40",
                )}
              >
                <opt.icon className={cn("h-5 w-5 shrink-0 mt-0.5", opt.color)} />
                <div className="min-w-0">
                  <p className="text-sm font-medium">{opt.label}</p>
                  <p className="text-[11px] text-muted-foreground">{opt.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Severity selector */}
        <div>
          <Label className="text-sm mb-2 block font-medium">How severe is this?</Label>
          <div className="flex gap-2">
            {SEVERITY_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setSeverity(opt.value)}
                className={cn(
                  "flex-1 rounded-md border px-3 py-2 text-xs font-medium transition-all",
                  severity === opt.value ? opt.color : "border-border text-muted-foreground hover:bg-muted/40",
                )}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Title */}
        <div>
          <Label htmlFor="fb-title" className="text-sm mb-2 block font-medium">Title *</Label>
          <Input
            id="fb-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Brief summary of the issue or suggestion"
            maxLength={200}
          />
        </div>

        {/* Description */}
        <div>
          <Label htmlFor="fb-desc" className="text-sm mb-2 block font-medium">Description *</Label>
          <Textarea
            id="fb-desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what happened, what you expected, and steps to reproduce (if applicable)…"
            className="min-h-[140px] resize-y"
            maxLength={5000}
          />
          <p className="text-[11px] text-muted-foreground mt-1">{description.length}/5000</p>
        </div>

        {/* Screenshot */}
        <div>
          <Label className="text-sm mb-2 block font-medium">Screenshot (optional)</Label>
          {screenshot ? (
            <div className="relative rounded-lg border overflow-hidden">
              <img src={screenshot} alt="Screenshot" className="w-full max-h-60 object-contain bg-muted/20" />
              <button
                onClick={() => setScreenshot(null)}
                className="absolute top-2 right-2 rounded-md bg-background/80 backdrop-blur p-1.5 hover:bg-background"
                aria-label="Remove screenshot"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => fileRef.current?.click()}
              className="w-full rounded-lg border-2 border-dashed border-border p-4 text-sm text-muted-foreground hover:border-primary/50 hover:bg-muted/30 transition-all flex items-center justify-center gap-2"
            >
              <Camera className="h-4 w-4" />
              Click to upload or paste an image (Ctrl+V)
            </button>
          )}
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleScreenshot(f);
            }}
          />
        </div>

        {/* Contact info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <Label htmlFor="fb-name" className="text-sm mb-2 block font-medium">Name (optional)</Label>
            <Input id="fb-name" value={reporterName} onChange={(e) => setReporterName(e.target.value)} placeholder="Anonymous" maxLength={100} />
          </div>
          <div>
            <Label htmlFor="fb-email" className="text-sm mb-2 block font-medium">Email (optional)</Label>
            <Input id="fb-email" type="email" value={reporterEmail} onChange={(e) => setReporterEmail(e.target.value)} placeholder="for follow-up" maxLength={200} />
          </div>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-between gap-2 pt-4 border-t">
          <div className="flex items-center gap-1.5">
            <Badge variant="outline" className="text-[10px]">{type}</Badge>
            <Badge variant="outline" className="text-[10px]">{severity}</Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={() => router.push("/")}>
              <ArrowLeft className="h-4 w-4 mr-1" />
              Cancel
            </Button>
            <Button onClick={submit} disabled={submitting || !title.trim() || !description.trim()} size="lg">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              {submitting ? "Submitting…" : "Submit feedback"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
