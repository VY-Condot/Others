"use client";

import { useRef, useState, useCallback } from "react";
import { UploadCloud, FileCode2, Sparkles, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { SAMPLE_CSPROJ } from "@/lib/csproj-parser";

interface Props {
  onAudit: (content: string, filename?: string) => void;
  loading: boolean;
}

export function FileUploader({ onAudit, loading }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [text, setText] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [filename, setFilename] = useState<string | null>(null);

  const handleFile = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const c = String(reader.result ?? "");
      setText(c);
      setFilename(file.name);
    };
    reader.readAsText(file);
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer.files?.[0];
      if (file) handleFile(file);
    },
    [handleFile],
  );

  return (
    <div className="space-y-3">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={cn(
          "relative rounded-xl border-2 border-dashed p-6 transition-all cursor-pointer group",
          dragOver
            ? "border-primary bg-primary/5 scale-[1.01]"
            : "border-border/80 hover:border-primary/60 hover:bg-muted/40 hover:shadow-md",
        )}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".csproj,.xml,.txt"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleFile(f);
          }}
        />
        <div className="flex flex-col items-center text-center gap-2">
          <div className="rounded-full bg-primary/10 p-3 group-hover:bg-primary/15 transition-colors">
            <UploadCloud className="h-6 w-6 text-primary" />
          </div>
          <div>
            <p className="text-sm font-medium">
              Drop a <code className="text-primary">.csproj</code> file here or click to browse
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              XML or text — parsed locally in your browser before being sent for audit
            </p>
          </div>
          {filename && (
            <div className="flex items-center gap-2 mt-1 text-xs bg-secondary rounded-full px-3 py-1">
              <FileCode2 className="h-3.5 w-3.5" />
              <span className="font-mono">{filename}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFilename(null);
                  setText("");
                }}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="relative">
        <Textarea
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            if (filename) setFilename(null);
          }}
          placeholder="…or paste your .csproj XML here"
          className="font-mono text-xs min-h-[160px] max-h-[300px] resize-y"
          spellCheck={false}
        />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button
          onClick={() => onAudit(text, filename ?? undefined)}
          disabled={loading || !text.trim()}
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4" />}
          {loading ? "Auditing…" : "Audit dependencies"}
        </Button>
        <Button
          variant="outline"
          onClick={() => {
            setText(SAMPLE_CSPROJ);
            setFilename("Sample.csproj");
          }}
          disabled={loading}
        >
          <Sparkles className="h-4 w-4" />
          Load sample
        </Button>
        {text && (
          <Button
            variant="ghost"
            onClick={() => {
              setText("");
              setFilename(null);
            }}
            disabled={loading}
          >
            Clear
          </Button>
        )}
        <span className="text-xs text-muted-foreground ml-auto">
          {text ? `${text.length.toLocaleString()} chars` : "Awaiting input"}
        </span>
      </div>
    </div>
  );
}
