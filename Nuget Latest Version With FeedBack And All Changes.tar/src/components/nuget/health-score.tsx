"use client";

import { useMemo } from "react";
import { cn } from "@/lib/utils";
import { useCountUp } from "@/hooks/use-count-up";
import type { AuditSeverity } from "@/lib/audit";

interface Props {
  totalPackages: number;
  outdatedCount: number;
  vulnerableCount: number;
  deprecatedCount: number;
  maxSeverity: AuditSeverity | null;
}

const sevPenalty: Record<AuditSeverity, number> = {
  low: 8,
  moderate: 18,
  high: 35,
  critical: 60,
};

function gradeFromScore(score: number): { letter: string; color: string; label: string } {
  if (score >= 90) return { letter: "A", color: "text-emerald-500", label: "Excellent" };
  if (score >= 75) return { letter: "B", color: "text-lime-500", label: "Good" };
  if (score >= 60) return { letter: "C", color: "text-yellow-500", label: "Fair" };
  if (score >= 40) return { letter: "D", color: "text-orange-500", label: "At risk" };
  return { letter: "F", color: "text-red-500", label: "Critical" };
}

export function HealthScore({
  totalPackages,
  outdatedCount,
  vulnerableCount,
  deprecatedCount,
  maxSeverity,
}: Props) {
  const { score, grade, breakdown } = useMemo(() => {
    let s = 100;
    const lines: { label: string; delta: number }[] = [];

    if (totalPackages === 0) {
      return { score: 100, grade: gradeFromScore(100), breakdown: lines };
    }

    // Vulnerability penalty — scaled by severity
    if (maxSeverity) {
      const pen = sevPenalty[maxSeverity];
      s -= pen;
      lines.push({ label: `${maxSeverity} vulnerability`, delta: -pen });
    }

    // Additional vulnerable packages (beyond the max severity one)
    const extraVuln = Math.max(0, vulnerableCount - 1);
    if (extraVuln > 0) {
      const pen = extraVuln * 6;
      s -= pen;
      lines.push({ label: `${extraVuln} more vulnerable`, delta: -pen });
    }

    // Outdated ratio
    const outdatedRatio = outdatedCount / totalPackages;
    const outdatedPen = Math.round(outdatedRatio * 25);
    if (outdatedPen > 0) {
      s -= outdatedPen;
      lines.push({ label: `${Math.round(outdatedRatio * 100)}% outdated`, delta: -outdatedPen });
    }

    // Deprecated
    if (deprecatedCount > 0) {
      const pen = deprecatedCount * 4;
      s -= pen;
      lines.push({ label: `${deprecatedCount} deprecated`, delta: -pen });
    }

    s = Math.max(0, Math.min(100, s));
    return { score: s, grade: gradeFromScore(s), breakdown: lines };
  }, [totalPackages, outdatedCount, vulnerableCount, deprecatedCount, maxSeverity]);

  const animatedScore = useCountUp(score, 1000, true);

  // Radial gauge geometry
  const size = 160;
  const stroke = 12;
  const r = (size - stroke) / 2;
  const cx = size / 2;
  const cy = size / 2;
  const circumference = 2 * Math.PI * r;
  const dash = (score / 100) * circumference;

  // Color stops for the arc
  const arcColor =
    score >= 90 ? "#10b981" : score >= 75 ? "#84cc16" : score >= 60 ? "#eab308" : score >= 40 ? "#f97316" : "#ef4444";

  return (
    <div className="flex flex-col sm:flex-row items-center gap-5">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          {/* Track */}
          <circle
            cx={cx}
            cy={cy}
            r={r}
            fill="none"
            stroke="currentColor"
            strokeWidth={stroke}
            className="text-muted/30"
          />
          {/* Score arc */}
          <circle
            cx={cx}
            cy={cy}
            r={r}
            fill="none"
            stroke={arcColor}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${dash} ${circumference}`}
            style={{ transition: "stroke-dasharray 0.8s cubic-bezier(0.22, 1, 0.36, 1)" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={cn("text-5xl font-bold leading-none", grade.color)}>{grade.letter}</span>
          <span className="text-xs font-medium text-muted-foreground mt-1 tabular-nums">{animatedScore}/100</span>
          <span className={cn("text-[10px] font-semibold uppercase tracking-wide", grade.color)}>
            {grade.label}
          </span>
        </div>
      </div>

      <div className="flex-1 min-w-0 w-full">
        <h3 className="text-sm font-semibold mb-2">Security health score</h3>
        <p className="text-xs text-muted-foreground mb-3">
          Composite grade from vulnerability severity, outdated ratio, and deprecation status.
        </p>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Base score</span>
            <span className="font-mono font-semibold">100</span>
          </div>
          {breakdown.length === 0 ? (
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">No penalties</span>
              <span className="font-mono font-semibold text-emerald-500">+0</span>
            </div>
          ) : (
            breakdown.map((b, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground capitalize">{b.label}</span>
                <span className="font-mono font-semibold text-red-500">{b.delta}</span>
              </div>
            ))
          )}
          <div className="flex items-center justify-between text-xs pt-1.5 border-t mt-1.5">
            <span className="font-semibold">Final score</span>
            <span className={cn("font-mono font-bold text-base tabular-nums", grade.color)}>{animatedScore}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
