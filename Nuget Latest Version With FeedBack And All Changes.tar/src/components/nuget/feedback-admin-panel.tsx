"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Bug,
  Lightbulb,
  MessageSquare,
  HelpCircle,
  Trash2,
  Loader2,
  Filter,
  Clock,
  ExternalLink,
  Save,
  Image as ImageIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

interface FeedbackItem {
  id: string;
  type: string;
  severity: string;
  title: string;
  description: string;
  page: string | null;
  userAgent: string | null;
  screenshot: string | null;
  status: string;
  adminNote: string | null;
  reporterName: string | null;
  reporterEmail: string | null;
  createdAt: string;
  updatedAt: string;
}

const TYPE_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  bug: Bug,
  feature: Lightbulb,
  feedback: MessageSquare,
  question: HelpCircle,
};

const TYPE_COLOR: Record<string, string> = {
  bug: "text-red-500",
  feature: "text-yellow-500",
  feedback: "text-blue-500",
  question: "text-purple-500",
};

const SEVERITY_STYLE: Record<string, string> = {
  low: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10",
  medium: "border-yellow-500/40 text-yellow-600 dark:text-yellow-400 bg-yellow-500/10",
  high: "border-orange-500/40 text-orange-600 dark:text-orange-400 bg-orange-500/10",
  critical: "border-red-500/40 text-red-600 dark:text-red-400 bg-red-500/10",
};

const STATUS_STYLE: Record<string, string> = {
  open: "border-blue-500/40 text-blue-600 dark:text-blue-400 bg-blue-500/10",
  "in-progress": "border-yellow-500/40 text-yellow-600 dark:text-yellow-400 bg-yellow-500/10",
  resolved: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10",
  closed: "border-muted-foreground/40 text-muted-foreground bg-muted/20",
};

const STATUSES = ["open", "in-progress", "resolved", "closed"];

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(iso).toLocaleDateString();
}

export function FeedbackAdminPanel({ open, onOpenChange }: Props) {
  const [items, setItems] = useState<FeedbackItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<"all" | "open" | "in-progress" | "resolved" | "closed">("all");
  const [selected, setSelected] = useState<FeedbackItem | null>(null);
  const [adminNote, setAdminNote] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/feedback");
      const data = await res.json();
      if (data.ok) setItems(data.items);
    } catch {
      toast.error("Failed to load feedback");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (open) load();
  }, [open, load]);

  const filtered = filter === "all" ? items : items.filter((i) => i.status === filter);

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/feedback/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (data.ok) {
        setItems((prev) => prev.map((i) => (i.id === id ? { ...i, status } : i)));
        if (selected?.id === id) setSelected((s) => s ? { ...s, status } : s);
        toast.success(`Marked as ${status}`);
      }
    } catch {
      toast.error("Update failed");
    }
  };

  const saveNote = async () => {
    if (!selected) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/feedback/${selected.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminNote }),
      });
      const data = await res.json();
      if (data.ok) {
        setItems((prev) => prev.map((i) => (i.id === selected.id ? { ...i, adminNote } : i)));
        setSelected((s) => s ? { ...s, adminNote } : s);
        toast.success("Note saved");
      }
    } catch {
      toast.error("Save failed");
    } finally {
      setSaving(false);
    }
  };

  const deleteItem = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Delete this feedback permanently?")) return;
    try {
      const res = await fetch(`/api/feedback/${id}`, { method: "DELETE" });
      if (res.ok) {
        setItems((prev) => prev.filter((i) => i.id !== id));
        if (selected?.id === id) setSelected(null);
        toast.success("Deleted");
      }
    } catch {
      toast.error("Delete failed");
    }
  };

  const counts = {
    all: items.length,
    open: items.filter((i) => i.status === "open").length,
    "in-progress": items.filter((i) => i.status === "in-progress").length,
    resolved: items.filter((i) => i.status === "resolved").length,
    closed: items.filter((i) => i.status === "closed").length,
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col p-0 gap-0">
        <DialogHeader className="p-4 border-b shrink-0">
          <DialogTitle className="flex items-center gap-2 text-base">
            <MessageSquare className="h-4 w-4" />
            Feedback &amp; Bug Reports
            <Badge variant="secondary" className="text-[10px]">{items.length}</Badge>
          </DialogTitle>
          <DialogDescription className="text-xs">
            Review, triage, and respond to user-submitted feedback.
          </DialogDescription>
        </DialogHeader>

        {/* Filter bar */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b shrink-0 overflow-x-auto no-scrollbar">
          <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          {(["all", "open", "in-progress", "resolved", "closed"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors shrink-0",
                filter === f ? "bg-primary text-primary-foreground" : "hover:bg-muted text-muted-foreground",
              )}
            >
              {f} <span className="opacity-60">({counts[f]})</span>
            </button>
          ))}
          <Button variant="ghost" size="sm" className="ml-auto h-7 text-[11px]" onClick={load} disabled={loading}>
            {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : "Refresh"}
          </Button>
        </div>

        <div className="flex flex-1 min-h-0 flex-col md:flex-row">
          {/* List */}
          <div className="flex-1 overflow-y-auto custom-scroll md:max-w-[340px] border-r">
            {loading && items.length === 0 ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 gap-2 text-center">
                <div className="rounded-full bg-muted p-3">
                  <MessageSquare className="h-5 w-5 text-muted-foreground" />
                </div>
                <p className="text-xs text-muted-foreground">No feedback {filter !== "all" && `with status "${filter}"`} yet.</p>
              </div>
            ) : (
              <div className="divide-y">
                {filtered.map((item) => {
                  const Icon = TYPE_ICON[item.type] ?? MessageSquare;
                  const isSelected = selected?.id === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => { setSelected(item); setAdminNote(item.adminNote ?? ""); }}
                      className={cn(
                        "w-full text-left p-3 hover:bg-muted/40 transition-colors group",
                        isSelected && "bg-primary/5",
                      )}
                    >
                      <div className="flex items-start gap-2">
                        <Icon className={cn("h-4 w-4 shrink-0 mt-0.5", TYPE_COLOR[item.type])} />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold truncate">{item.title}</p>
                          <p className="text-[10px] text-muted-foreground truncate mt-0.5">{item.description}</p>
                          <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                            <Badge variant="outline" className={cn("text-[9px]", SEVERITY_STYLE[item.severity])}>
                              {item.severity}
                            </Badge>
                            <Badge variant="outline" className={cn("text-[9px]", STATUS_STYLE[item.status])}>
                              {item.status}
                            </Badge>
                            {item.screenshot && (
                              <ImageIcon className="h-2.5 w-2.5 text-muted-foreground" />
                            )}
                            <span className="text-[9px] text-muted-foreground flex items-center gap-0.5 ml-auto">
                              <Clock className="h-2 w-2" />
                              {timeAgo(item.createdAt)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Detail */}
          <div className="flex-1 overflow-y-auto custom-scroll p-4">
            {!selected ? (
              <div className="flex flex-col items-center justify-center h-full gap-2 text-center text-xs text-muted-foreground py-12">
                <MessageSquare className="h-8 w-8 opacity-30" />
                <p>Select an item to view details</p>
              </div>
            ) : (
              <div className="space-y-3 animate-fade-up">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold">{selected.title}</p>
                    <p className="text-[10px] text-muted-foreground flex items-center gap-1.5 mt-0.5">
                      <Clock className="h-2.5 w-2.5" />
                      {new Date(selected.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={(e) => deleteItem(selected.id, e)}
                    className="text-muted-foreground hover:text-red-500 p-1 shrink-0"
                    aria-label="Delete"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap">
                  <Badge variant="outline" className={cn("text-[10px] gap-1", TYPE_COLOR[selected.type])}>
                    {(() => { const Icon = TYPE_ICON[selected.type] ?? MessageSquare; return <Icon className="h-2.5 w-2.5" />; })()}
                    {selected.type}
                  </Badge>
                  <Badge variant="outline" className={cn("text-[10px]", SEVERITY_STYLE[selected.severity])}>
                    {selected.severity}
                  </Badge>
                  <Badge variant="outline" className={cn("text-[10px]", STATUS_STYLE[selected.status])}>
                    {selected.status}
                  </Badge>
                </div>

                {/* Description */}
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Description</p>
                  <p className="text-xs leading-relaxed whitespace-pre-wrap bg-muted/30 rounded-md p-3 border">{selected.description}</p>
                </div>

                {/* Screenshot */}
                {selected.screenshot && (
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Screenshot</p>
                    <a href={selected.screenshot} target="_blank" rel="noreferrer noopener" className="block rounded-md border overflow-hidden hover:opacity-80 transition-opacity">
                      <img src={selected.screenshot} alt="Screenshot" className="w-full max-h-60 object-contain bg-muted/20" />
                    </a>
                  </div>
                )}

                {/* Metadata */}
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  {selected.reporterName && (
                    <div className="rounded-md border bg-card p-2">
                      <p className="text-muted-foreground">Reporter</p>
                      <p className="font-medium">{selected.reporterName}</p>
                    </div>
                  )}
                  {selected.reporterEmail && (
                    <div className="rounded-md border bg-card p-2">
                      <p className="text-muted-foreground">Email</p>
                      <a href={`mailto:${selected.reporterEmail}`} className="font-medium text-primary hover:underline truncate block">{selected.reporterEmail}</a>
                    </div>
                  )}
                  {selected.page && (
                    <div className="rounded-md border bg-card p-2">
                      <p className="text-muted-foreground">Page</p>
                      <p className="font-mono truncate">{selected.page}</p>
                    </div>
                  )}
                  {selected.userAgent && (
                    <div className="rounded-md border bg-card p-2">
                      <p className="text-muted-foreground">User agent</p>
                      <p className="font-mono truncate" title={selected.userAgent}>{selected.userAgent.slice(0, 60)}…</p>
                    </div>
                  )}
                </div>

                {/* Status controls */}
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">Status</p>
                  <div className="flex gap-1.5">
                    {STATUSES.map((s) => (
                      <button
                        key={s}
                        onClick={() => updateStatus(selected.id, s)}
                        className={cn(
                          "flex-1 rounded-md border px-2 py-1.5 text-[10px] font-medium transition-all",
                          selected.status === s ? STATUS_STYLE[s] : "border-border text-muted-foreground hover:bg-muted/40",
                        )}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Admin note */}
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">Admin note</p>
                  <Textarea
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    placeholder="Add internal notes (not visible to reporter)…"
                    className="text-xs min-h-[60px] resize-y"
                    maxLength={2000}
                  />
                  <Button variant="outline" size="sm" className="mt-1.5 h-7 text-[11px]" onClick={saveNote} disabled={saving}>
                    {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
                    Save note
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
