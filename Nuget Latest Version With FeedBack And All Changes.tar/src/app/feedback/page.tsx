"use client";

import { FeedbackForm } from "@/components/nuget/feedback-form";
import { ThemeToggle } from "@/components/nuget/theme-toggle";
import { PackageSearch, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function FeedbackPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Simple header for feedback page */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-3 sm:px-6 lg:px-8 h-14 flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5 shrink-0">
              <PackageSearch className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-semibold hidden xs:block">NuGet Auditor</span>
          </Link>
          <div className="ml-auto flex items-center gap-2">
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/">
                <ArrowLeft className="h-3.5 w-3.5" />
                Back to app
              </Link>
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1">
        <FeedbackForm />
      </main>
    </div>
  );
}
