import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "next-themes";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NuGet Visualizer & Auditor",
  description:
    "Parse a .csproj file, visualize its dependency tree, and highlight outdated or insecure NuGet packages. Powered by the nuget.org v3 API and GitHub Advisory data.",
  keywords: [
    "NuGet",
    "csproj",
    "dependency tree",
    "vulnerability audit",
    "outdated packages",
    ".NET",
    "ASP.NET Core",
  ],
  authors: [{ name: "NuGet Auditor" }],
  icons: {
    icon: "/icon.svg",
  },
  openGraph: {
    title: "NuGet Visualizer & Auditor",
    description: "Parse, visualize, and audit your .csproj dependencies.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <SonnerToaster richColors closeButton position="bottom-right" />
        </ThemeProvider>
      </body>
    </html>
  );
}
