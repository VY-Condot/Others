"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  PackageSearch,
  ArrowLeft,
  Lock,
  Loader2,
  Bug,
  Lightbulb,
  MessageSquare,
  HelpCircle,
  Trash2,
  Filter,
  Clock,
  Image as ImageIcon,
  Save,
  ExternalLink,
  LogOut,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { ThemeToggle } from "@/components/nuget/theme-toggle";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import Link from "next/link";

const AUTH_KEY = "nuget-admin-auth";

interface FeedbackItem {
  id: string;
  type: string;
  severity: string;
  title: string;
  description: string;
  page: string | null;
  userAgent: string | null;
  screenshot: string | null;
  status: string;
  adminNote: string | null;
  reporterName: string | null;
  reporterEmail: string | null;
  createdAt: string;
  updatedAt: string;
}

const TYPE_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  bug: Bug,
  feature: Lightbulb,
  feedback: MessageSquare,
  question: HelpCircle,
};
const TYPE_COLOR: Record<string, string> = {
  bug: "text-red-500",
  feature: "text-yellow-500",
  feedback: "text-blue-500",
  question: "text-purple-500",
};
const SEVERITY_STYLE: Record<string, string> = {
  low: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10",
  medium: "border-yellow-500/40 text-yellow-600 dark:text-yellow-400 bg-yellow-500/10",
  high: "border-orange-500/40 text-orange-600 dark:text-orange-400 bg-orange-500/10",
  critical: "border-red-500/40 text-red-600 dark:text-red-400 bg-red-500/10",
};
const STATUS_STYLE: Record<string, string> = {
  open: "border-blue-500/40 text-blue-600 dark:text-blue-400 bg-blue-500/10",
  "in-progress": "border-yellow-500/40 text-yellow-600 dark:text-yellow-400 bg-yellow-500/10",
  resolved: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10",
  closed: "border-muted-foreground/40 text-muted-foreground bg-muted/20",
};
const STATUSES = ["open", "in-progress", "resolved", "closed"];

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(iso).toLocaleDateString();
}

export default function AdminPage() {
  const router = useRouter();
  const [authed, setAuthed] = useState(false);
  const [token, setToken] = useState("");
  const [checking, setChecking] = useState(true);
  const [items, setItems] = useState<FeedbackItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<"all" | "open" | "in-progress" | "resolved" | "closed">("all");
  const [selected, setSelected] = useState<FeedbackItem | null>(null);
  const [adminNote, setAdminNote] = useState("");
  const [saving, setSaving] = useState(false);

  // Check existing auth on mount
  useEffect(() => {
    const stored = sessionStorage.getItem(AUTH_KEY);
    if (stored === "ok") setAuthed(true);
    setChecking(false);
  }, []);

  const login = async () => {
    if (!token.trim()) return;
    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });
      const data = await res.json();
      if (data.ok) {
        sessionStorage.setItem(AUTH_KEY, "ok");
        setAuthed(true);
        toast.success("Admin access granted");
      } else {
        toast.error("Invalid admin token");
      }
    } catch {
      toast.error("Auth failed");
    }
  };

  const logout = () => {
    sessionStorage.removeItem(AUTH_KEY);
    setAuthed(false);
    setToken("");
    setItems([]);
    setSelected(null);
    router.push("/");
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/feedback");
      const data = await res.json();
      if (data.ok) setItems(data.items);
    } catch {
      toast.error("Failed to load feedback");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (authed) load();
  }, [authed, load]);

  const filtered = filter === "all" ? items : items.filter((i) => i.status === filter);

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/feedback/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (data.ok) {
        setItems((prev) => prev.map((i) => (i.id === id ? { ...i, status } : i)));
        if (selected?.id === id) setSelected((s) => (s ? { ...s, status } : s));
        toast.success(`Marked as ${status}`);
      }
    } catch {
      toast.error("Update failed");
    }
  };

  const saveNote = async () => {
    if (!selected) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/feedback/${selected.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminNote }),
      });
      const data = await res.json();
      if (data.ok) {
        setItems((prev) => prev.map((i) => (i.id === selected.id ? { ...i, adminNote } : i)));
        setSelected((s) => (s ? { ...s, adminNote } : s));
        toast.success("Note saved");
      }
    } catch {
      toast.error("Save failed");
    } finally {
      setSaving(false);
    }
  };

  const deleteItem = async (id: string) => {
    if (!confirm("Delete this feedback permanently?")) return;
    try {
      const res = await fetch(`/api/feedback/${id}`, { method: "DELETE" });
      if (res.ok) {
        setItems((prev) => prev.filter((i) => i.id !== id));
        if (selected?.id === id) setSelected(null);
        toast.success("Deleted");
      }
    } catch {
      toast.error("Delete failed");
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Login gate
  if (!authed) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="border-b">
          <div className="mx-auto max-w-7xl px-4 h-14 flex items-center gap-2">
            <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5">
              <PackageSearch className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-semibold">NuGet Auditor</span>
            <div className="ml-auto flex items-center gap-2">
              <Button asChild variant="ghost" size="sm">
                <Link href="/"><ArrowLeft className="h-3.5 w-3.5" /> Back</Link>
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </header>
        <main className="flex-1 flex items-center justify-center px-4">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Admin Access
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                This area is restricted. Enter your admin token to view submitted feedback.
              </p>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label htmlFor="admin-token" className="text-xs mb-1.5 block">Admin token</Label>
                <Input
                  id="admin-token"
                  type="password"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && login()}
                  placeholder="Enter admin token"
                  autoFocus
                />
              </div>
              <Button onClick={login} className="w-full" disabled={!token.trim()}>
                <Lock className="h-4 w-4 mr-1" />
                Unlock
              </Button>
              <p className="text-[11px] text-muted-foreground text-center pt-2">
                This is a private admin area. Unauthorized access is prohibited.
              </p>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  // Authenticated admin dashboard
  const counts = {
    all: items.length,
    open: items.filter((i) => i.status === "open").length,
    "in-progress": items.filter((i) => i.status === "in-progress").length,
    resolved: items.filter((i) => i.status === "resolved").length,
    closed: items.filter((i) => i.status === "closed").length,
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-3 sm:px-6 lg:px-8 h-14 flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5">
              <PackageSearch className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-semibold hidden xs:block">NuGet Auditor</span>
          </Link>
          <Badge variant="outline" className="text-[10px] gap-1 border-red-500/30 text-red-600 dark:text-red-400">
            <Lock className="h-2.5 w-2.5" />
            ADMIN
          </Badge>
          <div className="ml-auto flex items-center gap-2">
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/"><ArrowLeft className="h-3.5 w-3.5" /> App</Link>
            </Button>
            <Button variant="ghost" size="sm" className="text-xs" onClick={logout}>
              <LogOut className="h-3.5 w-3.5" /> Logout
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 mx-auto w-full max-w-7xl px-3 sm:px-6 lg:px-8 py-6">
        <div className="mb-6">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Feedback Dashboard
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Review, triage, and manage user-submitted feedback and bug reports.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-4">
          {(["all", "open", "in-progress", "resolved", "closed"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-lg border p-3 text-left transition-all",
                filter === f ? "border-primary bg-primary/5" : "hover:bg-muted/40",
              )}
            >
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{f}</p>
              <p className="text-xl font-bold tabular-nums">{counts[f]}</p>
            </button>
          ))}
        </div>

        {/* Split layout */}
        <div className="grid grid-cols-1 lg:grid-cols-[360px_1fr] gap-4">
          {/* List */}
          <div className="rounded-lg border overflow-hidden">
            <div className="flex items-center justify-between px-3 py-2 border-b bg-muted/30">
              <span className="text-xs font-medium flex items-center gap-1.5">
                <Filter className="h-3.5 w-3.5" />
                {filtered.length} item{filtered.length === 1 ? "" : "s"}
              </span>
              <Button variant="ghost" size="sm" className="h-7 text-[11px]" onClick={load} disabled={loading}>
                {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : "Refresh"}
              </Button>
            </div>
            <div className="max-h-[600px] overflow-y-auto custom-scroll">
              {loading && items.length === 0 ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 gap-2 text-center">
                  <MessageSquare className="h-8 w-8 text-muted-foreground/40" />
                  <p className="text-xs text-muted-foreground">No feedback items.</p>
                </div>
              ) : (
                <div className="divide-y">
                  {filtered.map((item) => {
                    const Icon = TYPE_ICON[item.type] ?? MessageSquare;
                    const isSelected = selected?.id === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => { setSelected(item); setAdminNote(item.adminNote ?? ""); }}
                        className={cn(
                          "w-full text-left p-3 hover:bg-muted/40 transition-colors",
                          isSelected && "bg-primary/5",
                        )}
                      >
                        <div className="flex items-start gap-2">
                          <Icon className={cn("h-4 w-4 shrink-0 mt-0.5", TYPE_COLOR[item.type])} />
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-semibold truncate">{item.title}</p>
                            <p className="text-[10px] text-muted-foreground truncate mt-0.5">{item.description}</p>
                            <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                              <Badge variant="outline" className={cn("text-[9px]", SEVERITY_STYLE[item.severity])}>{item.severity}</Badge>
                              <Badge variant="outline" className={cn("text-[9px]", STATUS_STYLE[item.status])}>{item.status}</Badge>
                              {item.screenshot && <ImageIcon className="h-2.5 w-2.5 text-muted-foreground" />}
                              <span className="text-[9px] text-muted-foreground flex items-center gap-0.5 ml-auto">
                                <Clock className="h-2 w-2" />
                                {timeAgo(item.createdAt)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Detail */}
          <div className="rounded-lg border min-h-[400px]">
            {!selected ? (
              <div className="flex flex-col items-center justify-center h-full gap-2 text-center text-sm text-muted-foreground py-20">
                <MessageSquare className="h-10 w-10 opacity-30" />
                <p>Select an item to view details</p>
              </div>
            ) : (
              <div className="p-5 space-y-4 overflow-y-auto custom-scroll max-h-[600px] pb-6">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-base font-semibold">{selected.title}</p>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1.5 mt-1">
                      <Clock className="h-3 w-3" />
                      {new Date(selected.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive shrink-0" onClick={() => deleteItem(selected.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap">
                  <Badge variant="outline" className={cn("text-[10px] gap-1", TYPE_COLOR[selected.type])}>
                    {(() => { const Icon = TYPE_ICON[selected.type] ?? MessageSquare; return <Icon className="h-2.5 w-2.5" />; })()}
                    {selected.type}
                  </Badge>
                  <Badge variant="outline" className={cn("text-[10px]", SEVERITY_STYLE[selected.severity])}>{selected.severity}</Badge>
                  <Badge variant="outline" className={cn("text-[10px]", STATUS_STYLE[selected.status])}>{selected.status}</Badge>
                </div>

                <div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">Description</p>
                  <p className="text-sm leading-relaxed whitespace-pre-wrap bg-muted/30 rounded-md p-3 border">{selected.description}</p>
                </div>

                {selected.screenshot && (
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">Screenshot</p>
                    <a href={selected.screenshot} target="_blank" rel="noreferrer noopener" className="block rounded-md border overflow-hidden hover:opacity-80 transition-opacity">
                      <img src={selected.screenshot} alt="Screenshot" className="w-full max-h-72 object-contain bg-muted/20" />
                    </a>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  {selected.reporterName && (
                    <div className="rounded-md border bg-card p-2.5">
                      <p className="text-muted-foreground text-[10px] uppercase">Reporter</p>
                      <p className="font-medium mt-0.5">{selected.reporterName}</p>
                    </div>
                  )}
                  {selected.reporterEmail && (
                    <div className="rounded-md border bg-card p-2.5">
                      <p className="text-muted-foreground text-[10px] uppercase">Email</p>
                      <a href={`mailto:${selected.reporterEmail}`} className="font-medium text-primary hover:underline truncate block mt-0.5">{selected.reporterEmail}</a>
                    </div>
                  )}
                  {selected.page && (
                    <div className="rounded-md border bg-card p-2.5">
                      <p className="text-muted-foreground text-[10px] uppercase">Page</p>
                      <p className="font-mono truncate mt-0.5">{selected.page}</p>
                    </div>
                  )}
                  {selected.userAgent && (
                    <div className="rounded-md border bg-card p-2.5">
                      <p className="text-muted-foreground text-[10px] uppercase">User agent</p>
                      <p className="font-mono text-[10px] truncate mt-0.5" title={selected.userAgent}>{selected.userAgent.slice(0, 80)}…</p>
                    </div>
                  )}
                </div>

                <div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">Status</p>
                  <div className="flex gap-1.5">
                    {STATUSES.map((s) => (
                      <button
                        key={s}
                        onClick={() => updateStatus(selected.id, s)}
                        className={cn(
                          "flex-1 rounded-md border px-2 py-1.5 text-[11px] font-medium transition-all",
                          selected.status === s ? STATUS_STYLE[s] : "border-border text-muted-foreground hover:bg-muted/40",
                        )}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">Admin note</p>
                  <Textarea
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    placeholder="Add internal notes (not visible to reporter)…"
                    className="text-xs min-h-[70px] resize-y"
                    maxLength={2000}
                  />
                  <Button variant="outline" size="sm" className="mt-1.5 h-7 text-[11px]" onClick={saveNote} disabled={saving}>
                    {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
                    Save note
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
