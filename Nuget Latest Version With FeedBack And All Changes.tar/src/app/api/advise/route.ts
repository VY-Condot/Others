import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface AdviseBody {
  projectName: string | null;
  targetFrameworks: string[];
  sdk: string | null;
  packages: Array<{
    id: string;
    declaredVersion: string;
    latestStableVersion: string | null;
    isOutdated: boolean;
    isVulnerable: boolean;
    isDeprecated: boolean;
    maxSeverity: string | null;
    vulnerabilities: Array<{ severity: string; advisoryTitle?: string; range: string }>;
  }>;
}

/**
 * POST /api/advise
 * Body: AdviseBody (a slim summary of the audit result)
 * Returns: { ok: true, advice: string } — markdown advice from the LLM.
 *
 * The LLM is given a tight, structured summary (not the full audit) and asked
 * to produce a prioritized, plain-English remediation plan with concrete
 * `dotnet add package` commands. Streamed back as plain text.
 */
export async function POST(req: NextRequest) {
  let body: AdviseBody;
  try {
    body = (await req.json()) as AdviseBody;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  if (!body?.packages?.length) {
    return NextResponse.json({ error: "No packages provided." }, { status: 400 });
  }

  const vulnerable = body.packages.filter((p) => p.isVulnerable);
  const outdated = body.packages.filter((p) => p.isOutdated && !p.isVulnerable);
  const deprecated = body.packages.filter((p) => p.isDeprecated);

  const lines: string[] = [];
  lines.push(`# Project audit summary`);
  lines.push(`- Project: ${body.projectName ?? "unnamed"}`);
  lines.push(`- SDK: ${body.sdk ?? "unknown"}`);
  lines.push(`- Target frameworks: ${body.targetFrameworks.join(", ") || "unknown"}`);
  lines.push(`- Total declared packages: ${body.packages.length}`);
  lines.push("");
  lines.push(`## Vulnerable packages (${vulnerable.length})`);
  if (vulnerable.length === 0) lines.push("None.");
  for (const p of vulnerable) {
    lines.push(
      `- **${p.id}** declared=${p.declaredVersion} → latest=${p.latestStableVersion ?? "?"} severity=${p.maxSeverity ?? "?"}`,
    );
    for (const v of p.vulnerabilities.slice(0, 2)) {
      lines.push(`  - ${v.severity}: ${v.advisoryTitle ?? "advisory"} (range ${v.range})`);
    }
  }
  lines.push("");
  lines.push(`## Outdated but not vulnerable (${outdated.length})`);
  for (const p of outdated.slice(0, 15)) {
    lines.push(`- **${p.id}** ${p.declaredVersion} → ${p.latestStableVersion ?? "?"}`);
  }
  if (outdated.length > 15) lines.push(`- …and ${outdated.length - 15} more`);
  lines.push("");
  lines.push(`## Deprecated (${deprecated.length})`);
  for (const p of deprecated.slice(0, 10)) {
    lines.push(`- **${p.id}** ${p.declaredVersion}`);
  }

  const systemPrompt = `You are a senior .NET security and dependency management advisor. You analyze NuGet audit summaries and produce a concise, prioritized remediation plan in Markdown.

Rules:
- Be direct and specific. No generic platitudes.
- Prioritize: (1) critical/high vulnerabilities first, (2) moderate/low vulnerabilities, (3) major-version outdated packages, (4) deprecated packages, (5) minor/patch updates.
- For each actionable item, include a ready-to-run \`dotnet add package\` command with the recommended version.
- Flag any known breaking-change risks when upgrading major versions (e.g. MediatR 11→12, AutoMapper 12→13, Serilog 6→8, Npgsql 4→8, EF Core major bumps).
- Keep the response under ~500 words. Use tight Markdown with short sections.
- If everything is healthy, say so confidently in one line.`;

  const userPrompt = `${lines.join("\n")}

Produce a prioritized remediation plan now.`;

  try {
    const zai = await ZAI.create();
    const encoder = new TextEncoder();

    const stream = new ReadableStream({
      async start(controller) {
        try {
          const res = await zai.chat.completions.create({
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userPrompt },
            ],
            // non-streaming completion; we re-emit as a single chunk to keep it simple
            temperature: 0.4,
            max_tokens: 1200,
          });
          const content = res.choices?.[0]?.message?.content ?? "";
          controller.enqueue(encoder.encode(content));
        } catch (err) {
          controller.enqueue(
            encoder.encode(
              `> ⚠️ The AI advisor is temporarily unavailable. Here's a rule-based summary instead.\n\n` +
                `## Priority 1 — Vulnerabilities\n` +
                (vulnerable.length === 0
                  ? "None. \n"
                  : vulnerable
                      .map(
                        (p) =>
                          `- \`${p.id}\` (${p.declaredVersion} → ${p.latestStableVersion}): \`dotnet add package ${p.id} --version ${p.latestStableVersion}\``,
                      )
                      .join("\n")) +
                `\n\n## Priority 2 — Outdated (major bumps)\n` +
                (outdated.length === 0
                  ? "None.\n"
                  : outdated
                      .slice(0, 8)
                      .map(
                        (p) =>
                          `- \`${p.id}\` (${p.declaredVersion} → ${p.latestStableVersion}): \`dotnet add package ${p.id} --version ${p.latestStableVersion}\``,
                      )
                      .join("\n")) +
                `\n\n_Error: ${err instanceof Error ? err.message : String(err)}_`,
            ),
          );
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Advise failed.", detail: String(err) },
      { status: 500 },
    );
  }
}
