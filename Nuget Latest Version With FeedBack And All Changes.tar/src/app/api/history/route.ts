import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { AuditResult } from "@/lib/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/history — list all saved audit runs (newest first), slim metadata only.
 * POST /api/history — save a new audit run. Body: { result: AuditResult }
 */
export async function GET() {
  try {
    const runs = await db.auditRun.findMany({
      orderBy: { createdAt: "desc" },
      take: 50,
      select: {
        id: true,
        projectName: true,
        sdk: true,
        targetFramework: true,
        totalPackages: true,
        outdatedCount: true,
        vulnerableCount: true,
        deprecatedCount: true,
        maxSeverity: true,
        healthScore: true,
        createdAt: true,
      },
    });
    return NextResponse.json({ ok: true, runs });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: "Failed to load history.", detail: String(err) },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const result = body?.result as AuditResult | undefined;
    if (!result) {
      return NextResponse.json({ ok: false, error: "No audit result provided." }, { status: 400 });
    }

    // Compute a health score (mirrors the HealthScore component logic)
    const sevPenalty: Record<string, number> = { low: 8, moderate: 18, high: 35, critical: 60 };
    let score = 100;
    if (result.stats.maxSeverity) score -= sevPenalty[result.stats.maxSeverity] ?? 0;
    const extraVuln = Math.max(0, result.stats.vulnerableCount - 1);
    score -= extraVuln * 6;
    if (result.stats.totalPackages > 0) {
      score -= Math.round((result.stats.outdatedCount / result.stats.totalPackages) * 25);
    }
    score -= result.stats.deprecatedCount * 4;
    score = Math.max(0, Math.min(100, score));

    // Strip rawCsproj from the saved JSON (we store it separately)
    const { rawCsproj, ...resultWithoutRaw } = result;

    const run = await db.auditRun.create({
      data: {
        projectName: result.parsed.projectName ?? "unnamed",
        sdk: result.parsed.sdk ?? null,
        targetFramework: result.parsed.targetFrameworks.join(", ") || null,
        totalPackages: result.stats.totalPackages,
        outdatedCount: result.stats.outdatedCount,
        vulnerableCount: result.stats.vulnerableCount,
        deprecatedCount: result.stats.deprecatedCount,
        maxSeverity: result.stats.maxSeverity ?? null,
        healthScore: score,
        resultJson: JSON.stringify(resultWithoutRaw),
        csprojContent: rawCsproj ?? "",
      },
    });

    return NextResponse.json({ ok: true, id: run.id });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: "Failed to save audit.", detail: String(err) },
      { status: 500 },
    );
  }
}
