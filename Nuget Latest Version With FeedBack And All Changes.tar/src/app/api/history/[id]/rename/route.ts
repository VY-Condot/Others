import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * PATCH /api/history/[id]/rename
 * Body: { name: string }
 * Renames a saved audit run's project name.
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const name = body?.name?.trim();
    if (!name || name.length > 200) {
      return NextResponse.json({ error: "Invalid name." }, { status: 400 });
    }
    const updated = await db.auditRun.update({
      where: { id },
      data: { projectName: name },
      select: { id: true, projectName: true },
    });
    return NextResponse.json({ ok: true, run: updated });
  } catch (err) {
    return NextResponse.json(
      { error: "Rename failed.", detail: String(err) },
      { status: 500 },
    );
  }
}
