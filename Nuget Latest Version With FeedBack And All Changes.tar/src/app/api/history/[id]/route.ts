import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/history/[id] — load a single audit run with full result JSON.
 * DELETE /api/history/[id] — delete a saved audit run.
 */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const run = await db.auditRun.findUnique({ where: { id } });
    if (!run) {
      return NextResponse.json({ ok: false, error: "Not found." }, { status: 404 });
    }
    const result = JSON.parse(run.resultJson);
    // re-attach rawCsproj for the UI
    result.rawCsproj = run.csprojContent;
    return NextResponse.json({ ok: true, run, result });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: "Failed to load audit.", detail: String(err) },
      { status: 500 },
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    await db.auditRun.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: "Failed to delete audit.", detail: String(err) },
      { status: 500 },
    );
  }
}
