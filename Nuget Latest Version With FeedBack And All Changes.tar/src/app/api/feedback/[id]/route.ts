import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const VALID_STATUSES = ["open", "in-progress", "resolved", "closed"];

/**
 * PATCH /api/feedback/[id]
 * Body: { status?, adminNote? }
 * Updates the status and/or admin note of a feedback item.
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const data: Record<string, unknown> = {};
    if (body.status) {
      if (!VALID_STATUSES.includes(body.status)) {
        return NextResponse.json({ error: "Invalid status." }, { status: 400 });
      }
      data.status = body.status;
    }
    if (body.adminNote !== undefined) {
      data.adminNote = String(body.adminNote).slice(0, 2000) || null;
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ error: "No fields to update." }, { status: 400 });
    }

    const updated = await db.feedback.update({
      where: { id },
      data,
    });

    return NextResponse.json({ ok: true, item: updated });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to update feedback.", detail: String(err) },
      { status: 500 },
    );
  }
}

/**
 * DELETE /api/feedback/[id]
 * Permanently deletes a feedback item.
 */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    await db.feedback.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to delete feedback.", detail: String(err) },
      { status: 500 },
    );
  }
}
