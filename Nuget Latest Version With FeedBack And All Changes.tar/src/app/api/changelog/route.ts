import { NextRequest, NextResponse } from "next/server";
import semver from "semver";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

/**
 * GET /api/changelog?id=<packageId>&version=<version>
 *
 * Fetches the release notes for a specific package version from the NuGet
 * registration index. NuGet stores `releaseNotes` per catalog entry.
 * Falls back to the package description if no release notes are published.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const id = (url.searchParams.get("id") ?? "").toLowerCase().trim();
  const version = (url.searchParams.get("version") ?? "").toLowerCase().trim();

  if (!id) {
    return NextResponse.json({ error: "Package id is required." }, { status: 400 });
  }

  try {
    const regUrl = `https://api.nuget.org/v3/registration5-gz-semver2/${encodeURIComponent(id)}/index.json`;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 10_000);
    const res = await fetch(regUrl, {
      signal: ctrl.signal,
      headers: { Accept: "application/json", "User-Agent": "nuget-auditor/1.0" },
      cache: "no-store",
    });
    clearTimeout(timer);

    if (!res.ok) {
      return NextResponse.json({ error: `NuGet API ${res.status}` }, { status: 502 });
    }

    const json: any = await res.json();
    const pages = Array.isArray(json.items) ? json.items : [];
    const releases: Array<{ version: string; releaseNotes?: string; published?: string; description?: string }> = [];

    for (const page of pages) {
      const entries = Array.isArray(page.items) ? page.items : [];
      for (const entry of entries) {
        const cat = entry?.catalogEntry;
        if (!cat || !cat.version) continue;
        releases.push({
          version: cat.version,
          releaseNotes: cat.releaseNotes,
          published: cat.published,
          description: cat.description,
        });
      }
    }

    // Sort newest first (coerce semver)
    releases.sort((a, b) => {
      const va = semver.coerce(a.version);
      const vb = semver.coerce(b.version);
      if (!va || !vb) return b.version.localeCompare(a.version);
      return vb.compare(va);
    });

    if (version) {
      const exact = releases.find((r) => r.version.toLowerCase() === version);
      return NextResponse.json({
        ok: true,
        id,
        version,
        releaseNotes: exact?.releaseNotes ?? null,
        published: exact?.published ?? null,
        allReleases: releases.slice(0, 20).map((r) => ({ version: r.version, published: r.published, hasNotes: !!r.releaseNotes })),
      });
    }

    // No version specified — return the latest 10 with notes
    return NextResponse.json({
      ok: true,
      id,
      releases: releases.slice(0, 10).map((r) => ({
        version: r.version,
        releaseNotes: r.releaseNotes?.slice(0, 2000) ?? null,
        published: r.published,
      })),
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to fetch changelog.", detail: String(err) },
      { status: 500 },
    );
  }
}
