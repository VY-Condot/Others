import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

/**
 * GET /api/popularity?ids=Package1,Package2,Package3
 *
 * Fetches download counts for multiple package IDs using the NuGet v3 search
 * service (azuresearch-usnc.nuget.org/query). The search service returns
 * `totalDownloads` per package — the registration index does NOT include this.
 *
 * We query each package individually with a `q=packageId:` filter to get an
 * exact match, running them in parallel with a concurrency cap.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const idsParam = url.searchParams.get("ids") ?? "";
  const ids = idsParam
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 30);

  if (ids.length === 0) {
    return NextResponse.json({ error: "At least one package id required." }, { status: 400 });
  }

  try {
    const results: Record<string, { totalDownloads: number; verified: boolean; latestVersion: string | null }> = {};

    const CONCURRENCY = 6;
    let cursor = 0;

    async function worker() {
      while (cursor < ids.length) {
        const idx = cursor++;
        const originalId = ids[idx];
        const id = originalId.toLowerCase();
        try {
          const ctrl = new AbortController();
          const timer = setTimeout(() => ctrl.abort(), 8000);
          // Use the search service with an exact-id filter
          const searchUrl = `https://azuresearch-usnc.nuget.org/query?q=packageId:${encodeURIComponent(originalId)}&take=1&prerelease=false`;
          const res = await fetch(searchUrl, {
            signal: ctrl.signal,
            headers: { Accept: "application/json", "User-Agent": "nuget-auditor/1.0" },
            cache: "no-store",
          });
          clearTimeout(timer);
          if (!res.ok) continue;
          const json: any = await res.json();
          const data = json?.data?.[0];
          if (data) {
            results[id] = {
              totalDownloads: typeof data.totalDownloads === "number" ? data.totalDownloads : 0,
              verified: !!data.verified,
              latestVersion: data.version ?? null,
            };
          }
        } catch {
          // skip on error
        }
      }
    }

    await Promise.all(Array.from({ length: CONCURRENCY }, () => worker()));

    return NextResponse.json({ ok: true, popularity: results });
  } catch (err) {
    return NextResponse.json(
      { error: "Popularity fetch failed.", detail: String(err) },
      { status: 500 },
    );
  }
}
