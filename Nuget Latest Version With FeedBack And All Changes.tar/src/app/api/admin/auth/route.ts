import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/admin/auth
 * Body: { token: string }
 * Validates the admin token against the ADMIN_TOKEN env variable.
 * Returns ok:true if the token matches.
 *
 * This is a simple token gate — the admin route (/admin) is not linked
 * anywhere in the public UI and must be accessed by direct URL only.
 * Auth state is stored in sessionStorage (cleared on browser close).
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const token = body?.token;
    const adminToken = process.env.ADMIN_TOKEN;

    if (!adminToken) {
      return NextResponse.json({ error: "Admin access not configured." }, { status: 503 });
    }

    if (!token || token !== adminToken) {
      return NextResponse.json({ error: "Invalid token." }, { status: 401 });
    }

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Auth failed." }, { status: 500 });
  }
}
