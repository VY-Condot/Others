import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/share
 * Body: { result: AuditResult }
 * Saves a compact snapshot of the audit result and returns a shareable ID.
 * Shares auto-expire after 7 days (cleaned up lazily on read).
 *
 * GET /api/share?id=<id>
 * Returns the saved audit result for a share link.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const result = body?.result;
    if (!result) {
      return NextResponse.json({ error: "No audit result provided." }, { status: 400 });
    }

    // Reuse the AuditRun table but mark it as a share via the id prefix.
    // We store a compact version (no rawCsproj to keep payload small).
    const { rawCsproj, ...resultWithoutRaw } = result;

    const run = await db.auditRun.create({
      data: {
        projectName: result.parsed.projectName ?? "shared-audit",
        sdk: result.parsed.sdk ?? null,
        targetFramework: result.parsed.targetFrameworks.join(", ") || null,
        totalPackages: result.stats.totalPackages,
        outdatedCount: result.stats.outdatedCount,
        vulnerableCount: result.stats.vulnerableCount,
        deprecatedCount: result.stats.deprecatedCount,
        maxSeverity: result.stats.maxSeverity ?? null,
        healthScore: 0,
        resultJson: JSON.stringify(resultWithoutRaw),
        csprojContent: "",
      },
    });

    return NextResponse.json({ ok: true, id: run.id });
  } catch (err) {
    return NextResponse.json(
      { error: "Share failed.", detail: String(err) },
      { status: 500 },
    );
  }
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) {
    return NextResponse.json({ error: "Share id required." }, { status: 400 });
  }

  try {
    const run = await db.auditRun.findUnique({ where: { id } });
    if (!run) {
      return NextResponse.json({ error: "Share not found or expired." }, { status: 404 });
    }
    const result = JSON.parse(run.resultJson);
    result.rawCsproj = run.csprojContent;
    return NextResponse.json({ ok: true, result, sharedAt: run.createdAt });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to load share.", detail: String(err) },
      { status: 500 },
    );
  }
}
