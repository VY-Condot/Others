# NuGet Visualizer & Auditor — Worklog

## Project Status (as of 2025-07-28, Phase 18)

**Status: ✅ GitHub scanner + version drift matrix + badge fix (Phase 18 done)**

Three new dedicated pages added: /scan (GitHub URL fetcher), /matrix (version drift matrix), and badge sharing bug fixed.

---

## Phase 18 — GitHub scanner + drift matrix + badge fix (DONE this round)

### 1. GitHub URL Fetcher (`/scan` page)
- **`src/app/scan/page.tsx`**: Dedicated page for scanning GitHub repositories.
  - URL input with live branch/tag selector (fetches branches via GitHub API).
  - Scans the repository tree recursively via GitHub API (no cloning needed).
  - Finds all .csproj and .sln files.
  - Fetches raw .csproj content from raw.githubusercontent.com (parallel, concurrency 8).
  - Displays discovered projects as cards with SDK, target framework, package count.
  - Click any project → navigates to home page with the csproj content pre-loaded for auditing.
  - "View Version Drift Matrix" button → navigates to /matrix with all projects.
  - Features info cards: Direct Parsing, Branch Selector, .sln Support.
- **`src/app/api/github-scan/route.ts`**: Backend API.
  - POST: Parses GitHub URL (owner/repo/branch), fetches tree recursively, finds .csproj/.sln files, fetches raw content in parallel.
  - GET: Returns available branches and tags for a repository.
  - Auto-falls back from `main` to `master` branch if 404.
- **`src/lib/sln-parser.ts`**: .sln file parser that extracts project paths from Visual Studio solution files.

### 2. Multi-Project Version Drift Matrix (`/matrix` page)
- **`src/app/matrix/page.tsx`**: Dedicated page for the version drift matrix.
  - Loads projects from sessionStorage (set by /scan page) or manual file upload.
  - Builds a matrix: rows = packages, columns = projects, cells = version.
  - **Visual alerts**: rows with version drift (different versions across projects) are highlighted in red with a ⚠️ warning icon.
  - **Filter chips**: All / Drift / Consistent with live counts.
  - Project legend showing all project names.
  - Drift alert banner with explanation of why version drift is dangerous.
  - Empty state with "Scan GitHub Repository" and "Upload .csproj files" options.
  - Immutable state handling (useCallback for buildMatrix, useMemo for filtered data).

### 3. Badge Sharing Fix
- **Root cause**: `badge-generator.tsx` used `apiFetch()` but never imported it — caused a runtime ReferenceError when clicking "Create share link".
- **Fix**: Added `import { apiFetch } from "@/lib/api-fetch"` to the badge generator component.
- **Verified**: Badge API returns SVG, share API returns valid ID, badge endpoint serves correct SVG.

### 4. Navigation wiring
- **Header**: Added "GitHub Scan" and "Drift Matrix" links to both desktop and mobile menus (internal links, not external).
- **Footer**: Added "GitHub Repository Scanner" and "Version Drift Matrix" links to the Resources column.
- **Scan page**: Links to /matrix and back to home.
- **Matrix page**: Links to /scan and back to home.

### Verification
- **Scan page**: Renders with URL input, branch selector, feature info cards. HTTP 200.
- **Matrix page**: Renders with empty state (when no projects), "No projects loaded" with upload/scan options. HTTP 200.
- **Badge dialog**: Opens, shows SVG preview "NuGet audit: B · 89/100", Markdown/HTML snippets, Download SVG + Create share link buttons.
- **Badge API**: `/api/badge?id=test` returns 200 with SVG image.
- **Share API**: POST returns `{"ok":true,"id":"..."}` successfully.
- **Lint**: 0 errors, 0 warnings.
- **All routes**: Home 200, Scan 200, Matrix 200, Badge API 200.

## Priority recommendations
1. **Test with real GitHub repos**: scan a real .NET repository to verify end-to-end.
2. **Add .sln deep parsing**: when .sln files are found, parse them to discover .csproj paths that might not be in the tree.
3. **Matrix export**: allow exporting the drift matrix as CSV/JSON.
4. **Matrix fix suggestions**: show recommended unified version for drifted packages.
5. **Scan history**: save scanned repos for quick re-audit.
