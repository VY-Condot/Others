import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface ScanResult {
  repo: string;
  branch: string;
  slnFiles: string[];
  csprojFiles: Array<{ path: string; content: string; projectName: string }>;
  error?: string;
}

/**
 * POST /api/github-scan
 * Body: { url: string, branch?: string }
 *
 * Fetches a GitHub repository tree via the GitHub API (no cloning needed),
 * finds all .csproj and .sln files, and fetches their raw content.
 *
 * Supports:
 *   - GitHub URL parsing (repo owner/name, optional branch/tag)
 *   - .sln file parsing to discover .csproj paths
 *   - Branch/tag selector
 *   - Recursive tree scan
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const url: string = body?.url ?? "";
    const branch: string = body?.branch ?? "";

    if (!url) {
      return NextResponse.json({ error: "GitHub URL is required." }, { status: 400 });
    }

    // Parse GitHub URL: https://github.com/{owner}/{repo}[/tree/{branch}]
    const match = url.match(/github\.com\/([^\/]+)\/([^\/\?#]+)(?:\/tree\/([^\/\?#]+))?/);
    if (!match) {
      return NextResponse.json({ error: "Invalid GitHub URL. Expected: https://github.com/{owner}/{repo}" }, { status: 400 });
    }

    const [, owner, rawRepo, urlBranch] = match;
    const repo = rawRepo.replace(/\.git$/, "");
    const targetBranch = branch || urlBranch || "main";

    // Fetch the repository tree (recursive)
    const treeUrl = `https://api.github.com/repos/${owner}/${repo}/git/trees/${targetBranch}?recursive=1`;
    const treeRes = await fetch(treeUrl, {
      headers: {
        Accept: "application/vnd.github+json",
        "User-Agent": "nuget-auditor",
      },
      cache: "no-store",
    });

    if (treeRes.status === 404) {
      // Try 'master' branch if 'main' doesn't exist
      if (targetBranch === "main") {
        const masterUrl = `https://api.github.com/repos/${owner}/${repo}/git/trees/master?recursive=1`;
        const masterRes = await fetch(masterUrl, {
          headers: { Accept: "application/vnd.github+json", "User-Agent": "nuget-auditor" },
          cache: "no-store",
        });
        if (masterRes.ok) {
          return await processTree(owner, repo, "master", await masterRes.json());
        }
      }
      return NextResponse.json({ error: `Branch "${targetBranch}" not found. Try: main, master, develop.` }, { status: 404 });
    }

    if (!treeRes.ok) {
      const errText = await treeRes.text();
      return NextResponse.json({ error: `GitHub API error: ${treeRes.status}`, detail: errText.slice(0, 300) }, { status: 502 });
    }

    const treeData = await treeRes.json();
    return await processTree(owner, repo, targetBranch, treeData);
  } catch (err) {
    return NextResponse.json({ error: "Scan failed.", detail: String(err) }, { status: 500 });
  }
}

async function processTree(owner: string, repo: string, branch: string, treeData: any): Promise<NextResponse> {
  const result: ScanResult = { repo: `${owner}/${repo}`, branch, slnFiles: [], csprojFiles: [] };

  if (!treeData.tree || !Array.isArray(treeData.tree)) {
    return NextResponse.json({ error: "Invalid tree data from GitHub." }, { status: 502 });
  }

  // Find .sln and .csproj files
  const slnBlobs = treeData.tree.filter((t: any) => t.type === "blob" && t.path.endsWith(".sln"));
  const csprojBlobs = treeData.tree.filter((t: any) => t.type === "blob" && t.path.endsWith(".csproj"));

  result.slnFiles = slnBlobs.map((b: any) => b.path);

  // Fetch all .csproj file contents (in parallel with concurrency limit)
  const CONCURRENCY = 8;
  let cursor = 0;

  async function fetchCsproj(blob: any) {
    try {
      const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${blob.path}`;
      const res = await fetch(rawUrl, { cache: "no-store" });
      if (!res.ok) return null;
      const content = await res.text();
      // Extract project name from the path
      const projectName = blob.path.split("/").pop()?.replace(/\.csproj$/, "") ?? blob.path;
      return { path: blob.path, content, projectName };
    } catch {
      return null;
    }
  }

  const tasks: Promise<void>[] = [];
  for (let i = 0; i < CONCURRENCY; i++) {
    tasks.push((async () => {
      while (cursor < csprojBlobs.length) {
        const idx = cursor++;
        const file = await fetchCsproj(csprojBlobs[idx]);
        if (file) result.csprojFiles.push(file);
      }
    })());
  }
  await Promise.all(tasks);

  // Sort by path for consistent display
  result.csprojFiles.sort((a, b) => a.path.localeCompare(b.path));

  return NextResponse.json({ ok: true, result });
}

/**
 * GET /api/github-scan?owner=X&repo=Y
 * Returns available branches for a repository.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const owner = url.searchParams.get("owner");
  const repo = url.searchParams.get("repo");

  if (!owner || !repo) {
    return NextResponse.json({ error: "owner and repo params required." }, { status: 400 });
  }

  try {
    const branchesRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/branches?per_page=100`, {
      headers: { Accept: "application/vnd.github+json", "User-Agent": "nuget-auditor" },
      cache: "no-store",
    });

    if (!branchesRes.ok) {
      return NextResponse.json({ error: "Failed to fetch branches." }, { status: 502 });
    }

    const branches = await branchesRes.json();
    const tagsRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/tags?per_page=50`, {
      headers: { Accept: "application/vnd.github+json", "User-Agent": "nuget-auditor" },
      cache: "no-store",
    });
    const tags = tagsRes.ok ? await tagsRes.json() : [];

    return NextResponse.json({
      ok: true,
      branches: branches.map((b: any) => b.name),
      tags: tags.map((t: any) => t.name),
    });
  } catch (err) {
    return NextResponse.json({ error: "Failed to fetch branches.", detail: String(err) }, { status: 500 });
  }
}
