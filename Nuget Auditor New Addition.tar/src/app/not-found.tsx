"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { PackageSearch, Home, RotateCcw, Skull, Laugh } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const SARCASTIC_MESSAGES = [
  "Bro really typed a URL that doesn't exist 💀",
  "This page is in another castle... just kidding, it's just gone.",
  "404: Page found asleep. It's not coming to work today.",
  "You had ONE job: type a valid URL. Anyway, here we are.",
  "This page left the group chat.",
  "Page not found. But hey, neither is your dignity at this point.",
  "Error 404: The page you're looking for is as real as your CSS centering skills.",
  "This page took an L and isn't coming back.",
  "Skill issue detected: you navigated to nowhere.",
  "This page is giving... absolutely nothing.",
  "The page? Gone. The consequences? Eternal.",
  "404 — sounds like an area code where pages go missing.",
  "This page is more missing than my motivation on a Monday.",
  "Plot twist: the page was never real. It was all a figment of the URL bar.",
  "You: 'Let me just navigate here.' The page: 'Nah, I'm good.'",
];

const EMOJIS = ["💀", "😭", "🤡", "✨", "🔥", "🗿", "📉", "🏳️", "🫠", "💀"];

export default function NotFound() {
  const router = useRouter();
  const [message, setMessage] = useState(SARCASTIC_MESSAGES[0]);
  const [floatingEmojis, setFloatingEmojis] = useState<Array<{ id: number; emoji: string; x: number; y: number; delay: number; duration: number }>>([]);
  const [glitchText, setGlitchText] = useState("404");

  useEffect(() => {
    // Pick a random sarcastic message
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMessage(SARCASTIC_MESSAGES[Math.floor(Math.random() * SARCASTIC_MESSAGES.length)]);

    // Generate floating emojis
    const emojis = Array.from({ length: 12 }, (_, i) => ({
      id: i,
      emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)],
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 5,
      duration: 3 + Math.random() * 4,
    }));
    setFloatingEmojis(emojis);

    // Glitch effect on "404"
    const glitchInterval = setInterval(() => {
      const chars = ["4", "0", "4", "4", "0", "4", "💀", "4", "0", "4"];
      setGlitchText(chars[Math.floor(Math.random() * chars.length)] + "0" + chars[Math.floor(Math.random() * chars.length)]);
      setTimeout(() => setGlitchText("404"), 150);
    }, 3000);

    return () => clearInterval(glitchInterval);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-br from-background via-background to-purple-950/20 px-4">
      {/* Floating emojis background */}
      {floatingEmojis.map((e) => (
        <div
          key={e.id}
          className="absolute text-3xl md:text-5xl opacity-10 pointer-events-none animate-float"
          style={{
            left: `${e.x}%`,
            top: `${e.y}%`,
            animationDelay: `${e.delay}s`,
            animationDuration: `${e.duration}s`,
          }}
        >
          {e.emoji}
        </div>
      ))}

      {/* Gradient orbs */}
      <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-purple-500/10 blur-3xl animate-slow-spin pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-pink-500/10 blur-3xl pointer-events-none" />

      <div className="relative z-10 text-center max-w-2xl">
        {/* Badge */}
        <Badge variant="outline" className="mb-6 gap-1 animate-fade-up border-purple-500/30 text-purple-600 dark:text-purple-400 bg-purple-500/5">
          <Laugh className="h-3 w-3" />
          Error: Skill Issue
        </Badge>

        {/* Giant glitchy 404 */}
        <h1
          className="text-[8rem] md:text-[12rem] font-black leading-none tracking-tighter cursor-default select-none animate-fade-up"
          style={{ animationDelay: "60ms" }}
          onMouseEnter={() => {
            setGlitchText("💀0💀");
            setTimeout(() => setGlitchText("404"), 200);
          }}
        >
          <span className="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 bg-clip-text text-transparent animate-shimmer">
            {glitchText}
          </span>
        </h1>

        {/* Sarcastic heading */}
        <h2 className="text-2xl md:text-3xl font-bold mt-4 animate-fade-up" style={{ animationDelay: "120ms" }}>
          Bro really got lost 💀
        </h2>

        {/* Sarcastic message */}
        <p className="text-base md:text-lg text-muted-foreground mt-4 animate-fade-up leading-relaxed" style={{ animationDelay: "180ms" }}>
          {message}
        </p>

        {/* Interactive buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8 animate-fade-up" style={{ animationDelay: "240ms" }}>
          <Button
            size="lg"
            className="group bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white border-0 shadow-lg shadow-purple-500/25"
            onClick={() => router.push("/")}
          >
            <Home className="h-4 w-4 mr-2 group-hover:rotate-12 transition-transform" />
            Take me home (I'm lost)
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => router.refresh()}
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Try again (it won't help)
          </Button>
        </div>

        {/* Footer sass */}
        <div className="mt-12 flex items-center justify-center gap-2 text-xs text-muted-foreground animate-fade-up" style={{ animationDelay: "300ms" }}>
          <Skull className="h-3 w-3" />
          <span>This page has been reported missing since forever.</span>
          <Skull className="h-3 w-3" />
        </div>

        {/* Stats counter joke */}
        <div className="mt-6 grid grid-cols-3 gap-2 max-w-md mx-auto animate-fade-up" style={{ animationDelay: "360ms" }}>
          <div className="rounded-lg border bg-card/50 p-2">
            <p className="text-lg font-bold tabular-nums">∞</p>
            <p className="text-[10px] text-muted-foreground">pages missing</p>
          </div>
          <div className="rounded-lg border bg-card/50 p-2">
            <p className="text-lg font-bold tabular-nums">0</p>
            <p className="text-[10px] text-muted-foreground">pages found</p>
          </div>
          <div className="rounded-lg border bg-card/50 p-2">
            <p className="text-lg font-bold tabular-nums">1</p>
            <p className="text-[10px] text-muted-foreground">user disappointed</p>
          </div>
        </div>
      </div>

      {/* Bottom watermark */}
      <div className="absolute bottom-4 left-0 right-0 text-center text-[10px] text-muted-foreground/50">
        <PackageSearch className="h-3 w-3 inline mr-1" />
        NuGet Auditor · 404 Edition
      </div>
    </div>
  );
}
