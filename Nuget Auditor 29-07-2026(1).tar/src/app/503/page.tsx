import { HttpErrorPage } from "@/components/nuget/http-error-page";
export default function Page503() { return <HttpErrorPage statusCode={503} />; }
