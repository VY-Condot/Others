"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/lib/store";
import { Grid3x3, AlertTriangle, CheckCircle2, ArrowRight, Boxes, Upload, FileCode2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeToggle } from "@/components/nuget/theme-toggle";
import Link from "next/link";
import { toast } from "sonner";
import { parseCsproj, type ParsedCsproj } from "@/lib/csproj-parser";
import { cn } from "@/lib/utils";

interface MatrixProject {
  path: string;
  projectName: string;
  content: string;
}

interface MatrixRow {
  packageId: string;
  versions: Record<string, string>; // projectName → version
  hasDrift: boolean;
}

export default function MatrixPage() {
  const router = useRouter();
  const [projects, setProjects] = useState<MatrixProject[]>([]);
  const [matrix, setMatrix] = useState<MatrixRow[]>([]);
  const [filter, setFilter] = useState<"all" | "drift" | "consistent">("all");

  const buildMatrix = useCallback((projs: MatrixProject[]) => {
    const rowsMap = new Map<string, { packageId: string; versions: Record<string, string> }>();
    for (const proj of projs) {
      const parsed: ParsedCsproj = parseCsproj(proj.content);
      for (const pkg of parsed.packageReferences) {
        if (!rowsMap.has(pkg.id)) {
          rowsMap.set(pkg.id, { packageId: pkg.id, versions: {} });
        }
        rowsMap.get(pkg.id)!.versions[proj.projectName] = pkg.version;
      }
    }
    const rows: MatrixRow[] = [...rowsMap.values()].map((r) => {
      const uniqueVersions = new Set(Object.values(r.versions).filter(Boolean));
      return { packageId: r.packageId, versions: r.versions, hasDrift: uniqueVersions.size > 1 };
    });
    const sorted = rows.sort((a, b) => {
      if (a.hasDrift !== b.hasDrift) return a.hasDrift ? -1 : 1;
      return a.packageId.localeCompare(b.packageId);
    });
    setMatrix(sorted);
  }, []);

  const scannedProjects = useAppStore((s) => s.scannedProjects);

  useEffect(() => {
    if (scannedProjects && scannedProjects.length > 0) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setProjects(scannedProjects);
      buildMatrix(scannedProjects as MatrixProject[]);
    }
  }, [scannedProjects, buildMatrix]);

  const filteredMatrix = useMemo(() => {
    if (filter === "drift") return matrix.filter((r) => r.hasDrift);
    if (filter === "consistent") return matrix.filter((r) => !r.hasDrift);
    return matrix;
  }, [matrix, filter]);

  const driftCount = matrix.filter((r) => r.hasDrift).length;
  const projectNames = projects.map((p) => p.projectName);

  // Handle manual file upload
  const onFileUpload = async (files: FileList) => {
    const newProjects: MatrixProject[] = [];
    for (const file of Array.from(files)) {
      if (file.name.endsWith(".csproj")) {
        const content = await file.text();
        newProjects.push({
          path: file.name,
          projectName: file.name.replace(/\.csproj$/, ""),
          content,
        });
      }
    }
    if (newProjects.length > 0) {
      setProjects(newProjects);
      buildMatrix(newProjects);
      toast.success(`Loaded ${newProjects.length} .csproj files`);
    }
  };

  if (projects.length === 0) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
          <div className="mx-auto max-w-7xl px-4 h-14 flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5">
                <Grid3x3 className="h-4 w-4 text-white" />
              </div>
              <span className="text-sm font-semibold">NuGet Auditor</span>
            </Link>
            <Badge variant="outline" className="text-[10px] gap-1 border-amber-500/30 text-amber-600 dark:text-amber-400">
              <Grid3x3 className="h-2.5 w-2.5" />
              Version Drift Matrix
            </Badge>
            <div className="ml-auto flex items-center gap-2">
              <Button asChild variant="ghost" size="sm" className="text-xs">
                <Link href="/"><ArrowRight className="h-3.5 w-3.5 rotate-180" /> Back</Link>
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </header>
        <main className="flex-1 flex items-center justify-center px-4">
          <div className="text-center max-w-md">
            <div className="rounded-full bg-muted p-6 w-fit mx-auto mb-4">
              <Grid3x3 className="h-8 w-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold">No projects loaded</h2>
            <p className="text-sm text-muted-foreground mt-2 mb-6">
              Scan a GitHub repository or upload multiple .csproj files to visualize version drift across projects.
            </p>
            <div className="flex flex-col gap-2 items-center">
              <Button asChild>
                <Link href="/scan"><Boxes className="h-4 w-4 mr-2" /> Scan GitHub Repository</Link>
              </Button>
              <label className="cursor-pointer">
                <input
                  type="file"
                  accept=".csproj"
                  multiple
                  className="hidden"
                  onChange={(e) => e.target.files && onFileUpload(e.target.files)}
                />
                <span className="inline-flex items-center gap-2 px-4 py-2 border rounded-md text-sm hover:bg-muted transition-colors">
                  <Upload className="h-4 w-4" />
                  Upload .csproj files
                </span>
              </label>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 h-14 flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5">
              <Grid3x3 className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-semibold">NuGet Auditor</span>
          </Link>
          <Badge variant="outline" className="text-[10px] gap-1 border-amber-500/30 text-amber-600 dark:text-amber-400">
            <Grid3x3 className="h-2.5 w-2.5" />
            Version Drift Matrix
          </Badge>
          <div className="ml-auto flex items-center gap-2">
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/scan"><Boxes className="h-3.5 w-3.5" /> Scan</Link>
            </Button>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/"><ArrowRight className="h-3.5 w-3.5 rotate-180" /> Home</Link>
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 mx-auto w-full max-w-7xl px-4 py-6 space-y-4">
        {/* Summary */}
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <h1 className="text-xl font-bold">Version Drift Matrix</h1>
            <p className="text-xs text-muted-foreground mt-1">
              {projects.length} projects · {matrix.length} unique packages · {driftCount} with version drift
            </p>
          </div>
          <div className="flex gap-1.5">
            <button
              onClick={() => setFilter("all")}
              className={cn("px-3 py-1 text-xs rounded-md border", filter === "all" ? "bg-primary text-primary-foreground" : "hover:bg-muted")}
            >
              All ({matrix.length})
            </button>
            <button
              onClick={() => setFilter("drift")}
              className={cn("px-3 py-1 text-xs rounded-md border", filter === "drift" ? "border-red-500/40 text-red-600 bg-red-500/10" : "hover:bg-muted")}
            >
              ⚠️ Drift ({driftCount})
            </button>
            <button
              onClick={() => setFilter("consistent")}
              className={cn("px-3 py-1 text-xs rounded-md border", filter === "consistent" ? "border-emerald-500/40 text-emerald-600 bg-emerald-500/10" : "hover:bg-muted")}
            >
              ✅ Consistent ({matrix.length - driftCount})
            </button>
          </div>
        </div>

        {/* Project columns legend */}
        <div className="flex flex-wrap gap-2">
          {projectNames.map((name) => (
            <Badge key={name} variant="outline" className="text-[10px] gap-1">
              <FileCode2 className="h-2.5 w-2.5" />
              {name}
            </Badge>
          ))}
        </div>

        {/* Matrix table */}
        <div className="rounded-lg border overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-muted/50 sticky top-0">
              <tr>
                <th className="text-left p-3 font-semibold text-muted-foreground min-w-[200px]">
                  Package
                </th>
                {projectNames.map((name) => (
                  <th key={name} className="text-center p-3 font-semibold text-muted-foreground min-w-[100px]">
                    {name.length > 15 ? name.slice(0, 14) + "…" : name}
                  </th>
                ))}
                <th className="text-center p-3 font-semibold text-muted-foreground w-20">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredMatrix.length === 0 ? (
                <tr>
                  <td colSpan={projectNames.length + 2} className="p-8 text-center text-sm text-muted-foreground">
                    No packages match this filter.
                  </td>
                </tr>
              ) : (
                filteredMatrix.map((row) => (
                  <tr key={row.packageId} className={cn("border-t hover:bg-muted/20", row.hasDrift && "bg-red-500/5")}>
                    <td className="p-3 font-mono font-medium">
                      {row.hasDrift && <AlertTriangle className="inline h-3 w-3 text-red-500 mr-1" />}
                      {row.packageId}
                    </td>
                    {projectNames.map((name) => {
                      const version = row.versions[name];
                      return (
                        <td key={name} className="text-center p-3">
                          {version ? (
                            <span className={cn(
                              "inline-block font-mono text-[10px] px-1.5 py-0.5 rounded",
                              row.hasDrift ? "bg-red-500/10 text-red-600 dark:text-red-400" : "bg-muted text-muted-foreground"
                            )}>
                              {version}
                            </span>
                          ) : (
                            <span className="text-muted-foreground/30">—</span>
                          )}
                        </td>
                      );
                    })}
                    <td className="text-center p-3">
                      {row.hasDrift ? (
                        <Badge variant="outline" className="text-[9px] border-red-500/40 text-red-600 bg-red-500/10">
                          DRIFT
                        </Badge>
                      ) : (
                        <CheckCircle2 className="inline h-4 w-4 text-emerald-500" />
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Drift alert */}
        {driftCount > 0 && (
          <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-amber-700 dark:text-amber-300">
                  {driftCount} package{driftCount === 1 ? "" : "s"} have version drift
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Different projects are using different versions of the same package. This is a common cause of runtime errors in .NET.
                  Consider aligning versions across all projects in the solution.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
