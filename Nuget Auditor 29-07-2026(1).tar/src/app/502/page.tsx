import { HttpErrorPage } from "@/components/nuget/http-error-page";
export default function Page502() { return <HttpErrorPage statusCode={502} />; }
