import { HttpErrorPage } from "@/components/nuget/http-error-page";
export default function Page501() { return <HttpErrorPage statusCode={501} />; }
