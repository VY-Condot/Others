"use client";

import { useEffect, useState } from "react";
import { NotFoundPage } from "@/components/nuget/not-found-page";
import { NotFoundGlitch } from "@/components/nuget/not-found-glitch";

export default function NotFound() {
  const [variant, setVariant] = useState<"sarcastic" | "glitch" | null>(null);

  useEffect(() => {
    // Randomly select between the two 404 page variants
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setVariant(Math.random() < 0.5 ? "sarcastic" : "glitch");
  }, []);

  if (variant === null) {
    return null; // Prevent hydration mismatch — render nothing on first pass
  }

  return variant === "sarcastic" ? <NotFoundPage /> : <NotFoundGlitch />;
}
