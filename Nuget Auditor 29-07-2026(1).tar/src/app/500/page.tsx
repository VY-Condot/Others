import { HttpErrorPage } from "@/components/nuget/http-error-page";
export default function Page500() { return <HttpErrorPage statusCode={500} />; }
