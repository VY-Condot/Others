"use client";

import { HttpErrorPage } from "@/components/nuget/http-error-page";

export default function Error500() {
  return <HttpErrorPage statusCode={500} />;
}
