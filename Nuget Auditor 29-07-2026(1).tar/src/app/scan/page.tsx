"use client";

import { useState, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/lib/store";
import { Github, Loader2, GitBranch, FileCode2, ArrowRight, Search, AlertCircle, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ThemeToggle } from "@/components/nuget/theme-toggle";
import Link from "next/link";
import { toast } from "sonner";
import { parseCsproj, type ParsedCsproj } from "@/lib/csproj-parser";

interface ScanResult {
  repo: string;
  branch: string;
  slnFiles: string[];
  csprojFiles: Array<{ path: string; content: string; projectName: string }>;
}

export default function ScanPage() {
  const router = useRouter();
  const [url, setUrl] = useState("");
  const [branch, setBranch] = useState("");
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [branches, setBranches] = useState<string[]>([]);
  const [fetchingBranches, setFetchingBranches] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Restore scan context from store on mount (so users don't lose their scan
  // when returning from the audit page)
  const scanContext = useAppStore((s) => s.scanContext);
  const setScanContext = useAppStore((s) => s.setScanContext);

  useEffect(() => {
    if (scanContext && !result) {
      setUrl(scanContext.url);
      setBranch(scanContext.branch);
      setResult({
        repo: scanContext.repo,
        branch: scanContext.branch,
        slnFiles: scanContext.slnFiles,
        csprojFiles: scanContext.csprojFiles,
      });
    }
  }, [scanContext]);  

  const scan = useCallback(async () => {
    if (!url.trim()) return;
    setScanning(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch("/api/github-scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim(), branch: branch.trim() }),
      });
      const data = await res.json();
      if (data.ok) {
        setResult(data.result);
        // Persist scan context so users can return and pick another project
        setScanContext({
          url: url.trim(),
          branch: branch.trim() || data.result.branch,
          repo: data.result.repo,
          slnFiles: data.result.slnFiles,
          csprojFiles: data.result.csprojFiles,
        });
        toast.success(`Found ${data.result.csprojFiles.length} .csproj files in ${data.result.repo}`);
      } else {
        setError(data.error || "Scan failed");
        toast.error(data.error || "Scan failed");
      }
    } catch (err) {
      setError(String(err));
      toast.error("Scan failed");
    } finally {
      setScanning(false);
    }
  }, [url, branch]);

  const fetchBranches = useCallback(async (repoUrl: string) => {
    const match = repoUrl.match(/github\.com\/([^\/]+)\/([^\/\?#]+)/);
    if (!match) return;
    const [, owner, repo] = match;
    const cleanRepo = repo.replace(/\.git$/, "");
    setFetchingBranches(true);
    try {
      const res = await fetch(`/api/github-scan?owner=${owner}&repo=${cleanRepo}`);
      const data = await res.json();
      if (data.ok) {
        setBranches([...data.branches, ...data.tags]);
      }
    } catch { }
    finally { setFetchingBranches(false); }
  }, []);

  const onUrlChange = (v: string) => {
    setUrl(v);
    setBranches([]);
    if (v.includes("github.com/")) {
      fetchBranches(v);
    }
  };

  const setPending = useAppStore((s) => s.setPending);
  const setScannedProjects = useAppStore((s) => s.setScannedProjects);

  const auditProject = (project: { path: string; content: string; projectName: string }) => {
    setPending(project.content, project.projectName);
    router.push("/");
  };

  const auditAll = () => {
    if (!result) return;
    setScannedProjects(result.csprojFiles);
    router.push("/matrix");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 h-14 flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5">
              <Github className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-semibold">NuGet Auditor</span>
          </Link>
          <Badge variant="outline" className="text-[10px] gap-1 border-indigo-500/30 text-indigo-600 dark:text-indigo-400">
            <Search className="h-2.5 w-2.5" />
            GitHub Scanner
          </Badge>
          <div className="ml-auto flex items-center gap-2">
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/"><ArrowRight className="h-3.5 w-3.5 rotate-180" /> Back</Link>
            </Button>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/matrix">Matrix</Link>
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 mx-auto w-full max-w-4xl px-4 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Github className="h-6 w-6" />
            Scan a GitHub Repository
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Paste a GitHub URL to scan for .csproj files. No cloning needed — we fetch and parse directly via the GitHub API.
          </p>
        </div>

        {/* URL input */}
        <Card>
          <CardContent className="pt-6 space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">GitHub Repository URL</label>
              <div className="flex gap-2">
                <Input
                  value={url}
                  onChange={(e) => onUrlChange(e.target.value)}
                  placeholder="https://github.com/owner/repo"
                  className="flex-1"
                  onKeyDown={(e) => e.key === "Enter" && scan()}
                />
                <Button onClick={scan} disabled={scanning || !url.trim()}>
                  {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                  {scanning ? "Scanning…" : "Scan"}
                </Button>
              </div>
            </div>

            {/* Branch selector */}
            {(branches.length > 0 || fetchingBranches) && (
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block flex items-center gap-1">
                  <GitBranch className="h-3 w-3" />
                  Branch / Tag {fetchingBranches && <Loader2 className="h-3 w-3 animate-spin" />}
                </label>
                <select
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm"
                >
                  <option value="">Default (main/master)</option>
                  {branches.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>
            )}

            <p className="text-[11px] text-muted-foreground">
              💡 You can also paste a URL with a branch: <code className="font-mono">github.com/owner/repo/tree/develop</code>
            </p>
          </CardContent>
        </Card>

        {/* Error */}
        {error && (
          <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 flex items-start gap-2">
            <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-700 dark:text-red-300">Scan failed</p>
              <p className="text-xs text-muted-foreground mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-4 animate-fade-up">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div>
                <h2 className="text-lg font-semibold">{result.repo}</h2>
                <p className="text-xs text-muted-foreground flex items-center gap-1.5 mt-0.5">
                  <GitBranch className="h-3 w-3" />
                  Branch: {result.branch}
                  {result.slnFiles.length > 0 && (
                    <>
                      <span className="mx-1">·</span>
                      <FileCode2 className="h-3 w-3" />
                      {result.slnFiles.length} solution file(s)
                    </>
                  )}
                  <span className="mx-1">·</span>
                  <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                  {result.csprojFiles.length} .csproj file(s)
                </p>
              </div>
              {result.csprojFiles.length > 1 && (
                <Button onClick={auditAll} variant="default" size="sm">
                  View Version Drift Matrix →
                </Button>
              )}
            </div>

            {/* Project list */}
            <div className="space-y-2">
              {result.csprojFiles.map((project) => {
                const parsed: ParsedCsproj = parseCsproj(project.content);
                const pkgCount = parsed.packageReferences.length;
                return (
                  <Card key={project.path} className="hover:shadow-md transition-shadow cursor-pointer group" >
                    <CardContent className="pt-4 pb-4" onClick={() => auditProject(project)}>
                      <div className="flex items-center gap-3">
                        <div className="rounded-lg bg-primary/10 p-2 shrink-0">
                          <FileCode2 className="h-4 w-4 text-primary" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold truncate">{project.projectName}</p>
                          <p className="text-[11px] text-muted-foreground font-mono truncate">{project.path}</p>
                          <div className="flex items-center gap-1.5 mt-1">
                            {parsed.sdk && <Badge variant="secondary" className="text-[9px] font-mono">{parsed.sdk}</Badge>}
                            {parsed.targetFrameworks.length > 0 && (
                              <Badge variant="outline" className="text-[9px] font-mono">
                                {parsed.targetFrameworks.join(", ")}
                              </Badge>
                            )}
                            <Badge variant="outline" className="text-[9px]">
                              {pkgCount} package{pkgCount === 1 ? "" : "s"}
                            </Badge>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                          Audit →
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Features info */}
        {!result && !scanning && !error && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-8">
            <Card>
              <CardContent className="pt-5 text-center">
                <div className="rounded-full bg-indigo-500/10 p-3 w-fit mx-auto mb-2">
                  <Search className="h-5 w-5 text-indigo-500" />
                </div>
                <h3 className="text-sm font-semibold">Direct Parsing</h3>
                <p className="text-[11px] text-muted-foreground mt-1">Fetches .csproj files via GitHub API — no cloning needed.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-5 text-center">
                <div className="rounded-full bg-purple-500/10 p-3 w-fit mx-auto mb-2">
                  <GitBranch className="h-5 w-5 text-purple-500" />
                </div>
                <h3 className="text-sm font-semibold">Branch Selector</h3>
                <p className="text-[11px] text-muted-foreground mt-1">Target specific branches or tags to compare dependencies.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-5 text-center">
                <div className="rounded-full bg-emerald-500/10 p-3 w-fit mx-auto mb-2">
                  <FileCode2 className="h-5 w-5 text-emerald-500" />
                </div>
                <h3 className="text-sm font-semibold">.sln Support</h3>
                <p className="text-[11px] text-muted-foreground mt-1">Discovers all .csproj files from solution files automatically.</p>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
