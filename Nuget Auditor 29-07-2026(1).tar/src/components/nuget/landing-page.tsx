"use client";

import { useState, useEffect } from "react";
import {
  Zap,
  GitGraph,
  Bot,
  ShieldCheck,
  Terminal,
  Network,
  ArrowRight,
  Sparkles,
  TrendingUp,
  Lock,
  Github,
  FileCode2,
  CheckCircle2,
  Star,
  ChevronDown,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface Props {
  onLoadSample: () => void;
  onScrollToUpload: () => void;
}

const FEATURES = [
  {
    icon: GitGraph,
    title: "Force-directed graph",
    desc: "Watch your dependencies come alive in a real-time physics simulation. Drag, zoom, and explore every connection.",
    color: "from-blue-500 to-cyan-500",
    badge: "Interactive",
  },
  {
    icon: Bot,
    title: "AI remediation advisor",
    desc: "A senior .NET security advisor writes your prioritized upgrade plan with copy-ready dotnet commands.",
    color: "from-purple-500 to-pink-500",
    badge: "AI-powered",
  },
  {
    icon: ShieldCheck,
    title: "CVE auditing",
    desc: "Per-version matching against GitHub advisories with severity badges and a composite health score.",
    color: "from-emerald-500 to-teal-500",
    badge: "Security",
  },
  {
    icon: Terminal,
    title: "Upgrade toolkit",
    desc: "One-click dotnet CLI scripts, patched .csproj files, and Markdown audit reports for your team.",
    color: "from-orange-500 to-amber-500",
    badge: "Export",
  },
  {
    icon: TrendingUp,
    title: "Popularity metrics",
    desc: "See download counts for every package, with a risk-vs-popularity scatter chart.",
    color: "from-indigo-500 to-violet-500",
    badge: "Insights",
  },
  {
    icon: Lock,
    title: "License compliance",
    desc: "Automatic license classification — flag GPL, AGPL, and restrictive licenses before they reach production.",
    color: "from-rose-500 to-red-500",
    badge: "Compliance",
  },
];

const STATS = [
  { value: "nuget.org", label: "v3 API" },
  { value: "0", label: "data stored" },
  { value: "7", label: "audit views" },
  { value: "100%", label: "client-parsed" },
];

const STEPS = [
  {
    num: "01",
    title: "Drop your .csproj",
    desc: "Drag & drop, paste XML, or load a sample. Parsed locally in your browser — nothing leaves your machine until the audit.",
  },
  {
    num: "02",
    title: "Get instant audit",
    desc: "Every PackageReference is checked against nuget.org for the latest version, vulnerabilities, and deprecation status.",
  },
  {
    num: "03",
    title: "Visualize & fix",
    desc: "Explore the force graph, read the AI remediation plan, and copy the exact dotnet commands to upgrade.",
  },
];

export function LandingPage({ onLoadSample, onScrollToUpload }: Props) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="relative">
      {/* ===== HERO ===== */}
      <section className="relative overflow-hidden">
        {/* Background layers */}
        <div className="absolute inset-0 bg-grid opacity-50 pointer-events-none" />
        <div className="absolute -top-32 -right-32 h-[28rem] w-[28rem] rounded-full bg-primary/10 blur-3xl animate-slow-spin pointer-events-none" />
        <div className="absolute top-1/3 -left-40 h-80 w-80 rounded-full bg-purple-500/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 right-1/4 h-64 w-64 rounded-full bg-pink-500/10 blur-3xl animate-float pointer-events-none" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 md:pt-24 pb-12">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-6 gap-1.5 animate-fade-up px-3 py-1">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
              </span>
              Live nuget.org data · No signup required
            </Badge>

            <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight leading-[1.05] animate-fade-up" style={{ animationDelay: "60ms" }}>
              See your{" "}
              <span className="relative inline-block">
                <span className="bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent animate-shimmer">
                  dependencies
                </span>
                <svg className="absolute -bottom-2 left-0 w-full" height="8" viewBox="0 0 200 8" preserveAspectRatio="none">
                  <path d="M0,4 Q50,0 100,4 T200,4" stroke="url(#grad)" strokeWidth="3" fill="none" strokeLinecap="round" />
                  <defs>
                    <linearGradient id="grad" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="var(--primary)" />
                      <stop offset="50%" stopColor="#a855f7" />
                      <stop offset="100%" stopColor="#ec4899" />
                    </linearGradient>
                  </defs>
                </svg>
              </span>
              <br className="hidden sm:block" />
              catch the{" "}
              <span className="text-red-500">vulnerable</span> ones.
            </h1>

            <p className="mt-8 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-up leading-relaxed" style={{ animationDelay: "120ms" }}>
              Drop in a <code className="text-foreground font-mono text-base bg-muted px-1.5 py-0.5 rounded">.csproj</code> file and
              the auditor maps your dependency tree, flags outdated packages, and finds security advisories —
              all in one beautiful dashboard.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 animate-fade-up" style={{ animationDelay: "180ms" }}>
              <Button
                size="lg"
                className="group bg-gradient-to-r from-primary to-purple-500 hover:from-primary/90 hover:to-purple-500/90 text-white border-0 h-12 px-8 text-base shadow-lg shadow-purple-500/25"
                onClick={onScrollToUpload}
              >
                Start auditing
                <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-12 px-8 text-base"
                onClick={onLoadSample}
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Try with sample
              </Button>
            </div>

            {/* Stats bar */}
            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto animate-fade-up" style={{ animationDelay: "240ms" }}>
              {STATS.map((s) => (
                <div key={s.label} className="text-center">
                  <p className="text-2xl md:text-3xl font-bold bg-gradient-to-br from-foreground to-foreground/60 bg-clip-text text-transparent">
                    {s.value}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Scroll indicator */}
          <div className="flex justify-center mt-16 animate-fade-up" style={{ animationDelay: "300ms" }}>
            <ChevronDown className="h-5 w-5 text-muted-foreground animate-bounce" />
          </div>
        </div>
      </section>

      {/* ===== FEATURES GRID ===== */}
      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <Badge variant="outline" className="mb-3 gap-1">
            <Star className="h-3 w-3" />
            Features
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
            Everything you need to keep your{" "}
            <span className="bg-gradient-to-r from-primary to-purple-500 bg-clip-text text-transparent">.NET project healthy</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            Six powerful tools in one fast, beautiful dashboard. No installation, no signup, no data stored.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f, i) => (
            <div
              key={f.title}
              className="group relative rounded-2xl border bg-card p-6 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden animate-fade-up h-full flex flex-col"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              {/* gradient glow */}
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-5 transition-opacity duration-500 pointer-events-none" />

              <div className="flex items-start justify-between mb-4">
                <div className={cn("rounded-xl bg-gradient-to-br p-3 shadow-lg group-hover:scale-110 transition-transform duration-300", f.color)}>
                  <f.icon className="h-5 w-5 text-white" />
                </div>
                <Badge variant="secondary" className="text-[10px]">{f.badge}</Badge>
              </div>
              <h3 className="text-lg font-semibold mb-1.5">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ===== HOW IT WORKS ===== */}
      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 border-t">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <Badge variant="outline" className="mb-3 gap-1">
            <Zap className="h-3 w-3" />
            How it works
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Three steps to a secure project</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {STEPS.map((s, i) => (
            <div key={s.num} className="relative">
              {i < STEPS.length - 1 && (
                <div className="hidden md:block absolute top-8 left-[60%] w-full h-px bg-gradient-to-r from-border to-transparent" />
              )}
              <div className="relative rounded-2xl border bg-card p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-3xl font-bold bg-gradient-to-br from-primary to-purple-500 bg-clip-text text-transparent">
                    {s.num}
                  </span>
                  {i === 0 && <FileCode2 className="h-5 w-5 text-muted-foreground" />}
                  {i === 1 && <ShieldCheck className="h-5 w-5 text-muted-foreground" />}
                  {i === 2 && <CheckCircle2 className="h-5 w-5 text-muted-foreground" />}
                </div>
                <h3 className="text-lg font-semibold mb-1.5">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ===== CTA ===== */}
      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <div className="relative rounded-3xl border bg-gradient-to-br from-primary/10 via-purple-500/10 to-pink-500/10 p-10 md:p-16 text-center overflow-hidden">
          <div className="absolute -top-16 -right-16 h-48 w-48 rounded-full bg-purple-500/20 blur-3xl animate-slow-spin pointer-events-none" />
          <div className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-pink-500/20 blur-3xl pointer-events-none" />
          <div className="relative">
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight max-w-2xl mx-auto">
              Ready to audit your{" "}
              <span className="bg-gradient-to-r from-primary to-purple-500 bg-clip-text text-transparent">dependencies?</span>
            </h2>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              No signup. No data stored. Just paste your csproj and get a full security audit in seconds.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button
                size="lg"
                className="group bg-gradient-to-r from-primary to-purple-500 hover:from-primary/90 hover:to-purple-500/90 text-white border-0 h-12 px-8 text-base shadow-lg shadow-purple-500/25"
                onClick={onScrollToUpload}
              >
                Start now
                <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-12 px-8 text-base"
                onClick={onLoadSample}
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Load sample project
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="border-t">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="rounded-md bg-primary p-1">
              <Network className="h-3 w-3 text-primary-foreground" />
            </div>
            <span>NuGet Visualizer &amp; Auditor</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="https://learn.microsoft.com/en-us/nuget/" target="_blank" rel="noreferrer noopener" className="hover:text-foreground transition-colors">
              NuGet docs
            </a>
            <a href="https://github.com/advisories" target="_blank" rel="noreferrer noopener" className="hover:text-foreground transition-colors">
              <Github className="h-3.5 w-3.5 inline mr-1" />
              Advisories
            </a>
            <span className="opacity-60">No data leaves your browser</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
