"use client";

import { useState, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/lib/store";
import {
  Github,
  Loader2,
  GitBranch,
  FileCode2,
  ArrowRight,
  Search,
  AlertCircle,
  CheckCircle2,
  ShieldAlert,
  ArrowUpCircle,
  Activity,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Boxes,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/nuget/theme-toggle";
import Link from "next/link";
import { toast } from "sonner";
import { parseCsproj, type ParsedCsproj } from "@/lib/csproj-parser";
import type { AuditResult } from "@/lib/audit";
import { cn } from "@/lib/utils";

interface ScanResult {
  repo: string;
  branch: string;
  slnFiles: string[];
  csprojFiles: Array<{ path: string; content: string; projectName: string }>;
}

interface ProjectAuditState {
  loading: boolean;
  result: AuditResult | null;
  error: string | null;
  expanded: boolean;
}

export default function ScanPage() {
  const router = useRouter();
  const [url, setUrl] = useState("");
  const [branch, setBranch] = useState("");
  const [githubToken, setGithubToken] = useState("");
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [branches, setBranches] = useState<string[]>([]);
  const [fetchingBranches, setFetchingBranches] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Per-project audit state: keyed by project path
  const [audits, setAudits] = useState<Record<string, ProjectAuditState>>({});

  // Restore scan context from store
  const scanContext = useAppStore((s) => s.scanContext);
  const setScanContext = useAppStore((s) => s.setScanContext);
  const setPending = useAppStore((s) => s.setPending);
  const setScannedProjects = useAppStore((s) => s.setScannedProjects);

  useEffect(() => {
    if (scanContext && !result) {
      setUrl(scanContext.url);
      setBranch(scanContext.branch);
      setResult({
        repo: scanContext.repo,
        branch: scanContext.branch,
        slnFiles: scanContext.slnFiles,
        csprojFiles: scanContext.csprojFiles,
      });
    }
  }, [scanContext]);  

  const scan = useCallback(async () => {
    if (!url.trim()) return;
    setScanning(true);
    setError(null);
    setResult(null);
    setAudits({});
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (githubToken.trim()) {
        headers["x-github-token"] = githubToken.trim();
      }
      const res = await fetch("/api/github-scan", {
        method: "POST",
        headers,
        body: JSON.stringify({ url: url.trim(), branch: branch.trim() }),
      });
      const data = await res.json();
      if (data.ok) {
        setResult(data.result);
        setScanContext({
          url: url.trim(),
          branch: branch.trim() || data.result.branch,
          repo: data.result.repo,
          slnFiles: data.result.slnFiles,
          csprojFiles: data.result.csprojFiles,
        });
        toast.success(`Found ${data.result.csprojFiles.length} .csproj files in ${data.result.repo}`);
      } else {
        setError(data.error || "Scan failed");
        toast.error(data.error || "Scan failed");
      }
    } catch (err) {
      setError(String(err));
      toast.error("Scan failed");
    } finally {
      setScanning(false);
    }
  }, [url, branch]);

  const fetchBranches = useCallback(async (repoUrl: string, token?: string) => {
    const match = repoUrl.match(/github\.com\/([^\/]+)\/([^\/\?#]+)/);
    if (!match) return;
    const [, owner, repo] = match;
    const cleanRepo = repo.replace(/\.git$/, "");
    setFetchingBranches(true);
    try {
      const headers: Record<string, string> = {};
      if (token?.trim()) headers["x-github-token"] = token.trim();
      const res = await fetch(`/api/github-scan?owner=${owner}&repo=${cleanRepo}`, { headers });
      const data = await res.json();
      if (data.ok) {
        setBranches([...data.branches, ...data.tags]);
      }
    } catch { }
    finally { setFetchingBranches(false); }
  }, []);

  const onUrlChange = (v: string) => {
    setUrl(v);
    setBranches([]);
    if (v.includes("github.com/")) {
      fetchBranches(v, githubToken);
    }
  };

  // --- Inline audit: runs the audit API call in-place, no page navigation ---
  const auditInline = async (project: { path: string; content: string; projectName: string }) => {
    setAudits((prev) => ({
      ...prev,
      [project.path]: { loading: true, result: null, error: null, expanded: true },
    }));
    try {
      const res = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: project.content }),
      });
      const data = await res.json();
      if (data.ok) {
        setAudits((prev) => ({
          ...prev,
          [project.path]: { loading: false, result: data.result, error: null, expanded: true },
        }));
        toast.success(`Audit complete: ${project.projectName}`);
      } else {
        setAudits((prev) => ({
          ...prev,
          [project.path]: { loading: false, result: null, error: data.error || "Audit failed", expanded: true },
        }));
        toast.error(`Audit failed: ${project.projectName}`);
      }
    } catch (err) {
      setAudits((prev) => ({
        ...prev,
        [project.path]: { loading: false, result: null, error: String(err), expanded: true },
      }));
      toast.error(`Audit failed: ${project.projectName}`);
    }
  };

  const toggleExpand = (path: string) => {
    setAudits((prev) => ({
      ...prev,
      [path]: { ...(prev[path] || { loading: false, result: null, error: null }), expanded: !(prev[path]?.expanded) },
    }));
  };

  // Open full report on home page (optional — for users who want the full dashboard)
  const openFullReport = (project: { content: string; projectName: string }) => {
    setPending(project.content, project.projectName);
    router.push("/");
  };

  const auditAll = () => {
    if (!result) return;
    setScannedProjects(result.csprojFiles);
    router.push("/matrix");
  };

  // Bulk audit all projects
  const auditAllInline = async () => {
    if (!result) return;
    for (const project of result.csprojFiles) {
      if (!audits[project.path]?.result) {
        await auditInline(project);
      }
    }
    toast.success(`Bulk audit complete: ${result.csprojFiles.length} projects`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 h-14 flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5">
              <Github className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-semibold">NuGet Auditor</span>
          </Link>
          <Badge variant="outline" className="text-[10px] gap-1 border-indigo-500/30 text-indigo-600 dark:text-indigo-400">
            <Search className="h-2.5 w-2.5" />
            GitHub Scanner
          </Badge>
          <div className="ml-auto flex items-center gap-2">
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/"><ArrowRight className="h-3.5 w-3.5 rotate-180" /> Back</Link>
            </Button>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/matrix"><Boxes className="h-3.5 w-3.5" /> Matrix</Link>
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 mx-auto w-full max-w-4xl px-4 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Github className="h-6 w-6" />
            Scan a GitHub Repository
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Paste a GitHub URL to scan for .csproj files. Audit projects inline — no page-hopping needed.
          </p>
        </div>

        {/* URL input */}
        <Card>
          <CardContent className="pt-6 space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">GitHub Repository URL</label>
              <div className="flex gap-2">
                <Input
                  value={url}
                  onChange={(e) => onUrlChange(e.target.value)}
                  placeholder="https://github.com/owner/repo"
                  className="flex-1"
                  onKeyDown={(e) => e.key === "Enter" && scan()}
                />
                <Button onClick={scan} disabled={scanning || !url.trim()}>
                  {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                  {scanning ? "Scanning…" : "Scan"}
                </Button>
              </div>
            </div>

            {(branches.length > 0 || fetchingBranches) && (
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block flex items-center gap-1">
                  <GitBranch className="h-3 w-3" />
                  Branch / Tag {fetchingBranches && <Loader2 className="h-3 w-3 animate-spin" />}
                </label>
                <select
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm"
                >
                  <option value="">Default (main/master)</option>
                  {branches.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>
            )}

            {/* GitHub Token (optional — for higher rate limits) */}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                GitHub Token (optional — for higher rate limits)
              </label>
              <input
                type="password"
                value={githubToken}
                onChange={(e) => setGithubToken(e.target.value)}
                placeholder="ghp_xxxx or github_pat_xxxx"
                className="w-full rounded-md border bg-background px-3 py-2 text-sm font-mono"
              />
              <p className="text-[10px] text-muted-foreground mt-1">
                💡 Without a token, GitHub limits to 60 API requests/hour per IP. With a token, you get 5,000/hour.
                Create one at <a href="https://github.com/settings/tokens?type=beta" target="_blank" rel="noreferrer noopener" className="text-primary hover:underline">GitHub Settings → Developer settings → Personal access tokens</a> (public read access is enough).
                Your token is sent only to this server and never stored.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Error */}
        {error && (
          <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 flex items-start gap-2">
            <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-700 dark:text-red-300">Scan failed</p>
              <p className="text-xs text-muted-foreground mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-4 animate-fade-up">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div>
                <h2 className="text-lg font-semibold">{result.repo}</h2>
                <p className="text-xs text-muted-foreground flex items-center gap-1.5 mt-0.5">
                  <GitBranch className="h-3 w-3" />
                  Branch: {result.branch}
                  {result.slnFiles.length > 0 && (
                    <>
                      <span className="mx-1">·</span>
                      <FileCode2 className="h-3 w-3" />
                      {result.slnFiles.length} solution file(s)
                    </>
                  )}
                  <span className="mx-1">·</span>
                  <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                  {result.csprojFiles.length} .csproj file(s)
                </p>
              </div>
              <div className="flex gap-2">
                <Button onClick={auditAllInline} variant="outline" size="sm" disabled={scanning}>
                  <Activity className="h-3.5 w-3.5" />
                  Audit all
                </Button>
                {result.csprojFiles.length > 1 && (
                  <Button onClick={auditAll} variant="default" size="sm">
                    <Boxes className="h-3.5 w-3.5" />
                    Drift Matrix →
                  </Button>
                )}
              </div>
            </div>

            {/* Project list with inline audit */}
            <div className="space-y-3">
              {result.csprojFiles.map((project) => {
                const parsed: ParsedCsproj = parseCsproj(project.content);
                const pkgCount = parsed.packageReferences.length;
                const audit = audits[project.path];
                const isAuditing = audit?.loading;
                const hasResult = audit?.result;
                const hasError = audit?.error;

                return (
                  <Card key={project.path} className="overflow-hidden">
                    {/* Project header row */}
                    <CardContent className="pt-4 pb-4">
                      <div className="flex items-center gap-3">
                        <div className="rounded-lg bg-primary/10 p-2 shrink-0">
                          <FileCode2 className="h-4 w-4 text-primary" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold truncate">{project.projectName}</p>
                          <p className="text-[11px] text-muted-foreground font-mono truncate">{project.path}</p>
                          <div className="flex items-center gap-1.5 mt-1">
                            {parsed.sdk && <Badge variant="secondary" className="text-[9px] font-mono">{parsed.sdk}</Badge>}
                            {parsed.targetFrameworks.length > 0 && (
                              <Badge variant="outline" className="text-[9px] font-mono">
                                {parsed.targetFrameworks.join(", ")}
                              </Badge>
                            )}
                            <Badge variant="outline" className="text-[9px]">
                              {pkgCount} package{pkgCount === 1 ? "" : "s"}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs gap-1.5"
                            onClick={() => auditInline(project)}
                            disabled={isAuditing}
                          >
                            {isAuditing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
                            {isAuditing ? "Auditing…" : "Audit"}
                          </Button>
                          {hasResult && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-xs"
                              onClick={() => toggleExpand(project.path)}
                            >
                              {audit.expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>

                    {/* Inline audit results */}
                    {hasResult && audit.expanded && (
                      <div className="border-t bg-muted/20 p-4 animate-fade-up">
                        <InlineAuditSummary
                          result={audit.result!}
                          onOpenFullReport={() => openFullReport(project)}
                        />
                      </div>
                    )}

                    {/* Inline error */}
                    {hasError && audit.expanded && (
                      <div className="border-t bg-red-500/5 p-4">
                        <div className="flex items-start gap-2">
                          <AlertCircle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                          <div>
                            <p className="text-xs font-semibold text-red-600 dark:text-red-400">Audit failed</p>
                            <p className="text-[11px] text-muted-foreground mt-0.5 font-mono break-all">{audit.error}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Features info */}
        {!result && !scanning && !error && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-8">
            <Card>
              <CardContent className="pt-5 text-center">
                <div className="rounded-full bg-indigo-500/10 p-3 w-fit mx-auto mb-2">
                  <Search className="h-5 w-5 text-indigo-500" />
                </div>
                <h3 className="text-sm font-semibold">Inline Auditing</h3>
                <p className="text-[11px] text-muted-foreground mt-1">Audit projects directly on this page — no navigation needed.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-5 text-center">
                <div className="rounded-full bg-purple-500/10 p-3 w-fit mx-auto mb-2">
                  <GitBranch className="h-5 w-5 text-purple-500" />
                </div>
                <h3 className="text-sm font-semibold">Branch Selector</h3>
                <p className="text-[11px] text-muted-foreground mt-1">Target specific branches or tags to compare dependencies.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-5 text-center">
                <div className="rounded-full bg-emerald-500/10 p-3 w-fit mx-auto mb-2">
                  <Activity className="h-5 w-5 text-emerald-500" />
                </div>
                <h3 className="text-sm font-semibold">Bulk Audit</h3>
                <p className="text-[11px] text-muted-foreground mt-1">Audit all projects at once and compare results side-by-side.</p>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}

/**
 * Compact inline audit summary — shows the most important metrics without
 * the full dashboard. Includes a link to open the full report on the home page.
 */
function InlineAuditSummary({ result, onOpenFullReport }: { result: AuditResult; onOpenFullReport: () => void }) {
  const { stats } = result;

  // Compute health score
  const sevPenalty: Record<string, number> = { low: 8, moderate: 18, high: 35, critical: 60 };
  let score = 100;
  if (stats.maxSeverity) score -= sevPenalty[stats.maxSeverity] ?? 0;
  score -= Math.max(0, stats.vulnerableCount - 1) * 6;
  if (stats.totalPackages > 0) score -= Math.round((stats.outdatedCount / stats.totalPackages) * 25);
  score -= stats.deprecatedCount * 4;
  score = Math.max(0, Math.min(100, score));
  const grade = score >= 90 ? "A" : score >= 75 ? "B" : score >= 60 ? "C" : score >= 40 ? "D" : "F";
  const gradeColor = score >= 90 ? "text-emerald-500" : score >= 75 ? "text-lime-500" : score >= 60 ? "text-yellow-500" : score >= 40 ? "text-orange-500" : "text-red-500";

  return (
    <div className="space-y-3">
      {/* Quick stats row */}
      <div className="flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <div className={cn("text-2xl font-bold", gradeColor)}>{grade}</div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase leading-none">Score</p>
            <p className={cn("text-sm font-bold tabular-nums leading-tight", gradeColor)}>{score}/100</p>
          </div>
        </div>
        <div className="h-8 w-px bg-border" />
        <div className="flex items-center gap-1.5">
          <FileCode2 className="h-4 w-4 text-primary" />
          <div>
            <p className="text-[10px] text-muted-foreground uppercase leading-none">Packages</p>
            <p className="text-sm font-bold tabular-nums leading-tight">{stats.totalPackages}</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <ShieldAlert className={cn("h-4 w-4", stats.vulnerableCount > 0 ? "text-red-500" : "text-emerald-500")} />
          <div>
            <p className="text-[10px] text-muted-foreground uppercase leading-none">Vulnerable</p>
            <p className={cn("text-sm font-bold tabular-nums leading-tight", stats.vulnerableCount > 0 ? "text-red-500" : "text-emerald-500")}>{stats.vulnerableCount}</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <ArrowUpCircle className={cn("h-4 w-4", stats.outdatedCount > 0 ? "text-blue-500" : "text-emerald-500")} />
          <div>
            <p className="text-[10px] text-muted-foreground uppercase leading-none">Outdated</p>
            <p className={cn("text-sm font-bold tabular-nums leading-tight", stats.outdatedCount > 0 ? "text-blue-500" : "text-emerald-500")}>{stats.outdatedCount}</p>
          </div>
        </div>
        <Button variant="outline" size="sm" className="ml-auto text-xs gap-1.5" onClick={onOpenFullReport}>
          <ExternalLink className="h-3 w-3" />
          Full report
        </Button>
      </div>

      {/* Vulnerable packages list (if any) */}
      {stats.vulnerableCount > 0 && (
        <div className="rounded-md border border-red-500/30 bg-red-500/5 p-2.5">
          <p className="text-[10px] font-semibold text-red-600 dark:text-red-400 uppercase mb-1.5">
            ⚠️ Vulnerable packages
          </p>
          <div className="space-y-1">
            {result.packages.filter(p => p.isVulnerable).slice(0, 5).map((pkg) => (
              <div key={pkg.id} className="flex items-center gap-2 text-xs">
                <Badge variant="outline" className="text-[9px] border-red-500/40 text-red-600 dark:text-red-400 bg-red-500/10">
                  {pkg.maxSeverity}
                </Badge>
                <span className="font-mono font-medium">{pkg.id}</span>
                <span className="font-mono text-muted-foreground">{pkg.declaredVersion}</span>
                {pkg.latestStableVersion && (
                  <>
                    <span className="text-muted-foreground">→</span>
                    <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">{pkg.latestStableVersion}</span>
                  </>
                )}
              </div>
            ))}
            {stats.vulnerableCount > 5 && (
              <p className="text-[10px] text-muted-foreground">+{stats.vulnerableCount - 5} more…</p>
            )}
          </div>
        </div>
      )}

      {/* Outdated packages list (if any) */}
      {stats.outdatedCount > 0 && (
        <div className="rounded-md border border-blue-500/30 bg-blue-500/5 p-2.5">
          <p className="text-[10px] font-semibold text-blue-600 dark:text-blue-400 uppercase mb-1.5">
            ⬆️ Outdated packages
          </p>
          <div className="space-y-1">
            {result.packages.filter(p => p.isOutdated).slice(0, 5).map((pkg) => (
              <div key={pkg.id} className="flex items-center gap-2 text-xs">
                <span className="font-mono font-medium">{pkg.id}</span>
                <span className="font-mono text-muted-foreground">{pkg.declaredVersion}</span>
                <span className="text-muted-foreground">→</span>
                <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">{pkg.latestStableVersion}</span>
              </div>
            ))}
            {stats.outdatedCount > 5 && (
              <p className="text-[10px] text-muted-foreground">+{stats.outdatedCount - 5} more…</p>
            )}
          </div>
        </div>
      )}

      {/* Clean state */}
      {stats.vulnerableCount === 0 && stats.outdatedCount === 0 && (
        <div className="flex items-center gap-2 rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2.5">
          <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
            All {stats.totalPackages} packages are up to date with no known vulnerabilities. 🎉
          </p>
        </div>
      )}
    </div>
  );
}
