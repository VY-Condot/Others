"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ExternalLink,
  ShieldAlert,
  ArrowUpCircle,
  Ban,
  Boxes,
  Tag,
  User,
  Calendar,
  Link2,
  Copy,
  Check,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import type { AuditedPackage, AuditSeverity } from "@/lib/audit";

interface Props {
  pkg: AuditedPackage | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

const sevStyle: Record<AuditSeverity, string> = {
  low: "bg-yellow-500/15 text-yellow-700 dark:text-yellow-300 border-yellow-500/30",
  moderate: "bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-500/30",
  high: "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30",
  critical: "bg-red-600/20 text-red-800 dark:text-red-200 border-red-600/40",
};

export function PackageDetailDialog({ pkg, open, onOpenChange }: Props) {
  const [copied, setCopied] = useState(false);

  if (!pkg) return null;

  const snippet = `<PackageReference Include="${pkg.id}" Version="${pkg.latestStableVersion ?? pkg.declaredVersion}" />`;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(snippet);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // ignore
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto custom-scroll">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 flex-wrap">
            <span className="font-mono">{pkg.id}</span>
            {pkg.isVulnerable && (
              <Badge variant="outline" className={cn("uppercase text-[10px]", sevStyle[pkg.maxSeverity!])}>
                <ShieldAlert className="h-3 w-3" /> {pkg.maxSeverity}
              </Badge>
            )}
            {pkg.isOutdated && (
              <Badge variant="outline" className="text-[10px] border-blue-500/40 text-blue-700 dark:text-blue-300 bg-blue-500/10">
                <ArrowUpCircle className="h-3 w-3" /> outdated
              </Badge>
            )}
            {pkg.isDeprecated && (
              <Badge variant="outline" className="text-[10px] border-amber-500/40 text-amber-700 dark:text-amber-300 bg-amber-500/10">
                <Ban className="h-3 w-3" /> deprecated
              </Badge>
            )}
            {pkg.isPrerelease && (
              <Badge variant="outline" className="text-[10px] border-purple-500/40 text-purple-700 dark:text-purple-300 bg-purple-500/10">
                prerelease
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription>
            {pkg.description ?? "No description available from nuget.org."}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <InfoRow icon={Tag} label="Declared" value={pkg.declaredVersion || "—"} mono />
          <InfoRow icon={Boxes} label="Latest stable" value={pkg.latestStableVersion ?? "—"} mono accent />
          <InfoRow
            icon={Calendar}
            label="Latest (incl. pre)"
            value={pkg.latestVersion ?? "—"}
            mono
          />
          <InfoRow
            icon={User}
            label="Authors"
            value={pkg.authors?.join(", ") ?? "—"}
          />
        </div>

        {(pkg.projectUrl || pkg.licenseUrl) && (
          <div className="flex flex-wrap gap-2">
            {pkg.projectUrl && (
              <Button asChild variant="outline" size="sm">
                <a href={pkg.projectUrl} target="_blank" rel="noreferrer noopener">
                  <Link2 className="h-3.5 w-3.5" /> Project
                </a>
              </Button>
            )}
            {pkg.licenseUrl && (
              <Button asChild variant="outline" size="sm">
                <a href={pkg.licenseUrl} target="_blank" rel="noreferrer noopener">
                  <Tag className="h-3.5 w-3.5" /> License
                </a>
              </Button>
            )}
            <Button asChild variant="outline" size="sm">
              <a
                href={`https://www.nuget.org/packages/${encodeURIComponent(pkg.id)}`}
                target="_blank"
                rel="noreferrer noopener"
              >
                <ExternalLink className="h-3.5 w-3.5" /> nuget.org
              </a>
            </Button>
          </div>
        )}

        {/* Vulnerabilities */}
        {pkg.vulnerabilities.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-1.5">
              <ShieldAlert className="h-4 w-4 text-red-500" />
              {pkg.vulnerabilities.length} matching advisories
            </h4>
            <div className="space-y-2">
              {pkg.vulnerabilities.map((v, i) => (
                <div key={i} className="rounded-md border border-red-500/30 bg-red-500/5 p-3 text-xs space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={cn("uppercase text-[10px]", sevStyle[v.severity])}>
                      {v.severity}
                    </Badge>
                    <span className="font-mono text-muted-foreground">{v.range}</span>
                  </div>
                  {v.advisoryTitle && <p className="font-medium">{v.advisoryTitle}</p>}
                  <a
                    href={v.advisoryUrl}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex items-center gap-1 text-primary hover:underline"
                  >
                    <ExternalLink className="h-3 w-3" /> View advisory
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Transitive deps */}
        {pkg.transitiveDependencies.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-1.5">
              <Boxes className="h-4 w-4" />
              {pkg.transitiveDependencies.length} transitive dependencies
            </h4>
            <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto custom-scroll rounded-md border p-2">
              {pkg.transitiveDependencies.map((d, i) => (
                <Badge key={i} variant="secondary" className="font-mono text-[10px] gap-1">
                  {d.id}
                  <span className="text-muted-foreground">{d.range}</span>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Deprecation */}
        {pkg.isDeprecated && (
          <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3 text-xs space-y-1">
            <p className="font-semibold flex items-center gap-1.5">
              <Ban className="h-4 w-4 text-amber-500" /> Deprecated
            </p>
            {pkg.deprecationReasons.length > 0 && (
              <p className="text-muted-foreground">Reasons: {pkg.deprecationReasons.join(", ")}</p>
            )}
          </div>
        )}

        {/* Copyable snippet */}
        <div className="space-y-1.5">
          <h4 className="text-sm font-semibold">Recommended PackageReference</h4>
          <div className="relative rounded-md border bg-muted/40">
            <pre className="text-xs font-mono p-3 pr-10 overflow-x-auto">{snippet}</pre>
            <Button
              size="sm"
              variant="ghost"
              onClick={copy}
              className="absolute top-1.5 right-1.5 h-7 w-7 p-0"
              aria-label="Copy snippet"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Uses the latest stable version{pkg.latestStableVersion ? ` (${pkg.latestStableVersion})` : ""}. Review breaking changes before upgrading.
          </p>
        </div>

        {pkg.error && (
          <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3 text-xs">
            <p className="font-medium text-amber-700 dark:text-amber-300">Audit note</p>
            <p className="text-muted-foreground mt-0.5">{pkg.error}</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
  mono,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  mono?: boolean;
  accent?: boolean;
}) {
  return (
    <div className="rounded-md border bg-card p-3">
      <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mb-1">
        <Icon className="h-3 w-3" />
        {label}
      </div>
      <div className={cn("text-sm", mono && "font-mono", accent && "text-emerald-600 dark:text-emerald-400 font-semibold")}>
        {value}
      </div>
    </div>
  );
}
