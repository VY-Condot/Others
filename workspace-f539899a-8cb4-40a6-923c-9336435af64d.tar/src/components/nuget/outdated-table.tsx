"use client";

import { useMemo, useState } from "react";
import { ArrowUpCircle, ArrowUpDown, ExternalLink } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import semver from "semver";
import type { AuditedPackage } from "@/lib/audit";

interface Props {
  packages: AuditedPackage[];
  onSelect: (pkg: AuditedPackage) => void;
}

type SortKey = "id" | "version" | "behind";

function majorBump(a: string, b: string): boolean {
  const ca = semver.coerce(a);
  const cb = semver.coerce(b);
  if (!ca || !cb) return false;
  return ca.major < cb.major;
}

export function OutdatedTable({ packages, onSelect }: Props) {
  const outdated = useMemo(() => packages.filter((p) => p.isOutdated && p.latestStableVersion), [packages]);
  const [sortKey, setSortKey] = useState<SortKey>("behind");
  const [asc, setAsc] = useState(false);

  const sorted = useMemo(() => {
    const rows = [...outdated];
    rows.sort((a, b) => {
      let cmp = 0;
      if (sortKey === "id") cmp = a.id.localeCompare(b.id);
      else if (sortKey === "version") cmp = (a.declaredVersion || "").localeCompare(b.declaredVersion || "", undefined, { numeric: true });
      else {
        // "behind" — by semver distance, biggest first
        const da = semver.coerce(a.declaredVersion)?.version ?? "0.0.0";
        const db = semver.coerce(b.declaredVersion)?.version ?? "0.0.0";
        const la = semver.coerce(a.latestStableVersion)?.version ?? "0.0.0";
        const lb = semver.coerce(b.latestStableVersion)?.version ?? "0.0.0";
        cmp = semver.compare(la, lb) - semver.compare(la, db) - (semver.compare(la, db) - semver.compare(lb, db));
        // simpler: compare by diff of major versions
        cmp = (semver.major(lb) - semver.major(db)) - (semver.major(la) - semver.major(da));
      }
      return asc ? cmp : -cmp;
    });
    return rows;
  }, [outdated, sortKey, asc]);

  const toggleSort = (k: SortKey) => {
    if (k === sortKey) setAsc((a) => !a);
    else {
      setSortKey(k);
      setAsc(false);
    }
  };

  if (outdated.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-10 text-center gap-2">
        <div className="rounded-full bg-emerald-500/10 p-3">
          <ArrowUpCircle className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
        </div>
        <p className="text-sm font-medium">All packages are up to date</p>
        <p className="text-xs text-muted-foreground max-w-sm">
          Every declared version matches (or exceeds) the latest stable release published on nuget.org.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <ArrowUpCircle className="h-4 w-4 text-blue-500" />
        <span>
          <span className="font-semibold text-foreground">{outdated.length}</span> package
          {outdated.length === 1 ? "" : "s"} behind the latest stable release.
        </span>
      </div>

      <div className="rounded-md border overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>
                <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort("id")}>
                  Package <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead>
                <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort("version")}>
                  Declared <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead>Latest stable</TableHead>
              <TableHead>
                <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort("behind")}>
                  Bump <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sorted.map((p) => {
              const isMajor = majorBump(p.declaredVersion, p.latestStableVersion || "0.0.0");
              return (
                <TableRow
                  key={p.id}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => onSelect(p)}
                >
                  <TableCell className="font-mono text-xs font-medium">{p.id}</TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">{p.declaredVersion}</TableCell>
                  <TableCell className="font-mono text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                    {p.latestStableVersion}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[10px]",
                        isMajor
                          ? "border-orange-500/40 text-orange-700 dark:text-orange-300 bg-orange-500/10"
                          : "border-blue-500/40 text-blue-700 dark:text-blue-300 bg-blue-500/10",
                      )}
                    >
                      {isMajor ? "major" : "minor/patch"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" className="h-7 text-xs">
                      Details
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <p className="text-[11px] text-muted-foreground flex items-center gap-1">
        <ExternalLink className="h-3 w-3" />
        Tip: click any row to see full package metadata, advisories, and a copy-ready PackageReference snippet.
      </p>
    </div>
  );
}
