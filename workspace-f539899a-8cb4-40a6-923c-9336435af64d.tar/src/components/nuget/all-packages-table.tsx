"use client";

import { useMemo, useState } from "react";
import { ArrowUpDown, Search } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import type { AuditedPackage } from "@/lib/audit";

interface Props {
  packages: AuditedPackage[];
  onSelect: (pkg: AuditedPackage) => void;
}

type SortKey = "id" | "version" | "latest" | "status";

const sevDot: Record<string, string> = {
  low: "bg-yellow-500",
  moderate: "bg-orange-500",
  high: "bg-red-500",
  critical: "bg-red-600",
};

export function AllPackagesTable({ packages, onSelect }: Props) {
  const [query, setQuery] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("id");
  const [asc, setAsc] = useState(true);
  const [filter, setFilter] = useState<"all" | "vulnerable" | "outdated" | "deprecated">("all");

  const filtered = useMemo(() => {
    let list = packages;
    if (filter === "vulnerable") list = list.filter((p) => p.isVulnerable);
    else if (filter === "outdated") list = list.filter((p) => p.isOutdated);
    else if (filter === "deprecated") list = list.filter((p) => p.isDeprecated);

    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter((p) => p.id.toLowerCase().includes(q));
    }

    const sorted = [...list].sort((a, b) => {
      let cmp = 0;
      if (sortKey === "id") cmp = a.id.localeCompare(b.id);
      else if (sortKey === "version") cmp = (a.declaredVersion || "").localeCompare(b.declaredVersion || "", undefined, { numeric: true });
      else if (sortKey === "latest") cmp = (a.latestStableVersion || "").localeCompare(b.latestStableVersion || "", undefined, { numeric: true });
      else {
        // status: vulnerable first, then outdated, then ok
        const score = (p: AuditedPackage) => (p.isVulnerable ? 0 : p.isOutdated ? 1 : p.isDeprecated ? 2 : 3);
        cmp = score(a) - score(b);
      }
      return asc ? cmp : -cmp;
    });
    return sorted;
  }, [packages, query, sortKey, asc, filter]);

  const toggleSort = (k: SortKey) => {
    if (k === sortKey) setAsc((a) => !a);
    else {
      setSortKey(k);
      setAsc(true);
    }
  };

  const filters: { key: typeof filter; label: string }[] = [
    { key: "all", label: "All" },
    { key: "vulnerable", label: "Vulnerable" },
    { key: "outdated", label: "Outdated" },
    { key: "deprecated", label: "Deprecated" },
  ];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            placeholder="Filter by package id…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-8 h-8 text-sm"
          />
        </div>
        <div className="flex rounded-md border overflow-hidden">
          {filters.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={cn(
                "px-3 py-1.5 text-xs font-medium transition-colors",
                filter === f.key
                  ? "bg-primary text-primary-foreground"
                  : "hover:bg-muted",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-md border overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>
                <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort("id")}>
                  Package <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead>
                <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort("version")}>
                  Declared <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead>
                <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort("latest")}>
                  Latest <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead>
                <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort("status")}>
                  Status <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center text-sm text-muted-foreground py-8">
                  No packages match the current filter.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((p) => (
                <TableRow
                  key={p.id}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => onSelect(p)}
                >
                  <TableCell className="font-mono text-xs font-medium">{p.id}</TableCell>
                  <TableCell className="font-mono text-xs">{p.declaredVersion}</TableCell>
                  <TableCell className="font-mono text-xs">
                    {p.latestStableVersion ? (
                      <span className={p.isOutdated ? "text-emerald-600 dark:text-emerald-400 font-semibold" : "text-muted-foreground"}>
                        {p.latestStableVersion}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1 flex-wrap">
                      {p.isVulnerable && p.maxSeverity && (
                        <Badge variant="outline" className="text-[10px] gap-1 border-red-500/40 text-red-700 dark:text-red-300 bg-red-500/10">
                          <span className={cn("h-1.5 w-1.5 rounded-full", sevDot[p.maxSeverity])} />
                          {p.maxSeverity}
                        </Badge>
                      )}
                      {p.isOutdated && (
                        <Badge variant="outline" className="text-[10px] border-blue-500/40 text-blue-700 dark:text-blue-300 bg-blue-500/10">
                          outdated
                        </Badge>
                      )}
                      {p.isDeprecated && (
                        <Badge variant="outline" className="text-[10px] border-amber-500/40 text-amber-700 dark:text-amber-300 bg-amber-500/10">
                          deprecated
                        </Badge>
                      )}
                      {p.isPrerelease && (
                        <Badge variant="outline" className="text-[10px] border-purple-500/40 text-purple-700 dark:text-purple-300 bg-purple-500/10">
                          pre
                        </Badge>
                      )}
                      {!p.isVulnerable && !p.isOutdated && !p.isDeprecated && !p.isPrerelease && (
                        <Badge variant="outline" className="text-[10px] border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10">
                          ok
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
