"use client";

import { useCallback, useState } from "react";
import {
  PackageSearch,
  Github,
  ShieldCheck,
  Network,
  Zap,
  FileCode2,
  AlertCircle,
  RefreshCw,
  GitGraph,
  Bot,
  Terminal,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";

import { ThemeToggle } from "@/components/nuget/theme-toggle";
import { FileUploader } from "@/components/nuget/file-uploader";
import { StatsCards } from "@/components/nuget/stats-cards";
import { DependencyTree } from "@/components/nuget/dependency-tree";
import { VulnerabilityTable } from "@/components/nuget/vulnerability-table";
import { OutdatedTable } from "@/components/nuget/outdated-table";
import { AllPackagesTable } from "@/components/nuget/all-packages-table";
import { PackageDetailDialog } from "@/components/nuget/package-detail-dialog";
import { HealthScore } from "@/components/nuget/health-score";
import { ForceGraph } from "@/components/nuget/force-graph";
import { AiAdvisor } from "@/components/nuget/ai-advisor";
import { UpgradeGenerator } from "@/components/nuget/upgrade-generator";
import { AnalyticsDashboard } from "@/components/nuget/analytics-dashboard";
import { LicensePanel } from "@/components/nuget/license-panel";
import { PopularityPanel } from "@/components/nuget/popularity-panel";
import { VersionCompareDialog } from "@/components/nuget/version-compare-dialog";
import { AuditHistory } from "@/components/nuget/audit-history";
import { KeyboardShortcuts } from "@/components/nuget/keyboard-shortcuts";
import { AuditDiffView } from "@/components/nuget/audit-diff-view";
import { ChangelogViewer } from "@/components/nuget/changelog-viewer";
import { BarChart3, GitCompare, History, Save, BookOpen } from "lucide-react";

import type { AuditResult, AuditedPackage, DependencyTreeNode } from "@/lib/audit";

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedPkg, setSelectedPkg] = useState<AuditedPackage | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [comparePkg, setComparePkg] = useState<AuditedPackage | null>(null);
  const [compareOpen, setCompareOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [historyRefreshKey, setHistoryRefreshKey] = useState(0);
  const [activeTab, setActiveTab] = useState("graph");
  const [diffOpen, setDiffOpen] = useState(false);
  const [historyRuns, setHistoryRuns] = useState<Array<{
    id: string; projectName: string; createdAt: string; healthScore: number;
    totalPackages: number; outdatedCount: number; vulnerableCount: number;
  }>>([]);
  const [changelogPkg, setChangelogPkg] = useState<{ id: string; version: string } | null>(null);
  const [changelogOpen, setChangelogOpen] = useState(false);

  const onAudit = useCallback(async (content: string, filename?: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || `Audit failed (HTTP ${res.status})`);
      }
      setResult(data.result as AuditResult);
      const r = data.result as AuditResult;
      toast.success(
        `Audited ${r.stats.totalPackages} packages — ${r.stats.vulnerableCount} vulnerable, ${r.stats.outdatedCount} outdated`,
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
      toast.error("Audit failed", { description: msg });
    } finally {
      setLoading(false);
      // void filename to satisfy lint if unused
      void filename;
    }
  }, []);

  const onPkgSelect = useCallback((pkg: AuditedPackage) => {
    setSelectedPkg(pkg);
    setDialogOpen(true);
  }, []);

  const onCompare = useCallback((pkg: AuditedPackage) => {
    setComparePkg(pkg);
    setCompareOpen(true);
  }, []);

  const saveAudit = useCallback(async () => {
    if (!result) return;
    setSaving(true);
    try {
      const res = await fetch("/api/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result }),
      });
      const data = await res.json();
      if (data.ok) {
        toast.success("Audit saved to history");
        setHistoryRefreshKey((k) => k + 1);
      } else {
        toast.error("Save failed", { description: data.error });
      }
    } catch (err) {
      toast.error("Save failed", { description: String(err) });
    } finally {
      setSaving(false);
    }
  }, [result]);

  const handleShortcut = useCallback(
    (key: string) => {
      const tabMap: Record<string, string> = {
        "g f": "graph",
        "g t": "tree",
        "g v": "vulns",
        "g o": "outdated",
        "g a": "analytics",
        "g p": "all",
        "g u": "upgrade",
      };
      if (tabMap[key]) {
        setActiveTab(tabMap[key]);
        return;
      }
      if (key === "h") setHistoryOpen(true);
      else if (key === "s") saveAudit();
      else if (key === "n") {
        setResult(null);
        setError(null);
      } else if (key === "/") {
        const search = document.querySelector('input[placeholder*="Filter"]') as HTMLInputElement | null;
        search?.focus();
      }
    },
    [saveAudit],
  );

  const openDiff = useCallback(async () => {
    try {
      const res = await fetch("/api/history");
      const data = await res.json();
      if (data.ok) setHistoryRuns(data.runs);
    } catch {
      // ignore
    }
    setDiffOpen(true);
  }, []);

  const openChangelog = useCallback((pkg: AuditedPackage) => {
    setChangelogPkg({ id: pkg.id, version: pkg.declaredVersion });
    setChangelogOpen(true);
  }, []);

  const onTreeNodeSelect = useCallback(
    (node: DependencyTreeNode) => {
      if (node.kind === "root") return;
      // find matching audited package by id (case-insensitive)
      const match = result?.packages.find((p) => p.id.toLowerCase() === node.id.toLowerCase());
      if (match) {
        setSelectedPkg(match);
        setDialogOpen(true);
      }
    },
    [result],
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-14 flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-primary p-1.5">
              <PackageSearch className="h-4 w-4 text-primary-foreground" />
            </div>
            <div className="leading-tight">
              <h1 className="text-sm font-semibold">NuGet Visualizer &amp; Auditor</h1>
              <p className="text-[10px] text-muted-foreground hidden sm:block">
                parse · visualize · audit
              </p>
            </div>
          </div>

          <Badge variant="outline" className="hidden md:inline-flex text-[10px] gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
            nuget.org v3 API
          </Badge>

          <div className="ml-auto flex items-center gap-1.5">
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <a
                href="https://learn.microsoft.com/en-us/nuget/api/overview"
                target="_blank"
                rel="noreferrer noopener"
              >
                <FileCode2 className="h-3.5 w-3.5" /> API docs
              </a>
            </Button>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <a
                href="https://github.com/advisories?query=type%3Areviewed+ecosystem%3Anuget"
                target="_blank"
                rel="noreferrer noopener"
              >
                <Github className="h-3.5 w-3.5" /> Advisories
              </a>
            </Button>
            {result && (
              <Button
                variant="outline"
                size="sm"
                className="text-xs gap-1.5"
                onClick={saveAudit}
                disabled={saving}
              >
                {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                <span className="hidden sm:inline">Save</span>
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              className="text-xs gap-1.5"
              onClick={() => setHistoryOpen(true)}
            >
              <History className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">History</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-xs gap-1.5"
              onClick={openDiff}
            >
              <GitCompare className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Diff</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-xs"
              onClick={() => handleShortcut("?")}
              aria-label="Keyboard shortcuts"
              title="Keyboard shortcuts (?)"
            >
              <kbd className="font-mono text-[10px]">?</kbd>
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Hero */}
      {!result && (
        <section className="relative overflow-hidden border-b">
          {/* Grid background */}
          <div className="absolute inset-0 bg-grid opacity-60 pointer-events-none" />
          {/* Floating decorative orbs */}
          <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-primary/10 blur-3xl animate-slow-spin pointer-events-none" />
          <div className="absolute top-1/2 -left-32 h-64 w-64 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-20 right-1/3 h-48 w-48 rounded-full bg-pink-500/5 blur-2xl animate-float pointer-events-none" />

          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 md:py-20">
            <div className="max-w-3xl">
              <Badge variant="secondary" className="mb-4 gap-1 animate-fade-up">
                <Zap className="h-3 w-3" />
                Client-parsed · server-audited · live nuget.org data
              </Badge>
              <h2 className="text-3xl md:text-5xl font-bold tracking-tight leading-tight animate-fade-up" style={{ animationDelay: "60ms" }}>
                See your{" "}
                <span className="bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent animate-shimmer">
                  dependency tree
                </span>
                .{" "}
                Catch the{" "}
                <span className="text-red-500">vulnerable</span> ones.
              </h2>
              <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl animate-fade-up" style={{ animationDelay: "120ms" }}>
                Drop in a <code className="text-foreground font-mono text-sm">.csproj</code> file and
                the auditor will map out every <code className="text-foreground font-mono text-sm">PackageReference</code>,
                resolve transitive dependencies, and flag outdated or insecure packages using the
                nuget.org registration API and the GitHub Advisory database.
              </p>

              <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-w-4xl">
                <FeatureCard icon={GitGraph} title="Force-directed graph" desc="Live physics simulation — drag, zoom, and explore your dependency web visually." />
                <FeatureCard icon={Bot} title="AI remediation advisor" desc="A senior .NET security advisor writes your prioritized upgrade plan with copy-ready commands." />
                <FeatureCard icon={ShieldCheck} title="CVE auditing" desc="Per-version matching against GitHub advisories with severity badges & health score." />
                <FeatureCard icon={Zap} title="Outdated detection" desc="Side-by-side declared vs latest stable, with major-bump warnings." />
                <FeatureCard icon={Terminal} title="Upgrade script generator" desc="One-click dotnet CLI scripts, patched .csproj, and Markdown audit reports." />
                <FeatureCard icon={Network} title="Dependency tree" desc="Hierarchical view of project → direct → transitive deps, with severity dots." />
              </div>

              {/* Trust bar */}
              <div className="mt-12 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-muted-foreground animate-fade-up border-t border-border/40 pt-6" style={{ animationDelay: "300ms" }}>
                <span className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  No data stored — audits are ephemeral
                </span>
                <span className="flex items-center gap-1.5">
                  <PackageSearch className="h-3 w-3" />
                  nuget.org v3 registration API
                </span>
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="h-3 w-3" />
                  GitHub Advisory database
                </span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Main content */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-6 md:py-8 space-y-6">
        {/* Uploader card */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FileCode2 className="h-4 w-4" />
              {result ? "Re-run audit" : "Provide your .csproj"}
            </CardTitle>
            <CardDescription className="text-xs">
              Drag &amp; drop, browse, paste XML, or load the sample project to get started.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <FileUploader onAudit={onAudit} loading={loading} />
          </CardContent>
        </Card>

        {/* Error banner */}
        {error && (
          <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-red-700 dark:text-red-300">Audit failed</p>
              <p className="text-muted-foreground mt-0.5 font-mono text-xs break-all">{error}</p>
            </div>
            <Button variant="ghost" size="sm" className="ml-auto" onClick={() => setError(null)}>
              Dismiss
            </Button>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-6">
            {/* Project meta header */}
            <div className="flex flex-wrap items-center gap-3 rounded-xl border bg-card p-4">
              <div className="rounded-lg bg-primary/10 p-2">
                <FileCode2 className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-semibold truncate">
                    {result.parsed.projectName ?? "Unnamed project"}
                  </h3>
                  {result.parsed.sdk && (
                    <Badge variant="secondary" className="text-[10px] font-mono">
                      SDK: {result.parsed.sdk}
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {result.parsed.targetFrameworks.length > 0 ? (
                    <>Target: <span className="font-mono">{result.parsed.targetFrameworks.join(" · ")}</span></>
                  ) : (
                    "No target framework declared"
                  )}
                  {result.parsed.projectReferences.length > 0 && (
                    <> · {result.parsed.projectReferences.length} project reference(s)</>
                  )}
                  {result.parsed.frameworkReferences.length > 0 && (
                    <> · {result.parsed.frameworkReferences.length} framework ref(s)</>
                  )}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="ml-auto"
                onClick={() => {
                  setResult(null);
                  setError(null);
                }}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                New audit
              </Button>
            </div>

            {/* Stats + Health score */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="lg:col-span-2">
                <StatsCards stats={result.stats} durationMs={result.durationMs} />
              </div>
              <Card className="lg:col-span-1">
                <CardContent className="pt-6">
                  <HealthScore
                    totalPackages={result.stats.totalPackages}
                    outdatedCount={result.stats.outdatedCount}
                    vulnerableCount={result.stats.vulnerableCount}
                    deprecatedCount={result.stats.deprecatedCount}
                    maxSeverity={result.stats.maxSeverity}
                  />
                </CardContent>
              </Card>
            </div>

            {/* AI Advisor — always visible after audit */}
            <AiAdvisor result={result} />

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="flex w-full md:grid md:grid-cols-7 max-w-4xl h-auto overflow-x-auto no-scrollbar gap-1">
                <TabsTrigger value="graph" className="text-xs shrink-0">
                  <GitGraph className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Force graph</span>
                  <span className="md:hidden">Graph</span>
                </TabsTrigger>
                <TabsTrigger value="tree" className="text-xs shrink-0">
                  <Network className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Tree</span>
                  <span className="md:hidden">Tree</span>
                </TabsTrigger>
                <TabsTrigger value="vulns" className="text-xs shrink-0">
                  <ShieldCheck className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Vulnerabilities</span>
                  <span className="md:hidden">Vulns</span>
                  {result.stats.vulnerableCount > 0 && (
                    <Badge variant="destructive" className="ml-1.5 h-4 px-1 text-[10px]">
                      {result.stats.vulnerableCount}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="outdated" className="text-xs shrink-0">
                  <Zap className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Outdated</span>
                  <span className="md:hidden">Old</span>
                  {result.stats.outdatedCount > 0 && (
                    <span className="ml-1.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-blue-500 px-1 text-[10px] font-bold text-white">
                      {result.stats.outdatedCount}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="analytics" className="text-xs shrink-0">
                  <BarChart3 className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Analytics</span>
                  <span className="md:hidden">Stats</span>
                </TabsTrigger>
                <TabsTrigger value="all" className="text-xs shrink-0">
                  <PackageSearch className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">All packages</span>
                  <span className="md:hidden">All</span>
                </TabsTrigger>
                <TabsTrigger value="upgrade" className="text-xs shrink-0">
                  <Terminal className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Upgrade &amp; export</span>
                  <span className="md:hidden">Export</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="graph" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <GitGraph className="h-4 w-4" />
                      Interactive force-directed graph
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Live physics simulation. Drag nodes to pin them, scroll to zoom, hover for details. Red = vulnerable, blue = outdated.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ForceGraph tree={result.tree} onSelect={onTreeNodeSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="tree" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Network className="h-4 w-4" />
                      Dependency tree
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Click any node for full metadata. Direct dependencies are resolved one level deep into transitive deps.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <DependencyTree tree={result.tree} onSelect={onTreeNodeSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="vulns" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4" />
                      Vulnerability audit
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Declared versions matched against the GitHub Advisory ranges embedded in nuget.org registration data.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <VulnerabilityTable packages={result.packages} onSelect={onPkgSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="outdated" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Zap className="h-4 w-4" />
                      Outdated packages
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Compared against the latest stable (non-prerelease) release on nuget.org.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <OutdatedTable packages={result.packages} onSelect={onPkgSelect} onCompare={onCompare} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="analytics" className="mt-4 space-y-4">
                <AnalyticsDashboard result={result} />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <LicensePanel result={result} />
                  <PopularityPanel result={result} />
                </div>
              </TabsContent>

              <TabsContent value="all" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <PackageSearch className="h-4 w-4" />
                      All packages
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Every declared PackageReference with its resolved status. Filter &amp; sort to dig in.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <AllPackagesTable packages={result.packages} onSelect={onPkgSelect} onCompare={onCompare} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="upgrade" className="mt-4">
                <UpgradeGenerator result={result} />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </main>

      <Separator />

      {/* Footer */}
      <footer className="border-t bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <PackageSearch className="h-3.5 w-3.5" />
            <span>NuGet Visualizer &amp; Auditor · parses .csproj locally, audits via nuget.org v3 API</span>
          </div>
          <div className="flex items-center gap-4">
            <a
              href="https://learn.microsoft.com/en-us/nuget/"
              target="_blank"
              rel="noreferrer noopener"
              className="hover:text-foreground"
            >
              NuGet docs
            </a>
            <a
              href="https://github.com/advisories"
              target="_blank"
              rel="noreferrer noopener"
              className="hover:text-foreground"
            >
              GitHub Advisories
            </a>
            <span className="opacity-60">No data leaves this audit except to nuget.org.</span>
          </div>
        </div>
      </footer>

      <PackageDetailDialog
        pkg={selectedPkg}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onChangelog={openChangelog}
      />
      <VersionCompareDialog
        pkg={comparePkg}
        open={compareOpen}
        onOpenChange={setCompareOpen}
      />
      <AuditHistory
        open={historyOpen}
        onOpenChange={setHistoryOpen}
        currentResult={result}
        onLoadRun={setResult}
        refreshKey={historyRefreshKey}
      />
      <AuditDiffView
        open={diffOpen}
        onOpenChange={setDiffOpen}
        runs={historyRuns}
      />
      <ChangelogViewer
        packageId={changelogPkg?.id ?? null}
        version={changelogPkg?.version ?? null}
        open={changelogOpen}
        onOpenChange={setChangelogOpen}
      />
      <KeyboardShortcuts onShortcut={handleShortcut} />
    </div>
  );
}

function FeatureCard({
  icon: Icon,
  title,
  desc,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  desc: string;
}) {
  return (
    <div className="group relative rounded-xl border bg-card p-4 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 overflow-hidden flex flex-col h-full">
      {/* gradient glow on hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
      <div className="rounded-lg bg-primary/10 p-2 w-fit group-hover:bg-primary/15 group-hover:scale-110 transition-all duration-300">
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <h3 className="mt-3 text-sm font-semibold relative">{title}</h3>
      <p className="mt-1 text-xs text-muted-foreground leading-relaxed relative flex-1">{desc}</p>
    </div>
  );
}
