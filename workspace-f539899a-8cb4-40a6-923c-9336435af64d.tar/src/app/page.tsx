"use client";

import { useCallback, useState } from "react";
import {
  PackageSearch,
  Github,
  ShieldCheck,
  Network,
  Zap,
  FileCode2,
  AlertCircle,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";

import { ThemeToggle } from "@/components/nuget/theme-toggle";
import { FileUploader } from "@/components/nuget/file-uploader";
import { StatsCards } from "@/components/nuget/stats-cards";
import { DependencyTree } from "@/components/nuget/dependency-tree";
import { VulnerabilityTable } from "@/components/nuget/vulnerability-table";
import { OutdatedTable } from "@/components/nuget/outdated-table";
import { AllPackagesTable } from "@/components/nuget/all-packages-table";
import { PackageDetailDialog } from "@/components/nuget/package-detail-dialog";

import type { AuditResult, AuditedPackage, DependencyTreeNode } from "@/lib/audit";

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedPkg, setSelectedPkg] = useState<AuditedPackage | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const onAudit = useCallback(async (content: string, filename?: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || `Audit failed (HTTP ${res.status})`);
      }
      setResult(data.result as AuditResult);
      const r = data.result as AuditResult;
      toast.success(
        `Audited ${r.stats.totalPackages} packages — ${r.stats.vulnerableCount} vulnerable, ${r.stats.outdatedCount} outdated`,
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
      toast.error("Audit failed", { description: msg });
    } finally {
      setLoading(false);
      // void filename to satisfy lint if unused
      void filename;
    }
  }, []);

  const onPkgSelect = useCallback((pkg: AuditedPackage) => {
    setSelectedPkg(pkg);
    setDialogOpen(true);
  }, []);

  const onTreeNodeSelect = useCallback(
    (node: DependencyTreeNode) => {
      if (node.kind === "root") return;
      // find matching audited package by id (case-insensitive)
      const match = result?.packages.find((p) => p.id.toLowerCase() === node.id.toLowerCase());
      if (match) {
        setSelectedPkg(match);
        setDialogOpen(true);
      }
    },
    [result],
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-14 flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-primary p-1.5">
              <PackageSearch className="h-4 w-4 text-primary-foreground" />
            </div>
            <div className="leading-tight">
              <h1 className="text-sm font-semibold">NuGet Visualizer &amp; Auditor</h1>
              <p className="text-[10px] text-muted-foreground hidden sm:block">
                parse · visualize · audit
              </p>
            </div>
          </div>

          <Badge variant="outline" className="hidden md:inline-flex text-[10px] gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
            nuget.org v3 API
          </Badge>

          <div className="ml-auto flex items-center gap-1.5">
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <a
                href="https://learn.microsoft.com/en-us/nuget/api/overview"
                target="_blank"
                rel="noreferrer noopener"
              >
                <FileCode2 className="h-3.5 w-3.5" /> API docs
              </a>
            </Button>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <a
                href="https://github.com/advisories?query=type%3Areviewed+ecosystem%3Anuget"
                target="_blank"
                rel="noreferrer noopener"
              >
                <Github className="h-3.5 w-3.5" /> Advisories
              </a>
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Hero */}
      {!result && (
        <section className="relative overflow-hidden border-b">
          <div className="absolute inset-0 bg-grid opacity-60 pointer-events-none" />
          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 md:py-20">
            <div className="max-w-3xl">
              <Badge variant="secondary" className="mb-4 gap-1">
                <Zap className="h-3 w-3" />
                Client-parsed · server-audited · live nuget.org data
              </Badge>
              <h2 className="text-3xl md:text-5xl font-bold tracking-tight leading-tight">
                See your{" "}
                <span className="bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent animate-shimmer">
                  dependency tree
                </span>
                .{" "}
                Catch the{" "}
                <span className="text-red-500">vulnerable</span> ones.
              </h2>
              <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl">
                Drop in a <code className="text-foreground font-mono text-sm">.csproj</code> file and
                the auditor will map out every <code className="text-foreground font-mono text-sm">PackageReference</code>,
                resolve transitive dependencies, and flag outdated or insecure packages using the
                nuget.org registration API and the GitHub Advisory database.
              </p>

              <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-3xl">
                <FeatureCard
                  icon={Network}
                  title="Dependency tree"
                  desc="Hierarchical view of project → direct → transitive deps, with severity dots."
                />
                <FeatureCard
                  icon={ShieldCheck}
                  title="CVE auditing"
                  desc="Per-version matching against GitHub advisories with severity badges."
                />
                <FeatureCard
                  icon={Zap}
                  title="Outdated detection"
                  desc="Side-by-side declared vs latest stable, with major-bump warnings."
                />
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Main content */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-6 md:py-8 space-y-6">
        {/* Uploader card */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FileCode2 className="h-4 w-4" />
              {result ? "Re-run audit" : "Provide your .csproj"}
            </CardTitle>
            <CardDescription className="text-xs">
              Drag &amp; drop, browse, paste XML, or load the sample project to get started.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <FileUploader onAudit={onAudit} loading={loading} />
          </CardContent>
        </Card>

        {/* Error banner */}
        {error && (
          <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-red-700 dark:text-red-300">Audit failed</p>
              <p className="text-muted-foreground mt-0.5 font-mono text-xs break-all">{error}</p>
            </div>
            <Button variant="ghost" size="sm" className="ml-auto" onClick={() => setError(null)}>
              Dismiss
            </Button>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-6">
            {/* Project meta header */}
            <div className="flex flex-wrap items-center gap-3 rounded-xl border bg-card p-4">
              <div className="rounded-lg bg-primary/10 p-2">
                <FileCode2 className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-semibold truncate">
                    {result.parsed.projectName ?? "Unnamed project"}
                  </h3>
                  {result.parsed.sdk && (
                    <Badge variant="secondary" className="text-[10px] font-mono">
                      SDK: {result.parsed.sdk}
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {result.parsed.targetFrameworks.length > 0 ? (
                    <>Target: <span className="font-mono">{result.parsed.targetFrameworks.join(" · ")}</span></>
                  ) : (
                    "No target framework declared"
                  )}
                  {result.parsed.projectReferences.length > 0 && (
                    <> · {result.parsed.projectReferences.length} project reference(s)</>
                  )}
                  {result.parsed.frameworkReferences.length > 0 && (
                    <> · {result.parsed.frameworkReferences.length} framework ref(s)</>
                  )}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="ml-auto"
                onClick={() => {
                  setResult(null);
                  setError(null);
                }}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                New audit
              </Button>
            </div>

            {/* Stats */}
            <StatsCards stats={result.stats} durationMs={result.durationMs} />

            {/* Tabs */}
            <Tabs defaultValue="tree" className="w-full">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 max-w-2xl">
                <TabsTrigger value="tree" className="text-xs">
                  <Network className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Dependency tree</span>
                  <span className="md:hidden">Tree</span>
                </TabsTrigger>
                <TabsTrigger value="vulns" className="text-xs">
                  <ShieldCheck className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Vulnerabilities</span>
                  <span className="md:hidden">Vulns</span>
                  {result.stats.vulnerableCount > 0 && (
                    <Badge variant="destructive" className="ml-1.5 h-4 px-1 text-[10px]">
                      {result.stats.vulnerableCount}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="outdated" className="text-xs">
                  <Zap className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Outdated</span>
                  <span className="md:hidden">Old</span>
                  {result.stats.outdatedCount > 0 && (
                    <Badge variant="secondary" className="ml-1.5 h-4 px-1 text-[10px]">
                      {result.stats.outdatedCount}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="all" className="text-xs">
                  <PackageSearch className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">All packages</span>
                  <span className="md:hidden">All</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="tree" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Network className="h-4 w-4" />
                      Dependency tree
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Click any node for full metadata. Direct dependencies are resolved one level deep into transitive deps.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <DependencyTree tree={result.tree} onSelect={onTreeNodeSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="vulns" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4" />
                      Vulnerability audit
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Declared versions matched against the GitHub Advisory ranges embedded in nuget.org registration data.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <VulnerabilityTable packages={result.packages} onSelect={onPkgSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="outdated" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Zap className="h-4 w-4" />
                      Outdated packages
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Compared against the latest stable (non-prerelease) release on nuget.org.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <OutdatedTable packages={result.packages} onSelect={onPkgSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="all" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <PackageSearch className="h-4 w-4" />
                      All packages
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Every declared PackageReference with its resolved status. Filter &amp; sort to dig in.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <AllPackagesTable packages={result.packages} onSelect={onPkgSelect} />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </main>

      <Separator />

      {/* Footer */}
      <footer className="border-t bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <PackageSearch className="h-3.5 w-3.5" />
            <span>NuGet Visualizer &amp; Auditor · parses .csproj locally, audits via nuget.org v3 API</span>
          </div>
          <div className="flex items-center gap-4">
            <a
              href="https://learn.microsoft.com/en-us/nuget/"
              target="_blank"
              rel="noreferrer noopener"
              className="hover:text-foreground"
            >
              NuGet docs
            </a>
            <a
              href="https://github.com/advisories"
              target="_blank"
              rel="noreferrer noopener"
              className="hover:text-foreground"
            >
              GitHub Advisories
            </a>
            <span className="opacity-60">No data leaves this audit except to nuget.org.</span>
          </div>
        </div>
      </footer>

      <PackageDetailDialog
        pkg={selectedPkg}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
      />
    </div>
  );
}

function FeatureCard({
  icon: Icon,
  title,
  desc,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  desc: string;
}) {
  return (
    <div className="rounded-xl border bg-card p-4 hover:shadow-md hover:-translate-y-0.5 transition-all">
      <div className="rounded-lg bg-primary/10 p-2 w-fit">
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <h3 className="mt-3 text-sm font-semibold">{title}</h3>
      <p className="mt-1 text-xs text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}
