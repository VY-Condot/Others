/**
 * NuGet v3 API client (server-side only).
 *
 * Primary endpoint used:
 *   Registration Index (gzipped, semver2):
 *     https://api.nuget.org/v3/registration5-gz-semver2/{id-lowercase}/index.json
 *
 * This single endpoint returns:
 *   - all published versions (catalog entries)
 *   - dependencyGroups per version (for transitive tree)
 *   - a top-level `vulnerabilities` array (NuGet embeds GitHub advisory data)
 *   - deprecation info per version
 *
 * We use this instead of the autocomplete/search service because it is the
 * authoritative source for versions + vulnerabilities in one call.
 *
 * All network calls are guarded with:
 *   - a 10s timeout (AbortController)
 *   - in-memory TTL cache (10 minutes)
 *   - graceful fallback to a bundled static dataset (PACKAGES_FALLBACK)
 *     so the auditor remains useful when the sandbox has no outbound network.
 */

import semver from "semver";

const REGISTRATION_BASE =
  "https://api.nuget.org/v3/registration5-gz-semver2";
const NUGET_TIMEOUT_MS = 10_000;
const CACHE_TTL_MS = 10 * 60 * 1000;

export type NuGetSeverity = "low" | "moderate" | "high" | "critical";

export interface NuGetVulnerability {
  severity: NuGetSeverity;
  advisoryUrl: string;
  range: string; // semver range, e.g. "[,6.35.0)"
  advisoryTitle?: string;
}

export interface NuGetDepInfo {
  id: string;
  range: string; // dependency range, may be "*"
}

export interface NuGetVersionEntry {
  version: string;
  listed: boolean;
  isPrerelease: boolean;
  dependencies: NuGetDepInfo[];
  description?: string;
  authors?: string | string[];
  iconUrl?: string;
  projectUrl?: string;
  licenseUrl?: string;
  requireLicenseAcceptance?: boolean;
  published?: string;
  deprecation?: {
    reasons: string[];
    message?: string;
    alternatePackage?: { id: string; range?: string };
  };
}

export interface NuGetPackageInfo {
  id: string;
  found: boolean;
  latestStableVersion: string | null;
  latestVersion: string | null;
  versions: NuGetVersionEntry[];
  vulnerabilities: NuGetVulnerability[];
  fetchedAt: string;
  source: "live" | "fallback" | "error";
  error?: string;
}

interface CacheEntry {
  ts: number;
  data: NuGetPackageInfo;
}

const cache = new Map<string, CacheEntry>();

async function fetchWithTimeout(url: string, ms: number): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { Accept: "application/json", "User-Agent": "nuget-auditor/1.0" },
      // Next.js fetch cache disabled for live data
      cache: "no-store",
    });
    return res;
  } finally {
    clearTimeout(timer);
  }
}

function normalizeAuthors(a: unknown): string | string[] | undefined {
  if (!a) return undefined;
  if (Array.isArray(a)) return a.filter(Boolean) as string[];
  if (typeof a === "string") return a.split(",").map((s) => s.trim()).filter(Boolean);
  return undefined;
}

/**
 * Parse a registration index JSON document into a NuGetPackageInfo.
 */
function parseRegistrationIndex(id: string, json: any, source: "live" | "fallback"): NuGetPackageInfo {
  const versions: NuGetVersionEntry[] = [];
  const pages = Array.isArray(json.items) ? json.items : [];

  for (const page of pages) {
    // Some registrations are paginated and require a follow-up fetch to /page.json.
    // For the semver2-gz endpoint, items are usually inlined; if not, we skip
    // the inner items gracefully (we still have the top-level items array if present).
    const entries = Array.isArray(page.items) ? page.items : [];
    for (const entry of entries) {
      const cat = entry?.catalogEntry;
      if (!cat || !cat.version) continue;
      const version: string = cat.version;
      const isPrerelease = /-[0-9A-Za-z.-]+/.test(version);
      const depGroups: any[] = Array.isArray(cat.dependencyGroups) ? cat.dependencyGroups : [];
      const dependencies: NuGetDepInfo[] = [];
      for (const g of depGroups) {
        const ds = Array.isArray(g.dependencies) ? g.dependencies : [];
        for (const d of ds) {
          if (d.id) dependencies.push({ id: d.id as string, range: (d.range as string) || "*" });
        }
      }
      versions.push({
        version,
        listed: cat.listed !== false,
        isPrerelease,
        dependencies,
        description: cat.description,
        authors: normalizeAuthors(cat.authors),
        iconUrl: cat.iconUrl,
        projectUrl: cat.projectUrl,
        licenseUrl: cat.licenseUrl,
        requireLicenseAcceptance: cat.requireLicenseAcceptance,
        published: cat.published,
        deprecation: cat.deprecation
          ? {
              reasons: Array.isArray(cat.deprecation.reasons) ? cat.deprecation.reasons : [],
              message: cat.deprecation.message,
              alternatePackage: cat.deprecation.alternatePackage
                ? {
                    id: cat.deprecation.alternatePackage.id,
                    range: cat.deprecation.alternatePackage.range,
                  }
                : undefined,
            }
          : undefined,
      });
    }
  }

  const allVulnsRaw = Array.isArray(json.vulnerabilities) ? json.vulnerabilities : [];
  const vulnerabilities: NuGetVulnerability[] = allVulnsRaw.map((v: any) => ({
    severity: (v.severity as NuGetSeverity) || "moderate",
    advisoryUrl: v.advisoryUrl,
    range: v.range,
    advisoryTitle: v.advisoryTitle || v["@id"] || undefined,
  }));

  const sortedStable = versions
    .filter((v) => !v.isPrerelease && v.listed !== false)
    .sort((a, b) => semver.compare(semver.coerce(b.version) ?? "0.0.0", semver.coerce(a.version) ?? "0.0.0"));
  const sortedAll = [...versions].sort((a, b) =>
    semver.compare(semver.coerce(b.version) ?? "0.0.0", semver.coerce(a.version) ?? "0.0.0"),
  );

  return {
    id,
    found: versions.length > 0,
    latestStableVersion: sortedStable[0]?.version ?? null,
    latestVersion: sortedAll[0]?.version ?? null,
    versions,
    vulnerabilities,
    fetchedAt: new Date().toISOString(),
    source,
  };
}

/**
 * Bundled fallback data for a handful of well-known packages. Used when the
 * NuGet API is unreachable (sandbox without outbound network). The versions
 * below are intentionally a mix of outdated/vulnerable/current so the auditor
 * remains demonstrable offline.
 */
const PACKAGES_FALLBACK: Record<string, any> = {
  "system.identitymodel.tokens.jwt": {
    items: [
      {
        items: [
          {
            catalogEntry: {
              version: "6.10.0",
              description: "Includes types that provide support for JWT tokens.",
              authors: "Microsoft",
              dependencyGroups: [
                {
                  dependencies: [
                    { id: "Microsoft.IdentityModel.Logging", range: "6.10.0" },
                    { id: "Microsoft.IdentityModel.Tokens", range: "6.10.0" },
                    { id: "System.Text.Encodings.Web", range: "4.7.2" },
                  ],
                },
              ],
            },
          },
          { catalogEntry: { version: "7.5.0", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [
      {
        severity: "high",
        advisoryUrl: "https://github.com/advisories/GHSA-9rr5-rm7p-m2r2",
        range: "[,7.0.0)",
        advisoryTitle: "Microsoft Identity Model Token Validation Spoofing Vulnerability",
      },
    ],
  },
  "newtonsoft.json": {
    items: [
      {
        items: [
          { catalogEntry: { version: "13.0.1", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "13.0.3", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "npgsql": {
    items: [
      {
        items: [
          { catalogEntry: { version: "4.0.4", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "8.0.3", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [
      {
        severity: "high",
        advisoryUrl: "https://github.com/advisories/GHSA-7mjr-rgj7-pg2x",
        range: "[,4.0.5)",
        advisoryTitle: "Npgsql SQL injection via array parameter",
      },
    ],
  },
  "serilog.aspnetcore": {
    items: [
      {
        items: [
          { catalogEntry: { version: "6.1.0", dependencyGroups: [{ dependencies: [{ id: "Serilog", range: "2.10.0" }] }] } },
          { catalogEntry: { version: "8.0.1", dependencyGroups: [{ dependencies: [{ id: "Serilog", range: "3.1.0" }] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "dapper": {
    items: [
      {
        items: [
          { catalogEntry: { version: "2.0.123", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "2.1.35", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "mediatr": {
    items: [
      {
        items: [
          { catalogEntry: { version: "11.0.0", dependencyGroups: [{ dependencies: [{ id: "MediatR.Contracts", range: "1.0.1" }] }] } },
          { catalogEntry: { version: "12.2.0", dependencyGroups: [{ dependencies: [{ id: "MediatR.Contracts", range: "2.0.1" }] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "automapper": {
    items: [
      {
        items: [
          { catalogEntry: { version: "12.0.1", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "13.0.1", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "polly": {
    items: [
      {
        items: [
          { catalogEntry: { version: "7.2.3", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "8.4.1", dependencyGroups: [{ dependencies: [{ id: "Polly.Core", range: "8.4.1" }] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "fluentvalidation": {
    items: [
      {
        items: [
          { catalogEntry: { version: "11.5.0", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "11.9.2", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "swashbuckle.aspnetcore": {
    items: [
      {
        items: [
          { catalogEntry: { version: "6.5.0", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "6.6.2", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "microsoft.entityframeworkcore.sqlserver": {
    items: [
      {
        items: [
          { catalogEntry: { version: "8.0.0", dependencyGroups: [{ dependencies: [{ id: "Microsoft.Data.SqlClient", range: "5.1.1" }] }] } },
          { catalogEntry: { version: "8.0.8", dependencyGroups: [{ dependencies: [{ id: "Microsoft.Data.SqlClient", range: "5.2.2" }] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "microsoft.extensions.configuration": {
    items: [
      {
        items: [
          { catalogEntry: { version: "8.0.0", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "8.0.1", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "microsoft.extensions.dependencyinjection": {
    items: [
      {
        items: [
          { catalogEntry: { version: "8.0.0", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "8.0.1", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "microsoft.aspnetcore.authentication.jwtbearer": {
    items: [
      {
        items: [
          { catalogEntry: { version: "8.0.0", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "8.0.8", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "microsoft.aspnetcore.authentication.openidconnect": {
    items: [
      {
        items: [
          { catalogEntry: { version: "7.0.5", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "8.0.8", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "serilog.sinks.console": {
    items: [
      {
        items: [
          { catalogEntry: { version: "4.1.0", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "6.0.0", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "opentelemetry.extensions.hosting": {
    items: [
      {
        items: [
          { catalogEntry: { version: "1.5.1", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "1.9.0", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "microsoft.entityframeworkcore.design": {
    items: [
      {
        items: [
          { catalogEntry: { version: "8.0.0", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "8.0.8", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
  "csvhelper": {
    items: [
      {
        items: [
          { catalogEntry: { version: "30.0.1", dependencyGroups: [{ dependencies: [] }] } },
          { catalogEntry: { version: "33.0.1", dependencyGroups: [{ dependencies: [] }] } },
        ],
      },
    ],
    vulnerabilities: [],
  },
};

function fallbackFor(id: string): NuGetPackageInfo | null {
  const data = PACKAGES_FALLBACK[id.toLowerCase()];
  if (!data) {
    return {
      id,
      found: false,
      latestStableVersion: null,
      latestVersion: null,
      versions: [],
      vulnerabilities: [],
      fetchedAt: new Date().toISOString(),
      source: "error",
      error: "Package not found (offline mode; live NuGet API unreachable).",
    };
  }
  return parseRegistrationIndex(id, data, "fallback");
}

/**
 * Fetch full package info from NuGet. Returns a cached result if fresh.
 */
export async function getPackageInfo(id: string): Promise<NuGetPackageInfo> {
  const key = id.toLowerCase();
  const cached = cache.get(key);
  if (cached && Date.now() - cached.ts < CACHE_TTL_MS) {
    return cached.data;
  }

  const url = `${REGISTRATION_BASE}/${encodeURIComponent(key)}/index.json`;
  try {
    const res = await fetchWithTimeout(url, NUGET_TIMEOUT_MS);
    if (res.status === 404) {
      const info: NuGetPackageInfo = {
        id,
        found: false,
        latestStableVersion: null,
        latestVersion: null,
        versions: [],
        vulnerabilities: [],
        fetchedAt: new Date().toISOString(),
        source: "live",
        error: "Package not found on nuget.org.",
      };
      cache.set(key, { ts: Date.now(), data: info });
      return info;
    }
    if (!res.ok) {
      throw new Error(`NuGet API ${res.status}`);
    }
    const json = await res.json();
    const info = parseRegistrationIndex(id, json, "live");
    cache.set(key, { ts: Date.now(), data: info });
    return info;
  } catch (err) {
    const fallback = fallbackFor(id);
    if (fallback) {
      cache.set(key, { ts: Date.now(), data: fallback });
      return fallback;
    }
    const info: NuGetPackageInfo = {
      id,
      found: false,
      latestStableVersion: null,
      latestVersion: null,
      versions: [],
      vulnerabilities: [],
      fetchedAt: new Date().toISOString(),
      source: "error",
      error: err instanceof Error ? err.message : "Unknown fetch error",
    };
    cache.set(key, { ts: Date.now(), data: info });
    return info;
  }
}
