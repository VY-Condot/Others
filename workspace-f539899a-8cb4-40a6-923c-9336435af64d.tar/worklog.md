# NuGet Visualizer & Auditor — Worklog

## Project Status (as of 2025-07-23, Phase 6)

**Status: ✅ Stable & feature-rich (Phase 1 + 2 + 3 + 4 + 5 + 6 done)**

A lightweight web app that parses a user's `.csproj` file, maps out the dependency tree visually, and highlights outdated or insecure NuGet packages. Built on Next.js 16 + TypeScript (the sandbox is strictly Next.js — ASP.NET Core/Blazor cannot run here, so equivalent functionality is delivered via Next.js App Router + server API routes).

---

## Current goals / completed modifications

### Phase 1 — Core auditor (DONE)
- csproj parser, NuGet v3 client, audit orchestration, audit API, base UI.

### Phase 2 — Standout features (DONE)
- Security Health Score, Interactive Force-Directed Graph, AI Remediation Advisor, Upgrade & Export Toolkit.

### Phase 3 — Analytics & comparison (DONE)
- Dependency Analytics Dashboard (4 recharts), Version Compare Dialog, hero styling overhaul.

### Phase 4 — Persistence, keyboard nav, polish (DONE)
- Audit History Persistence (Prisma/SQLite), Keyboard Shortcuts, Animated number counters, upgrade generator default scope bug fix.

### Phase 5 — Diff, changelog, AI card redesign (DONE)
- Audit Diff View, Package Changelog Viewer, AI Advisor card redesign (pulsing gradient, GLM badge, gradient CTA), tab badge prominence.

### Phase 6 — License compliance + popularity metrics (DONE this round)
- **License Compliance Panel** (`license-panel.tsx`):
  - Extended `nuget.ts` to capture `licenseExpression` per version, extended `audit.ts` with `LicenseCategory` type + `classifyLicense()` heuristic classifier.
  - 6 categories: permissive (MIT/Apache/BSD/ISC), weak copyleft (LGPL/MPL/CDDL), strong copyleft (GPL/AGPL), restrictive (proprietary/commercial), unknown, none.
  - Panel UI: colored breakdown bar (red/green/yellow/orange segments), per-category cards with counts, percentages, descriptions, and package lists with license expressions. Risk badge showing "X risky" or "All clear".
  - Added License InfoRow to package detail dialog (shows licenseExpression e.g. "Apache-2.0").
  - VLM confirmed: "No license (11) 58%" + "Permissive (8) 42%" with package lists and descriptions.
- **Package Popularity Panel** (`popularity-panel.tsx` + fixed `/api/popularity`):
  - **BUG FIX**: Original popularity API used the registration index endpoint which does NOT include download counts (returned 0 for all). Fixed to use the NuGet search service (`azuresearch-usnc.nuget.org/query?q=packageId:X`) which returns `totalDownloads`.
  - Verified: Newtonsoft.Json 8.7B downloads, Dapper 720M, Serilog.AspNetCore 752M.
  - Panel UI: bubble scatter chart (downloads log-scale vs risk score, colored by status), "Most downloaded" ranked list with download counts (B/M/K formatting), verified badges, total downloads + verified count summary.
  - VLM confirmed: scatter chart with colored bubbles, ranked list with 8.7B/7.4B/6.6B download counts.
- Both panels wired into the Analytics tab in a 2-column grid below the existing AnalyticsDashboard.
- Lint error fixed in `popularity-panel.tsx` (set-state-in-effect for loading guard).

### Verification results (agent-browser end-to-end, this round)
- Audit flow: 19 packages, 8 outdated, live nuget.org, ~0.9s. No errors.
- **License Panel**: renders in Analytics tab. Breakdown bar shows 58% red (No license) + 42% green (Permissive). "No license (11)" card with warning icon + package list. "Permissive (8)" card with checkmark + packages showing license expressions (MIT, Apache-2.0, BSD-3-Clause). Footer note about heuristic classification.
- **Popularity Panel**: renders with real download data. Scatter chart shows bubbles colored by status (blue=outdated, green=ok). "Most downloaded" list shows Newtonsoft.Json 8.7B, Microsoft.Extensions.DependencyInjection 7.4B, etc. with verified badges and status indicators.
- **Package detail dialog**: new License InfoRow shows "Apache-2.0" for Dapper. VLM rated dialog 9/10.
- API `/api/popularity` returns 200 with real download counts for all 19 packages.
- Lint: `bun run lint` passes clean (0 errors, 0 warnings).
- Dev server: running on port 3000, no runtime errors.

## Unresolved issues / risks
- Force graph physics takes 1-2s to settle (acceptable).
- NuGet API depends on outbound network; bundled fallback covers ~18 common packages.
- 5 targeted `eslint-disable-next-line` comments for intentional patterns.
- License classification is heuristic — may misclassify unusual licenses. Footer note warns users to verify.
- Popularity API makes individual search requests per package (no batch endpoint) — capped at 30 packages with concurrency 6 to stay fast.
- The "N" badge in screenshots is Next.js Dev Tools (not our app).

## Priority recommendations for next phase
1. **Multi-csproj support**: upload a `.sln` or multiple `.csproj` files, show cross-project dependency overlap.
2. **Historical vulnerability timeline**: chart when CVEs were disclosed vs when the declared version was released.
3. **Watch mode**: re-audit on file change with a WebSocket mini-service.
4. **Export to PDF**: one-click PDF report generation for compliance sharing.
5. **Graph node keyboard navigation**: arrow-key navigation between force-graph nodes for accessibility.
6. **Batch upgrade simulation**: "what if I upgrade all to latest?" — preview the resulting health score before running.
7. **Package dependency graph mini-map**: a zoomed-out overview of the force graph for large dependency webs.
8. **Audit scheduling**: schedule recurring audits via cron, email/notify on new vulnerabilities.
