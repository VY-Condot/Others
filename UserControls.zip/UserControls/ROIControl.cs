﻿using CsplCam.Library.Enums;
using CsplCam.Library.Interfaces;
using CsplCam.Library.Models;
using CsplCameraOcr.UI;
using System;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using ZXingCpp;

namespace CsplCameraOcr.UserControls
{
    public partial class ROIControl : UserControl, IRoiControl,IThresholding
    {
        //GET ROI OBJECT
        public RoiObject BoundedROI { get; private set; }
        public Size? ControlSize { get; set; }

        // --- FLAG ---
        private bool _isBinding = false;

        //create eventhandler for roi changed
        public event EventHandler SelectionClick;
        public event EventHandler SettingsChanged;
        public event EventHandler DecodeRequested;

        public event EventHandler TrainTemplateRequested;

        //new event for open the anchor setting window
        public event EventHandler OpenAnchorSettingsWindow;

        //new event for open the roi anchor reference window
        public event EventHandler OpenRoiReferenceWindow;
        public event EventHandler ApplyThreshold;

        ////new event for open the barcode reading and detecting mode
        //public event EventHandler OpenBarCodeDetectionMode;

        string[] strBarCodeFormats = new string[] { string.Empty, "Pharma" };

        public ROIControl()
        {
            InitializeComponent();

            // =================================================================
            // OPTIMIZATION: ENABLE DEEP DOUBLE BUFFERING TO KILL FLICKERING
            // =================================================================
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint, true);
            UpdateStyles();
            EnableDoubleBuffering(TblPNlMain);
            EnableDoubleBuffering(TblPnlRoiOcrData);

            cmbRotationAngle.DataSource = Enum.GetValues(typeof(RotationAngles));
          
            // 1. Manually add only the exact enum values you want to show
            CmbSegments.DataSource = new[] {
                                        SegmentationMode.Industrial,
                                        SegmentationMode.Punctuation, // Add any other modes you actually want to display here
                                    };

            // 2. Set the default selected item
            CmbSegments.SelectedItem = SegmentationMode.Industrial;


            //click events
            Click += (sender, args) => SelectionClick?.Invoke(this, EventArgs.Empty);
            GrpRoiData.Click += (sender, args) => SelectionClick?.Invoke(this, EventArgs.Empty);
            GrpBlobFilter.Click += (sender, args) => SelectionClick?.Invoke(this, EventArgs.Empty);

            //assign the size
            ControlSize = new Size(this.Width, this.Height);
        }

        // =================================================================
        // OPTIMIZATION HELPER: Forces TableLayoutPanels to render smoothly
        // =================================================================
        private void EnableDoubleBuffering(Control control)
        {
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        public void BindData(RoiObject roi, bool isSelected)
        {
            _isBinding = true; //stop listening

            try
            {
                BoundedROI = roi;

                // 1. Visual Selection State
                Color bg = isSelected ? Color.SeaShell : Color.White;
                if (this.BackColor != bg) this.BackColor = bg;

                // 2. Common Data
                string title = $"{roi.Name} ({roi.Type})";
                if (GrpRoiData.Text != title) GrpRoiData.Text = title;

                if (!TxtDecoded.Focused && roi.DecodedText != TxtDecoded.Text)
                    TxtDecoded.Text = roi.DecodedText;

                if (!chkDoOCR.Focused && chkDoOCR.Checked != roi.RunOcrMode)
                    chkDoOCR.Checked = roi.RunOcrMode;

                if (!chkAnchor.Focused && chkAnchor.Checked != roi.IsAnchor)
                    chkAnchor.Checked = roi.IsAnchor;

                if (chkIsUseReferance.Checked != roi.IsUseRoiReference)
                    chkIsUseReferance.Checked = roi.IsUseRoiReference;

                // =========================================================
                // OPTIMIZATION: Suspend Layout during heavy UI shifts
                // =========================================================
                TblPNlMain.SuspendLayout();

                if (!TxtExpected.Focused && roi.ExpectedText != TxtExpected.Text)
                    TxtExpected.Text = roi.ExpectedText;

                if (!TxtExpectedThr.Focused && roi.Threshold != (double)TxtExpectedThr.Value)
                    TxtExpectedThr.Value = (decimal)roi.Threshold;

                if (!numPadOCRExpected.Focused && roi.OcrExpectedResultCount != (double)numPadOCRExpected.Value)
                    numPadOCRExpected.Value = (decimal)roi.OcrExpectedResultCount;

                string scoreText = (Math.Floor(roi.RoiScore * 100) / 100.00).ToString("0.00");
                if (!LblDecodedThr.Focused && LblDecodedThr.Text != scoreText)
                    LblDecodedThr.Text = scoreText;

                if (!string.IsNullOrWhiteSpace(BoundedROI.OverAllResult))
                {
                    var targetColor = string.Equals(BoundedROI.OverAllResult, "Pass", StringComparison.OrdinalIgnoreCase) ? Color.Green : Color.Red;
                    if (lblOverAllResult.ForeColor != targetColor) lblOverAllResult.ForeColor = targetColor;
                    if (lblOverAllResult.Text != BoundedROI.OverAllResult) lblOverAllResult.Text = BoundedROI.OverAllResult;
                }

                //set the charcount of ocr result 
                string strCharCount = $"Scan Char Count : {BoundedROI.CharResults.Count}";
                if (lblOcrCharCount.Text != strCharCount) lblOcrCharCount.Text = strCharCount;

                SetNum(NumPadMinWidth, roi.MinBlobW);
                SetNum(NumPadMaxWidth, roi.MaxBlobW);
                SetNum(NumPadMinHeight, roi.MinBlobH);
                SetNum(NumPadMaxHeight, roi.MaxBlobH);

                btnCopyDecodedText.Visible = true;

                if (cmbRotationAngle.Items.Count > 0 && !cmbRotationAngle.Focused && (RotationAngles)cmbRotationAngle.SelectedItem != roi.RotationAngle)
                    cmbRotationAngle.SelectedItem = roi.RotationAngle;

                SetNum(NumPadMorphKeranalWidth, roi.MorphKernelWidth);
                SetNum(NumPadMorphIteration, roi.MorphIterations);

                CheckedRadioButtonState(roi.MorphOp);

                if (!chkEnableThresholding.Focused && chkEnableThresholding.Checked != roi.EnableThresholding)
                    chkEnableThresholding.Checked = roi.EnableThresholding;

                if(!trckBarThreshold.Focused && trckBarThreshold.Value != roi.ThresholdMin)
                    trckBarThreshold.Value = roi.ThresholdMin;

                TblPNlMain.ResumeLayout(true);
            }
            finally
            {
                _isBinding = false; //resume listening
            }
        }

        private void CheckedRadioButtonState(MorphOperation morphOperation)
        {
            switch (morphOperation)
            {
                case MorphOperation.None:
                    if (!rdMorphModeNone.Checked) rdMorphModeNone.Checked = true;
                    break;
                case MorphOperation.Erode:
                    if (!rdMorphModeErode.Checked) rdMorphModeErode.Checked = true;
                    break;
                case MorphOperation.Dilate:
                    if (!rdMorphModeDilate.Checked) rdMorphModeDilate.Checked = true;
                    break;
            }
        }

        private void SetNum(NumericUpDown num, int val)
        {
            if (!num.Focused)
            {
                int safeVal = Math.Max((int)num.Minimum, Math.Min((int)num.Maximum, val));
                if (num.Value != safeVal) num.Value = safeVal;
            }
        }

        private void BtnDecodeROI_Click(object sender, EventArgs e) { DecodeRequested?.Invoke(this, EventArgs.Empty); }

        private void TxtExpected_TextChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;
            BoundedROI.ExpectedText = TxtExpected.Text;
        }

        private void NumPadMaxWidth_ValueChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;
            BoundedROI.MaxBlobW = (int)NumPadMaxWidth.Value;
        }

        private void TxtExpectedThr_TextChanged(object sender, EventArgs e)
        {
            if (double.TryParse(TxtExpectedThr.Text, out double val))
            {
                if (BoundedROI.Type == RoiType.TemplateMatch) BoundedROI.TmThreshold = val;
                else BoundedROI.Threshold = val;
            }
        }

        private void NumPadMinWidth_ValueChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;
            BoundedROI.MinBlobW = (int)NumPadMinWidth.Value;
        }

        private void NumPadMinHeight_ValueChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;
            BoundedROI.MinBlobH = (int)NumPadMinHeight.Value;
        }

        private void NumPadMaxHeight_ValueChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;
            BoundedROI.MaxBlobH = (int)NumPadMaxHeight.Value;
        }

        private void chkDoOCR_CheckedChanged(object sender, EventArgs e)
        {
            //BoundedROI.RunOcrMode = chkDoOCR.Checked;
            //if (!string.IsNullOrWhiteSpace(TxtExpected.Text))
            //{
            //    BoundedROI.RunOcrMode = chkDoOCR.Checked;
            //    TxtExpected.Enabled = !chkDoOCR.Checked;
            //}
            //else
            //{
            //    BoundedROI.RunOcrMode = true;
            //}
            BoundedROI.RunOcrMode = lblOcrCount.Enabled = numPadOCRExpected.Enabled = chkDoOCR.Checked;
            TxtExpected.Enabled = !chkDoOCR.Checked;
        }

        public void SetSelectionState(bool isSelected)
        {
            Color bg = isSelected ? Color.LemonChiffon : Color.WhiteSmoke;
            if (this.BackColor != bg) this.BackColor = bg;
        }

        private void CmbRotationAngle_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isBinding || BoundedROI == null) return;
            BoundedROI.RotationAngle = (RotationAngles)cmbRotationAngle.SelectedItem;
            SettingsChanged?.Invoke(this, EventArgs.Empty);
        }

        private void NumPadMorphKeranalWidth_ValueChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;
            BoundedROI.MorphKernelWidth = BoundedROI.MorphKernelHeight = (int)NumPadMorphKeranalWidth.Value;
            SettingsChanged?.Invoke(this, EventArgs.Empty);
        }

        // =================================================================
        // OPTIMIZATION: Safe Image Disposing to prevent GDI Crashes
        // =================================================================
        public void SetPreviewImage(System.Drawing.Bitmap newImage)
        {
            if (newImage == null) return;

            var oldImage = pzPreview.Image;
            bool sizeChanged = oldImage == null || oldImage.Width != newImage.Width || oldImage.Height != newImage.Height;

            // Assign new before disposing old to prevent UI red-X crash
            pzPreview.Image = newImage;

            if (sizeChanged)
            {
                pzPreview.AutoFit();
            }

            if (oldImage != null)
            {
                oldImage.Dispose();
            }
        }

        private void MorphModeSelection(string StrMorphMode)
        {
            if (string.IsNullOrWhiteSpace(StrMorphMode)) return;
            Enum.TryParse(typeof(MorphOperation), StrMorphMode, true, out var mode);
            if (mode is null || _isBinding || BoundedROI == null) return;
            BoundedROI.MorphOp = (MorphOperation)mode;

            BoundedROI.EnableThresholding = false;

            SettingsChanged?.Invoke(this, EventArgs.Empty);
        }

        private void RdMorphModeNone_Click(object sender, EventArgs e)
        {
            var d = (RadioButton)sender;
            MorphModeSelection(d.Text);
        }

        private void RdMorphModeErode_Click(object sender, EventArgs e)
        {
            var d = (RadioButton)sender;
            MorphModeSelection(d.Text);
        }

        private void RdMorphModeDilate_Click(object sender, EventArgs e)
        {
            var d = (RadioButton)sender;
            MorphModeSelection(d.Text);
        }

        private void TxtExpectedThr_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) e.SuppressKeyPress = true;
        }

        private void TxtExpected_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) e.SuppressKeyPress = true;
        }

        private void CmbRotationAngle_Validating(object sender, CancelEventArgs e)
        {
            var strAngle = cmbRotationAngle.SelectedItem;
            if (!cmbRotationAngle.Items.Contains(strAngle) && cmbRotationAngle.Focused)
            {
                MessageBox.Show("Please select correct angle from dropdown.", "Invalid Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Cancel = true;
            }
        }

        private void BtnCharResult_Click(object sender, EventArgs e)
        {
            if (BoundedROI is null || BoundedROI.CharResults is null) return;
            FrmCharResult frmChar = new(BoundedROI.CharResults);
            frmChar.ShowDialog();
        }

        private void ChkAnchor_CheckedChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;

            BoundedROI.IsAnchor = chkAnchor.Checked;
            chkIsUseReferance.Enabled = chkAnchor.Checked;

            OpenAnchorSettingsWindow?.Invoke(this, EventArgs.Empty);
        }

        private void ChkIsUseReferance_CheckedChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;

            BoundedROI.IsUseRoiReference = chkIsUseReferance.Checked;
            OpenRoiReferenceWindow?.Invoke(this, EventArgs.Empty);
        }

        private void BtnCopyDecodedText_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtDecoded.Text)) return;

            TxtExpected.Text = TxtDecoded.Text;
        }

        private void CmbSegments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isBinding || BoundedROI == null) return;
            BoundedROI.SegmentationMode = (SegmentationMode)CmbSegments.SelectedItem;
            SettingsChanged?.Invoke(this, EventArgs.Empty);
        }

        private void TxtExpectedThr_ValueChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;

            //if (BoundedROI.Type == RoiType.TemplateMatch) 
            //    BoundedROI.TmThreshold = (double)TxtExpectedThr.Value;
            //else 
            BoundedROI.Threshold = (double)TxtExpectedThr.Value;
        }

        private void NumPadOCRExpected_ValueChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;

            //if (BoundedROI.Type == RoiType.TemplateMatch) 
            //    BoundedROI.TmThreshold = (double)TxtExpectedThr.Value;
            //else 
            BoundedROI.OcrExpectedResultCount = (double)numPadOCRExpected.Value;
        }

        private void RdThresolding_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RdMorphModeDilate_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RdThresolding_Click(object sender, EventArgs e)
        {
            var d = (RadioButton)sender;

            MorphModeSelection(d.Text);
        }

        private void ModernTrackBar1_ValueChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;
            BoundedROI.ThresholdMin = (int)trckBarThreshold.Value;
            BoundedROI.ThresholdMax = 255;
            ApplyThreshold?.Invoke(this, EventArgs.Empty);
        }

        private void ChkEnableThresholding_CheckedChanged(object sender, EventArgs e)
        {
            if (BoundedROI is null || _isBinding) return;

            BoundedROI.EnableThresholding = chkEnableThresholding.Checked;
            BoundedROI.MorphOp = MorphOperation.None;

            SettingsChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
