﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace CsplCameraOcr.UserControls
{
    public enum ModernTheme
    {
        Custom,
        CondotRed,
        DarkMode,
        LightMode,
        NeonBlue,
        EmeraldGreen
    }

    [DefaultEvent("ValueChanged")]
    public partial class ModernTrackBar : UserControl
    {
        private TableLayoutPanel layout;
        private Label lblValue;
        private Label lblMin;
        private Label lblMax;
        private FlatSlider slider;

        private string _unit = "";
        private ModernTheme _theme = ModernTheme.CondotRed;

        public event EventHandler ValueChanged;

        public ModernTrackBar()
        {
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;

            InitializeCom();
            ApplyTheme(_theme);
        }

        private void InitializeCom()
        {
            Size = new Size(280, 85);

            layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 3,
                ColumnCount = 2,
                Margin = new Padding(0),
                BackColor = Color.Transparent
            };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

            lblValue = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                AutoSize = true,
                Padding = new Padding(0, 0, 0, 5),
                BackColor = Color.Transparent
            };

            lblMin = new Label
            {
                Dock = DockStyle.Left,
                TextAlign = ContentAlignment.BottomLeft,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                AutoSize = true,
                BackColor = Color.Transparent
            };

            lblMax = new Label
            {
                Dock = DockStyle.Right,
                TextAlign = ContentAlignment.BottomRight,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                AutoSize = true,
                BackColor = Color.Transparent
            };

            slider = new FlatSlider
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(8, 5, 8, 5)
            };

            slider.ValueChanged += (s, e) =>
            {
                UpdateLabels();
                ValueChanged?.Invoke(this, e);
            };

            layout.Controls.Add(lblValue, 0, 0);
            layout.SetColumnSpan(lblValue, 2);

            layout.Controls.Add(slider, 0, 1);
            layout.SetColumnSpan(slider, 2);

            layout.Controls.Add(lblMin, 0, 2);
            layout.Controls.Add(lblMax, 1, 2);

            this.Controls.Add(layout);
        }

        #region PROPERTIES: DATA BINDING & KEYBOARD

        [Category("Modern Data"), Description("The minimum value of the trackbar.")]
        public double Minimum { get => slider.Minimum; set { slider.Minimum = value; UpdateLabels(); } }

        [Category("Modern Data"), Description("The maximum value of the trackbar.")]
        public double Maximum { get => slider.Maximum; set { slider.Maximum = value; UpdateLabels(); } }

        [Category("Modern Data"), Description("The current value of the trackbar.")]
        public double Value { get => slider.Value; set { slider.Value = value; UpdateLabels(); } }

        // NEW PROPERTY EXPOSED FOR DESIGNER
        [Category("Modern Data"), Description("If true, rounds the value to a whole number when dragging or using keys.")]
        public bool IsRoundOfValue
        {
            get => slider.IsRoundOfValue;
            set
            {
                slider.IsRoundOfValue = value;
                // Force re-evaluation of current value to apply rounding immediately
                slider.Value = slider.Value;
                UpdateLabels();
            }
        }

        [Category("Modern Data"), Description("The unit string to display next to the value (e.g., kPa, ms).")]
        public string Unit
        {
            get => _unit;
            set
            {
                _unit = value;
                UpdateLabels();
            }
        }

        [Category("Modern Data"), Description("Shows the conversion formula if unit is kPa")]
        public bool ShowConverSion { get; set; } = true;

        [Browsable(false)]
        public double ConverSionVal { get; private set; } = 0;

        [Category("Modern Data"), Description("Absolute value for kPa calculation.")]
        public double ConversionAbsVal { get; set; } = 2475.0;

        [Category("Modern Data"), Description("Division factor for kPa calculation.")]
        public double ConversionDivFact { get; set; } = 17.0;

        [Category("Modern Keyboard"), Description("Amount to change when using Arrow Keys.")]
        public double SmallChange { get => slider.SmallChange; set => slider.SmallChange = value; }

        [Category("Modern Keyboard"), Description("Amount to change when using Page Up/Page Down.")]
        public double LargeChange { get => slider.LargeChange; set => slider.LargeChange = value; }

        #endregion

        #region PROPERTIES: UI & STYLING

        [Category("Modern Styling"), Description("Choose a preset color theme, or select Custom to build your own.")]
        public ModernTheme Theme
        {
            get => _theme;
            set { _theme = value; ApplyTheme(value); }
        }

        [Category("Modern Styling"), Description("Inverts the slider so Maximum is on the Left and Minimum is on the Right.")]
        public bool Inverted
        {
            get => slider.Inverted;
            set
            {
                slider.Inverted = value;
                UpdateLabels();
                slider.Invalidate();
            }
        }

        [Category("Modern Styling - Colors")]
        public Color TrackerGradientStart { get => slider.TrackerGradientStart; set { slider.TrackerGradientStart = value; _theme = ModernTheme.Custom; } }

        [Category("Modern Styling - Colors")]
        public Color TrackerGradientEnd { get => slider.TrackerGradientEnd; set { slider.TrackerGradientEnd = value; _theme = ModernTheme.Custom; } }

        [Category("Modern Styling - Colors")]
        public Color TrackEmptyColor { get => slider.TrackEmptyColor; set { slider.TrackEmptyColor = value; _theme = ModernTheme.Custom; } }

        [Category("Modern Styling - Colors")]
        public Color ThumbColor { get => slider.ThumbColor; set { slider.ThumbColor = value; _theme = ModernTheme.Custom; } }

        [Category("Modern Styling - Colors")]
        public Color ThumbBorderColor { get => slider.ThumbBorderColor; set { slider.ThumbBorderColor = value; _theme = ModernTheme.Custom; } }

        [Category("Modern Styling - Colors")]
        public Color ValueTextColor { get => lblValue.ForeColor; set { lblValue.ForeColor = value; _theme = ModernTheme.Custom; } }

        [Category("Modern Styling - Colors")]
        public Color MinMaxTextColor { get => lblMin.ForeColor; set { lblMin.ForeColor = value; lblMax.ForeColor = value; _theme = ModernTheme.Custom; } }

        #endregion

        public double ConvertkPaToInt(double intParamRegVal, double intPramAbsVal, double intDivisionfac)
        {
            double CalVal = intParamRegVal - intPramAbsVal;
            double DivVal = CalVal / intDivisionfac;
            return Math.Round(DivVal, 2);
        }

        private void UpdateLabels()
        {
            if (slider.Inverted)
            {
                lblMin.Text = Maximum.ToString("0.##");
                lblMax.Text = Minimum.ToString("0.##");
            }
            else
            {
                lblMin.Text = Minimum.ToString("0.##");
                lblMax.Text = Maximum.ToString("0.##");
            }

            ConverSionVal = ConvertkPaToInt(Value, ConversionAbsVal, ConversionDivFact);

            if (string.Equals(_unit, "kPa", StringComparison.OrdinalIgnoreCase) && ShowConverSion)
            {
                lblValue.Text = $"{Value.ToString("0.##")} ({ConverSionVal} {_unit})";
            }
            else if (!string.IsNullOrEmpty(_unit))
            {
                lblValue.Text = $"{Value.ToString("0.##")} {_unit}".Trim();
            }
            else
            {
                lblValue.Text = Value.ToString("0.##");
            }
        }

        private void ApplyTheme(ModernTheme theme)
        {
            if (theme == ModernTheme.Custom) return;

            switch (theme)
            {
                case ModernTheme.CondotRed:
                    TrackerGradientStart = Color.FromArgb(218, 37, 29); TrackerGradientEnd = Color.FromArgb(255, 87, 34);
                    TrackEmptyColor = Color.FromArgb(220, 220, 225); ThumbColor = Color.White; ThumbBorderColor = Color.FromArgb(218, 37, 29);
                    ValueTextColor = Color.FromArgb(40, 40, 40); MinMaxTextColor = Color.Gray; break;
                case ModernTheme.DarkMode:
                    TrackerGradientStart = Color.FromArgb(64, 153, 255); TrackerGradientEnd = Color.FromArgb(0, 212, 255);
                    TrackEmptyColor = Color.FromArgb(50, 50, 50); ThumbColor = Color.FromArgb(30, 30, 30); ThumbBorderColor = Color.FromArgb(0, 212, 255);
                    ValueTextColor = Color.White; MinMaxTextColor = Color.Silver; break;
                case ModernTheme.LightMode:
                    TrackerGradientStart = Color.FromArgb(100, 100, 100); TrackerGradientEnd = Color.FromArgb(150, 150, 150);
                    TrackEmptyColor = Color.FromArgb(230, 230, 230); ThumbColor = Color.White; ThumbBorderColor = Color.FromArgb(100, 100, 100);
                    ValueTextColor = Color.Black; MinMaxTextColor = Color.DimGray; break;
                case ModernTheme.NeonBlue:
                    TrackerGradientStart = Color.FromArgb(0, 242, 254); TrackerGradientEnd = Color.FromArgb(79, 172, 254);
                    TrackEmptyColor = Color.FromArgb(30, 40, 50); ThumbColor = Color.White; ThumbBorderColor = Color.FromArgb(0, 242, 254);
                    ValueTextColor = Color.FromArgb(0, 242, 254); MinMaxTextColor = Color.LightSteelBlue; break;
                case ModernTheme.EmeraldGreen:
                    TrackerGradientStart = Color.FromArgb(17, 153, 142); TrackerGradientEnd = Color.FromArgb(56, 239, 125);
                    TrackEmptyColor = Color.FromArgb(220, 235, 225); ThumbColor = Color.White; ThumbBorderColor = Color.FromArgb(17, 153, 142);
                    ValueTextColor = Color.FromArgb(20, 100, 80); MinMaxTextColor = Color.Gray; break;
            }
            _theme = theme;
        }
    }

    // =========================================================================
    // THE CUSTOM DRAWN MODERN SLIDER ENGINE
    // =========================================================================
    public class FlatSlider : Control
    {
        private double _min = 0.0, _max = 100.0, _value = 0.0;
        private bool _isDragging = false;
        private bool _isHovered = false;

        public bool Inverted { get; set; } = false;
        public bool IsRoundOfValue { get; set; } = false;

        public Color TrackerGradientStart { get; set; } = Color.FromArgb(218, 37, 29);
        public Color TrackerGradientEnd { get; set; } = Color.FromArgb(255, 87, 34);
        public Color TrackEmptyColor { get; set; } = Color.FromArgb(220, 220, 225);
        public Color ThumbColor { get; set; } = Color.White;
        public Color ThumbBorderColor { get; set; } = Color.FromArgb(218, 37, 29);

        public double SmallChange { get; set; } = 1.0;
        public double LargeChange { get; set; } = 5.0;

        public event EventHandler ValueChanged;

        public double Minimum { get => _min; set { _min = value; Invalidate(); } }
        public double Maximum { get => _max; set { _max = value; Invalidate(); } }

        public double Value
        {
            get => _value;
            set
            {
                // Clamp value to min/max bounds
                double target = Math.Max(_min, Math.Min(_max, value));

                //  If IsRoundOfValue is true, round to nearest whole number
                if (IsRoundOfValue)
                {
                    target = Math.Round(target, MidpointRounding.AwayFromZero);
                }

                if (Math.Abs(_value - target) > double.Epsilon)
                {
                    _value = target;
                    ValueChanged?.Invoke(this, EventArgs.Empty);
                }
                Invalidate();
            }
        }

        public FlatSlider()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor | ControlStyles.Selectable, true);
            this.BackColor = Color.Transparent;
            this.Cursor = Cursors.Hand;
            this.TabStop = true;
        }

        #region MOUSE & FOCUS HANDLING

        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnMouseEnter(EventArgs e) { _isHovered = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _isHovered = false; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            this.Focus();
            if (e.Button == MouseButtons.Left) { _isDragging = true; UpdateValueFromMouse(e.X); }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_isDragging) UpdateValueFromMouse(e.X);
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e) { _isDragging = false; Invalidate(); base.OnMouseUp(e); }

        private void UpdateValueFromMouse(int mouseX)
        {
            int maxThumbSize = 24;
            int trackX = maxThumbSize / 2;
            int trackWidth = this.Width - maxThumbSize;

            if (trackWidth <= 0) return;

            float percent = (float)(mouseX - trackX) / trackWidth;
            percent = Math.Max(0f, Math.Min(1f, percent));

            if (Inverted)
                Value = _max - percent * (_max - _min);
            else
                Value = _min + percent * (_max - _min);
        }

        #endregion

        #region KEYBOARD HANDLING

        protected override bool IsInputKey(Keys keyData)
        {
            switch (keyData)
            {
                case Keys.Right:
                case Keys.Left:
                case Keys.Up:
                case Keys.Down:
                    return true;
            }
            return base.IsInputKey(keyData);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);

            if (Inverted)
            {
                if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Up) Value += SmallChange;
                else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Down) Value -= SmallChange;
                else if (e.KeyCode == Keys.PageUp) Value += LargeChange;
                else if (e.KeyCode == Keys.PageDown) Value -= LargeChange;
                else if (e.KeyCode == Keys.Home) Value = Maximum;
                else if (e.KeyCode == Keys.End) Value = Minimum;
            }
            else
            {
                if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Down) Value -= SmallChange;
                else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Up) Value += SmallChange;
                else if (e.KeyCode == Keys.PageDown) Value -= LargeChange;
                else if (e.KeyCode == Keys.PageUp) Value += LargeChange;
                else if (e.KeyCode == Keys.Home) Value = Minimum;
                else if (e.KeyCode == Keys.End) Value = Maximum;
            }
        }

        #endregion

        #region CUSTOM PAINTING

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int thumbSize = (_isDragging || _isHovered) ? 22 : 18;
            int trackHeight = 6;

            int maxThumbSize = 24;
            int trackX = maxThumbSize / 2;
            int trackY = (this.Height - trackHeight) / 2;
            int trackWidth = this.Width - maxThumbSize;

            if (trackWidth <= 0) return;

            using (GraphicsPath bgPath = GetRoundedRect(new Rectangle(trackX, trackY, trackWidth, trackHeight), trackHeight / 2))
            using (SolidBrush bgBrush = new SolidBrush(TrackEmptyColor))
                g.FillPath(bgBrush, bgPath);

            double range = _max - _min;
            float percentVal = range > 0 ? (float)((_value - _min) / range) : 0f;

            if (float.IsNaN(percentVal) || float.IsInfinity(percentVal)) percentVal = 0f;
            percentVal = Math.Max(0f, Math.Min(1f, percentVal));

            if (Inverted)
                percentVal = 1f - percentVal;

            int valX = trackX + (int)(percentVal * trackWidth);

            Rectangle fillRect;

            if (_min < 0 && _max > 0)
            {
                float percentZero = (float)((0 - _min) / range);
                if (Inverted) percentZero = 1f - percentZero;
                int zeroX = trackX + (int)(percentZero * trackWidth);

                if (valX >= zeroX)
                    fillRect = new Rectangle(zeroX, trackY, valX - zeroX, trackHeight);
                else
                    fillRect = new Rectangle(valX, trackY, zeroX - valX, trackHeight);
            }
            else
            {
                fillRect = new Rectangle(trackX, trackY, valX - trackX, trackHeight);
            }

            if (fillRect.Width > 0)
            {
                using (GraphicsPath fillPath = GetRoundedRect(fillRect, trackHeight / 2))
                using (LinearGradientBrush fillBrush = new LinearGradientBrush(fillRect, TrackerGradientStart, TrackerGradientEnd, LinearGradientMode.Horizontal))
                    g.FillPath(fillBrush, fillPath);
            }

            int thumbX = valX - (thumbSize / 2);
            int thumbY = (this.Height - thumbSize) / 2;
            Rectangle thumbRect = new Rectangle(thumbX, thumbY, thumbSize, thumbSize);

            if (this.Focused)
            {
                int glowSize = thumbSize + 6;
                Rectangle glowRect = new Rectangle(thumbX - 3, thumbY - 3, glowSize, glowSize);
                using (SolidBrush focusBrush = new SolidBrush(Color.FromArgb(80, TrackerGradientEnd)))
                    g.FillEllipse(focusBrush, glowRect);
            }

            using (SolidBrush shadowBrush = new SolidBrush(Color.FromArgb(50, 0, 0, 0)))
                g.FillEllipse(shadowBrush, thumbRect.X + 1, thumbRect.Y + 2, thumbSize, thumbSize);

            using (SolidBrush thumbBrush = new SolidBrush(ThumbColor))
            using (Pen thumbPen = new Pen(ThumbBorderColor, (_isDragging ? 3.5f : 2.5f)))
            {
                g.FillEllipse(thumbBrush, thumbRect);
                g.DrawEllipse(thumbPen, thumbRect);
            }
        }

        private GraphicsPath GetRoundedRect(Rectangle bounds, int radius)
        {
            int diameter = radius * 2;
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(bounds.Location, size);
            GraphicsPath path = new GraphicsPath();

            if (radius == 0) { path.AddRectangle(bounds); return path; }

            path.AddArc(arc, 180, 90); arc.X = bounds.Right - diameter;
            path.AddArc(arc, 270, 90); arc.Y = bounds.Bottom - diameter;
            path.AddArc(arc, 0, 90); arc.X = bounds.Left;
            path.AddArc(arc, 90, 90);

            path.CloseFigure();
            return path;
        }

        #endregion
    }
}