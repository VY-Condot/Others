﻿using CsplCameraOcr.UserControls;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace OpenCV_SharpNet.UserControls
{
    partial class ROIControlBarCode
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ROIControlBarCode));
            TblPNlMain = new TableLayoutPanel();
            grpQC_Result = new GroupBox();
            tblPnlgs1Repo = new TableLayoutPanel();
            lstGS1_Repo = new ListBox();
            tblPnlGrade = new TableLayoutPanel();
            cmbPassingGrade = new ComboBox();
            lblPassingGrade = new Label();
            chkGradingRepo = new CheckBox();
            btnSetting = new Button();
            TblPnlRotationAngle = new TableLayoutPanel();
            LblRotationAngle = new Label();
            cmbRotationAngle = new ComboBox();
            chkAnchor = new CheckBox();
            chkIsUseReferance = new CheckBox();
            TblPnlBottom = new TableLayoutPanel();
            BtnDecodeROI = new Button();
            GrpRoiData = new GroupBox();
            TblPnlRoiOcrData = new TableLayoutPanel();
            txtExpected = new TextBox();
            lblExpectedValue = new Label();
            chkBarcodeFormatAuto = new CheckBox();
            cmbBarcodeFormat = new ComboBox();
            lblBarcodeFormat = new Label();
            LblDecoded = new Label();
            TxtDecoded = new TextBox();
            chkEnableExpectedMode = new CheckBox();
            btnCopyDecodedText = new Button();
            tblPnlScanResult = new TableLayoutPanel();
            lblScanResultValue = new Label();
            lblScanResult = new Label();
            TblImageAndRepo = new TableLayoutPanel();
            pzPreview = new PanZoomViewer();
            grpBoxAdvancedMode = new GroupBox();
            tableLayoutPanel2 = new TableLayoutPanel();
            numPadExpectedCount = new NumericUpDown();
            lblExpectedCount = new Label();
            chkBarcodeAdvancedMode = new CheckBox();
            TblPNlMain.SuspendLayout();
            grpQC_Result.SuspendLayout();
            tblPnlgs1Repo.SuspendLayout();
            tblPnlGrade.SuspendLayout();
            TblPnlRotationAngle.SuspendLayout();
            TblPnlBottom.SuspendLayout();
            GrpRoiData.SuspendLayout();
            TblPnlRoiOcrData.SuspendLayout();
            tblPnlScanResult.SuspendLayout();
            TblImageAndRepo.SuspendLayout();
            grpBoxAdvancedMode.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numPadExpectedCount).BeginInit();
            SuspendLayout();
            // 
            // TblPNlMain
            // 
            TblPNlMain.ColumnCount = 1;
            TblPNlMain.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TblPNlMain.Controls.Add(grpQC_Result, 0, 4);
            TblPNlMain.Controls.Add(TblPnlRotationAngle, 0, 2);
            TblPNlMain.Controls.Add(TblPnlBottom, 0, 5);
            TblPNlMain.Controls.Add(GrpRoiData, 0, 0);
            TblPNlMain.Controls.Add(TblImageAndRepo, 0, 3);
            TblPNlMain.Controls.Add(grpBoxAdvancedMode, 0, 1);
            TblPNlMain.Dock = DockStyle.Fill;
            TblPNlMain.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TblPNlMain.Location = new Point(0, 0);
            TblPNlMain.Name = "TblPNlMain";
            TblPNlMain.RowCount = 7;
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 267F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 71F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 91F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 262F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 58F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            TblPNlMain.Size = new Size(597, 807);
            TblPNlMain.TabIndex = 0;
            // 
            // grpQC_Result
            // 
            grpQC_Result.Controls.Add(tblPnlgs1Repo);
            grpQC_Result.Dock = DockStyle.Fill;
            grpQC_Result.Font = new Font("Calibri", 11F, FontStyle.Bold);
            grpQC_Result.Location = new Point(3, 482);
            grpQC_Result.Name = "grpQC_Result";
            grpQC_Result.Size = new Size(591, 256);
            grpQC_Result.TabIndex = 10;
            grpQC_Result.TabStop = false;
            grpQC_Result.Text = "QC Report";
            grpQC_Result.UseCompatibleTextRendering = true;
            // 
            // tblPnlgs1Repo
            // 
            tblPnlgs1Repo.ColumnCount = 1;
            tblPnlgs1Repo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tblPnlgs1Repo.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tblPnlgs1Repo.Controls.Add(lstGS1_Repo, 0, 1);
            tblPnlgs1Repo.Controls.Add(tblPnlGrade, 0, 0);
            tblPnlgs1Repo.Dock = DockStyle.Fill;
            tblPnlgs1Repo.Font = new Font("Calibri", 11F, FontStyle.Bold);
            tblPnlgs1Repo.Location = new Point(3, 26);
            tblPnlgs1Repo.Name = "tblPnlgs1Repo";
            tblPnlgs1Repo.RowCount = 2;
            tblPnlgs1Repo.RowStyles.Add(new RowStyle(SizeType.Absolute, 51F));
            tblPnlgs1Repo.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tblPnlgs1Repo.Size = new Size(585, 227);
            tblPnlgs1Repo.TabIndex = 0;
            // 
            // lstGS1_Repo
            // 
            lstGS1_Repo.Dock = DockStyle.Fill;
            lstGS1_Repo.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lstGS1_Repo.FormattingEnabled = true;
            lstGS1_Repo.ItemHeight = 22;
            lstGS1_Repo.Location = new Point(3, 54);
            lstGS1_Repo.Name = "lstGS1_Repo";
            lstGS1_Repo.Size = new Size(579, 170);
            lstGS1_Repo.TabIndex = 8;
            // 
            // tblPnlGrade
            // 
            tblPnlGrade.ColumnCount = 5;
            tblPnlGrade.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 163F));
            tblPnlGrade.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 111F));
            tblPnlGrade.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 132F));
            tblPnlGrade.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 127F));
            tblPnlGrade.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tblPnlGrade.Controls.Add(cmbPassingGrade, 3, 0);
            tblPnlGrade.Controls.Add(lblPassingGrade, 2, 0);
            tblPnlGrade.Controls.Add(chkGradingRepo, 0, 0);
            tblPnlGrade.Controls.Add(btnSetting, 1, 0);
            tblPnlGrade.Dock = DockStyle.Fill;
            tblPnlGrade.Font = new Font("Calibri", 11F, FontStyle.Bold);
            tblPnlGrade.Location = new Point(3, 3);
            tblPnlGrade.Name = "tblPnlGrade";
            tblPnlGrade.RowCount = 1;
            tblPnlGrade.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tblPnlGrade.Size = new Size(579, 45);
            tblPnlGrade.TabIndex = 9;
            // 
            // cmbPassingGrade
            // 
            cmbPassingGrade.Dock = DockStyle.Fill;
            cmbPassingGrade.Font = new Font("Calibri", 11F, FontStyle.Bold);
            cmbPassingGrade.FormattingEnabled = true;
            cmbPassingGrade.Location = new Point(409, 8);
            cmbPassingGrade.Margin = new Padding(3, 8, 3, 3);
            cmbPassingGrade.Name = "cmbPassingGrade";
            cmbPassingGrade.Size = new Size(121, 30);
            cmbPassingGrade.TabIndex = 12;
            cmbPassingGrade.SelectedIndexChanged += CmbPassingGrade_SelectedIndexChanged;
            // 
            // lblPassingGrade
            // 
            lblPassingGrade.AutoSize = true;
            lblPassingGrade.Dock = DockStyle.Fill;
            lblPassingGrade.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblPassingGrade.Location = new Point(277, 3);
            lblPassingGrade.Margin = new Padding(3);
            lblPassingGrade.Name = "lblPassingGrade";
            lblPassingGrade.Size = new Size(126, 39);
            lblPassingGrade.TabIndex = 11;
            lblPassingGrade.Text = "Passing Grade :";
            lblPassingGrade.TextAlign = ContentAlignment.MiddleLeft;
            lblPassingGrade.UseCompatibleTextRendering = true;
            // 
            // chkGradingRepo
            // 
            chkGradingRepo.AutoSize = true;
            chkGradingRepo.Dock = DockStyle.Fill;
            chkGradingRepo.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkGradingRepo.Location = new Point(3, 3);
            chkGradingRepo.Name = "chkGradingRepo";
            chkGradingRepo.Padding = new Padding(5, 0, 0, 0);
            chkGradingRepo.Size = new Size(157, 39);
            chkGradingRepo.TabIndex = 9;
            chkGradingRepo.Text = "Grading Report";
            chkGradingRepo.UseCompatibleTextRendering = true;
            chkGradingRepo.UseVisualStyleBackColor = true;
            chkGradingRepo.CheckedChanged += ChkGradingRepo_CheckedChanged;
            // 
            // btnSetting
            // 
            btnSetting.BackColor = Color.Red;
            btnSetting.Dock = DockStyle.Fill;
            btnSetting.Enabled = false;
            btnSetting.Font = new Font("Calibri", 11F, FontStyle.Bold);
            btnSetting.ForeColor = Color.White;
            btnSetting.Location = new Point(166, 3);
            btnSetting.Name = "btnSetting";
            btnSetting.Size = new Size(105, 39);
            btnSetting.TabIndex = 10;
            btnSetting.Text = "Setting";
            btnSetting.UseCompatibleTextRendering = true;
            btnSetting.UseVisualStyleBackColor = false;
            btnSetting.Click += BtnSetting_Click;
            // 
            // TblPnlRotationAngle
            // 
            TblPnlRotationAngle.ColumnCount = 5;
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 95F));
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 183F));
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 9F));
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 149F));
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TblPnlRotationAngle.Controls.Add(LblRotationAngle, 0, 0);
            TblPnlRotationAngle.Controls.Add(cmbRotationAngle, 1, 0);
            TblPnlRotationAngle.Controls.Add(chkAnchor, 3, 0);
            TblPnlRotationAngle.Controls.Add(chkIsUseReferance, 4, 0);
            TblPnlRotationAngle.Dock = DockStyle.Fill;
            TblPnlRotationAngle.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TblPnlRotationAngle.Location = new Point(3, 341);
            TblPnlRotationAngle.Name = "TblPnlRotationAngle";
            TblPnlRotationAngle.RowCount = 1;
            TblPnlRotationAngle.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            TblPnlRotationAngle.Size = new Size(591, 44);
            TblPnlRotationAngle.TabIndex = 5;
            // 
            // LblRotationAngle
            // 
            LblRotationAngle.AutoSize = true;
            LblRotationAngle.Dock = DockStyle.Fill;
            LblRotationAngle.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblRotationAngle.Location = new Point(3, 3);
            LblRotationAngle.Margin = new Padding(3);
            LblRotationAngle.Name = "LblRotationAngle";
            LblRotationAngle.Size = new Size(89, 38);
            LblRotationAngle.TabIndex = 2;
            LblRotationAngle.Text = " Rotation : ";
            LblRotationAngle.TextAlign = ContentAlignment.MiddleLeft;
            LblRotationAngle.UseCompatibleTextRendering = true;
            // 
            // cmbRotationAngle
            // 
            cmbRotationAngle.Font = new Font("Calibri", 11F, FontStyle.Bold);
            cmbRotationAngle.FormattingEnabled = true;
            cmbRotationAngle.Location = new Point(98, 8);
            cmbRotationAngle.Margin = new Padding(3, 8, 3, 3);
            cmbRotationAngle.Name = "cmbRotationAngle";
            cmbRotationAngle.Size = new Size(177, 30);
            cmbRotationAngle.TabIndex = 3;
            cmbRotationAngle.SelectedIndexChanged += CmbRotationAngle_SelectedIndexChanged;
            cmbRotationAngle.Validating += CmbRotationAngle_Validating;
            // 
            // chkAnchor
            // 
            chkAnchor.AutoSize = true;
            chkAnchor.Dock = DockStyle.Fill;
            chkAnchor.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkAnchor.Location = new Point(290, 3);
            chkAnchor.Name = "chkAnchor";
            chkAnchor.Size = new Size(143, 38);
            chkAnchor.TabIndex = 9;
            chkAnchor.Text = "Enable Anchor";
            chkAnchor.UseCompatibleTextRendering = true;
            chkAnchor.UseVisualStyleBackColor = true;
            chkAnchor.CheckedChanged += ChkAnchor_CheckedChanged;
            // 
            // chkIsUseReferance
            // 
            chkIsUseReferance.AutoSize = true;
            chkIsUseReferance.Dock = DockStyle.Fill;
            chkIsUseReferance.Enabled = false;
            chkIsUseReferance.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkIsUseReferance.Location = new Point(439, 3);
            chkIsUseReferance.Name = "chkIsUseReferance";
            chkIsUseReferance.Size = new Size(149, 38);
            chkIsUseReferance.TabIndex = 10;
            chkIsUseReferance.Text = "Use ROI Ref.";
            chkIsUseReferance.UseCompatibleTextRendering = true;
            chkIsUseReferance.UseVisualStyleBackColor = true;
            chkIsUseReferance.CheckedChanged += ChkIsUseReferance_CheckedChanged;
            // 
            // TblPnlBottom
            // 
            TblPnlBottom.ColumnCount = 3;
            TblPnlBottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            TblPnlBottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 158F));
            TblPnlBottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            TblPnlBottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            TblPnlBottom.Controls.Add(BtnDecodeROI, 1, 0);
            TblPnlBottom.Dock = DockStyle.Fill;
            TblPnlBottom.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TblPnlBottom.Location = new Point(3, 744);
            TblPnlBottom.Name = "TblPnlBottom";
            TblPnlBottom.RowCount = 1;
            TblPnlBottom.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            TblPnlBottom.Size = new Size(591, 52);
            TblPnlBottom.TabIndex = 3;
            // 
            // BtnDecodeROI
            // 
            BtnDecodeROI.BackColor = Color.Red;
            BtnDecodeROI.Dock = DockStyle.Fill;
            BtnDecodeROI.Font = new Font("Calibri", 11F, FontStyle.Bold);
            BtnDecodeROI.ForeColor = Color.Transparent;
            BtnDecodeROI.Image = (Image)resources.GetObject("BtnDecodeROI.Image");
            BtnDecodeROI.ImageAlign = ContentAlignment.MiddleLeft;
            BtnDecodeROI.Location = new Point(219, 3);
            BtnDecodeROI.Name = "BtnDecodeROI";
            BtnDecodeROI.Padding = new Padding(10, 0, 0, 0);
            BtnDecodeROI.Size = new Size(152, 46);
            BtnDecodeROI.TabIndex = 2;
            BtnDecodeROI.Text = "Decode ROI";
            BtnDecodeROI.TextImageRelation = TextImageRelation.ImageBeforeText;
            BtnDecodeROI.UseCompatibleTextRendering = true;
            BtnDecodeROI.UseVisualStyleBackColor = false;
            BtnDecodeROI.Click += BtnDecodeROI_Click;
            // 
            // GrpRoiData
            // 
            GrpRoiData.BackColor = Color.Transparent;
            GrpRoiData.Controls.Add(TblPnlRoiOcrData);
            GrpRoiData.Dock = DockStyle.Fill;
            GrpRoiData.Font = new Font("Calibri", 11F, FontStyle.Bold);
            GrpRoiData.Location = new Point(3, 3);
            GrpRoiData.Name = "GrpRoiData";
            GrpRoiData.Size = new Size(591, 261);
            GrpRoiData.TabIndex = 0;
            GrpRoiData.TabStop = false;
            GrpRoiData.Text = "ROI Name";
            GrpRoiData.UseCompatibleTextRendering = true;
            // 
            // TblPnlRoiOcrData
            // 
            TblPnlRoiOcrData.ColumnCount = 3;
            TblPnlRoiOcrData.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 95F));
            TblPnlRoiOcrData.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TblPnlRoiOcrData.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 270F));
            TblPnlRoiOcrData.Controls.Add(txtExpected, 1, 3);
            TblPnlRoiOcrData.Controls.Add(lblExpectedValue, 0, 3);
            TblPnlRoiOcrData.Controls.Add(chkBarcodeFormatAuto, 2, 0);
            TblPnlRoiOcrData.Controls.Add(cmbBarcodeFormat, 1, 0);
            TblPnlRoiOcrData.Controls.Add(lblBarcodeFormat, 0, 0);
            TblPnlRoiOcrData.Controls.Add(LblDecoded, 0, 1);
            TblPnlRoiOcrData.Controls.Add(TxtDecoded, 1, 1);
            TblPnlRoiOcrData.Controls.Add(chkEnableExpectedMode, 1, 2);
            TblPnlRoiOcrData.Controls.Add(btnCopyDecodedText, 2, 2);
            TblPnlRoiOcrData.Controls.Add(tblPnlScanResult, 0, 4);
            TblPnlRoiOcrData.Dock = DockStyle.Fill;
            TblPnlRoiOcrData.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TblPnlRoiOcrData.Location = new Point(3, 26);
            TblPnlRoiOcrData.Name = "TblPnlRoiOcrData";
            TblPnlRoiOcrData.RowCount = 5;
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Absolute, 32F));
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
            TblPnlRoiOcrData.Size = new Size(585, 232);
            TblPnlRoiOcrData.TabIndex = 0;
            // 
            // txtExpected
            // 
            txtExpected.BackColor = Color.White;
            txtExpected.BorderStyle = BorderStyle.FixedSingle;
            TblPnlRoiOcrData.SetColumnSpan(txtExpected, 2);
            txtExpected.Dock = DockStyle.Fill;
            txtExpected.Font = new Font("Calibri", 11F, FontStyle.Bold);
            txtExpected.Location = new Point(98, 135);
            txtExpected.Multiline = true;
            txtExpected.Name = "txtExpected";
            txtExpected.Size = new Size(484, 54);
            txtExpected.TabIndex = 15;
            txtExpected.TextChanged += TxtExpected_TextChanged;
            // 
            // lblExpectedValue
            // 
            lblExpectedValue.AutoSize = true;
            lblExpectedValue.Dock = DockStyle.Fill;
            lblExpectedValue.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblExpectedValue.Location = new Point(3, 135);
            lblExpectedValue.Margin = new Padding(3);
            lblExpectedValue.Name = "lblExpectedValue";
            lblExpectedValue.Size = new Size(89, 54);
            lblExpectedValue.TabIndex = 14;
            lblExpectedValue.Text = "Expected : ";
            lblExpectedValue.TextAlign = ContentAlignment.MiddleLeft;
            lblExpectedValue.UseCompatibleTextRendering = true;
            // 
            // chkBarcodeFormatAuto
            // 
            chkBarcodeFormatAuto.AutoSize = true;
            chkBarcodeFormatAuto.Dock = DockStyle.Fill;
            chkBarcodeFormatAuto.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkBarcodeFormatAuto.Location = new Point(318, 3);
            chkBarcodeFormatAuto.Name = "chkBarcodeFormatAuto";
            chkBarcodeFormatAuto.Padding = new Padding(5, 0, 0, 0);
            chkBarcodeFormatAuto.Size = new Size(264, 34);
            chkBarcodeFormatAuto.TabIndex = 13;
            chkBarcodeFormatAuto.Text = "Auto";
            chkBarcodeFormatAuto.UseCompatibleTextRendering = true;
            chkBarcodeFormatAuto.UseVisualStyleBackColor = true;
            chkBarcodeFormatAuto.Click += ChkBarcodeFormatAuto_Click;
            // 
            // cmbBarcodeFormat
            // 
            cmbBarcodeFormat.Dock = DockStyle.Fill;
            cmbBarcodeFormat.Font = new Font("Calibri", 11F, FontStyle.Bold);
            cmbBarcodeFormat.FormattingEnabled = true;
            cmbBarcodeFormat.Location = new Point(98, 5);
            cmbBarcodeFormat.Margin = new Padding(3, 5, 3, 3);
            cmbBarcodeFormat.Name = "cmbBarcodeFormat";
            cmbBarcodeFormat.Size = new Size(214, 30);
            cmbBarcodeFormat.TabIndex = 4;
            cmbBarcodeFormat.SelectedIndexChanged += CmbBarcodeFormat_SelectedIndexChanged;
            // 
            // lblBarcodeFormat
            // 
            lblBarcodeFormat.AutoSize = true;
            lblBarcodeFormat.Dock = DockStyle.Fill;
            lblBarcodeFormat.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblBarcodeFormat.Location = new Point(3, 3);
            lblBarcodeFormat.Margin = new Padding(3);
            lblBarcodeFormat.Name = "lblBarcodeFormat";
            lblBarcodeFormat.Size = new Size(89, 34);
            lblBarcodeFormat.TabIndex = 0;
            lblBarcodeFormat.Text = "Format : ";
            lblBarcodeFormat.TextAlign = ContentAlignment.MiddleLeft;
            lblBarcodeFormat.UseCompatibleTextRendering = true;
            // 
            // LblDecoded
            // 
            LblDecoded.AutoSize = true;
            LblDecoded.Dock = DockStyle.Fill;
            LblDecoded.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblDecoded.Location = new Point(3, 43);
            LblDecoded.Margin = new Padding(3);
            LblDecoded.Name = "LblDecoded";
            LblDecoded.Size = new Size(89, 54);
            LblDecoded.TabIndex = 1;
            LblDecoded.Text = "Decoded : ";
            LblDecoded.TextAlign = ContentAlignment.MiddleLeft;
            LblDecoded.UseCompatibleTextRendering = true;
            // 
            // TxtDecoded
            // 
            TxtDecoded.BackColor = Color.White;
            TxtDecoded.BorderStyle = BorderStyle.FixedSingle;
            TblPnlRoiOcrData.SetColumnSpan(TxtDecoded, 2);
            TxtDecoded.Dock = DockStyle.Fill;
            TxtDecoded.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TxtDecoded.Location = new Point(98, 43);
            TxtDecoded.Multiline = true;
            TxtDecoded.Name = "TxtDecoded";
            TxtDecoded.ReadOnly = true;
            TxtDecoded.Size = new Size(484, 54);
            TxtDecoded.TabIndex = 3;
            // 
            // chkEnableExpectedMode
            // 
            chkEnableExpectedMode.AutoSize = true;
            chkEnableExpectedMode.Dock = DockStyle.Fill;
            chkEnableExpectedMode.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkEnableExpectedMode.Location = new Point(98, 103);
            chkEnableExpectedMode.Name = "chkEnableExpectedMode";
            chkEnableExpectedMode.Size = new Size(214, 26);
            chkEnableExpectedMode.TabIndex = 16;
            chkEnableExpectedMode.Text = "Enable Expected Match";
            chkEnableExpectedMode.UseCompatibleTextRendering = true;
            chkEnableExpectedMode.UseVisualStyleBackColor = true;
            chkEnableExpectedMode.CheckedChanged += ChkEnableExpectedMode_CheckedChanged;
            // 
            // btnCopyDecodedText
            // 
            btnCopyDecodedText.BackColor = Color.Red;
            btnCopyDecodedText.Dock = DockStyle.Fill;
            btnCopyDecodedText.Font = new Font("Calibri", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCopyDecodedText.ForeColor = Color.Transparent;
            btnCopyDecodedText.ImageAlign = ContentAlignment.MiddleLeft;
            btnCopyDecodedText.Location = new Point(325, 100);
            btnCopyDecodedText.Margin = new Padding(10, 0, 10, 0);
            btnCopyDecodedText.Name = "btnCopyDecodedText";
            btnCopyDecodedText.Padding = new Padding(10, 0, 0, 0);
            btnCopyDecodedText.Size = new Size(250, 32);
            btnCopyDecodedText.TabIndex = 17;
            btnCopyDecodedText.Text = "Copy Decoded Text";
            btnCopyDecodedText.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCopyDecodedText.UseCompatibleTextRendering = true;
            btnCopyDecodedText.UseVisualStyleBackColor = false;
            btnCopyDecodedText.Click += BtnCopyDecodedText_Click;
            // 
            // tblPnlScanResult
            // 
            tblPnlScanResult.ColumnCount = 2;
            TblPnlRoiOcrData.SetColumnSpan(tblPnlScanResult, 2);
            tblPnlScanResult.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 36.56958F));
            tblPnlScanResult.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 63.43042F));
            tblPnlScanResult.Controls.Add(lblScanResultValue, 1, 0);
            tblPnlScanResult.Controls.Add(lblScanResult, 0, 0);
            tblPnlScanResult.Dock = DockStyle.Fill;
            tblPnlScanResult.Location = new Point(3, 195);
            tblPnlScanResult.Name = "tblPnlScanResult";
            tblPnlScanResult.RowCount = 1;
            tblPnlScanResult.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tblPnlScanResult.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tblPnlScanResult.Size = new Size(309, 34);
            tblPnlScanResult.TabIndex = 19;
            // 
            // lblScanResultValue
            // 
            lblScanResultValue.AutoSize = true;
            lblScanResultValue.Dock = DockStyle.Fill;
            lblScanResultValue.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblScanResultValue.ForeColor = Color.Red;
            lblScanResultValue.Location = new Point(116, 3);
            lblScanResultValue.Margin = new Padding(3);
            lblScanResultValue.Name = "lblScanResultValue";
            lblScanResultValue.Size = new Size(190, 28);
            lblScanResultValue.TabIndex = 19;
            lblScanResultValue.Text = "Fail";
            lblScanResultValue.TextAlign = ContentAlignment.MiddleLeft;
            lblScanResultValue.UseCompatibleTextRendering = true;
            // 
            // lblScanResult
            // 
            lblScanResult.AutoSize = true;
            lblScanResult.Dock = DockStyle.Fill;
            lblScanResult.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblScanResult.Location = new Point(3, 3);
            lblScanResult.Margin = new Padding(3);
            lblScanResult.Name = "lblScanResult";
            lblScanResult.Size = new Size(107, 28);
            lblScanResult.TabIndex = 18;
            lblScanResult.Text = "Scan Result : ";
            lblScanResult.TextAlign = ContentAlignment.MiddleLeft;
            lblScanResult.UseCompatibleTextRendering = true;
            // 
            // TblImageAndRepo
            // 
            TblImageAndRepo.ColumnCount = 1;
            TblImageAndRepo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TblImageAndRepo.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            TblImageAndRepo.Controls.Add(pzPreview, 0, 0);
            TblImageAndRepo.Dock = DockStyle.Fill;
            TblImageAndRepo.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TblImageAndRepo.Location = new Point(3, 391);
            TblImageAndRepo.Name = "TblImageAndRepo";
            TblImageAndRepo.RowCount = 1;
            TblImageAndRepo.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            TblImageAndRepo.Size = new Size(591, 85);
            TblImageAndRepo.TabIndex = 9;
            // 
            // pzPreview
            // 
            pzPreview.Dock = DockStyle.Fill;
            pzPreview.Image = null;
            pzPreview.Interpolation = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            pzPreview.Location = new Point(3, 3);
            pzPreview.Name = "pzPreview";
            pzPreview.Size = new Size(585, 79);
            pzPreview.TabIndex = 0;
            // 
            // grpBoxAdvancedMode
            // 
            grpBoxAdvancedMode.Controls.Add(tableLayoutPanel2);
            grpBoxAdvancedMode.Dock = DockStyle.Fill;
            grpBoxAdvancedMode.Font = new Font("Calibri", 11F, FontStyle.Bold);
            grpBoxAdvancedMode.Location = new Point(3, 270);
            grpBoxAdvancedMode.Name = "grpBoxAdvancedMode";
            grpBoxAdvancedMode.Size = new Size(591, 65);
            grpBoxAdvancedMode.TabIndex = 11;
            grpBoxAdvancedMode.TabStop = false;
            grpBoxAdvancedMode.Text = "Processing mode and output check";
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 4;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 173F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 217F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Controls.Add(numPadExpectedCount, 2, 0);
            tableLayoutPanel2.Controls.Add(lblExpectedCount, 1, 0);
            tableLayoutPanel2.Controls.Add(chkBarcodeAdvancedMode, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Font = new Font("Calibri", 11F, FontStyle.Bold);
            tableLayoutPanel2.Location = new Point(3, 26);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Size = new Size(585, 36);
            tableLayoutPanel2.TabIndex = 6;
            // 
            // numPadExpectedCount
            // 
            numPadExpectedCount.Dock = DockStyle.Left;
            numPadExpectedCount.Font = new Font("Calibri", 11F, FontStyle.Bold);
            numPadExpectedCount.Location = new Point(393, 3);
            numPadExpectedCount.Maximum = new decimal(new int[] { 50000, 0, 0, 0 });
            numPadExpectedCount.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numPadExpectedCount.Name = "numPadExpectedCount";
            numPadExpectedCount.Size = new Size(67, 30);
            numPadExpectedCount.TabIndex = 14;
            numPadExpectedCount.Value = new decimal(new int[] { 1, 0, 0, 0 });
            numPadExpectedCount.ValueChanged += NumPadExpectedCount_ValueChanged;
            // 
            // lblExpectedCount
            // 
            lblExpectedCount.AutoSize = true;
            lblExpectedCount.Dock = DockStyle.Fill;
            lblExpectedCount.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblExpectedCount.Location = new Point(176, 3);
            lblExpectedCount.Margin = new Padding(3);
            lblExpectedCount.Name = "lblExpectedCount";
            lblExpectedCount.Size = new Size(211, 30);
            lblExpectedCount.TabIndex = 13;
            lblExpectedCount.Text = "Expected Barcode Count : ";
            lblExpectedCount.TextAlign = ContentAlignment.MiddleLeft;
            lblExpectedCount.UseCompatibleTextRendering = true;
            // 
            // chkBarcodeAdvancedMode
            // 
            chkBarcodeAdvancedMode.AutoSize = true;
            chkBarcodeAdvancedMode.Dock = DockStyle.Fill;
            chkBarcodeAdvancedMode.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkBarcodeAdvancedMode.Location = new Point(3, 3);
            chkBarcodeAdvancedMode.Name = "chkBarcodeAdvancedMode";
            chkBarcodeAdvancedMode.Padding = new Padding(5, 0, 0, 0);
            chkBarcodeAdvancedMode.Size = new Size(167, 30);
            chkBarcodeAdvancedMode.TabIndex = 12;
            chkBarcodeAdvancedMode.Text = "Advanced Mode";
            chkBarcodeAdvancedMode.UseCompatibleTextRendering = true;
            chkBarcodeAdvancedMode.UseVisualStyleBackColor = true;
            chkBarcodeAdvancedMode.Click += ChkBarcodeAdvancedMode_Click;
            // 
            // ROIControlBarCode
            // 
            AutoScaleDimensions = new SizeF(120F, 120F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.White;
            BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(TblPNlMain);
            DoubleBuffered = true;
            Font = new Font("Palatino Linotype", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "ROIControlBarCode";
            Size = new Size(597, 807);
            TblPNlMain.ResumeLayout(false);
            grpQC_Result.ResumeLayout(false);
            tblPnlgs1Repo.ResumeLayout(false);
            tblPnlGrade.ResumeLayout(false);
            tblPnlGrade.PerformLayout();
            TblPnlRotationAngle.ResumeLayout(false);
            TblPnlRotationAngle.PerformLayout();
            TblPnlBottom.ResumeLayout(false);
            GrpRoiData.ResumeLayout(false);
            TblPnlRoiOcrData.ResumeLayout(false);
            TblPnlRoiOcrData.PerformLayout();
            tblPnlScanResult.ResumeLayout(false);
            tblPnlScanResult.PerformLayout();
            TblImageAndRepo.ResumeLayout(false);
            grpBoxAdvancedMode.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numPadExpectedCount).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel TblPNlMain;
        private GroupBox GrpRoiData;
        private TableLayoutPanel TblPnlRoiOcrData;
        private Label LblExpected;
        private Label LblExpectedThresold;
        private Label LblDecoded;
        private TextBox TxtDecoded;
        private Label LblDecodedThresold;
        private TextBox TxtExpectedThr;
        private Label LblDecodedThr;
        //private CheckBox chkDoOCR;
        private TableLayoutPanel TblPnlBlobFil;
        private Label LblBlobMaxWidth;
        private Label LblBlobMinWidth;
        private Label LblBlobMinHeight;
        private Label LblBlobMaxHeight;
        private NumericUpDown NumPadMaxWidth;
        private NumericUpDown NumPadMinWidth;
        private NumericUpDown NumPadMinHeight;
        private NumericUpDown NumPadMaxHeight;
        private TableLayoutPanel TblPnlBottom;
        private Button BtnDecodeROI;
        private GroupBox GrpBlobFilter;
        private TableLayoutPanel TblPnlRotationAngle;
        private Label LblRotationAngle;
        private ListBox lstGS1_Repo;
        private TableLayoutPanel TblImageAndRepo;
        private GroupBox grpQC_Result;
        private Label lblOverAllResult;
        private Button btnCharResult;
        private ComboBox cmbRotationAngle;
        private CheckBox chkAnchor;
        private CheckBox chkIsUseReferance;
        private ComboBox cmbBarcodeFormat;
        private Label lblBarcodeFormat;
        private GroupBox grpBoxAdvancedMode;
        private TableLayoutPanel tableLayoutPanel2;
        //private CheckBox chkIsBarcodeFormatAuto;
        private CheckBox chkBarcodeAdvancedMode;
        private TableLayoutPanel tblPnlgs1Repo;
        private CheckBox chkGradingRepo;
        private TableLayoutPanel tblPnlGrade;
        private Button btnSetting;
        private Label lblExpectedCount;
        private NumericUpDown numPadExpectedCount;
        private PanZoomViewer pzPreview;
        private Label lblPassingGrade;
        private ComboBox cmbPassingGrade;
        private TextBox txtExpected;
        private Label lblExpectedValue;
        private CheckBox chkBarcodeFormatAuto;
        private CheckBox chkEnableExpectedMode;
        private Button btnCopyDecodedText;
        private Label lblScanResult;
        private TableLayoutPanel tblPnlScanResult;
        private Label lblScanResultValue;
    }
}
