﻿using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CsplCameraOcr.UserControls
{
    partial class ROIControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ROIControl));
            TblPNlMain = new TableLayoutPanel();
            grpImgThresold = new GroupBox();
            tableLayoutPanel3 = new TableLayoutPanel();
            chkEnableThresholding = new CheckBox();
            lblThresoldingValue = new Label();
            trckBarThreshold = new ModernTrackBar();
            GrpBoxSegMentMode = new GroupBox();
            tableLayoutPanel2 = new TableLayoutPanel();
            CmbSegments = new ComboBox();
            GrpBoxMorph = new GroupBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            tblPnlMorphMode = new TableLayoutPanel();
            rdMorphModeDilate = new RadioButton();
            rdMorphModeErode = new RadioButton();
            rdMorphModeNone = new RadioButton();
            NumPadMorphIteration = new NumericUpDown();
            lblMorphMode = new Label();
            lblMorphIternation = new Label();
            lblMorphKeranalWidth = new Label();
            NumPadMorphKeranalWidth = new NumericUpDown();
            TblPnlRotationAngle = new TableLayoutPanel();
            LblRotationAngle = new Label();
            cmbRotationAngle = new ComboBox();
            chkAnchor = new CheckBox();
            chkIsUseReferance = new CheckBox();
            TblPnlBottom = new TableLayoutPanel();
            BtnDecodeROI = new Button();
            btnCharResult = new Button();
            GrpRoiData = new GroupBox();
            TblPnlRoiOcrData = new TableLayoutPanel();
            numPadOCRExpected = new NumericUpDown();
            lblOcrCount = new Label();
            lblOverAllResult = new Label();
            LblDecoded = new Label();
            LblDecodedThr = new Label();
            LblDecodedThresold = new Label();
            chkDoOCR = new CheckBox();
            pnlBtnAndAdavancedBarcode = new Panel();
            btnCopyDecodedText = new Button();
            TxtDecoded = new TextBox();
            lblOcrCharCount = new Label();
            LblExpected = new Label();
            TxtExpected = new TextBox();
            LblExpectedThresold = new Label();
            TxtExpectedThr = new NumericUpDown();
            GrpBlobFilter = new GroupBox();
            TblPnlBlobFil = new TableLayoutPanel();
            NumPadMaxWidth = new NumericUpDown();
            LblBlobMaxWidth = new Label();
            LblBlobMinWidth = new Label();
            LblBlobMinHeight = new Label();
            LblBlobMaxHeight = new Label();
            NumPadMinWidth = new NumericUpDown();
            NumPadMinHeight = new NumericUpDown();
            NumPadMaxHeight = new NumericUpDown();
            pzPreview = new PanZoomViewer();
            TblPNlMain.SuspendLayout();
            grpImgThresold.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            GrpBoxSegMentMode.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            GrpBoxMorph.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            tblPnlMorphMode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumPadMorphIteration).BeginInit();
            ((System.ComponentModel.ISupportInitialize)NumPadMorphKeranalWidth).BeginInit();
            TblPnlRotationAngle.SuspendLayout();
            TblPnlBottom.SuspendLayout();
            GrpRoiData.SuspendLayout();
            TblPnlRoiOcrData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numPadOCRExpected).BeginInit();
            pnlBtnAndAdavancedBarcode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)TxtExpectedThr).BeginInit();
            GrpBlobFilter.SuspendLayout();
            TblPnlBlobFil.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumPadMaxWidth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)NumPadMinWidth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)NumPadMinHeight).BeginInit();
            ((System.ComponentModel.ISupportInitialize)NumPadMaxHeight).BeginInit();
            SuspendLayout();
            // 
            // TblPNlMain
            // 
            TblPNlMain.ColumnCount = 1;
            TblPNlMain.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TblPNlMain.Controls.Add(grpImgThresold, 0, 5);
            TblPNlMain.Controls.Add(GrpBoxSegMentMode, 0, 0);
            TblPNlMain.Controls.Add(GrpBoxMorph, 0, 4);
            TblPNlMain.Controls.Add(TblPnlRotationAngle, 0, 3);
            TblPNlMain.Controls.Add(TblPnlBottom, 0, 7);
            TblPNlMain.Controls.Add(GrpRoiData, 0, 1);
            TblPNlMain.Controls.Add(GrpBlobFilter, 0, 2);
            TblPNlMain.Controls.Add(pzPreview, 0, 6);
            TblPNlMain.Dock = DockStyle.Fill;
            TblPNlMain.Location = new Point(0, 0);
            TblPNlMain.Name = "TblPNlMain";
            TblPNlMain.RowCount = 6;
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 78F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 241F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 102F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 49F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 113F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 161F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 116F));
            TblPNlMain.RowStyles.Add(new RowStyle(SizeType.Absolute, 8F));
            TblPNlMain.Size = new Size(597, 915);
            TblPNlMain.TabIndex = 0;
            // 
            // grpImgThresold
            // 
            grpImgThresold.Controls.Add(tableLayoutPanel3);
            grpImgThresold.Dock = DockStyle.Fill;
            grpImgThresold.Font = new Font("Calibri", 11F, FontStyle.Bold);
            grpImgThresold.Location = new Point(3, 586);
            grpImgThresold.Name = "grpImgThresold";
            grpImgThresold.Size = new Size(591, 155);
            grpImgThresold.TabIndex = 10;
            grpImgThresold.TabStop = false;
            grpImgThresold.Text = "Thresold Operation";
            grpImgThresold.UseCompatibleTextRendering = true;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 179F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel3.Controls.Add(chkEnableThresholding, 0, 0);
            tableLayoutPanel3.Controls.Add(lblThresoldingValue, 0, 1);
            tableLayoutPanel3.Controls.Add(trckBarThreshold, 1, 1);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(3, 26);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 26.984127F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 73.01588F));
            tableLayoutPanel3.Size = new Size(585, 126);
            tableLayoutPanel3.TabIndex = 1;
            // 
            // chkEnableThresholding
            // 
            chkEnableThresholding.AutoSize = true;
            tableLayoutPanel3.SetColumnSpan(chkEnableThresholding, 2);
            chkEnableThresholding.Dock = DockStyle.Fill;
            chkEnableThresholding.Location = new Point(3, 3);
            chkEnableThresholding.Name = "chkEnableThresholding";
            chkEnableThresholding.Size = new Size(579, 28);
            chkEnableThresholding.TabIndex = 0;
            chkEnableThresholding.Text = "Enable Thresholding";
            chkEnableThresholding.UseVisualStyleBackColor = true;
            chkEnableThresholding.CheckedChanged += ChkEnableThresholding_CheckedChanged;
            // 
            // lblThresoldingValue
            // 
            lblThresoldingValue.AutoSize = true;
            lblThresoldingValue.Dock = DockStyle.Fill;
            lblThresoldingValue.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblThresoldingValue.Location = new Point(3, 37);
            lblThresoldingValue.Margin = new Padding(3);
            lblThresoldingValue.Name = "lblThresoldingValue";
            lblThresoldingValue.Size = new Size(173, 86);
            lblThresoldingValue.TabIndex = 16;
            lblThresoldingValue.Text = "Thresolding Amount:";
            lblThresoldingValue.TextAlign = ContentAlignment.MiddleLeft;
            lblThresoldingValue.UseCompatibleTextRendering = true;
            // 
            // trckBarThreshold
            // 
            trckBarThreshold.BackColor = Color.Transparent;
            trckBarThreshold.ConversionAbsVal = 2475D;
            trckBarThreshold.ConversionDivFact = 17D;
            trckBarThreshold.Dock = DockStyle.Fill;
            trckBarThreshold.Inverted = false;
            trckBarThreshold.IsRoundOfValue = true;
            trckBarThreshold.LargeChange = 5D;
            trckBarThreshold.Location = new Point(182, 37);
            trckBarThreshold.Maximum = 255D;
            trckBarThreshold.Minimum = 0D;
            trckBarThreshold.MinMaxTextColor = Color.Gray;
            trckBarThreshold.Name = "trckBarThreshold";
            trckBarThreshold.ShowConverSion = true;
            trckBarThreshold.Size = new Size(400, 86);
            trckBarThreshold.SmallChange = 1D;
            trckBarThreshold.TabIndex = 15;
            trckBarThreshold.Theme = ModernTheme.Custom;
            trckBarThreshold.ThumbBorderColor = Color.FromArgb(218, 37, 29);
            trckBarThreshold.ThumbColor = Color.White;
            trckBarThreshold.TrackEmptyColor = Color.FromArgb(220, 220, 225);
            trckBarThreshold.TrackerGradientEnd = Color.FromArgb(255, 87, 34);
            trckBarThreshold.TrackerGradientStart = Color.FromArgb(218, 37, 29);
            trckBarThreshold.Unit = "";
            trckBarThreshold.Value = 0D;
            trckBarThreshold.ValueTextColor = Color.FromArgb(40, 40, 40);
            trckBarThreshold.ValueChanged += ModernTrackBar1_ValueChanged;
            // 
            // GrpBoxSegMentMode
            // 
            GrpBoxSegMentMode.Controls.Add(tableLayoutPanel2);
            GrpBoxSegMentMode.Dock = DockStyle.Fill;
            GrpBoxSegMentMode.Font = new Font("Calibri", 11F, FontStyle.Bold);
            GrpBoxSegMentMode.Location = new Point(3, 3);
            GrpBoxSegMentMode.Name = "GrpBoxSegMentMode";
            GrpBoxSegMentMode.Size = new Size(591, 72);
            GrpBoxSegMentMode.TabIndex = 8;
            GrpBoxSegMentMode.TabStop = false;
            GrpBoxSegMentMode.Text = "Segmentation Mode";
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 298F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Controls.Add(CmbSegments, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 26);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Size = new Size(585, 43);
            tableLayoutPanel2.TabIndex = 6;
            // 
            // CmbSegments
            // 
            CmbSegments.Dock = DockStyle.Fill;
            CmbSegments.Font = new Font("Calibri", 11F, FontStyle.Bold);
            CmbSegments.FormattingEnabled = true;
            CmbSegments.Location = new Point(3, 8);
            CmbSegments.Margin = new Padding(3, 8, 3, 3);
            CmbSegments.Name = "CmbSegments";
            CmbSegments.Size = new Size(292, 30);
            CmbSegments.TabIndex = 3;
            CmbSegments.SelectedIndexChanged += CmbSegments_SelectedIndexChanged;
            // 
            // GrpBoxMorph
            // 
            GrpBoxMorph.Controls.Add(tableLayoutPanel1);
            GrpBoxMorph.Dock = DockStyle.Fill;
            GrpBoxMorph.Font = new Font("Calibri", 11F, FontStyle.Bold);
            GrpBoxMorph.Location = new Point(3, 473);
            GrpBoxMorph.Name = "GrpBoxMorph";
            GrpBoxMorph.Size = new Size(591, 107);
            GrpBoxMorph.TabIndex = 6;
            GrpBoxMorph.TabStop = false;
            GrpBoxMorph.Text = "Morphological operations";
            GrpBoxMorph.UseCompatibleTextRendering = true;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 7;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 124F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 54F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 148F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 66F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 55F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(tblPnlMorphMode, 1, 0);
            tableLayoutPanel1.Controls.Add(NumPadMorphIteration, 3, 1);
            tableLayoutPanel1.Controls.Add(lblMorphMode, 0, 0);
            tableLayoutPanel1.Controls.Add(lblMorphIternation, 2, 1);
            tableLayoutPanel1.Controls.Add(lblMorphKeranalWidth, 0, 1);
            tableLayoutPanel1.Controls.Add(NumPadMorphKeranalWidth, 1, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(3, 26);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 52.85714F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 47.14286F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(585, 78);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // tblPnlMorphMode
            // 
            tblPnlMorphMode.ColumnCount = 3;
            tableLayoutPanel1.SetColumnSpan(tblPnlMorphMode, 4);
            tblPnlMorphMode.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 31.8518581F));
            tblPnlMorphMode.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 37.7777824F));
            tblPnlMorphMode.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30.370369F));
            tblPnlMorphMode.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tblPnlMorphMode.Controls.Add(rdMorphModeDilate, 2, 0);
            tblPnlMorphMode.Controls.Add(rdMorphModeErode, 1, 0);
            tblPnlMorphMode.Controls.Add(rdMorphModeNone, 0, 0);
            tblPnlMorphMode.Dock = DockStyle.Fill;
            tblPnlMorphMode.Location = new Point(127, 3);
            tblPnlMorphMode.Name = "tblPnlMorphMode";
            tblPnlMorphMode.RowCount = 1;
            tblPnlMorphMode.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tblPnlMorphMode.Size = new Size(317, 35);
            tblPnlMorphMode.TabIndex = 14;
            // 
            // rdMorphModeDilate
            // 
            rdMorphModeDilate.AutoSize = true;
            rdMorphModeDilate.Dock = DockStyle.Fill;
            rdMorphModeDilate.Font = new Font("Calibri", 11F, FontStyle.Bold);
            rdMorphModeDilate.Location = new Point(222, 3);
            rdMorphModeDilate.Name = "rdMorphModeDilate";
            rdMorphModeDilate.Size = new Size(92, 29);
            rdMorphModeDilate.TabIndex = 2;
            rdMorphModeDilate.TabStop = true;
            rdMorphModeDilate.Text = "Dilate";
            rdMorphModeDilate.UseCompatibleTextRendering = true;
            rdMorphModeDilate.UseVisualStyleBackColor = true;
            rdMorphModeDilate.CheckedChanged += RdMorphModeDilate_CheckedChanged;
            rdMorphModeDilate.Click += RdMorphModeDilate_Click;
            // 
            // rdMorphModeErode
            // 
            rdMorphModeErode.AutoSize = true;
            rdMorphModeErode.Dock = DockStyle.Fill;
            rdMorphModeErode.Font = new Font("Calibri", 11F, FontStyle.Bold);
            rdMorphModeErode.Location = new Point(103, 3);
            rdMorphModeErode.Name = "rdMorphModeErode";
            rdMorphModeErode.Size = new Size(113, 29);
            rdMorphModeErode.TabIndex = 1;
            rdMorphModeErode.TabStop = true;
            rdMorphModeErode.Text = "Erode";
            rdMorphModeErode.UseCompatibleTextRendering = true;
            rdMorphModeErode.UseVisualStyleBackColor = true;
            rdMorphModeErode.Click += RdMorphModeErode_Click;
            // 
            // rdMorphModeNone
            // 
            rdMorphModeNone.AutoSize = true;
            rdMorphModeNone.Dock = DockStyle.Fill;
            rdMorphModeNone.Font = new Font("Calibri", 11F, FontStyle.Bold);
            rdMorphModeNone.Location = new Point(3, 3);
            rdMorphModeNone.Name = "rdMorphModeNone";
            rdMorphModeNone.Size = new Size(94, 29);
            rdMorphModeNone.TabIndex = 0;
            rdMorphModeNone.TabStop = true;
            rdMorphModeNone.Text = "None";
            rdMorphModeNone.UseCompatibleTextRendering = true;
            rdMorphModeNone.UseVisualStyleBackColor = true;
            rdMorphModeNone.Click += RdMorphModeNone_Click;
            // 
            // NumPadMorphIteration
            // 
            NumPadMorphIteration.Dock = DockStyle.Fill;
            NumPadMorphIteration.Enabled = false;
            NumPadMorphIteration.Font = new Font("Calibri", 11F, FontStyle.Bold);
            NumPadMorphIteration.Location = new Point(329, 44);
            NumPadMorphIteration.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            NumPadMorphIteration.Name = "NumPadMorphIteration";
            NumPadMorphIteration.Size = new Size(60, 30);
            NumPadMorphIteration.TabIndex = 11;
            // 
            // lblMorphMode
            // 
            lblMorphMode.AutoSize = true;
            lblMorphMode.Dock = DockStyle.Fill;
            lblMorphMode.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblMorphMode.Location = new Point(3, 3);
            lblMorphMode.Margin = new Padding(3);
            lblMorphMode.Name = "lblMorphMode";
            lblMorphMode.Size = new Size(118, 35);
            lblMorphMode.TabIndex = 12;
            lblMorphMode.Text = "Morph Mode: ";
            lblMorphMode.TextAlign = ContentAlignment.MiddleLeft;
            lblMorphMode.UseCompatibleTextRendering = true;
            // 
            // lblMorphIternation
            // 
            lblMorphIternation.AutoSize = true;
            lblMorphIternation.Dock = DockStyle.Fill;
            lblMorphIternation.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblMorphIternation.Location = new Point(181, 44);
            lblMorphIternation.Margin = new Padding(3);
            lblMorphIternation.Name = "lblMorphIternation";
            lblMorphIternation.Size = new Size(142, 31);
            lblMorphIternation.TabIndex = 10;
            lblMorphIternation.Text = "Morph Iteration :";
            lblMorphIternation.TextAlign = ContentAlignment.MiddleLeft;
            lblMorphIternation.UseCompatibleTextRendering = true;
            // 
            // lblMorphKeranalWidth
            // 
            lblMorphKeranalWidth.AutoSize = true;
            lblMorphKeranalWidth.Dock = DockStyle.Fill;
            lblMorphKeranalWidth.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblMorphKeranalWidth.Location = new Point(3, 44);
            lblMorphKeranalWidth.Margin = new Padding(3);
            lblMorphKeranalWidth.Name = "lblMorphKeranalWidth";
            lblMorphKeranalWidth.Size = new Size(118, 31);
            lblMorphKeranalWidth.TabIndex = 0;
            lblMorphKeranalWidth.Text = "Kernel Size :";
            lblMorphKeranalWidth.TextAlign = ContentAlignment.MiddleLeft;
            lblMorphKeranalWidth.UseCompatibleTextRendering = true;
            // 
            // NumPadMorphKeranalWidth
            // 
            NumPadMorphKeranalWidth.Dock = DockStyle.Fill;
            NumPadMorphKeranalWidth.Font = new Font("Calibri", 11F, FontStyle.Bold);
            NumPadMorphKeranalWidth.Location = new Point(127, 44);
            NumPadMorphKeranalWidth.Maximum = new decimal(new int[] { 50, 0, 0, 0 });
            NumPadMorphKeranalWidth.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            NumPadMorphKeranalWidth.Name = "NumPadMorphKeranalWidth";
            NumPadMorphKeranalWidth.Size = new Size(48, 30);
            NumPadMorphKeranalWidth.TabIndex = 6;
            NumPadMorphKeranalWidth.Value = new decimal(new int[] { 1, 0, 0, 0 });
            NumPadMorphKeranalWidth.ValueChanged += NumPadMorphKeranalWidth_ValueChanged;
            // 
            // TblPnlRotationAngle
            // 
            TblPnlRotationAngle.ColumnCount = 5;
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 95F));
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 183F));
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 9F));
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 149F));
            TblPnlRotationAngle.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TblPnlRotationAngle.Controls.Add(LblRotationAngle, 0, 0);
            TblPnlRotationAngle.Controls.Add(cmbRotationAngle, 1, 0);
            TblPnlRotationAngle.Controls.Add(chkAnchor, 3, 0);
            TblPnlRotationAngle.Controls.Add(chkIsUseReferance, 4, 0);
            TblPnlRotationAngle.Dock = DockStyle.Fill;
            TblPnlRotationAngle.Location = new Point(3, 424);
            TblPnlRotationAngle.Name = "TblPnlRotationAngle";
            TblPnlRotationAngle.RowCount = 1;
            TblPnlRotationAngle.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            TblPnlRotationAngle.Size = new Size(591, 43);
            TblPnlRotationAngle.TabIndex = 5;
            // 
            // LblRotationAngle
            // 
            LblRotationAngle.AutoSize = true;
            LblRotationAngle.Dock = DockStyle.Fill;
            LblRotationAngle.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblRotationAngle.Location = new Point(3, 3);
            LblRotationAngle.Margin = new Padding(3);
            LblRotationAngle.Name = "LblRotationAngle";
            LblRotationAngle.Size = new Size(89, 37);
            LblRotationAngle.TabIndex = 2;
            LblRotationAngle.Text = " Rotation : ";
            LblRotationAngle.TextAlign = ContentAlignment.MiddleLeft;
            LblRotationAngle.UseCompatibleTextRendering = true;
            // 
            // cmbRotationAngle
            // 
            cmbRotationAngle.Font = new Font("Calibri", 11F, FontStyle.Bold);
            cmbRotationAngle.FormattingEnabled = true;
            cmbRotationAngle.Location = new Point(98, 8);
            cmbRotationAngle.Margin = new Padding(3, 8, 3, 3);
            cmbRotationAngle.Name = "cmbRotationAngle";
            cmbRotationAngle.Size = new Size(177, 30);
            cmbRotationAngle.TabIndex = 3;
            cmbRotationAngle.SelectedIndexChanged += CmbRotationAngle_SelectedIndexChanged;
            cmbRotationAngle.Validating += CmbRotationAngle_Validating;
            // 
            // chkAnchor
            // 
            chkAnchor.AutoSize = true;
            chkAnchor.Dock = DockStyle.Fill;
            chkAnchor.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkAnchor.Location = new Point(290, 3);
            chkAnchor.Name = "chkAnchor";
            chkAnchor.Size = new Size(143, 37);
            chkAnchor.TabIndex = 9;
            chkAnchor.Text = "Enable Anchor";
            chkAnchor.UseCompatibleTextRendering = true;
            chkAnchor.UseVisualStyleBackColor = true;
            chkAnchor.CheckedChanged += ChkAnchor_CheckedChanged;
            // 
            // chkIsUseReferance
            // 
            chkIsUseReferance.Dock = DockStyle.Fill;
            chkIsUseReferance.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkIsUseReferance.Location = new Point(439, 3);
            chkIsUseReferance.Name = "chkIsUseReferance";
            chkIsUseReferance.Size = new Size(149, 37);
            chkIsUseReferance.TabIndex = 10;
            chkIsUseReferance.Text = "Use Ref. Roi";
            chkIsUseReferance.CheckedChanged += ChkIsUseReferance_CheckedChanged;
            // 
            // TblPnlBottom
            // 
            TblPnlBottom.ColumnCount = 4;
            TblPnlBottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            TblPnlBottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 163F));
            TblPnlBottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 155F));
            TblPnlBottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            TblPnlBottom.Controls.Add(BtnDecodeROI, 1, 0);
            TblPnlBottom.Controls.Add(btnCharResult, 2, 0);
            TblPnlBottom.Dock = DockStyle.Fill;
            TblPnlBottom.Location = new Point(3, 863);
            TblPnlBottom.Name = "TblPnlBottom";
            TblPnlBottom.RowCount = 1;
            TblPnlBottom.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            TblPnlBottom.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            TblPnlBottom.Size = new Size(591, 49);
            TblPnlBottom.TabIndex = 3;
            // 
            // BtnDecodeROI
            // 
            BtnDecodeROI.BackColor = Color.Red;
            BtnDecodeROI.Dock = DockStyle.Fill;
            BtnDecodeROI.Font = new Font("Calibri", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnDecodeROI.ForeColor = Color.Transparent;
            BtnDecodeROI.Image = (Image)resources.GetObject("BtnDecodeROI.Image");
            BtnDecodeROI.ImageAlign = ContentAlignment.MiddleLeft;
            BtnDecodeROI.Location = new Point(139, 3);
            BtnDecodeROI.Name = "BtnDecodeROI";
            BtnDecodeROI.Padding = new Padding(10, 0, 0, 0);
            BtnDecodeROI.Size = new Size(157, 43);
            BtnDecodeROI.TabIndex = 2;
            BtnDecodeROI.Text = "Decode ROI";
            BtnDecodeROI.TextImageRelation = TextImageRelation.ImageBeforeText;
            BtnDecodeROI.UseCompatibleTextRendering = true;
            BtnDecodeROI.UseVisualStyleBackColor = false;
            BtnDecodeROI.Click += BtnDecodeROI_Click;
            // 
            // btnCharResult
            // 
            btnCharResult.BackColor = Color.Red;
            btnCharResult.Dock = DockStyle.Fill;
            btnCharResult.Font = new Font("Calibri", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCharResult.ForeColor = Color.Transparent;
            btnCharResult.Image = (Image)resources.GetObject("btnCharResult.Image");
            btnCharResult.ImageAlign = ContentAlignment.MiddleLeft;
            btnCharResult.Location = new Point(302, 3);
            btnCharResult.Name = "btnCharResult";
            btnCharResult.Padding = new Padding(10, 0, 0, 0);
            btnCharResult.Size = new Size(149, 43);
            btnCharResult.TabIndex = 3;
            btnCharResult.Text = "Char Result";
            btnCharResult.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCharResult.UseCompatibleTextRendering = true;
            btnCharResult.UseVisualStyleBackColor = false;
            btnCharResult.Click += BtnCharResult_Click;
            // 
            // GrpRoiData
            // 
            GrpRoiData.BackColor = Color.Transparent;
            GrpRoiData.Controls.Add(TblPnlRoiOcrData);
            GrpRoiData.Dock = DockStyle.Fill;
            GrpRoiData.Font = new Font("Calibri", 11F, FontStyle.Bold);
            GrpRoiData.Location = new Point(3, 81);
            GrpRoiData.Name = "GrpRoiData";
            GrpRoiData.Size = new Size(591, 235);
            GrpRoiData.TabIndex = 0;
            GrpRoiData.TabStop = false;
            GrpRoiData.Text = "ROI Name";
            GrpRoiData.UseCompatibleTextRendering = true;
            // 
            // TblPnlRoiOcrData
            // 
            TblPnlRoiOcrData.ColumnCount = 5;
            TblPnlRoiOcrData.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 93F));
            TblPnlRoiOcrData.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TblPnlRoiOcrData.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 115F));
            TblPnlRoiOcrData.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 67F));
            TblPnlRoiOcrData.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90F));
            TblPnlRoiOcrData.Controls.Add(numPadOCRExpected, 3, 2);
            TblPnlRoiOcrData.Controls.Add(lblOcrCount, 2, 2);
            TblPnlRoiOcrData.Controls.Add(lblOverAllResult, 4, 1);
            TblPnlRoiOcrData.Controls.Add(LblDecoded, 0, 0);
            TblPnlRoiOcrData.Controls.Add(LblDecodedThr, 3, 0);
            TblPnlRoiOcrData.Controls.Add(LblDecodedThresold, 2, 0);
            TblPnlRoiOcrData.Controls.Add(chkDoOCR, 4, 0);
            TblPnlRoiOcrData.Controls.Add(pnlBtnAndAdavancedBarcode, 1, 3);
            TblPnlRoiOcrData.Controls.Add(TxtDecoded, 1, 0);
            TblPnlRoiOcrData.Controls.Add(lblOcrCharCount, 2, 3);
            TblPnlRoiOcrData.Controls.Add(LblExpected, 0, 1);
            TblPnlRoiOcrData.Controls.Add(TxtExpected, 1, 1);
            TblPnlRoiOcrData.Controls.Add(LblExpectedThresold, 2, 1);
            TblPnlRoiOcrData.Controls.Add(TxtExpectedThr, 3, 1);
            TblPnlRoiOcrData.Dock = DockStyle.Fill;
            TblPnlRoiOcrData.Location = new Point(3, 26);
            TblPnlRoiOcrData.Name = "TblPnlRoiOcrData";
            TblPnlRoiOcrData.RowCount = 4;
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Percent, 50.88757F));
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Percent, 24.260355F));
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Percent, 24.8520718F));
            TblPnlRoiOcrData.RowStyles.Add(new RowStyle(SizeType.Absolute, 32F));
            TblPnlRoiOcrData.Size = new Size(585, 206);
            TblPnlRoiOcrData.TabIndex = 0;
            // 
            // numPadOCRExpected
            // 
            numPadOCRExpected.BorderStyle = BorderStyle.FixedSingle;
            numPadOCRExpected.Dock = DockStyle.Fill;
            numPadOCRExpected.Font = new Font("Calibri", 11F, FontStyle.Bold);
            numPadOCRExpected.Location = new Point(431, 133);
            numPadOCRExpected.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            numPadOCRExpected.Name = "numPadOCRExpected";
            numPadOCRExpected.Size = new Size(61, 30);
            numPadOCRExpected.TabIndex = 13;
            numPadOCRExpected.ValueChanged += NumPadOCRExpected_ValueChanged;
            // 
            // lblOcrCount
            // 
            lblOcrCount.AutoSize = true;
            lblOcrCount.Dock = DockStyle.Fill;
            lblOcrCount.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblOcrCount.Location = new Point(316, 133);
            lblOcrCount.Margin = new Padding(3);
            lblOcrCount.Name = "lblOcrCount";
            lblOcrCount.Size = new Size(109, 37);
            lblOcrCount.TabIndex = 12;
            lblOcrCount.Text = "Expected Char Count: ";
            lblOcrCount.TextAlign = ContentAlignment.MiddleLeft;
            lblOcrCount.UseCompatibleTextRendering = true;
            // 
            // lblOverAllResult
            // 
            lblOverAllResult.AutoSize = true;
            lblOverAllResult.Dock = DockStyle.Fill;
            lblOverAllResult.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblOverAllResult.Location = new Point(498, 91);
            lblOverAllResult.Margin = new Padding(3);
            lblOverAllResult.Name = "lblOverAllResult";
            lblOverAllResult.Size = new Size(84, 36);
            lblOverAllResult.TabIndex = 9;
            lblOverAllResult.Text = "Pass/Fail";
            lblOverAllResult.TextAlign = ContentAlignment.MiddleLeft;
            lblOverAllResult.UseCompatibleTextRendering = true;
            // 
            // LblDecoded
            // 
            LblDecoded.AutoSize = true;
            LblDecoded.Dock = DockStyle.Fill;
            LblDecoded.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblDecoded.Location = new Point(3, 3);
            LblDecoded.Margin = new Padding(3);
            LblDecoded.Name = "LblDecoded";
            LblDecoded.Size = new Size(87, 82);
            LblDecoded.TabIndex = 1;
            LblDecoded.Text = "Decoded : ";
            LblDecoded.TextAlign = ContentAlignment.MiddleLeft;
            LblDecoded.UseCompatibleTextRendering = true;
            // 
            // LblDecodedThr
            // 
            LblDecodedThr.BackColor = Color.Gainsboro;
            LblDecodedThr.BorderStyle = BorderStyle.FixedSingle;
            LblDecodedThr.Dock = DockStyle.Fill;
            LblDecodedThr.FlatStyle = FlatStyle.Flat;
            LblDecodedThr.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblDecodedThr.Location = new Point(431, 25);
            LblDecodedThr.Margin = new Padding(3, 25, 3, 25);
            LblDecodedThr.Name = "LblDecodedThr";
            LblDecodedThr.Padding = new Padding(2, 0, 0, 0);
            LblDecodedThr.Size = new Size(61, 38);
            LblDecodedThr.TabIndex = 6;
            LblDecodedThr.Text = "0.8";
            LblDecodedThr.TextAlign = ContentAlignment.MiddleLeft;
            LblDecodedThr.UseCompatibleTextRendering = true;
            // 
            // LblDecodedThresold
            // 
            LblDecodedThresold.AutoSize = true;
            LblDecodedThresold.Dock = DockStyle.Fill;
            LblDecodedThresold.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblDecodedThresold.Location = new Point(316, 3);
            LblDecodedThresold.Margin = new Padding(3);
            LblDecodedThresold.Name = "LblDecodedThresold";
            LblDecodedThresold.Size = new Size(109, 82);
            LblDecodedThresold.TabIndex = 5;
            LblDecodedThresold.Text = "Result Score: ";
            LblDecodedThresold.TextAlign = ContentAlignment.MiddleLeft;
            LblDecodedThresold.UseCompatibleTextRendering = true;
            // 
            // chkDoOCR
            // 
            chkDoOCR.AutoSize = true;
            chkDoOCR.Dock = DockStyle.Fill;
            chkDoOCR.Font = new Font("Calibri", 11F, FontStyle.Bold);
            chkDoOCR.Location = new Point(498, 3);
            chkDoOCR.Name = "chkDoOCR";
            chkDoOCR.Size = new Size(84, 82);
            chkDoOCR.TabIndex = 8;
            chkDoOCR.Text = "OCR Mode";
            chkDoOCR.UseCompatibleTextRendering = true;
            chkDoOCR.UseVisualStyleBackColor = true;
            chkDoOCR.CheckedChanged += chkDoOCR_CheckedChanged;
            // 
            // pnlBtnAndAdavancedBarcode
            // 
            pnlBtnAndAdavancedBarcode.Controls.Add(btnCopyDecodedText);
            pnlBtnAndAdavancedBarcode.Dock = DockStyle.Fill;
            pnlBtnAndAdavancedBarcode.Location = new Point(93, 173);
            pnlBtnAndAdavancedBarcode.Margin = new Padding(0);
            pnlBtnAndAdavancedBarcode.Name = "pnlBtnAndAdavancedBarcode";
            pnlBtnAndAdavancedBarcode.Size = new Size(220, 33);
            pnlBtnAndAdavancedBarcode.TabIndex = 11;
            // 
            // btnCopyDecodedText
            // 
            btnCopyDecodedText.BackColor = Color.Red;
            btnCopyDecodedText.Dock = DockStyle.Fill;
            btnCopyDecodedText.Font = new Font("Calibri", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCopyDecodedText.ForeColor = Color.Transparent;
            btnCopyDecodedText.ImageAlign = ContentAlignment.MiddleLeft;
            btnCopyDecodedText.Location = new Point(0, 0);
            btnCopyDecodedText.Margin = new Padding(10, 0, 10, 0);
            btnCopyDecodedText.Name = "btnCopyDecodedText";
            btnCopyDecodedText.Padding = new Padding(10, 0, 0, 0);
            btnCopyDecodedText.Size = new Size(220, 33);
            btnCopyDecodedText.TabIndex = 10;
            btnCopyDecodedText.Text = "Copy Decoded Text";
            btnCopyDecodedText.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCopyDecodedText.UseCompatibleTextRendering = true;
            btnCopyDecodedText.UseVisualStyleBackColor = false;
            btnCopyDecodedText.Visible = false;
            btnCopyDecodedText.Click += BtnCopyDecodedText_Click;
            // 
            // TxtDecoded
            // 
            TxtDecoded.BackColor = Color.Gainsboro;
            TxtDecoded.BorderStyle = BorderStyle.FixedSingle;
            TxtDecoded.Dock = DockStyle.Fill;
            TxtDecoded.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TxtDecoded.Location = new Point(96, 3);
            TxtDecoded.Multiline = true;
            TxtDecoded.Name = "TxtDecoded";
            TxtDecoded.ReadOnly = true;
            TxtDecoded.Size = new Size(214, 82);
            TxtDecoded.TabIndex = 3;
            // 
            // lblOcrCharCount
            // 
            lblOcrCharCount.AutoSize = true;
            TblPnlRoiOcrData.SetColumnSpan(lblOcrCharCount, 3);
            lblOcrCharCount.Dock = DockStyle.Fill;
            lblOcrCharCount.Font = new Font("Calibri", 11F, FontStyle.Bold);
            lblOcrCharCount.ForeColor = Color.Maroon;
            lblOcrCharCount.Location = new Point(316, 176);
            lblOcrCharCount.Margin = new Padding(3);
            lblOcrCharCount.Name = "lblOcrCharCount";
            lblOcrCharCount.Size = new Size(266, 27);
            lblOcrCharCount.TabIndex = 14;
            lblOcrCharCount.Text = "Scan Char Count : ";
            lblOcrCharCount.TextAlign = ContentAlignment.MiddleLeft;
            lblOcrCharCount.UseCompatibleTextRendering = true;
            // 
            // LblExpected
            // 
            LblExpected.AutoSize = true;
            LblExpected.Dock = DockStyle.Fill;
            LblExpected.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblExpected.Location = new Point(3, 91);
            LblExpected.Margin = new Padding(3);
            LblExpected.Name = "LblExpected";
            LblExpected.Size = new Size(87, 36);
            LblExpected.TabIndex = 0;
            LblExpected.Text = "Expected : ";
            LblExpected.TextAlign = ContentAlignment.MiddleLeft;
            LblExpected.UseCompatibleTextRendering = true;
            // 
            // TxtExpected
            // 
            TxtExpected.BorderStyle = BorderStyle.FixedSingle;
            TxtExpected.Dock = DockStyle.Fill;
            TxtExpected.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TxtExpected.Location = new Point(96, 91);
            TxtExpected.Multiline = true;
            TxtExpected.Name = "TxtExpected";
            TblPnlRoiOcrData.SetRowSpan(TxtExpected, 2);
            TxtExpected.Size = new Size(214, 79);
            TxtExpected.TabIndex = 2;
            TxtExpected.TextChanged += TxtExpected_TextChanged;
            TxtExpected.KeyDown += TxtExpected_KeyDown;
            // 
            // LblExpectedThresold
            // 
            LblExpectedThresold.AutoSize = true;
            LblExpectedThresold.Dock = DockStyle.Fill;
            LblExpectedThresold.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblExpectedThresold.Location = new Point(316, 91);
            LblExpectedThresold.Margin = new Padding(3);
            LblExpectedThresold.Name = "LblExpectedThresold";
            LblExpectedThresold.Size = new Size(109, 36);
            LblExpectedThresold.TabIndex = 4;
            LblExpectedThresold.Text = "Minimum Score :";
            LblExpectedThresold.TextAlign = ContentAlignment.MiddleLeft;
            LblExpectedThresold.UseCompatibleTextRendering = true;
            // 
            // TxtExpectedThr
            // 
            TxtExpectedThr.BorderStyle = BorderStyle.FixedSingle;
            TxtExpectedThr.DecimalPlaces = 2;
            TxtExpectedThr.Dock = DockStyle.Fill;
            TxtExpectedThr.Font = new Font("Calibri", 11F, FontStyle.Bold);
            TxtExpectedThr.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            TxtExpectedThr.Location = new Point(431, 91);
            TxtExpectedThr.Maximum = new decimal(new int[] { 1, 0, 0, 0 });
            TxtExpectedThr.Name = "TxtExpectedThr";
            TxtExpectedThr.Size = new Size(61, 30);
            TxtExpectedThr.TabIndex = 7;
            TxtExpectedThr.Value = new decimal(new int[] { 5, 0, 0, 65536 });
            TxtExpectedThr.ValueChanged += TxtExpectedThr_ValueChanged;
            // 
            // GrpBlobFilter
            // 
            GrpBlobFilter.Controls.Add(TblPnlBlobFil);
            GrpBlobFilter.Dock = DockStyle.Fill;
            GrpBlobFilter.Font = new Font("Calibri", 11F, FontStyle.Bold);
            GrpBlobFilter.Location = new Point(3, 322);
            GrpBlobFilter.Name = "GrpBlobFilter";
            GrpBlobFilter.Size = new Size(591, 96);
            GrpBlobFilter.TabIndex = 4;
            GrpBlobFilter.TabStop = false;
            GrpBlobFilter.Text = "Blob Filter";
            GrpBlobFilter.UseCompatibleTextRendering = true;
            // 
            // TblPnlBlobFil
            // 
            TblPnlBlobFil.ColumnCount = 5;
            TblPnlBlobFil.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110F));
            TblPnlBlobFil.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 76F));
            TblPnlBlobFil.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 129F));
            TblPnlBlobFil.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 76F));
            TblPnlBlobFil.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TblPnlBlobFil.Controls.Add(NumPadMaxWidth, 3, 0);
            TblPnlBlobFil.Controls.Add(LblBlobMaxWidth, 2, 0);
            TblPnlBlobFil.Controls.Add(LblBlobMinWidth, 0, 0);
            TblPnlBlobFil.Controls.Add(LblBlobMinHeight, 0, 1);
            TblPnlBlobFil.Controls.Add(LblBlobMaxHeight, 2, 1);
            TblPnlBlobFil.Controls.Add(NumPadMinWidth, 1, 0);
            TblPnlBlobFil.Controls.Add(NumPadMinHeight, 1, 1);
            TblPnlBlobFil.Controls.Add(NumPadMaxHeight, 3, 1);
            TblPnlBlobFil.Dock = DockStyle.Fill;
            TblPnlBlobFil.Location = new Point(3, 26);
            TblPnlBlobFil.Name = "TblPnlBlobFil";
            TblPnlBlobFil.RowCount = 2;
            TblPnlBlobFil.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            TblPnlBlobFil.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            TblPnlBlobFil.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            TblPnlBlobFil.Size = new Size(585, 67);
            TblPnlBlobFil.TabIndex = 1;
            // 
            // NumPadMaxWidth
            // 
            NumPadMaxWidth.Dock = DockStyle.Fill;
            NumPadMaxWidth.Font = new Font("Calibri", 11F, FontStyle.Bold);
            NumPadMaxWidth.Location = new Point(318, 3);
            NumPadMaxWidth.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            NumPadMaxWidth.Name = "NumPadMaxWidth";
            NumPadMaxWidth.Size = new Size(70, 30);
            NumPadMaxWidth.TabIndex = 8;
            NumPadMaxWidth.ValueChanged += NumPadMaxWidth_ValueChanged;
            // 
            // LblBlobMaxWidth
            // 
            LblBlobMaxWidth.AutoSize = true;
            LblBlobMaxWidth.Dock = DockStyle.Fill;
            LblBlobMaxWidth.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblBlobMaxWidth.Location = new Point(189, 3);
            LblBlobMaxWidth.Margin = new Padding(3);
            LblBlobMaxWidth.Name = "LblBlobMaxWidth";
            LblBlobMaxWidth.Size = new Size(123, 27);
            LblBlobMaxWidth.TabIndex = 4;
            LblBlobMaxWidth.Text = "Max Width :";
            LblBlobMaxWidth.TextAlign = ContentAlignment.MiddleLeft;
            LblBlobMaxWidth.UseCompatibleTextRendering = true;
            // 
            // LblBlobMinWidth
            // 
            LblBlobMinWidth.AutoSize = true;
            LblBlobMinWidth.Dock = DockStyle.Fill;
            LblBlobMinWidth.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblBlobMinWidth.Location = new Point(3, 3);
            LblBlobMinWidth.Margin = new Padding(3);
            LblBlobMinWidth.Name = "LblBlobMinWidth";
            LblBlobMinWidth.Size = new Size(104, 27);
            LblBlobMinWidth.TabIndex = 0;
            LblBlobMinWidth.Text = "Min Width : ";
            LblBlobMinWidth.TextAlign = ContentAlignment.MiddleLeft;
            LblBlobMinWidth.UseCompatibleTextRendering = true;
            // 
            // LblBlobMinHeight
            // 
            LblBlobMinHeight.AutoSize = true;
            LblBlobMinHeight.Dock = DockStyle.Fill;
            LblBlobMinHeight.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblBlobMinHeight.Location = new Point(3, 36);
            LblBlobMinHeight.Margin = new Padding(3);
            LblBlobMinHeight.Name = "LblBlobMinHeight";
            LblBlobMinHeight.Size = new Size(104, 28);
            LblBlobMinHeight.TabIndex = 1;
            LblBlobMinHeight.Text = "Min Height : ";
            LblBlobMinHeight.TextAlign = ContentAlignment.MiddleLeft;
            LblBlobMinHeight.UseCompatibleTextRendering = true;
            // 
            // LblBlobMaxHeight
            // 
            LblBlobMaxHeight.AutoSize = true;
            LblBlobMaxHeight.Dock = DockStyle.Fill;
            LblBlobMaxHeight.Font = new Font("Calibri", 11F, FontStyle.Bold);
            LblBlobMaxHeight.Location = new Point(189, 36);
            LblBlobMaxHeight.Margin = new Padding(3);
            LblBlobMaxHeight.Name = "LblBlobMaxHeight";
            LblBlobMaxHeight.Size = new Size(123, 28);
            LblBlobMaxHeight.TabIndex = 5;
            LblBlobMaxHeight.Text = "Max Height : ";
            LblBlobMaxHeight.TextAlign = ContentAlignment.MiddleLeft;
            LblBlobMaxHeight.UseCompatibleTextRendering = true;
            // 
            // NumPadMinWidth
            // 
            NumPadMinWidth.Dock = DockStyle.Fill;
            NumPadMinWidth.Font = new Font("Calibri", 11F, FontStyle.Bold);
            NumPadMinWidth.Location = new Point(113, 3);
            NumPadMinWidth.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            NumPadMinWidth.Name = "NumPadMinWidth";
            NumPadMinWidth.Size = new Size(70, 30);
            NumPadMinWidth.TabIndex = 6;
            NumPadMinWidth.ValueChanged += NumPadMinWidth_ValueChanged;
            // 
            // NumPadMinHeight
            // 
            NumPadMinHeight.Dock = DockStyle.Fill;
            NumPadMinHeight.Font = new Font("Calibri", 11F, FontStyle.Bold);
            NumPadMinHeight.Location = new Point(113, 36);
            NumPadMinHeight.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            NumPadMinHeight.Name = "NumPadMinHeight";
            NumPadMinHeight.Size = new Size(70, 30);
            NumPadMinHeight.TabIndex = 7;
            NumPadMinHeight.ValueChanged += NumPadMinHeight_ValueChanged;
            // 
            // NumPadMaxHeight
            // 
            NumPadMaxHeight.Dock = DockStyle.Fill;
            NumPadMaxHeight.Font = new Font("Calibri", 11F, FontStyle.Bold);
            NumPadMaxHeight.Location = new Point(318, 36);
            NumPadMaxHeight.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            NumPadMaxHeight.Name = "NumPadMaxHeight";
            NumPadMaxHeight.Size = new Size(70, 30);
            NumPadMaxHeight.TabIndex = 9;
            NumPadMaxHeight.ValueChanged += NumPadMaxHeight_ValueChanged;
            // 
            // pzPreview
            // 
            pzPreview.Dock = DockStyle.Fill;
            pzPreview.Image = null;
            pzPreview.Interpolation = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            pzPreview.Location = new Point(3, 747);
            pzPreview.Name = "pzPreview";
            pzPreview.Size = new Size(591, 110);
            pzPreview.TabIndex = 9;
            // 
            // ROIControl
            // 
            AutoScaleDimensions = new SizeF(120F, 120F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.White;
            BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(TblPNlMain);
            DoubleBuffered = true;
            Font = new Font("Palatino Linotype", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "ROIControl";
            Size = new Size(597, 915);
            TblPNlMain.ResumeLayout(false);
            grpImgThresold.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            GrpBoxSegMentMode.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            GrpBoxMorph.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tblPnlMorphMode.ResumeLayout(false);
            tblPnlMorphMode.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)NumPadMorphIteration).EndInit();
            ((System.ComponentModel.ISupportInitialize)NumPadMorphKeranalWidth).EndInit();
            TblPnlRotationAngle.ResumeLayout(false);
            TblPnlRotationAngle.PerformLayout();
            TblPnlBottom.ResumeLayout(false);
            GrpRoiData.ResumeLayout(false);
            TblPnlRoiOcrData.ResumeLayout(false);
            TblPnlRoiOcrData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numPadOCRExpected).EndInit();
            pnlBtnAndAdavancedBarcode.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)TxtExpectedThr).EndInit();
            GrpBlobFilter.ResumeLayout(false);
            TblPnlBlobFil.ResumeLayout(false);
            TblPnlBlobFil.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)NumPadMaxWidth).EndInit();
            ((System.ComponentModel.ISupportInitialize)NumPadMinWidth).EndInit();
            ((System.ComponentModel.ISupportInitialize)NumPadMinHeight).EndInit();
            ((System.ComponentModel.ISupportInitialize)NumPadMaxHeight).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel TblPNlMain;
        private GroupBox GrpRoiData;
        private TableLayoutPanel TblPnlRoiOcrData;
        private Label LblExpected;
        private Label LblExpectedThresold;
        private Label LblDecoded;
        private TextBox TxtExpected;
        private TextBox TxtDecoded;
        private Label LblDecodedThresold;
        private NumericUpDown TxtExpectedThr;
        private Label LblDecodedThr;
        private CheckBox chkDoOCR;
        private TableLayoutPanel TblPnlBlobFil;
        private Label LblBlobMaxWidth;
        private Label LblBlobMinWidth;
        private Label LblBlobMinHeight;
        private Label LblBlobMaxHeight;
        private NumericUpDown NumPadMaxWidth;
        private NumericUpDown NumPadMinWidth;
        private NumericUpDown NumPadMinHeight;
        private NumericUpDown NumPadMaxHeight;
        private GroupBox GrpBlobFilter;
        private TableLayoutPanel TblPnlRotationAngle;
        private Label LblRotationAngle;
        private GroupBox GrpBoxMorph;
        private TableLayoutPanel tableLayoutPanel1;
        private Label lblMorphKeranalWidth;
        private NumericUpDown NumPadMorphKeranalWidth;
        private NumericUpDown NumPadMorphIteration;
        private Label lblMorphIternation;
        private Label lblMorphMode;
        private TableLayoutPanel tblPnlMorphMode;
        private RadioButton rdMorphModeDilate;
        private RadioButton rdMorphModeErode;
        private RadioButton rdMorphModeNone;
        private Label lblOverAllResult;
        private ComboBox cmbRotationAngle;
        private CheckBox chkAnchor;
        private CheckBox chkIsUseReferance;
        private Button btnCopyDecodedText;
        private Panel pnlBtnAndAdavancedBarcode;
        private TableLayoutPanel TblPnlBottom;
        private Button BtnDecodeROI;
        private Button btnCharResult;
        private GroupBox GrpBoxSegMentMode;
        private TableLayoutPanel tableLayoutPanel2;
        private ComboBox CmbSegments;
        private PanZoomViewer pzPreview;
        private NumericUpDown numPadOCRExpected;
        private Label lblOcrCount;
        private Label lblOcrCharCount;
        private ModernTrackBar trckBarThreshold;
        private Label lblThresoldingValue;
        private GroupBox grpImgThresold;
        private TableLayoutPanel tableLayoutPanel3;
        private CheckBox chkEnableThresholding;
    }
}
