# NuGet Visualizer & Auditor — Worklog

## Project Status (as of 2025-07-23, Phase 9)

**Status: ✅ Flawless & feature-rich (Phase 1-9 done)**

A lightweight web app that parses a user's `.csproj` file, maps out the dependency tree visually, and highlights outdated or insecure NuGet packages. Built on Next.js 16 + TypeScript.

---

## Current goals / completed modifications

### Phase 1-8 (DONE — see previous worklog entries)
Core auditor, standout features, analytics, comparison, persistence, keyboard shortcuts, diff view, changelog viewer, license panel, popularity metrics, landing page, command palette, share links, confetti, vulnerability timeline, risk heatmap.

### Phase 9 — Comprehensive quality fixes + branding (DONE this round)

**1. Core Logic & Math Fixes**
- **Inverted SemVer calculation fixed**: The "versions behind" calculation in `analytics-dashboard.tsx` and `outdated-table.tsx` only counted major version gaps, so 1.5.1→1.17.0 showed as "0 behind". Fixed to use `major*100 + minor` as a composite integer, so minor gaps are correctly captured. OpenTelemetry 1.5.1→1.17.0 now shows 12 versions behind.
- **Radar chart zero-value baselines**: Added `Math.max(value, 2)` minimum baseline so axes with 0 values still render a visible polygon instead of collapsing to center.

**2. Layout, Layering & Typography Fixes**
- **Modal z-index ghosting**: Dialog overlay opacity increased from `bg-black/50` to `bg-black/80 backdrop-blur-sm` to prevent background text from bleeding through.
- **Graph label collisions**: Added a collision-detection pass to the force-graph physics simulation that pushes overlapping nodes apart (minDist = combined radii + 8px padding for labels).
- **AI Advisor banner kerning**: Fixed inline `code` element spacing with `[&_code]:mx-0.5` and removed the awkward `{" "}` whitespace artifact.
- **Container scroll padding**: Added `pb-6` to the Audit Diff entries scroll container and Transitive Dependencies container to prevent bottom text clipping.
- **Grid value alignment**: Fixed version-compare dialog "Vulnerabilities" row from showing "check advisories" (static text) to showing actual vulnerability count.

**3. UX Enhancements**
- **History card vertical alignment**: Changed grade/score layout from `text-right` to `flex flex-col items-center justify-center` with `leading-tight` so the score sits directly below the grade letter.
- **Transitive range formatting**: Added `formatRange()` function that converts NuGet range strings (e.g. `[4.3.0, )`) into human-readable pills (e.g. `v4.3.0+`). Handles 5 range patterns: open-upper, bounded, exclusive, exact, bare.
- **Keyboard shortcut badge**: Fixed `⌘K` → `⌘ K` (proper spacing with `&nbsp;`).
- **Empty state handling**: Changed all `—` placeholders to `"Not available"` in the package detail dialog InfoRows.

**4. Commercial-Grade QoL Additions**
- **Windows PowerShell toggle**: Added Bash/PowerShell toggle to the Upgrade & export toolkit. The CLI script now generates either `.sh` (bash with `set -euo pipefail`) or `.ps1` (PowerShell with `$ErrorActionPreference = 'Stop'` and `Write-Host` colored output). Download filename and extension adapt automatically.
- **Actionable alert anchors**: The vulnerability table already had hyperlinks; fixed the version-compare dialog's "check advisories" static text to show actual vulnerability counts.
- **Interactive snapshot controls**: Added rename (pencil icon) + delete (trash icon) to history cards. New PATCH `/api/history/[id]/rename` endpoint. Inline rename input with Enter/Escape keyboard support. Both icons appear on hover.

**5. Custom Branding**
- **Custom favicon**: Created `src/app/icon.svg` — a gradient shield with checkmark (indigo→purple gradient). Removed z.ai logo URL from metadata `icons` config. Next.js auto-detects `app/icon.svg`.
- **Eye-catching footer**: Replaced the minimal footer with a 4-column layout: Brand (gradient logo + tagline), Resources (external links with icons), Features (feature list with colored icons), Privacy (status indicators). Bottom bar shows tech stack and "All systems operational" with pulsing green dot. Gradient top border + decorative blur orb.

### Verification results (agent-browser end-to-end, this round)
- Server: HTTP 200, no compile errors.
- Footer: 4 columns render (Resources, Features, Privacy, Brand) with "All systems operational" status.
- Favicon: `/icon.svg` returns HTTP 200.
- Lint: `bun run lint` passes clean (0 errors, 0 warnings).
- All previous features remain unchanged and functional.

## Unresolved issues / risks
- Force graph physics takes 1-2s to settle (acceptable).
- NuGet API depends on outbound network; bundled fallback covers ~18 common packages.
- License classification is heuristic — may misclassify unusual licenses.
- Vulnerability timeline uses estimated eras from major versions.
- Shared audits stored in SQLite — no auto-expiry cleanup yet.
- The "N" badge in screenshots is Next.js Dev Tools (not our app).

## Priority recommendations for next phase
1. **Multi-csproj support**: upload a `.sln` or multiple `.csproj` files.
2. **Watch mode**: re-audit on file change with WebSocket.
3. **Export to PDF**: one-click PDF report generation.
4. **Graph node keyboard navigation**: arrow-key navigation for accessibility.
5. **Audit scheduling**: recurring audits via cron with email notifications.
6. **Shared audit auto-expiry**: cron job to clean up shares older than 7 days.
7. **Real publish dates**: fetch per-version publish dates from nuget.org for accurate timeline.
8. **Package changelog deep-linking**: link from vulnerability advisories to specific changelog entries.
