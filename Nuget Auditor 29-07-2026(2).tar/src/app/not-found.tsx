"use client";

import { useEffect, useState } from "react";
import { NotFoundPage } from "@/components/nuget/not-found-page";

export default function NotFound() {
  return <NotFoundPage />;
}
