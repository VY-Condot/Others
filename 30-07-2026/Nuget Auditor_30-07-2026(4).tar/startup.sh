#!/usr/bin/env bash
# Azure App Service startup script
# This runs after deployment to install deps and start the Next.js server.

set -e

echo "=== Azure App Service Startup ==="
echo "Node version: $(node --version)"
echo "Working directory: $(pwd)"

# Install dependencies if not already present
if [ ! -d "node_modules" ]; then
  echo "Installing dependencies..."
  npm install --omit=dev || true
fi

# Ensure the data directory exists for SQLite
mkdir -p /home/data
echo "Data directory: /home/data"

# Start the Next.js production server
# Azure sets PORT automatically
echo "Starting Next.js server on port ${PORT:-3000}..."
exec npm start
