import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Standalone output for Azure App Service / container deployment
  output: "standalone",
  // TypeScript checking (kept relaxed for dev speed)
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Azure-compatible server settings
  serverExternalPackages: ["@prisma/client"],
  // Allow cross-origin for Azure preview domains
  allowedDevOrigins: ["*.azurewebsites.net", "*.trafficmanager.net"],
  // Compress responses
  compress: true,
  // Power-by header disabled for security
  poweredByHeader: false,
  // Production source maps (for debugging, not exposed to users)
  productionBrowserSourceMaps: false,
  // Headers for performance, security, and caching
  async headers() {
    return [
      {
        // Security + performance headers for all routes
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "X-DNS-Prefetch-Control", value: "on" },
          { key: "X-XSS-Protection", value: "1; mode=block" },
        ],
      },
      {
        // Aggressive caching for static assets (1 year)
        source: "/_next/static/(.*)",
        headers: [
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
        ],
      },
      {
        // Cache icons and manifest
        source: "/(icon.svg|manifest.json|robots.txt)",
        headers: [
          { key: "Cache-Control", value: "public, max-age=86400" },
        ],
      },
      {
        // Service worker — no cache (always fresh)
        source: "/sw.js",
        headers: [
          { key: "Cache-Control", value: "no-cache, no-store, must-revalidate" },
        ],
      },
    ];
  },
};

export default nextConfig;
