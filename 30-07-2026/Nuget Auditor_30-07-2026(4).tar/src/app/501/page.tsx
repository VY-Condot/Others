import { ViralErrorPage } from "@/components/nuget/viral-error-page";

export default function Page501() {
  return <ViralErrorPage statusCode={501} />;
}
