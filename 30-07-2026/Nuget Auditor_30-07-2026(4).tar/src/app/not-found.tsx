"use client";

import { ViralErrorPage } from "@/components/nuget/viral-error-page";

export default function NotFound() {
  return <ViralErrorPage statusCode={404} />;
}
