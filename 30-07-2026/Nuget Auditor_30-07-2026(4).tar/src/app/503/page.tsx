import { ViralErrorPage } from "@/components/nuget/viral-error-page";

export default function Page503() {
  return <ViralErrorPage statusCode={503} />;
}
