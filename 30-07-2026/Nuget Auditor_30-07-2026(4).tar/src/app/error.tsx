"use client";

import { ViralErrorPage } from "@/components/nuget/viral-error-page";

export default function Error500() {
  return <ViralErrorPage statusCode={500} />;
}
