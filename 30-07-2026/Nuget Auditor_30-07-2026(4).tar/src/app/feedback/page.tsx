"use client";

import { FeedbackForm } from "@/components/nuget/feedback-form";
import { GlobalLayout } from "@/components/nuget/global-layout";

export default function FeedbackPage() {
  return (
    <GlobalLayout>
      <main className="flex-1">
        <FeedbackForm />
      </main>
    </GlobalLayout>
  );
}
