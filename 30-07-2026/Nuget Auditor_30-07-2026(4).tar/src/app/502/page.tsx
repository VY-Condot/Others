import { ViralErrorPage } from "@/components/nuget/viral-error-page";

export default function Page502() {
  return <ViralErrorPage statusCode={502} />;
}
