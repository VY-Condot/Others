import { NextRequest, NextResponse } from "next/server";
import { auditCsproj } from "@/lib/audit";
import { auditSchema, validateBody } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
// Audit may take a while when NuGet is slow
export const maxDuration = 60;

/**
 * POST /api/audit
 * Body: { "content": "<raw .csproj XML>" }
 * Returns: AuditResult
 *
 * Also accepts a multipart/form-data upload with a field named `file`
 * for direct file uploads.
 */
export async function POST(req: NextRequest) {
  let content: string | null = null;
  let filename: string | undefined;

  const contentType = req.headers.get("content-type") ?? "";

  try {
    if (contentType.includes("multipart/form-data")) {
      const form = await req.formData();
      const file = form.get("file");
      if (file instanceof File) {
        content = await file.text();
        filename = file.name;
      } else {
        const c = form.get("content");
        if (typeof c === "string") content = c;
      }
    } else {
      const body = await req.json();
      // Validate with Zod
      const validation = validateBody(auditSchema, body);
      if (!validation.success) {
        return NextResponse.json({ error: validation.error }, { status: 400 });
      }
      content = validation.data.content;
    }
  } catch (err) {
    return NextResponse.json(
      { error: "Invalid request body.", detail: String(err) },
      { status: 400 },
    );
  }

  if (!content || !content.trim()) {
    return NextResponse.json(
      { error: "No csproj content provided. Send JSON { content } or multipart file=." },
      { status: 400 },
    );
  }

  if (content.length > 2_000_000) {
    return NextResponse.json(
      { error: "csproj content too large (max 2MB)." },
      { status: 413 },
    );
  }

  try {
    const result = await auditCsproj(content);
    return NextResponse.json({ ok: true, filename, result });
  } catch (err) {
    return NextResponse.json(
      { error: "Audit failed.", detail: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    );
  }
}
