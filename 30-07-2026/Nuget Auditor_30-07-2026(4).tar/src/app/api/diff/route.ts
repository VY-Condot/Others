import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import semver from "semver";
import type { AuditedPackage } from "@/lib/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface DiffEntry {
  id: string;
  kind: "added" | "removed" | "upgraded" | "downgraded" | "unchanged" | "vuln-fixed" | "vuln-introduced";
  fromVersion?: string;
  toVersion?: string;
  fromVulnerable?: boolean;
  toVulnerable?: boolean;
  fromOutdated?: boolean;
  toOutdated?: boolean;
}

/**
 * GET /api/diff?a=<id>&b=<id>
 * Computes a package-level diff between two saved audit runs.
 * Returns arrays of added/removed/changed packages + summary stats.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const aId = url.searchParams.get("a");
  const bId = url.searchParams.get("b");
  const clientId = req.headers.get("x-client-id") ?? "anonymous";

  if (!aId || !bId) {
    return NextResponse.json({ error: "Both `a` and `b` query params are required." }, { status: 400 });
  }

  try {
    // Only fetch runs that belong to the requesting client (data isolation)
    const [runA, runB] = await Promise.all([
      db.auditRun.findFirst({ where: { id: aId, clientId } }),
      db.auditRun.findFirst({ where: { id: bId, clientId } }),
    ]);

    if (!runA || !runB) {
      return NextResponse.json({ error: "Audit run not found or not owned by this client." }, { status: 404 });
    }

    const resultA = JSON.parse(runA.resultJson);
    const resultB = JSON.parse(runB.resultJson);
    const pkgsA = (resultA.packages as AuditedPackage[]) ?? [];
    const pkgsB = (resultB.packages as AuditedPackage[]) ?? [];

    const mapA = new Map(pkgsA.map((p) => [p.id.toLowerCase(), p]));
    const mapB = new Map(pkgsB.map((p) => [p.id.toLowerCase(), p]));

    const allIds = new Set([...mapA.keys(), ...mapB.keys()]);
    const entries: DiffEntry[] = [];

    for (const id of allIds) {
      const a = mapA.get(id);
      const b = mapB.get(id);

      if (a && !b) {
        entries.push({
          id: a.id,
          kind: "removed",
          fromVersion: a.declaredVersion,
          fromVulnerable: a.isVulnerable,
          fromOutdated: a.isOutdated,
        });
      } else if (!a && b) {
        entries.push({
          id: b.id,
          kind: "added",
          toVersion: b.declaredVersion,
          toVulnerable: b.isVulnerable,
          toOutdated: b.isOutdated,
        });
      } else if (a && b) {
        const coercedA = semver.coerce(a.declaredVersion);
        const coercedB = semver.coerce(b.declaredVersion);
        const versionChanged = a.declaredVersion !== b.declaredVersion;
        let kind: DiffEntry["kind"] = "unchanged";

        if (versionChanged && coercedA && coercedB) {
          kind = semver.gt(coercedB, coercedA) ? "upgraded" : "downgraded";
        } else if (versionChanged) {
          kind = "upgraded"; // assume upgrade if unparseable
        }

        // Vuln status change takes precedence for visibility
        if (a.isVulnerable && !b.isVulnerable) {
          kind = "vuln-fixed";
        } else if (!a.isVulnerable && b.isVulnerable) {
          kind = "vuln-introduced";
        }

        entries.push({
          id: a.id,
          kind,
          fromVersion: a.declaredVersion,
          toVersion: b.declaredVersion,
          fromVulnerable: a.isVulnerable,
          toVulnerable: b.isVulnerable,
          fromOutdated: a.isOutdated,
          toOutdated: b.isOutdated,
        });
      }
    }

    // Sort: changes first, then alpha
    const order: Record<DiffEntry["kind"], number> = {
      "vuln-introduced": 0,
      "vuln-fixed": 1,
      downgraded: 2,
      added: 3,
      removed: 4,
      upgraded: 5,
      unchanged: 6,
    };
    entries.sort((x, y) => {
      const o = order[x.kind] - order[y.kind];
      if (o !== 0) return o;
      return x.id.localeCompare(y.id);
    });

    const summary = {
      added: entries.filter((e) => e.kind === "added").length,
      removed: entries.filter((e) => e.kind === "removed").length,
      upgraded: entries.filter((e) => e.kind === "upgraded").length,
      downgraded: entries.filter((e) => e.kind === "downgraded").length,
      unchanged: entries.filter((e) => e.kind === "unchanged").length,
      vulnFixed: entries.filter((e) => e.kind === "vuln-fixed").length,
      vulnIntroduced: entries.filter((e) => e.kind === "vuln-introduced").length,
      healthScoreA: runA.healthScore,
      healthScoreB: runB.healthScore,
      scoreDelta: runB.healthScore - runA.healthScore,
      projectNameA: runA.projectName,
      projectNameB: runB.projectName,
      createdAtA: runA.createdAt,
      createdAtB: runB.createdAt,
      outdatedA: runA.outdatedCount,
      outdatedB: runB.outdatedCount,
      vulnerableA: runA.vulnerableCount,
      vulnerableB: runB.vulnerableCount,
    };

    return NextResponse.json({ ok: true, entries, summary });
  } catch (err) {
    return NextResponse.json(
      { error: "Diff failed.", detail: String(err) },
      { status: 500 },
    );
  }
}
