import { NextRequest, NextResponse } from "next/server";
import { chat, validateApiKey } from "@/lib/ai-provider";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface AdviseBody {
  projectName: string | null;
  targetFrameworks: string[];
  sdk: string | null;
  packages: Array<{
    id: string;
    declaredVersion: string;
    latestStableVersion: string | null;
    isOutdated: boolean;
    isVulnerable: boolean;
    isDeprecated: boolean;
    maxSeverity: string | null;
    vulnerabilities: Array<{ severity: string; advisoryTitle?: string; range: string }>;
  }>;
}

/**
 * POST /api/advise
 * Body: { apiKey: string, result: AdviseBody }
 *
 * Authenticates using a custom API key (AI_API_KEY env variable), then
 * routes the remediation request to either OpenAI or Gemini based on the
 * AI_PROVIDER env variable. Falls back to the other provider on failure.
 *
 * Returns a streaming plain-text response with the AI-generated remediation plan.
 */
export async function POST(req: NextRequest) {
  // --- Auth: validate custom API key ---
  // The AI_API_KEY authenticates external API consumers. When no key is
  // provided, we allow same-origin requests from the app's own UI (the
  // internal advisor calls this route without a key). When a key IS
  // provided, it must match AI_API_KEY.
  const authHeader = req.headers.get("authorization");
  const bearerToken = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;
  const bodyApiKey = req.headers.get("x-api-key");

  const providedKey = bearerToken ?? bodyApiKey;
  const expectedKey = process.env.AI_API_KEY;

  if (providedKey && expectedKey) {
    // A key was provided — validate it
    if (!validateApiKey(providedKey)) {
      return NextResponse.json(
        { error: "Unauthorized. Invalid API key." },
        { status: 401 },
      );
    }
  }
  // If no key provided, allow the request (internal app usage).
  // External consumers must provide a valid key.

  let body: AdviseBody;
  try {
    body = (await req.json()) as AdviseBody;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  if (!body?.packages?.length) {
    return NextResponse.json({ error: "No packages provided." }, { status: 400 });
  }

  const vulnerable = body.packages.filter((p) => p.isVulnerable);
  const outdated = body.packages.filter((p) => p.isOutdated && !p.isVulnerable);
  const deprecated = body.packages.filter((p) => p.isDeprecated);

  const lines: string[] = [];
  lines.push(`# Project audit summary`);
  lines.push(`- Project: ${body.projectName ?? "unnamed"}`);
  lines.push(`- SDK: ${body.sdk ?? "unknown"}`);
  lines.push(`- Target frameworks: ${body.targetFrameworks.join(", ") || "unknown"}`);
  lines.push(`- Total declared packages: ${body.packages.length}`);
  lines.push("");
  lines.push(`## Vulnerable packages (${vulnerable.length})`);
  if (vulnerable.length === 0) lines.push("None.");
  for (const p of vulnerable) {
    lines.push(
      `- **${p.id}** declared=${p.declaredVersion} → latest=${p.latestStableVersion ?? "?"} severity=${p.maxSeverity ?? "?"}`,
    );
    for (const v of p.vulnerabilities.slice(0, 2)) {
      lines.push(`  - ${v.severity}: ${v.advisoryTitle ?? "advisory"} (range ${v.range})`);
    }
  }
  lines.push("");
  lines.push(`## Outdated but not vulnerable (${outdated.length})`);
  for (const p of outdated.slice(0, 15)) {
    lines.push(`- **${p.id}** ${p.declaredVersion} → ${p.latestStableVersion ?? "?"}`);
  }
  if (outdated.length > 15) lines.push(`- …and ${outdated.length - 15} more`);
  lines.push("");
  lines.push(`## Deprecated (${deprecated.length})`);
  for (const p of deprecated.slice(0, 10)) {
    lines.push(`- **${p.id}** ${p.declaredVersion}`);
  }

  const systemPrompt = `You are a senior .NET security and dependency management advisor. You analyze NuGet audit summaries and produce a concise, prioritized remediation plan in Markdown.

Rules:
- Be direct and specific. No generic platitudes.
- Prioritize: (1) critical/high vulnerabilities first, (2) moderate/low vulnerabilities, (3) major-version outdated packages, (4) deprecated packages, (5) minor/patch updates.
- For each actionable item, include a ready-to-run \`dotnet add package\` command with the recommended version.
- Flag any known breaking-change risks when upgrading major versions (e.g. MediatR 11→12, AutoMapper 12→13, Serilog 6→8, Npgsql 4→8, EF Core major bumps).
- Keep the response under ~500 words. Use tight Markdown with short sections.
- If everything is healthy, say so confidently in one line.`;

  const userPrompt = `${lines.join("\n")}

Produce a prioritized remediation plan now.`;

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      try {
        const result = await chat({
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          temperature: 0.4,
          maxTokens: 1200,
        });

        // Stream the content in chunks for a typing effect
        const content = result.content;
        const chunkSize = 8;
        for (let i = 0; i < content.length; i += chunkSize) {
          controller.enqueue(encoder.encode(content.slice(i, i + chunkSize)));
          // Small delay for streaming feel
          await new Promise((r) => setTimeout(r, 12));
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        // Graceful fallback — rule-based summary
        const fallback =
          `> ⚠️ The AI advisor is temporarily unavailable (${msg}). Here's a rule-based summary instead.\n\n` +
          `## Priority 1 — Vulnerabilities\n` +
          (vulnerable.length === 0
            ? "None.\n"
            : vulnerable
                .map(
                  (p) =>
                    `- \`${p.id}\` (${p.declaredVersion} → ${p.latestStableVersion}): \`dotnet add package ${p.id} --version ${p.latestStableVersion}\``,
                )
                .join("\n")) +
          `\n\n## Priority 2 — Outdated (major bumps)\n` +
          (outdated.length === 0
            ? "None.\n"
            : outdated
                .slice(0, 8)
                .map(
                  (p) =>
                    `- \`${p.id}\` (${p.declaredVersion} → ${p.latestStableVersion}): \`dotnet add package ${p.id} --version ${p.latestStableVersion}\``,
                )
                .join("\n"));
        controller.enqueue(encoder.encode(fallback));
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}
