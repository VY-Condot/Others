import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { feedbackSchema, validateBody } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const VALID_TYPES = ["bug", "feature", "feedback", "question"];
const VALID_SEVERITIES = ["low", "medium", "high", "critical"];

/**
 * GET /api/feedback
 * Returns all feedback items, newest first. Supports optional ?status= and ?type= filters.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const statusFilter = url.searchParams.get("status");
  const typeFilter = url.searchParams.get("type");

  try {
    const where: Record<string, unknown> = {};
    if (statusFilter) where.status = statusFilter;
    if (typeFilter) where.type = typeFilter;

    const items = await db.feedback.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 200,
    });

    return NextResponse.json({ ok: true, items });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to load feedback.", detail: String(err) },
      { status: 500 },
    );
  }
}

/**
 * POST /api/feedback
 * Body: { type, severity, title, description, screenshot?, reporterName?, reporterEmail? }
 * Creates a new feedback/bug report. Captures page URL and user agent automatically.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // Validate with Zod
    const validation = validateBody(feedbackSchema, body);
    if (!validation.success) {
      return NextResponse.json({ error: validation.error }, { status: 400 });
    }
    const { type, severity, title, description, screenshot: rawScreenshot, page, reporterName, reporterEmail } = validation.data;

    // Cap screenshot size to 500KB (base64 string length)
    let screenshot: string | null = rawScreenshot ?? null;
    if (screenshot && screenshot.length > 700_000) {
      screenshot = screenshot.slice(0, 700_000);
    }

    const userAgent = req.headers.get("user-agent") ?? null;

    const item = await db.feedback.create({
      data: {
        type,
        severity,
        title: title.trim().slice(0, 200),
        description: description.trim().slice(0, 5000),
        screenshot,
        page,
        userAgent,
        reporterName,
        reporterEmail,
        status: "open",
      },
    });

    return NextResponse.json({ ok: true, id: item.id });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to submit feedback.", detail: String(err) },
      { status: 500 },
    );
  }
}
