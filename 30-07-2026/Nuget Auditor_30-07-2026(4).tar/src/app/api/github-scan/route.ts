import { NextRequest, NextResponse } from "next/server";
import { githubScanSchema, validateBody } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface ScanResult {
  repo: string;
  branch: string;
  slnFiles: string[];
  csprojFiles: Array<{ path: string; content: string; projectName: string }>;
  error?: string;
}

/**
 * Get GitHub auth headers. Uses:
 *   1. Server-side GITHUB_TOKEN env var (if configured)
 *   2. Client-provided token via x-github-token header (optional, per-request)
 *
 * If no token is available, makes unauthenticated requests (limited to 60/hour).
 */
function getGithubHeaders(clientToken?: string | null): Record<string, string> {
  const token = clientToken || process.env.GITHUB_TOKEN;
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "User-Agent": "nuget-auditor",
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }
  return headers;
}

/** Check if a 403 response is due to rate limiting. */
function isRateLimited(res: Response): boolean {
  const remaining = res.headers.get("x-ratelimit-remaining");
  return res.status === 403 && (remaining === "0" || remaining === null);
}

/** Build a user-friendly rate limit error message. */
function rateLimitError(res: Response): { error: string; resetAt?: string } {
  const resetEpoch = res.headers.get("x-ratelimit-reset");
  let resetMsg = "";
  if (resetEpoch) {
    const resetDate = new Date(parseInt(resetEpoch) * 1000);
    const mins = Math.max(1, Math.ceil((resetDate.getTime() - Date.now()) / 60000));
    resetMsg = ` Rate limit resets in ~${mins} minute${mins === 1 ? "" : "s"}.`;
  }
  return {
    error: `GitHub API rate limit exceeded.${resetMsg} Add a GitHub personal access token (Settings → Developer settings → Personal access tokens → Fine-grained tokens, public read access) in the token field below to get 5,000 requests/hour instead of 60.`,
  };
}

/**
 * POST /api/github-scan
 * Body: { url: string, branch?: string }
 * Headers: x-github-token (optional, for authenticated requests)
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const validation = validateBody(githubScanSchema, body);
    if (!validation.success) {
      return NextResponse.json({ error: validation.error }, { status: 400 });
    }
    const { url, branch } = validation.data;
    const clientToken = req.headers.get("x-github-token");
    const headers = getGithubHeaders(clientToken);

    // Parse GitHub URL
    const match = url.match(/github\.com\/([^\/]+)\/([^\/\?#]+)(?:\/tree\/([^\/\?#]+))?/);
    if (!match) {
      return NextResponse.json({ error: "Invalid GitHub URL. Expected: https://github.com/{owner}/{repo}" }, { status: 400 });
    }

    const [, owner, rawRepo, urlBranch] = match;
    const repo = rawRepo.replace(/\.git$/, "");
    const targetBranch = branch || urlBranch || "main";

    // Fetch the repository tree (recursive)
    const treeUrl = `https://api.github.com/repos/${owner}/${repo}/git/trees/${targetBranch}?recursive=1`;
    const treeRes = await fetch(treeUrl, { headers, cache: "no-store" });

    // Handle 403 rate limit
    if (isRateLimited(treeRes)) {
      const rlError = rateLimitError(treeRes);
      return NextResponse.json(rlError, { status: 429 });
    }

    if (treeRes.status === 404) {
      // Try 'master' branch if 'main' doesn't exist
      if (targetBranch === "main") {
        const masterRes = await fetch(
          `https://api.github.com/repos/${owner}/${repo}/git/trees/master?recursive=1`,
          { headers, cache: "no-store" },
        );
        if (isRateLimited(masterRes)) {
          const rlError = rateLimitError(masterRes);
          return NextResponse.json(rlError, { status: 429 });
        }
        if (masterRes.ok) {
          return await processTree(owner, repo, "master", await masterRes.json(), clientToken);
        }
      }
      return NextResponse.json(
        { error: `Branch "${targetBranch}" not found. Try: main, master, develop.` },
        { status: 404 },
      );
    }

    if (!treeRes.ok) {
      const errText = await treeRes.text();
      return NextResponse.json(
        { error: `GitHub API error: ${treeRes.status}`, detail: errText.slice(0, 300) },
        { status: 502 },
      );
    }

    const treeData = await treeRes.json();
    return await processTree(owner, repo, targetBranch, treeData, clientToken);
  } catch (err) {
    return NextResponse.json({ error: "Scan failed.", detail: String(err) }, { status: 500 });
  }
}

async function processTree(
  owner: string,
  repo: string,
  branch: string,
  treeData: any,
  clientToken?: string | null,
): Promise<NextResponse> {
  const result: ScanResult = { repo: `${owner}/${repo}`, branch, slnFiles: [], csprojFiles: [] };

  if (!treeData.tree || !Array.isArray(treeData.tree)) {
    return NextResponse.json({ error: "Invalid tree data from GitHub." }, { status: 502 });
  }

  // Find .sln and .csproj files
  const slnBlobs = treeData.tree.filter((t: any) => t.type === "blob" && t.path.endsWith(".sln"));
  const csprojBlobs = treeData.tree.filter((t: any) => t.type === "blob" && t.path.endsWith(".csproj"));

  result.slnFiles = slnBlobs.map((b: any) => b.path);

  // For raw file fetches, we don't need auth (raw.githubusercontent.com is not rate-limited the same way)
  // But we pass the token anyway for private repos
  const rawHeaders: Record<string, string> = {};
  const token = clientToken || process.env.GITHUB_TOKEN;
  if (token) {
    rawHeaders.Authorization = `Bearer ${token}`;
  }

  // Fetch all .csproj file contents (in parallel with concurrency limit)
  const CONCURRENCY = 5; // Reduced from 8 to be gentler on rate limits
  let cursor = 0;

  async function fetchCsproj(blob: any) {
    try {
      const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${blob.path}`;
      const res = await fetch(rawUrl, { headers: rawHeaders, cache: "no-store" });
      if (!res.ok) return null;
      const content = await res.text();
      const projectName = blob.path.split("/").pop()?.replace(/\.csproj$/, "") ?? blob.path;
      return { path: blob.path, content, projectName };
    } catch {
      return null;
    }
  }

  const tasks: Promise<void>[] = [];
  for (let i = 0; i < CONCURRENCY; i++) {
    tasks.push(
      (async () => {
        while (cursor < csprojBlobs.length) {
          const idx = cursor++;
          const file = await fetchCsproj(csprojBlobs[idx]);
          if (file) result.csprojFiles.push(file);
        }
      })(),
    );
  }
  await Promise.all(tasks);

  result.csprojFiles.sort((a, b) => a.path.localeCompare(b.path));

  return NextResponse.json({ ok: true, result });
}

/**
 * GET /api/github-scan?owner=X&repo=Y
 * Returns available branches for a repository.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const owner = url.searchParams.get("owner");
  const repo = url.searchParams.get("repo");
  const clientToken = req.headers.get("x-github-token");
  const headers = getGithubHeaders(clientToken);

  if (!owner || !repo) {
    return NextResponse.json({ error: "owner and repo params required." }, { status: 400 });
  }

  try {
    const branchesRes = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/branches?per_page=100`,
      { headers, cache: "no-store" },
    );

    if (isRateLimited(branchesRes)) {
      const rlError = rateLimitError(branchesRes);
      return NextResponse.json(rlError, { status: 429 });
    }

    if (!branchesRes.ok) {
      return NextResponse.json({ error: "Failed to fetch branches." }, { status: 502 });
    }

    const branches = await branchesRes.json();
    const tagsRes = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/tags?per_page=50`,
      { headers, cache: "no-store" },
    );
    const tags = tagsRes.ok ? await tagsRes.json() : [];

    return NextResponse.json({
      ok: true,
      branches: branches.map((b: any) => b.name),
      tags: tags.map((t: any) => t.name),
    });
  } catch (err) {
    return NextResponse.json({ error: "Failed to fetch branches.", detail: String(err) }, { status: 500 });
  }
}
