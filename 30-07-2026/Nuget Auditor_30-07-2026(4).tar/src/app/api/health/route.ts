import { NextResponse } from "next/server";
import { isAzure, getPort } from "@/lib/azure-config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/health
 * Health check endpoint for Azure App Service / Azure Functions.
 * Returns 200 OK with status info if the app is running.
 */
export async function GET() {
  return NextResponse.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    azure: isAzure(),
    port: getPort(),
    uptime: process.uptime(),
  });
}
