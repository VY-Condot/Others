import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/badge?id=<shareId>
 *
 * Serves an SVG health score badge for a shared audit. This is the viral
 * loop endpoint — badges embedded in GitHub READMEs point here, and each
 * view is free advertising for the NuGet Auditor.
 *
 * Returns an SVG image (shields.io-compatible style).
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");

  if (!id) {
    return NextResponse.json({ error: "Share id required." }, { status: 400 });
  }

  let score = 0;
  let grade = "F";
  let color = "#ef4444";

  try {
    const run = await db.auditRun.findUnique({ where: { id } });
    if (run) {
      score = run.healthScore;
      grade = score >= 90 ? "A" : score >= 75 ? "B" : score >= 60 ? "C" : score >= 40 ? "D" : "F";
      color = score >= 90 ? "#10b981" : score >= 75 ? "#84cc16" : score >= 60 ? "#eab308" : score >= 40 ? "#f97316" : "#ef4444";
    }
  } catch {
    // If DB fails, show a default badge
  }

  const leftWidth = 90;
  const rightWidth = 70;
  const totalWidth = leftWidth + rightWidth;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${totalWidth}" height="20" role="img" aria-label="NuGet audit: ${grade} (${score}/100)">
  <linearGradient id="s" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <clipPath id="r"><rect width="${totalWidth}" height="20" rx="3" fill="#fff"/></clipPath>
  <g clip-path="url(#r)">
    <rect width="${leftWidth}" height="20" fill="#4a4a4a"/>
    <rect x="${leftWidth}" width="${rightWidth}" height="20" fill="${color}"/>
    <rect width="${totalWidth}" height="20" fill="url(#s)"/>
  </g>
  <g fill="#fff" text-anchor="middle" font-family="Verdana,DejaVu Sans,sans-serif" font-size="11">
    <text x="${leftWidth / 2}" y="14">NuGet audit</text>
    <text x="${leftWidth + rightWidth / 2}" y="14">${grade} · ${score}/100</text>
  </g>
</svg>`;

  return new NextResponse(svg, {
    headers: {
      "Content-Type": "image/svg+xml",
      "Cache-Control": "public, max-age=3600",
    },
  });
}
