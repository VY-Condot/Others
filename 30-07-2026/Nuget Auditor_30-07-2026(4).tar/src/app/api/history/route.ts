import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { AuditResult } from "@/lib/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/history — list saved audit runs for the requesting client only.
 * The clientId is read from the `x-client-id` header (set by the browser).
 * This ensures users only see their own audits, not other users' data.
 *
 * POST /api/history — save a new audit run, tagged with the client's ID.
 */
export async function GET(req: NextRequest) {
  const clientId = req.headers.get("x-client-id") ?? "anonymous";
  try {
    const runs = await db.auditRun.findMany({
      where: { clientId },
      orderBy: { createdAt: "desc" },
      take: 50,
      select: {
        id: true,
        projectName: true,
        sdk: true,
        targetFramework: true,
        totalPackages: true,
        outdatedCount: true,
        vulnerableCount: true,
        deprecatedCount: true,
        maxSeverity: true,
        healthScore: true,
        createdAt: true,
      },
    });
    return NextResponse.json({ ok: true, runs });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: "Failed to load history.", detail: String(err) },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  const clientId = req.headers.get("x-client-id") ?? "anonymous";
  try {
    const body = await req.json();
    const result = body?.result as AuditResult | undefined;
    if (!result) {
      return NextResponse.json({ ok: false, error: "No audit result provided." }, { status: 400 });
    }

    // Compute a health score (mirrors the HealthScore component logic)
    const sevPenalty: Record<string, number> = { low: 8, moderate: 18, high: 35, critical: 60 };
    let score = 100;
    if (result.stats.maxSeverity) score -= sevPenalty[result.stats.maxSeverity] ?? 0;
    const extraVuln = Math.max(0, result.stats.vulnerableCount - 1);
    score -= extraVuln * 6;
    if (result.stats.totalPackages > 0) {
      score -= Math.round((result.stats.outdatedCount / result.stats.totalPackages) * 25);
    }
    score -= result.stats.deprecatedCount * 4;
    score = Math.max(0, Math.min(100, score));

    // Strip rawCsproj from the saved JSON (we store it separately)
    const { rawCsproj, ...resultWithoutRaw } = result;

    const run = await db.auditRun.create({
      data: {
        clientId,
        projectName: result.parsed.projectName ?? "unnamed",
        sdk: result.parsed.sdk ?? null,
        targetFramework: result.parsed.targetFrameworks.join(", ") || null,
        totalPackages: result.stats.totalPackages,
        outdatedCount: result.stats.outdatedCount,
        vulnerableCount: result.stats.vulnerableCount,
        deprecatedCount: result.stats.deprecatedCount,
        maxSeverity: result.stats.maxSeverity ?? null,
        healthScore: score,
        resultJson: JSON.stringify(resultWithoutRaw),
        csprojContent: rawCsproj ?? "",
      },
    });

    return NextResponse.json({ ok: true, id: run.id });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: "Failed to save audit.", detail: String(err) },
      { status: 500 },
    );
  }
}
