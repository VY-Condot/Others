import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/history/[id] — load a single audit run with full result JSON.
 * Only returns the run if it belongs to the requesting client (x-client-id header).
 *
 * DELETE /api/history/[id] — delete a saved audit run (client-scoped).
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const clientId = req.headers.get("x-client-id") ?? "anonymous";
  try {
    const { id } = await params;
    const run = await db.auditRun.findFirst({ where: { id, clientId } });
    if (!run) {
      return NextResponse.json({ ok: false, error: "Not found." }, { status: 404 });
    }
    const result = JSON.parse(run.resultJson);
    // re-attach rawCsproj for the UI
    result.rawCsproj = run.csprojContent;
    return NextResponse.json({ ok: true, run, result });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: "Failed to load audit.", detail: String(err) },
      { status: 500 },
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const clientId = req.headers.get("x-client-id") ?? "anonymous";
  try {
    const { id } = await params;
    // Only delete if owned by this client
    const existing = await db.auditRun.findFirst({ where: { id, clientId } });
    if (!existing) {
      return NextResponse.json({ ok: false, error: "Not found." }, { status: 404 });
    }
    await db.auditRun.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: "Failed to delete audit.", detail: String(err) },
      { status: 500 },
    );
  }
}
