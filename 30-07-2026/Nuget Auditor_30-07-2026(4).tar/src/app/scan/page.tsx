"use client";

import { useState, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/lib/store";
import {
  Github,
  Loader2,
  GitBranch,
  FileCode2,
  ArrowRight,
  Search,
  AlertCircle,
  CheckCircle2,
  ShieldAlert,
  Activity,
  Boxes,
  ChevronDown,
  ChevronUp,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ThemeToggle } from "@/components/nuget/theme-toggle";
import { GlobalLayout } from "@/components/nuget/global-layout";
import Link from "next/link";
import { toast } from "sonner";
import { parseCsproj, type ParsedCsproj } from "@/lib/csproj-parser";
import type { AuditResult } from "@/lib/audit";
import { cn } from "@/lib/utils";

// Reuse main page components for full feature parity
import { HealthScore } from "@/components/nuget/health-score";
import { StatsCards } from "@/components/nuget/stats-cards";
import { VulnerabilityTable } from "@/components/nuget/vulnerability-table";
import { OutdatedTable } from "@/components/nuget/outdated-table";
import { AllPackagesTable } from "@/components/nuget/all-packages-table";
import { QuickStatsBar } from "@/components/nuget/quick-stats-bar";
import { AnalyticsDashboard } from "@/components/nuget/analytics-dashboard";
import { AiAdvisor } from "@/components/nuget/ai-advisor";
import { PackageDetailDialog } from "@/components/nuget/package-detail-dialog";
import { VersionCompareDialog } from "@/components/nuget/version-compare-dialog";
import { UpgradeGenerator } from "@/components/nuget/upgrade-generator";
import type { AuditedPackage } from "@/lib/audit";

interface ScanResult {
  repo: string;
  branch: string;
  slnFiles: string[];
  csprojFiles: Array<{ path: string; content: string; projectName: string }>;
}

export default function ScanPage() {
  const router = useRouter();
  const [url, setUrl] = useState("");
  const [branch, setBranch] = useState("");
  const [githubToken, setGithubToken] = useState("");
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [branches, setBranches] = useState<string[]>([]);
  const [fetchingBranches, setFetchingBranches] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Per-project audit results: keyed by project path
  const [audits, setAudits] = useState<Record<string, AuditResult | "loading" | "error">>({});
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [bulkAuditing, setBulkAuditing] = useState(false);
  const [bulkProgress, setBulkProgress] = useState(0);
  const [activeTab, setActiveTab] = useState("overview");

  const scanContext = useAppStore((s) => s.scanContext);
  const setScanContext = useAppStore((s) => s.setScanContext);
  const setScannedProjects = useAppStore((s) => s.setScannedProjects);

  useEffect(() => {
    if (scanContext && !result) {
      setUrl(scanContext.url);
      setBranch(scanContext.branch);
      setResult({
        repo: scanContext.repo,
        branch: scanContext.branch,
        slnFiles: scanContext.slnFiles,
        csprojFiles: scanContext.csprojFiles,
      });
    }
  }, [scanContext]);  

  const scan = useCallback(async () => {
    if (!url.trim()) return;
    setScanning(true);
    setError(null);
    setResult(null);
    setAudits({});
    setSelectedProject(null);
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (githubToken.trim()) headers["x-github-token"] = githubToken.trim();
      const res = await fetch("/api/github-scan", {
        method: "POST",
        headers,
        body: JSON.stringify({ url: url.trim(), branch: branch.trim() }),
      });
      const data = await res.json();
      if (data.ok) {
        setResult(data.result);
        setScanContext({
          url: url.trim(),
          branch: branch.trim() || data.result.branch,
          repo: data.result.repo,
          slnFiles: data.result.slnFiles,
          csprojFiles: data.result.csprojFiles,
        });
        toast.success(`Found ${data.result.csprojFiles.length} .csproj files in ${data.result.repo}`);
      } else {
        setError(data.error || "Scan failed");
        toast.error(data.error || "Scan failed");
      }
    } catch (err) {
      setError(String(err));
      toast.error("Scan failed");
    } finally {
      setScanning(false);
    }
  }, [url, branch, githubToken]);

  const fetchBranches = useCallback(async (repoUrl: string, token?: string) => {
    const match = repoUrl.match(/github\.com\/([^\/]+)\/([^\/\?#]+)/);
    if (!match) return;
    const [, owner, repo] = match;
    const cleanRepo = repo.replace(/\.git$/, "");
    setFetchingBranches(true);
    try {
      const headers: Record<string, string> = {};
      if (token?.trim()) headers["x-github-token"] = token.trim();
      const res = await fetch(`/api/github-scan?owner=${owner}&repo=${cleanRepo}`, { headers });
      const data = await res.json();
      if (data.ok) setBranches([...data.branches, ...data.tags]);
    } catch { }
    finally { setFetchingBranches(false); }
  }, []);

  const onUrlChange = (v: string) => {
    setUrl(v);
    setBranches([]);
    if (v.includes("github.com/")) fetchBranches(v, githubToken);
  };

  // --- Audit a single project inline ---
  const auditProject = async (project: { path: string; content: string; projectName: string }) => {
    setAudits((prev) => ({ ...prev, [project.path]: "loading" }));
    setSelectedProject(project.path);
    try {
      const res = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: project.content }),
      });
      const data = await res.json();
      if (data.ok) {
        setAudits((prev) => ({ ...prev, [project.path]: data.result as AuditResult }));
        toast.success(`Audit complete: ${project.projectName}`);
      } else {
        setAudits((prev) => ({ ...prev, [project.path]: "error" }));
        toast.error(`Audit failed: ${project.projectName}`);
      }
    } catch {
      setAudits((prev) => ({ ...prev, [project.path]: "error" }));
      toast.error(`Audit failed: ${project.projectName}`);
    }
  };

  // --- Bulk audit ALL projects ---
  const auditAllProjects = async () => {
    if (!result) return;
    setBulkAuditing(true);
    setBulkProgress(0);
    const total = result.csprojFiles.length;
    for (let i = 0; i < result.csprojFiles.length; i++) {
      const project = result.csprojFiles[i];
      if (audits[project.path] && audits[project.path] !== "error") {
        setBulkProgress(i + 1);
        continue;
      }
      setAudits((prev) => ({ ...prev, [project.path]: "loading" }));
      if (!selectedProject) setSelectedProject(project.path);
      try {
        const res = await fetch("/api/audit", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: project.content }),
        });
        const data = await res.json();
        if (data.ok) {
          setAudits((prev) => ({ ...prev, [project.path]: data.result as AuditResult }));
        } else {
          setAudits((prev) => ({ ...prev, [project.path]: "error" }));
        }
      } catch {
        setAudits((prev) => ({ ...prev, [project.path]: "error" }));
      }
      setBulkProgress(i + 1);
    }
    setBulkAuditing(false);
    toast.success(`Bulk audit complete: ${total} projects`);
  };

  const goToMatrix = () => {
    if (!result) return;
    setScannedProjects(result.csprojFiles);
    router.push("/matrix");
  };

  const selectedAudit = selectedProject ? audits[selectedProject] : null;
  const selectedProjectData = result?.csprojFiles.find((p) => p.path === selectedProject);

  return (
    <GlobalLayout>
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 py-6 space-y-4">
        {/* URL Input Card */}
        <Card>
          <CardContent className="pt-5 space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">GitHub Repository URL</label>
              <div className="flex gap-2">
                <Input
                  value={url}
                  onChange={(e) => onUrlChange(e.target.value)}
                  placeholder="https://github.com/owner/repo"
                  className="flex-1"
                  onKeyDown={(e) => e.key === "Enter" && scan()}
                />
                <Button onClick={scan} disabled={scanning || !url.trim()}>
                  {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                  {scanning ? "Scanning…" : "Scan"}
                </Button>
              </div>
            </div>
            {(branches.length > 0 || fetchingBranches) && (
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block flex items-center gap-1">
                  <GitBranch className="h-3 w-3" />
                  Branch / Tag {fetchingBranches && <Loader2 className="h-3 w-3 animate-spin" />}
                </label>
                <select value={branch} onChange={(e) => setBranch(e.target.value)}
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm">
                  <option value="">Default (main/master)</option>
                  {branches.map((b) => <option key={b} value={b}>{b}</option>)}
                </select>
              </div>
            )}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">GitHub Token (optional — for higher rate limits)</label>
              <input type="password" value={githubToken} onChange={(e) => setGithubToken(e.target.value)}
                placeholder="ghp_xxxx or github_pat_xxxx"
                className="w-full rounded-md border bg-background px-3 py-2 text-sm font-mono" />
              <p className="text-[10px] text-muted-foreground mt-1">
                💡 Without a token: 60 requests/hour. With a token: 5,000/hour.{" "}
                <a href="https://github.com/settings/tokens?type=beta" target="_blank" rel="noreferrer noopener" className="text-primary hover:underline">Create token →</a>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Error */}
        {error && (
          <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 flex items-start gap-2">
            <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-700 dark:text-red-300">Scan failed</p>
              <p className="text-xs text-muted-foreground mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {/* Scan Results + Dashboard */}
        {result && (
          <div className="space-y-4">
            {/* Repo header with actions */}
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div>
                <h2 className="text-lg font-semibold">{result.repo}</h2>
                <p className="text-xs text-muted-foreground flex items-center gap-1.5 mt-0.5">
                  <GitBranch className="h-3 w-3" /> {result.branch}
                  <span className="mx-1">·</span> <FileCode2 className="h-3 w-3" /> {result.slnFiles.length} solution(s)
                  <span className="mx-1">·</span> <CheckCircle2 className="h-3 w-3 text-emerald-500" /> {result.csprojFiles.length} .csproj file(s)
                </p>
              </div>
              <div className="flex gap-2 items-center">
                {bulkAuditing && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    Auditing {bulkProgress}/{result.csprojFiles.length}…
                  </div>
                )}
                <Button onClick={auditAllProjects} variant="default" size="sm" disabled={bulkAuditing}>
                  <Activity className="h-3.5 w-3.5" />
                  {bulkAuditing ? `Auditing ${bulkProgress}/${result.csprojFiles.length}` : "Audit All"}
                </Button>
                {result.csprojFiles.length > 1 && (
                  <Button onClick={goToMatrix} variant="outline" size="sm">
                    <Boxes className="h-3.5 w-3.5" /> Matrix →
                  </Button>
                )}
              </div>
            </div>

            {/* Bulk progress bar */}
            {bulkAuditing && (
              <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-primary transition-all duration-300" style={{ width: `${(bulkProgress / result.csprojFiles.length) * 100}%` }} />
              </div>
            )}

            {/* Two-column layout: project list + dashboard */}
            <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-4">
              {/* Project list sidebar */}
              <div className="space-y-2">
                <p className="text-xs font-semibold uppercase text-muted-foreground px-1">Projects ({result.csprojFiles.length})</p>
                <div className="space-y-1.5 max-h-[600px] overflow-y-auto custom-scroll pr-1">
                  {result.csprojFiles.map((project) => {
                    const parsed: ParsedCsproj = parseCsproj(project.content);
                    const audit = audits[project.path];
                    const isSelected = selectedProject === project.path;
                    return (
                      <button
                        key={project.path}
                        onClick={() => {
                          setSelectedProject(project.path);
                          if (!audit || audit === "error") auditProject(project);
                        }}
                        className={cn(
                          "w-full text-left rounded-lg border p-2.5 transition-all",
                          isSelected ? "border-primary bg-primary/5 ring-1 ring-primary/20" : "hover:bg-muted/40",
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-semibold truncate">{project.projectName}</p>
                            <p className="text-[10px] text-muted-foreground font-mono truncate">{project.path}</p>
                          </div>
                          {audit === "loading" && <Loader2 className="h-3.5 w-3.5 animate-spin shrink-0" />}
                          {audit && audit !== "loading" && audit !== "error" && (
                            <AuditBadge audit={audit as AuditResult} />
                          )}
                          {audit === "error" && <AlertCircle className="h-3.5 w-3.5 text-red-500 shrink-0" />}
                        </div>
                        {(parsed.sdk || parsed.targetFrameworks.length > 0) && (
                          <div className="flex items-center gap-1 mt-1">
                            {parsed.sdk && <Badge variant="secondary" className="text-[8px] font-mono">{parsed.sdk}</Badge>}
                            {parsed.targetFrameworks.length > 0 && (
                              <Badge variant="outline" className="text-[8px] font-mono">{parsed.targetFrameworks.join(",")}</Badge>
                            )}
                            <Badge variant="outline" className="text-[8px]">{parsed.packageReferences.length} pkg</Badge>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Dynamic Dashboard */}
              <div className="min-w-0">
                {!selectedProject && (
                  <div className="flex flex-col items-center justify-center h-[400px] border rounded-lg border-dashed">
                    <div className="rounded-full bg-muted p-4 mb-3"><FileCode2 className="h-8 w-8 text-muted-foreground" /></div>
                    <p className="text-sm font-medium">Select a project to audit</p>
                    <p className="text-xs text-muted-foreground mt-1">Click any project on the left, or "Audit All" for bulk scanning.</p>
                  </div>
                )}

                {selectedProject && audits[selectedProject] === "loading" && (
                  <div className="flex flex-col items-center justify-center h-[400px] border rounded-lg">
                    <Loader2 className="h-8 w-8 animate-spin text-primary mb-3" />
                    <p className="text-sm font-medium">Auditing {selectedProjectData?.projectName}…</p>
                    <p className="text-xs text-muted-foreground mt-1">Fetching package data from nuget.org</p>
                  </div>
                )}

                {selectedProject && audits[selectedProject] === "error" && (
                  <div className="flex flex-col items-center justify-center h-[400px] border rounded-lg border-red-500/30">
                    <AlertCircle className="h-8 w-8 text-red-500 mb-3" />
                    <p className="text-sm font-medium text-red-600">Audit failed</p>
                    <Button variant="outline" size="sm" className="mt-3" onClick={() => selectedProjectData && auditProject(selectedProjectData)}>
                      <RefreshCw /> Retry
                    </Button>
                  </div>
                )}

                {selectedProject && audits[selectedProject] && audits[selectedProject] !== "loading" && audits[selectedProject] !== "error" && (
                  <ProjectDashboard result={audits[selectedProject] as AuditResult} activeTab={activeTab} onTabChange={setActiveTab} />
                )}
              </div>
            </div>
          </div>
        )}

        {/* Feature cards (empty state) */}
        {!result && !scanning && !error && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-8 items-stretch">
            <Card className="h-full flex flex-col">
              <CardContent className="pt-5 text-center flex flex-col flex-1">
                <div className="rounded-full bg-indigo-500/10 p-3 w-fit mx-auto mb-2"><Search className="h-5 w-5 text-indigo-500" /></div>
                <h3 className="text-sm font-semibold">Inline Auditing</h3>
                <p className="text-[11px] text-muted-foreground mt-1 flex-1">Audit projects directly on this page — no navigation needed.</p>
              </CardContent>
            </Card>
            <Card className="h-full flex flex-col">
              <CardContent className="pt-5 text-center flex flex-col flex-1">
                <div className="rounded-full bg-purple-500/10 p-3 w-fit mx-auto mb-2"><GitBranch className="h-5 w-5 text-purple-500" /></div>
                <h3 className="text-sm font-semibold">Branch Selector</h3>
                <p className="text-[11px] text-muted-foreground mt-1 flex-1">Target specific branches or tags to compare dependencies.</p>
              </CardContent>
            </Card>
            <Card className="h-full flex flex-col">
              <CardContent className="pt-5 text-center flex flex-col flex-1">
                <div className="rounded-full bg-emerald-500/10 p-3 w-fit mx-auto mb-2"><Activity className="h-5 w-5 text-emerald-500" /></div>
                <h3 className="text-sm font-semibold">Bulk Audit</h3>
                <p className="text-[11px] text-muted-foreground mt-1 flex-1">Audit all projects at once with progress tracking.</p>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </GlobalLayout>
  );
}

// --- Small badge showing audit grade in the project list ---
function AuditBadge({ audit }: { audit: AuditResult }) {
  const s = audit.stats;
  const sevPenalty: Record<string, number> = { low: 8, moderate: 18, high: 35, critical: 60 };
  let score = 100;
  if (s.maxSeverity) score -= sevPenalty[s.maxSeverity] ?? 0;
  score -= Math.max(0, s.vulnerableCount - 1) * 6;
  if (s.totalPackages > 0) score -= Math.round((s.outdatedCount / s.totalPackages) * 25);
  score -= s.deprecatedCount * 4;
  score = Math.max(0, Math.min(100, score));
  const grade = score >= 90 ? "A" : score >= 75 ? "B" : score >= 60 ? "C" : score >= 40 ? "D" : "F";
  const color = score >= 90 ? "text-emerald-500" : score >= 75 ? "text-lime-500" : score >= 60 ? "text-yellow-500" : score >= 40 ? "text-orange-500" : "text-red-500";

  return (
    <div className="flex items-center gap-1 shrink-0">
      {s.vulnerableCount > 0 && <ShieldAlert className="h-3 w-3 text-red-500" />}
      <span className={cn("text-xs font-bold", color)}>{grade}</span>
    </div>
  );
}

// --- Full project dashboard (reuses main page components) ---
function ProjectDashboard({ result, activeTab, onTabChange }: { result: AuditResult; activeTab: string; onTabChange: (t: string) => void }) {
  const [selectedPkg, setSelectedPkg] = useState<AuditedPackage | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [comparePkg, setComparePkg] = useState<AuditedPackage | null>(null);
  const [compareOpen, setCompareOpen] = useState(false);

  const onPkgSelect = useCallback((pkg: AuditedPackage) => {
    setSelectedPkg(pkg);
    setDialogOpen(true);
  }, []);

  const onCompare = useCallback((pkg: AuditedPackage) => {
    setComparePkg(pkg);
    setCompareOpen(true);
  }, []);

  return (
    <div className="space-y-4">
      {/* Project header */}
      <div className="flex items-center gap-3 rounded-xl border bg-card p-3">
        <div className="rounded-lg bg-primary/10 p-2"><FileCode2 className="h-4 w-4 text-primary" /></div>
        <div className="min-w-0">
          <h3 className="font-semibold text-sm truncate">{result.parsed.projectName ?? "Unnamed"}</h3>
          <p className="text-[11px] text-muted-foreground">
            {result.parsed.sdk && <span>SDK: {result.parsed.sdk} · </span>}
            {result.parsed.targetFrameworks.length > 0 && <span>Target: {result.parsed.targetFrameworks.join(", ")}</span>}
          </p>
        </div>
      </div>

      {/* Quick stats + health score */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        <div className="lg:col-span-2">
          <StatsCards stats={result.stats} durationMs={result.durationMs} />
        </div>
        <Card className="lg:col-span-1">
          <CardContent className="pt-5">
            <HealthScore
              totalPackages={result.stats.totalPackages}
              outdatedCount={result.stats.outdatedCount}
              vulnerableCount={result.stats.vulnerableCount}
              deprecatedCount={result.stats.deprecatedCount}
              maxSeverity={result.stats.maxSeverity}
            />
          </CardContent>
        </Card>
      </div>

      {/* Quick stats bar */}
      <QuickStatsBar result={result} />

      {/* AI Advisor — always visible */}
      <AiAdvisor result={result} />

      {/* Tabs for full deep-dive */}
      <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
        <TabsList className="flex w-full md:grid md:grid-cols-6 h-auto overflow-x-auto no-scrollbar gap-1">
          <TabsTrigger value="overview" className="text-xs shrink-0 px-3">Overview</TabsTrigger>
          <TabsTrigger value="analytics" className="text-xs shrink-0 px-3">Analytics</TabsTrigger>
          <TabsTrigger value="vulnerabilities" className="text-xs shrink-0 px-3">
            Vulns
            {result.stats.vulnerableCount > 0 && (
              <span className="ml-1.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white">
                {result.stats.vulnerableCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="outdated" className="text-xs shrink-0 px-3">
            Outdated
            {result.stats.outdatedCount > 0 && (
              <span className="ml-1.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-blue-500 px-1 text-[10px] font-bold text-white">
                {result.stats.outdatedCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="all" className="text-xs shrink-0 px-3">All Pkgs</TabsTrigger>
          <TabsTrigger value="upgrade" className="text-xs shrink-0 px-3">Upgrade</TabsTrigger>
        </TabsList>

        {/* Overview tab */}
        <TabsContent value="overview" className="mt-3">
          <Card>
            <CardContent className="pt-4">
              <h4 className="text-sm font-semibold mb-3">Audit Summary</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div className="rounded-md border bg-card p-2.5">
                  <p className="text-[10px] text-muted-foreground uppercase">Total</p>
                  <p className="text-lg font-bold">{result.stats.totalPackages}</p>
                </div>
                <div className="rounded-md border bg-card p-2.5">
                  <p className="text-[10px] text-muted-foreground uppercase">Vulnerable</p>
                  <p className={cn("text-lg font-bold", result.stats.vulnerableCount > 0 ? "text-red-500" : "text-emerald-500")}>{result.stats.vulnerableCount}</p>
                </div>
                <div className="rounded-md border bg-card p-2.5">
                  <p className="text-[10px] text-muted-foreground uppercase">Outdated</p>
                  <p className={cn("text-lg font-bold", result.stats.outdatedCount > 0 ? "text-blue-500" : "text-emerald-500")}>{result.stats.outdatedCount}</p>
                </div>
                <div className="rounded-md border bg-card p-2.5">
                  <p className="text-[10px] text-muted-foreground uppercase">Clean</p>
                  <p className="text-lg font-bold text-emerald-500">{result.stats.totalPackages - result.stats.vulnerableCount - result.stats.outdatedCount}</p>
                </div>
              </div>
              {result.stats.vulnerableCount === 0 && result.stats.outdatedCount === 0 && (
                <div className="flex items-center gap-2 rounded-md border border-emerald-500/30 bg-emerald-500/5 p-3 mt-3">
                  <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                  <p className="text-sm text-emerald-600 dark:text-emerald-400 font-medium">
                    All {result.stats.totalPackages} packages are up to date with no known vulnerabilities. 🎉
                  </p>
                </div>
              )}
              <div className="mt-4">
                <p className="text-[10px] text-muted-foreground uppercase mb-1.5">Sources</p>
                <p className="text-xs">
                  <span className="text-emerald-600">live: {result.stats.sources.live}</span>
                  {" · "}
                  <span className="text-amber-600">fallback: {result.stats.sources.fallback}</span>
                  {" · "}
                  <span className="text-red-600">error: {result.stats.sources.error}</span>
                  {" · "}
                  <span className="text-muted-foreground">took {(result.durationMs / 1000).toFixed(2)}s</span>
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics tab — charts and visualizations */}
        <TabsContent value="analytics" className="mt-3 space-y-4">
          <AnalyticsDashboard result={result} />
        </TabsContent>

        {/* Vulnerabilities tab */}
        <TabsContent value="vulnerabilities" className="mt-3">
          <Card>
            <CardContent className="pt-4">
              <VulnerabilityTable packages={result.packages} onSelect={onPkgSelect} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Outdated tab */}
        <TabsContent value="outdated" className="mt-3">
          <Card>
            <CardContent className="pt-4">
              <OutdatedTable packages={result.packages} onSelect={onPkgSelect} onCompare={onCompare} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* All packages tab */}
        <TabsContent value="all" className="mt-3">
          <Card>
            <CardContent className="pt-4">
              <AllPackagesTable packages={result.packages} onSelect={onPkgSelect} onCompare={onCompare} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Upgrade tab */}
        <TabsContent value="upgrade" className="mt-3">
          <UpgradeGenerator result={result} />
        </TabsContent>
      </Tabs>

      {/* Package detail dialog — opens when user clicks a package */}
      <PackageDetailDialog pkg={selectedPkg} open={dialogOpen} onOpenChange={setDialogOpen} />

      {/* Version compare dialog — opens when user clicks "Compare" */}
      <VersionCompareDialog pkg={comparePkg} open={compareOpen} onOpenChange={setCompareOpen} />
    </div>
  );
}
