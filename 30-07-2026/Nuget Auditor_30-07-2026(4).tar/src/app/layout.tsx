import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "next-themes";
import { ServiceWorkerRegister } from "@/components/nuget/sw-register";
import { StructuredData } from "@/components/nuget/structured-data";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://nuget-auditor.example.com"),
  title: {
    default: "NuGet Visualizer & Auditor — Scan .csproj for Vulnerabilities",
    template: "%s | NuGet Auditor",
  },
  description:
    "Free online tool to parse .csproj files, visualize NuGet dependency trees, and audit packages for security vulnerabilities, outdated versions, and license compliance. No signup required.",
  keywords: [
    "NuGet audit",
    "csproj analyzer",
    "NuGet vulnerability scanner",
    "dependency tree visualizer",
    "NuGet package security",
    "outdated NuGet packages",
    ".NET security audit",
    "NuGet compliance check",
    "csproj parser online",
    "NuGet dependency graph",
    "ASP.NET Core security",
    "NuGet CVE checker",
  ],
  authors: [{ name: "0xz.0nfirex" }],
  creator: "0xz.0nfirex",
  publisher: "0xz.0nfirex",
  icons: {
    icon: "/icon.svg",
    apple: "/icon.svg",
  },
  openGraph: {
    title: "NuGet Visualizer & Auditor — Scan .csproj for Vulnerabilities",
    description:
      "Parse .csproj files, visualize dependency trees, and audit NuGet packages for vulnerabilities, outdated versions, and license compliance. Free, no signup.",
    type: "website",
    locale: "en_US",
    siteName: "NuGet Auditor",
    images: [
      {
        url: "/icon.svg",
        width: 64,
        height: 64,
        alt: "NuGet Auditor — Dependency security scanner",
      },
    ],
  },
  twitter: {
    card: "summary",
    title: "NuGet Visualizer & Auditor",
    description:
      "Parse .csproj files, visualize dependency trees, and audit NuGet packages for vulnerabilities. Free online tool.",
    images: ["/icon.svg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: "/",
  },
  category: "developer tools",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "NuGet Auditor",
  },
};

export const viewport: Viewport = {
  themeColor: "#6366f1",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <StructuredData />
        <ServiceWorkerRegister />
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <SonnerToaster richColors closeButton position="bottom-right" />
        </ThemeProvider>
      </body>
    </html>
  );
}
