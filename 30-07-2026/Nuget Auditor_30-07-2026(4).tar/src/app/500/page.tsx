import { ViralErrorPage } from "@/components/nuget/viral-error-page";

export default function Page500() {
  return <ViralErrorPage statusCode={500} />;
}
