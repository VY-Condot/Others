"use client";

import { useState, useCallback, useEffect } from "react";
import { EyeOff, Eye, X, Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "nuget-auditor-ignore-list";

interface Props {
  onIgnoreChange?: (ignored: Set<string>) => void;
}

/**
 * Package ignore list — users can suppress specific packages from the audit
 * (e.g. internal packages, packages they can't upgrade). The list persists
 * in localStorage and is applied to the audit result display.
 */
export function IgnoreListButton({ onIgnoreChange }: Props) {
  const [open, setOpen] = useState(false);
  const [ignored, setIgnored] = useState<Set<string>>(new Set());
  const [input, setInput] = useState("");

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setIgnored(new Set(JSON.parse(stored)));
      }
    } catch { }
  }, []);

  const persist = useCallback((set: Set<string>) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...set]));
    onIgnoreChange?.(set);
  }, [onIgnoreChange]);

  const addIgnore = () => {
    const id = input.trim();
    if (!id) return;
    const next = new Set(ignored);
    next.add(id);
    setIgnored(next);
    persist(next);
    setInput("");
    toast.success(`"${id}" added to ignore list`);
  };

  const removeIgnore = (id: string) => {
    const next = new Set(ignored);
    next.delete(id);
    setIgnored(next);
    persist(next);
    toast.success(`"${id}" removed from ignore list`);
  };

  const clearAll = () => {
    setIgnored(new Set());
    persist(new Set());
    toast.success("Ignore list cleared");
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="text-xs gap-1.5"
        onClick={() => setOpen(true)}
      >
        <Settings2 className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Ignore list</span>
        {ignored.size > 0 && (
          <Badge variant="secondary" className="text-[9px] h-4 px-1">{ignored.size}</Badge>
        )}
      </Button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setOpen(false)}>
          <div className="bg-background border rounded-lg p-5 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <EyeOff className="h-4 w-4" />
                Package Ignore List
              </h3>
              <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              Packages in this list are hidden from audit results. Useful for internal packages or packages you can&apos;t upgrade.
            </p>
            <div className="flex gap-2 mb-3">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addIgnore()}
                placeholder="Package ID (e.g. Microsoft.Extensions.Logging)"
                className="text-xs"
              />
              <Button size="sm" onClick={addIgnore} disabled={!input.trim()}>Add</Button>
            </div>
            {ignored.size > 0 ? (
              <div className="space-y-1.5 max-h-[300px] overflow-y-auto">
                {[...ignored].sort().map((id) => (
                  <div key={id} className="flex items-center justify-between rounded-md border px-2 py-1.5 text-xs">
                    <span className="font-mono truncate">{id}</span>
                    <button onClick={() => removeIgnore(id)} className="text-muted-foreground hover:text-red-500 shrink-0 ml-2">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
                <button onClick={clearAll} className="w-full text-xs text-red-500 hover:text-red-600 pt-2">
                  Clear all
                </button>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground text-center py-4">No packages ignored yet.</p>
            )}
          </div>
        </div>
      )}
    </>
  );
}
