export function NotFoundPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-background to-purple-950/20 px-4 text-center">
      <div className="text-[8rem] md:text-[12rem] font-black leading-none bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 bg-clip-text text-transparent animate-fade-up">
        404
      </div>
      <h2 className="text-2xl md:text-3xl font-bold mt-4 animate-fade-up" style={{ animationDelay: "60ms" }}>
        Bro really got lost 💀
      </h2>
      <p className="text-muted-foreground mt-4 max-w-md animate-fade-up" style={{ animationDelay: "120ms" }}>
        This page left the group chat. You had ONE job: type a valid URL.
      </p>
      <div className="flex gap-3 mt-8 animate-fade-up" style={{ animationDelay: "180ms" }}>
        <a href="/" className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg font-medium hover:opacity-90 transition-opacity">
          Take me home (I'm lost)
        </a>
      </div>
      <div className="mt-12 grid grid-cols-3 gap-2 max-w-md animate-fade-up" style={{ animationDelay: "240ms" }}>
        <div className="border rounded-lg p-2">
          <p className="text-lg font-bold">∞</p>
          <p className="text-[10px] text-muted-foreground">pages missing</p>
        </div>
        <div className="border rounded-lg p-2">
          <p className="text-lg font-bold">0</p>
          <p className="text-[10px] text-muted-foreground">pages found</p>
        </div>
        <div className="border rounded-lg p-2">
          <p className="text-lg font-bold">1</p>
          <p className="text-[10px] text-muted-foreground">user disappointed</p>
        </div>
      </div>
    </div>
  );
}
