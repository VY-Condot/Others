"use client";

import { useState, useMemo } from "react";
import { Award, Copy, Check, Download, Share2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api-fetch";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

/**
 * Badge Generator — creates a shareable SVG health score badge that users
 * can embed in their GitHub README, project page, or website. This drives
 * viral adoption: every project showing the badge is free advertising for
 * the NuGet Auditor.
 */
export function BadgeGenerator({ result }: Props) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [sharing, setSharing] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);

  const { score, grade, color, label } = useMemo(() => {
    const s = result.stats;
    let sc = 100;
    if (s.maxSeverity) {
      const pen = { low: 8, moderate: 18, high: 35, critical: 60 }[s.maxSeverity] ?? 0;
      sc -= pen;
    }
    sc -= Math.max(0, s.vulnerableCount - 1) * 6;
    if (s.totalPackages > 0) sc -= Math.round((s.outdatedCount / s.totalPackages) * 25);
    sc -= s.deprecatedCount * 4;
    sc = Math.max(0, Math.min(100, sc));

    const g = sc >= 90 ? "A" : sc >= 75 ? "B" : sc >= 60 ? "C" : sc >= 40 ? "D" : "F";
    const c = sc >= 90 ? "#10b981" : sc >= 75 ? "#84cc16" : sc >= 60 ? "#eab308" : sc >= 40 ? "#f97316" : "#ef4444";
    const l = sc >= 90 ? "excellent" : sc >= 75 ? "good" : sc >= 60 ? "fair" : sc >= 40 ? "at risk" : "critical";
    return { score: sc, grade: g, color: c, label: l };
  }, [result]);

  const badgeSvg = useMemo(() => {
    // GitHub-style badge SVG (shields.io compatible look)
    const leftWidth = 90;
    const rightWidth = 70;
    const totalWidth = leftWidth + rightWidth;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${totalWidth}" height="20" role="img" aria-label="NuGet audit: ${grade} (${score}/100)">
  <linearGradient id="s" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <clipPath id="r"><rect width="${totalWidth}" height="20" rx="3" fill="#fff"/></clipPath>
  <g clip-path="url(#r)">
    <rect width="${leftWidth}" height="20" fill="#4a4a4a"/>
    <rect x="${leftWidth}" width="${rightWidth}" height="20" fill="${color}"/>
    <rect width="${totalWidth}" height="20" fill="url(#s)"/>
  </g>
  <g fill="#fff" text-anchor="middle" font-family="Verdana,DejaVu Sans,sans-serif" font-size="11">
    <text x="${leftWidth / 2}" y="14">NuGet audit</text>
    <text x="${leftWidth + rightWidth / 2}" y="14">${grade} · ${score}/100</text>
  </g>
</svg>`;
  }, [grade, score, color]);

  const markdown = `[![NuGet Audit](${shareUrl ?? "https://nuget-auditor.example.com/badge.svg"})](https://nuget-auditor.example.com)`;
  const html = `<a href="https://nuget-auditor.example.com"><img src="${shareUrl ?? "https://nuget-auditor.example.com/badge.svg"}" alt="NuGet Audit: ${grade} (${score}/100)" /></a>`;

  const copy = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(null), 1500);
    } catch {
      toast.error("Copy failed");
    }
  };

  const downloadSvg = () => {
    const blob = new Blob([badgeSvg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "nuget-audit-badge.svg";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Badge SVG downloaded");
  };

  const shareBadge = async () => {
    setSharing(true);
    try {
      const res = await apiFetch("/api/share", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result }),
      });
      const data = await res.json();
      if (data.ok) {
        setShareUrl(`${window.location.origin}/api/badge?id=${data.id}`);
        toast.success("Shareable badge URL created!");
      }
    } catch {
      toast.error("Failed to create shareable badge");
    } finally {
      setSharing(false);
    }
  };

  return (
    <>
      <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={() => setOpen(true)}>
        <Award className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Badge</span>
      </Button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setOpen(false)}>
          <div className="bg-background border rounded-lg p-6 max-w-lg w-full max-h-[85vh] overflow-y-auto custom-scroll" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold flex items-center gap-2">
                <Award className="h-4 w-4" />
                Health Score Badge
              </h3>
              <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>

            <p className="text-xs text-muted-foreground mb-4">
              Show off your project&apos;s dependency health! Embed this badge in your GitHub README, website, or documentation. Every badge links back to the NuGet Auditor — spreading the word.
            </p>

            {/* Badge preview */}
            <div className="rounded-lg border bg-muted/20 p-6 text-center mb-4">
              <div className="inline-block" dangerouslySetInnerHTML={{ __html: badgeSvg }} />
              <p className="text-[10px] text-muted-foreground mt-2">Grade {grade} · {score}/100 · {label}</p>
            </div>

            {/* Actions */}
            <div className="flex gap-2 mb-4">
              <Button variant="outline" size="sm" className="flex-1" onClick={downloadSvg}>
                <Download className="h-3.5 w-3.5" /> Download SVG
              </Button>
              <Button variant="outline" size="sm" className="flex-1" onClick={shareBadge} disabled={sharing}>
                {sharing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Share2 className="h-3.5 w-3.5" />}
                Create share link
              </Button>
            </div>

            {shareUrl && (
              <div className="rounded-md border bg-emerald-500/5 p-2.5 mb-4">
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 mb-1">✓ Shareable badge URL created!</p>
                <code className="text-[10px] font-mono break-all">{shareUrl}</code>
              </div>
            )}

            {/* Code snippets */}
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <p className="text-[10px] font-semibold uppercase text-muted-foreground">Markdown (GitHub README)</p>
                  <button onClick={() => copy("md", shareUrl ? `[![NuGet Audit](${shareUrl})](https://nuget-auditor.example.com)` : markdown)} className="text-xs text-primary hover:underline">
                    {copied === "md" ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                  </button>
                </div>
                <pre className="text-[10px] font-mono p-2 rounded-md border bg-muted/40 overflow-x-auto">{shareUrl ? `[![NuGet Audit](${shareUrl})](https://nuget-auditor.example.com)` : markdown}</pre>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <p className="text-[10px] font-semibold uppercase text-muted-foreground">HTML</p>
                  <button onClick={() => copy("html", shareUrl ? `<a href="https://nuget-auditor.example.com"><img src="${shareUrl}" alt="NuGet Audit" /></a>` : html)} className="text-xs text-primary hover:underline">
                    {copied === "html" ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                  </button>
                </div>
                <pre className="text-[10px] font-mono p-2 rounded-md border bg-muted/40 overflow-x-auto">{shareUrl ? `<a href="https://nuget-auditor.example.com"><img src="${shareUrl}" alt="NuGet Audit" /></a>` : html}</pre>
              </div>
            </div>

            <p className="text-[10px] text-muted-foreground mt-4 text-center">
              💡 Tip: Add the badge to your README to show your project takes dependency security seriously.
            </p>
          </div>
        </div>
      )}
    </>
  );
}
