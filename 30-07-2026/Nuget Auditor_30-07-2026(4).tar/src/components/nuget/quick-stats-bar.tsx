"use client";

import { TrendingUp, ShieldCheck, AlertTriangle, Package, Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

/**
 * Quick stats summary bar — shows the most important health metrics in a
 * compact horizontal strip with trend indicators. Designed for at-a-glance
 * scanning before diving into details.
 */
export function QuickStatsBar({ result }: Props) {
  const { stats } = result;
  const healthScore = Math.max(0, Math.min(100,
    100 - (stats.maxSeverity === "critical" ? 60 : stats.maxSeverity === "high" ? 35 : stats.maxSeverity === "moderate" ? 18 : stats.maxSeverity === "low" ? 8 : 0)
    - Math.max(0, stats.vulnerableCount - 1) * 6
    - Math.round((stats.outdatedCount / Math.max(1, stats.totalPackages)) * 25)
    - stats.deprecatedCount * 4
  ));

  const grade = healthScore >= 90 ? "A" : healthScore >= 75 ? "B" : healthScore >= 60 ? "C" : healthScore >= 40 ? "D" : "F";
  const gradeColor = healthScore >= 90 ? "text-emerald-500" : healthScore >= 75 ? "text-lime-500" : healthScore >= 60 ? "text-yellow-500" : healthScore >= 40 ? "text-orange-500" : "text-red-500";

  const items = [
    { icon: Activity, label: "Health", value: `${grade} (${healthScore})`, color: gradeColor },
    { icon: Package, label: "Packages", value: stats.totalPackages, color: "text-primary" },
    { icon: AlertTriangle, label: "Vulnerable", value: stats.vulnerableCount, color: stats.vulnerableCount > 0 ? "text-red-500" : "text-emerald-500" },
    { icon: TrendingUp, label: "Outdated", value: stats.outdatedCount, color: stats.outdatedCount > 0 ? "text-blue-500" : "text-emerald-500" },
    { icon: ShieldCheck, label: "Clean", value: stats.totalPackages - stats.vulnerableCount - stats.outdatedCount, color: "text-emerald-500" },
  ];

  return (
    <div className="flex items-center gap-4 rounded-lg border bg-card px-4 py-2.5 overflow-x-auto no-scrollbar">
      {items.map((item, i) => (
        <div key={item.label} className="flex items-center gap-2 shrink-0">
          {i > 0 && <div className="h-6 w-px bg-border mr-2" />}
          <item.icon className={cn("h-4 w-4", item.color)} />
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide leading-none">{item.label}</p>
            <p className={cn("text-sm font-bold tabular-nums leading-tight", item.color)}>{item.value}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
