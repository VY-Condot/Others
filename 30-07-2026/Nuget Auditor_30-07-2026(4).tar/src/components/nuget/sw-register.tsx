"use client";

import { useEffect } from "react";

/**
 * Registers the service worker for PWA offline support.
 * Only runs in production to avoid caching issues during development.
 */
export function ServiceWorkerRegister() {
  useEffect(() => {
    if (
      typeof window !== "undefined" &&
      "serviceWorker" in navigator &&
      process.env.NODE_ENV === "production"
    ) {
      navigator.serviceWorker
        .register("/sw.js")
        .then(() => {
          // SW registered successfully
        })
        .catch(() => {
          // SW registration failed — app still works online
        });
    }
  }, []);

  return null;
}
