"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { Home, RotateCcw, Skull, Sparkles, Zap, AlertOctagon, ServerCrash, Ban, CloudOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ErrorConfig {
  code: number;
  emoji: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  glow: string;
  messages: string[];
  terminalLines: string[];
}

const ERROR_CONFIGS: Record<number, ErrorConfig> = {
  404: {
    code: 404,
    emoji: "👻",
    title: "Page Not Found",
    icon: Skull,
    color: "#a855f7",
    glow: "rgba(168, 85, 247, 0.15)",
    messages: [
      "Bro really typed a URL that doesn't exist 💀",
      "This page left the group chat.",
      "404: Page found asleep. It's not coming to work today.",
      "This page is in another castle... just kidding, it's just gone.",
      "Error 404: The page you're looking for is as real as your CSS centering skills.",
      "This page took an L and isn't coming back.",
      "Skill issue detected: you navigated to nowhere.",
      "The page? Gone. The consequences? Eternal.",
    ],
    terminalLines: [
      "FATAL: PageNotFoundException",
      '  at Router.match("/unknown")',
      '  at User.navigateTo("where am I?")',
      "  → Suggestion: Check your URL or go home",
    ],
  },
  500: {
    code: 500,
    emoji: "🔥",
    title: "Server on Fire",
    icon: ServerCrash,
    color: "#ef4444",
    glow: "rgba(239, 68, 68, 0.15)",
    messages: [
      "The server caught fire. We're putting it out. 🔥",
      "Something broke on our end. It's not you, it's us. For real this time.",
      "The server said 'nah, I'm done' and walked out.",
      "500: Server.exe has entered witness protection.",
      "Our servers are having an existential crisis.",
    ],
    terminalLines: [
      "ERROR 500: InternalServerError",
      "  at Server.handleRequest()",
      "  at Database.query() ← things got spicy here",
      "  → Don't worry, we've been notified",
    ],
  },
  501: {
    code: 501,
    emoji: "🚧",
    title: "Not Implemented",
    icon: Ban,
    color: "#eab308",
    glow: "rgba(234, 179, 8, 0.15)",
    messages: [
      "We haven't built this yet. It's on the roadmap. Probably.",
      "501: This feature exists in our dreams, not in production.",
      "You found a feature that's still in the 'good idea' phase.",
      "Not implemented. But hey, great ideas start somewhere!",
      "This is a 'future us' problem. Future us is not ready.",
    ],
    terminalLines: [
      "NOT_IMPLEMENTED 501",
      "  at Feature.request()",
      "  → Status: TODO (since forever)",
    ],
  },
  502: {
    code: 502,
    emoji: "🌉",
    title: "Bad Gateway",
    icon: CloudOff,
    color: "#f97316",
    glow: "rgba(249, 115, 22, 0.15)",
    messages: [
      "The gateway is down. It forgot its keys.",
      "502: The middleman ghosted both of us.",
      "Bad gateway? More like bad day-way.",
      "Our servers and the internet are not talking right now.",
      "The connection between services is having a therapy session.",
    ],
    terminalLines: [
      "BAD_GATEWAY 502",
      "  at Gateway.proxy()",
      "  at UpstreamService.respond() ← ghosted",
      "  → Try again in a moment",
    ],
  },
  503: {
    code: 503,
    emoji: "💤",
    title: "Service Unavailable",
    icon: AlertOctagon,
    color: "#3b82f6",
    glow: "rgba(59, 130, 246, 0.15)",
    messages: [
      "The service is taking a nap. Try again in a bit. 💤",
      "503: We're overwhelmed. Like, genuinely. Please give us a moment.",
      "Service unavailable. It's not you. It's traffic.",
      "Our servers need a break. They've been carrying the whole app.",
      "Temporarily down for vibes maintenance.",
    ],
    terminalLines: [
      "SERVICE_UNAVAILABLE 503",
      "  at LoadBalancer.check()",
      "  → Status: overloaded, please retry",
    ],
  },
};

export function ViralErrorPage({ statusCode = 500 }: { statusCode?: number }) {
  const router = useRouter();
  const config = ERROR_CONFIGS[statusCode] ?? ERROR_CONFIGS[500];
  const Icon = config.icon;

  const [message, setMessage] = useState(config.messages[0]);
  const [glitch, setGlitch] = useState(false);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; size: number; delay: number; duration: number }>>([]);
  const [typedText, setTypedText] = useState("");
  const terminalRef = useRef<string>("");

  useEffect(() => {
    setMessage(config.messages[Math.floor(Math.random() * config.messages.length)]);

    // Generate floating particles
    setParticles(
      Array.from({ length: 15 }, (_, i) => ({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: 2 + Math.random() * 6,
        delay: Math.random() * 5,
        duration: 3 + Math.random() * 5,
      })),
    );

    // Glitch effect loop
    const glitchInterval = setInterval(() => {
      setGlitch(true);
      setTimeout(() => setGlitch(false), 150);
    }, 3000);

    // Typewriter effect for terminal
    terminalRef.current = config.terminalLines.join("\n");
    let charIndex = 0;
    const typeInterval = setInterval(() => {
      if (charIndex <= terminalRef.current.length) {
        setTypedText(terminalRef.current.slice(0, charIndex));
        charIndex++;
      } else {
        clearInterval(typeInterval);
      }
    }, 25);

    return () => {
      clearInterval(glitchInterval);
      clearInterval(typeInterval);
    };
  }, [config]);

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden px-4"
      style={{ background: `radial-gradient(ellipse at center, ${config.glow} 0%, transparent 70%)` }}
    >
      {/* Floating particles */}
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full pointer-events-none animate-float"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background: config.color,
            opacity: 0.15,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
          }}
        />
      ))}

      {/* Grid background */}
      <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />

      {/* Glow orb */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl pointer-events-none"
        style={{ width: 400, height: 400, background: config.glow }}
      />

      <div className="relative z-10 text-center max-w-2xl">
        {/* Glitch status code */}
        <div className="relative mb-2">
          <h1
            className="text-[7rem] md:text-[11rem] font-black leading-none tracking-tighter transition-all"
            style={{
              color: glitch ? "transparent" : config.color,
              textShadow: glitch
                ? `2px 0 ${config.color}, -2px 0 #ec4899, 0 0 20px ${config.glow}`
                : `0 0 40px ${config.glow}`,
              transform: glitch ? "skewX(2deg)" : "none",
            }}
          >
            {statusCode}
          </h1>
          {glitch && (
            <h1
              className="absolute inset-0 text-[7rem] md:text-[11rem] font-black leading-none tracking-tighter opacity-60"
              style={{ color: "#ec4899", transform: "skewX(-1deg) translateX(3px)" }}
            >
              {statusCode}
            </h1>
          )}
        </div>

        {/* Emoji bounce */}
        <div className="text-5xl mb-3 animate-float" style={{ animationDuration: "2s" }}>
          {config.emoji}
        </div>

        {/* Title with icon */}
        <div className="flex items-center justify-center gap-2 mb-3">
          <Icon className="h-5 w-5" style={{ color: config.color }} />
          <h2 className="text-xl md:text-2xl font-bold">{config.title}</h2>
        </div>

        {/* Sarcastic message */}
        <p className="text-base text-muted-foreground mt-2 max-w-md mx-auto leading-relaxed">
          {message}
        </p>

        {/* Terminal-style error log with typewriter effect */}
        <div className="mt-6 rounded-lg border bg-card/80 backdrop-blur p-4 font-mono text-xs text-left max-w-md mx-auto">
          <div className="flex items-center gap-1.5 mb-2 pb-2 border-b">
            <span className="h-2.5 w-2.5 rounded-full bg-red-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-yellow-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
            <span className="ml-2 text-muted-foreground">error_{statusCode}.log</span>
          </div>
          <pre className="text-muted-foreground whitespace-pre-wrap">
            <span style={{ color: config.color }}>{typedText}</span>
            <span className="animate-pulse">▊</span>
          </pre>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
          <Button
            size="lg"
            className="text-white border-0 shadow-lg"
            style={{ background: `linear-gradient(135deg, ${config.color}, #ec4899)` }}
            onClick={() => router.push("/")}
          >
            <Home className="h-4 w-4 mr-2" />
            Take me home
          </Button>
          <Button size="lg" variant="outline" onClick={() => router.refresh()}>
            <RotateCcw className="h-4 w-4 mr-2" />
            Try again (it might work)
          </Button>
        </div>

        {/* Share-worthy stat */}
        <div className="mt-10 flex items-center justify-center gap-6 text-xs text-muted-foreground">
          <div className="text-center">
            <p className="text-lg font-bold" style={{ color: config.color }}>∞</p>
            <p className="text-[10px]">pages like this</p>
          </div>
          <div className="h-8 w-px bg-border" />
          <div className="text-center">
            <p className="text-lg font-bold" style={{ color: config.color }}>0</p>
            <p className="text-[10px]">that were found</p>
          </div>
          <div className="h-8 w-px bg-border" />
          <div className="text-center">
            <p className="text-lg font-bold" style={{ color: config.color }}>1</p>
            <p className="text-[10px]">user disappointed</p>
          </div>
        </div>

        {/* Footer sass */}
        <p className="mt-6 text-[10px] text-muted-foreground/50">
          <Sparkles className="inline h-2.5 w-2.5 mr-1" />
          Screenshot this and send it to your friends. They'll think you broke the internet.
        </p>
      </div>
    </div>
  );
}
