"use client";

import { Download, FileJson } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
}

export function ExportJsonButton({ result }: Props) {
  const exportJson = () => {
    const exportData = {
      projectName: result.parsed.projectName,
      sdk: result.parsed.sdk,
      targetFrameworks: result.parsed.targetFrameworks,
      generatedAt: result.generatedAt,
      stats: result.stats,
      packages: result.packages.map((p) => ({
        id: p.id,
        declaredVersion: p.declaredVersion,
        latestStableVersion: p.latestStableVersion,
        isOutdated: p.isOutdated,
        isVulnerable: p.isVulnerable,
        isDeprecated: p.isDeprecated,
        maxSeverity: p.maxSeverity,
        licenseCategory: p.licenseCategory,
        vulnerabilities: p.vulnerabilities,
      })),
    };
    const json = JSON.stringify(exportData, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${result.parsed.projectName ?? "audit"}-${new Date().toISOString().split("T")[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Audit exported as JSON");
  };

  return (
    <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={exportJson}>
      <FileJson className="h-3.5 w-3.5" />
      <span className="hidden sm:inline">Export JSON</span>
    </Button>
  );
}
