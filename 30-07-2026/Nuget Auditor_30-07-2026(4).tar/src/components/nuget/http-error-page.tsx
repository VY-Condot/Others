"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Home, RotateCcw, AlertTriangle, Server, Wrench, CloudOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ErrorVariant {
  statusCode: number;
  title: string;
  emoji: string;
  messages: string[];
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgGradient: string;
}

const ERROR_VARIANTS: Record<number, ErrorVariant> = {
  500: {
    statusCode: 500,
    title: "Internal Server Error",
    emoji: "🔥",
    icon: Server,
    color: "text-red-500",
    bgGradient: "from-red-500/10 via-orange-500/5 to-transparent",
    messages: [
      "The server caught fire. We're putting it out. 🔥",
      "Something broke on our end. It's not you, it's us. For real this time.",
      "The server said 'nah, I'm done' and walked out.",
      "500: Server.exe has entered witness protection.",
      "Our servers are having an existential crisis.",
    ],
  },
  501: {
    statusCode: 501,
    title: "Not Implemented",
    emoji: "🚧",
    icon: Wrench,
    color: "text-yellow-500",
    bgGradient: "from-yellow-500/10 via-amber-500/5 to-transparent",
    messages: [
      "We haven't built this yet. It's on the roadmap. Probably.",
      "501: This feature exists in our dreams, not in production.",
      "You found a feature that's still in the 'good idea' phase.",
      "Not implemented. But hey, great ideas start somewhere!",
      "This is a 'future us' problem. Future us is not ready.",
    ],
  },
  502: {
    statusCode: 502,
    title: "Bad Gateway",
    emoji: " Gateway timeout",
    icon: CloudOff,
    color: "text-orange-500",
    bgGradient: "from-orange-500/10 via-amber-500/5 to-transparent",
    messages: [
      "The gateway is down. It forgot its keys.",
      "502: The middleman ghosted both of us.",
      "Bad gateway? More like bad day-way.",
      "Our servers and the internet are not talking right now.",
      "The connection between services is having a therapy session.",
    ],
  },
  503: {
    statusCode: 503,
    title: "Service Unavailable",
    emoji: "💤",
    icon: AlertTriangle,
    color: "text-blue-500",
    bgGradient: "from-blue-500/10 via-indigo-500/5 to-transparent",
    messages: [
      "The service is taking a nap. Try again in a bit. 💤",
      "503: We're overwhelmed. Like, genuinely. Please give us a moment.",
      "Service unavailable. It's not you. It's traffic.",
      "Our servers need a break. They've been carrying the whole app.",
      "Temporarily down for vibes maintenance.",
    ],
  },
};

export function HttpErrorPage({ statusCode = 500 }: { statusCode?: number }) {
  const router = useRouter();
  const [message, setMessage] = useState("");
  const variant = ERROR_VARIANTS[statusCode] ?? ERROR_VARIANTS[500];
  const Icon = variant.icon;

  useEffect(() => {
     
    setMessage(variant.messages[Math.floor(Math.random() * variant.messages.length)]);
  }, [variant]);

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-br ${variant.bgGradient} px-4`}>
      {/* Grid background */}
      <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />

      {/* Floating orbs */}
      <div className={`absolute -top-24 -right-24 h-72 w-72 rounded-full ${variant.color.replace("text-", "bg-")}/10 blur-3xl pointer-events-none`} />
      <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-muted/10 blur-3xl pointer-events-none" />

      <div className="relative z-10 text-center max-w-2xl">
        {/* Status code */}
        <div className="flex items-center justify-center gap-3 mb-2">
          <Icon className={`h-12 w-12 ${variant.color}`} />
          <h1 className={`text-[6rem] md:text-[9rem] font-black leading-none ${variant.color}`}>
            {statusCode}
          </h1>
        </div>

        {/* Emoji */}
        <div className="text-5xl mb-4">{variant.emoji}</div>

        {/* Title */}
        <h2 className="text-xl md:text-2xl font-bold">
          {variant.title}
        </h2>

        {/* Sarcastic message */}
        <p className="text-base text-muted-foreground mt-3 max-w-md mx-auto leading-relaxed">
          {message}
        </p>

        {/* Terminal-style error */}
        <div className="mt-6 rounded-lg border bg-card/80 backdrop-blur p-4 font-mono text-xs text-left max-w-md mx-auto">
          <div className="flex items-center gap-1.5 mb-2 pb-2 border-b">
            <span className="h-2.5 w-2.5 rounded-full bg-red-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-yellow-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
            <span className="ml-2 text-muted-foreground">server.log</span>
          </div>
          <p className={variant.color}>ERROR {statusCode}: {variant.title}</p>
          <p className="text-muted-foreground">  at Server.handleRequest()</p>
          <p className="text-muted-foreground">  at Router.dispatch()</p>
          <p className="text-yellow-500">  → Don't worry, we've been notified</p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
          <Button
            size="lg"
            className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white border-0"
            onClick={() => router.push("/")}
          >
            <Home className="h-4 w-4 mr-2" />
            Go home
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => router.refresh()}
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Try again
          </Button>
        </div>

        {/* Footer text */}
        <p className="mt-8 text-[11px] text-muted-foreground">
          If this keeps happening, <a href="/feedback" className="text-primary hover:underline">tell us about it</a>.
        </p>
      </div>
    </div>
  );
}
