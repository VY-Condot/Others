"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ArrowRight,
  Plus,
  Minus,
  ArrowUpCircle,
  ArrowDownCircle,
  ShieldCheck,
  ShieldAlert,
  TrendingUp,
  TrendingDown,
  Minus as NoChange,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api-fetch";

interface DiffEntry {
  id: string;
  kind: "added" | "removed" | "upgraded" | "downgraded" | "unchanged" | "vuln-fixed" | "vuln-introduced";
  fromVersion?: string;
  toVersion?: string;
  fromVulnerable?: boolean;
  toVulnerable?: boolean;
  fromOutdated?: boolean;
  toOutdated?: boolean;
}

interface DiffSummary {
  added: number;
  removed: number;
  upgraded: number;
  downgraded: number;
  unchanged: number;
  vulnFixed: number;
  vulnIntroduced: number;
  healthScoreA: number;
  healthScoreB: number;
  scoreDelta: number;
  projectNameA: string;
  projectNameB: string;
  createdAtA: string;
  createdAtB: string;
  outdatedA: number;
  outdatedB: number;
  vulnerableA: number;
  vulnerableB: number;
}

interface Run {
  id: string;
  projectName: string;
  createdAt: string;
  healthScore: number;
  totalPackages: number;
  outdatedCount: number;
  vulnerableCount: number;
}

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  runs: Run[];
  preselect?: { a?: string; b?: string };
}

const KIND_META: Record<DiffEntry["kind"], { label: string; icon: React.ComponentType<{ className?: string }>; color: string; bg: string }> = {
  added: { label: "Added", icon: Plus, color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500/10" },
  removed: { label: "Removed", icon: Minus, color: "text-red-600 dark:text-red-400", bg: "bg-red-500/10" },
  upgraded: { label: "Upgraded", icon: ArrowUpCircle, color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-500/10" },
  downgraded: { label: "Downgraded", icon: ArrowDownCircle, color: "text-orange-600 dark:text-orange-400", bg: "bg-orange-500/10" },
  "vuln-fixed": { label: "Vuln fixed", icon: ShieldCheck, color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500/10" },
  "vuln-introduced": { label: "Vuln introduced", icon: ShieldAlert, color: "text-red-600 dark:text-red-400", bg: "bg-red-500/10" },
  unchanged: { label: "Unchanged", icon: NoChange, color: "text-muted-foreground", bg: "bg-muted/30" },
};

export function AuditDiffView({ open, onOpenChange, runs, preselect }: Props) {
  const [aId, setAId] = useState<string>("");
  const [bId, setBId] = useState<string>("");
  const [diff, setDiff] = useState<{ entries: DiffEntry[]; summary: DiffSummary } | null>(null);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<"all" | "changes">("changes");

  useEffect(() => {
    if (open && runs.length >= 2) {
      setAId(preselect?.a ?? runs[runs.length - 1]?.id ?? "");
      setBId(preselect?.b ?? runs[0]?.id ?? "");
    }
  }, [open, runs, preselect]);

  const computeDiff = useCallback(async () => {
    if (!aId || !bId || aId === bId) return;
    setLoading(true);
    try {
      const res = await apiFetch(`/api/diff?a=${aId}&b=${bId}`);
      const data = await res.json();
      if (data.ok) {
        setDiff({ entries: data.entries, summary: data.summary });
      } else {
        toast.error(data.error || "Diff failed");
      }
    } catch {
      toast.error("Diff failed");
    } finally {
      setLoading(false);
    }
  }, [aId, bId]);

  useEffect(() => {
    if (open && aId && bId && aId !== bId) {
      computeDiff();
    }
  }, [aId, bId, open, computeDiff]);

  const filtered = diff
    ? filter === "changes"
      ? diff.entries.filter((e) => e.kind !== "unchanged")
      : diff.entries
    : [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto custom-scroll">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowRight className="h-4 w-4" />
            Audit diff
          </DialogTitle>
          <DialogDescription>
            Compare two saved audits to see what packages were added, removed, upgraded, or became vulnerable.
          </DialogDescription>
        </DialogHeader>

        {runs.length < 2 ? (
          <div className="py-10 text-center text-sm text-muted-foreground">
            Save at least 2 audits to enable diff comparison.
          </div>
        ) : (
          <div className="space-y-4">
            {/* Selector */}
            <div className="flex items-center gap-2">
              <select
                value={aId}
                onChange={(e) => setAId(e.target.value)}
                className="flex-1 rounded-md border bg-background px-3 py-2 text-xs font-mono"
              >
                {runs.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.projectName} · {new Date(r.createdAt).toLocaleString()} · score {r.healthScore}
                  </option>
                ))}
              </select>
              <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" />
              <select
                value={bId}
                onChange={(e) => setBId(e.target.value)}
                className="flex-1 rounded-md border bg-background px-3 py-2 text-xs font-mono"
              >
                {runs.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.projectName} · {new Date(r.createdAt).toLocaleString()} · score {r.healthScore}
                  </option>
                ))}
              </select>
            </div>

            {loading && (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            )}

            {diff && !loading && (
              <>
                {/* Summary cards */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <SummaryCard
                    label="Health score"
                    value={`${diff.summary.healthScoreA} → ${diff.summary.healthScoreB}`}
                    delta={diff.summary.scoreDelta}
                    goodWhenPositive
                  />
                  <SummaryCard
                    label="Outdated"
                    value={`${diff.summary.outdatedA} → ${diff.summary.outdatedB}`}
                    delta={diff.summary.outdatedB - diff.summary.outdatedA}
                    goodWhenNegative
                  />
                  <SummaryCard
                    label="Vulnerable"
                    value={`${diff.summary.vulnerableA} → ${diff.summary.vulnerableB}`}
                    delta={diff.summary.vulnerableB - diff.summary.vulnerableA}
                    goodWhenNegative
                  />
                  <SummaryCard
                    label="Total changes"
                    value={String(
                      diff.summary.added + diff.summary.removed + diff.summary.upgraded +
                      diff.summary.downgraded + diff.summary.vulnFixed + diff.summary.vulnIntroduced,
                    )}
                  />
                </div>

                {/* Change chips */}
                <div className="flex flex-wrap gap-1.5">
                  {diff.summary.added > 0 && <Chip kind="added" count={diff.summary.added} />}
                  {diff.summary.removed > 0 && <Chip kind="removed" count={diff.summary.removed} />}
                  {diff.summary.upgraded > 0 && <Chip kind="upgraded" count={diff.summary.upgraded} />}
                  {diff.summary.downgraded > 0 && <Chip kind="downgraded" count={diff.summary.downgraded} />}
                  {diff.summary.vulnFixed > 0 && <Chip kind="vuln-fixed" count={diff.summary.vulnFixed} />}
                  {diff.summary.vulnIntroduced > 0 && <Chip kind="vuln-introduced" count={diff.summary.vulnIntroduced} />}
                  {diff.summary.unchanged > 0 && <Chip kind="unchanged" count={diff.summary.unchanged} />}
                </div>

                {/* Filter toggle */}
                <div className="flex rounded-md border overflow-hidden w-fit">
                  <button
                    onClick={() => setFilter("changes")}
                    className={cn("px-3 py-1 text-xs", filter === "changes" ? "bg-primary text-primary-foreground" : "hover:bg-muted")}
                  >
                    Changes only ({filtered.length})
                  </button>
                  <button
                    onClick={() => setFilter("all")}
                    className={cn("px-3 py-1 text-xs", filter === "all" ? "bg-primary text-primary-foreground" : "hover:bg-muted")}
                  >
                    All ({diff.entries.length})
                  </button>
                </div>

                {/* Entries */}
                <div className="rounded-md border max-h-[400px] overflow-y-auto custom-scroll pb-6">
                  {filtered.length === 0 ? (
                    <div className="p-8 text-center text-sm text-muted-foreground">
                      {filter === "changes"
                        ? "No changes between these two audits — your dependencies are stable. 🎉"
                        : "No packages in either audit."}
                    </div>
                  ) : (
                    <table className="w-full text-xs">
                      <tbody>
                        {filtered.map((e, i) => {
                          const meta = KIND_META[e.kind];
                          return (
                            <tr key={i} className="border-t first:border-t-0 hover:bg-muted/30">
                              <td className="p-2 w-28">
                                <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold uppercase", meta.color)}>
                                  <meta.icon className="h-3 w-3" />
                                  {meta.label}
                                </span>
                              </td>
                              <td className="p-2 font-mono font-medium">{e.id}</td>
                              <td className="p-2 text-right font-mono text-muted-foreground">
                                {e.fromVersion && (
                                  <span className="line-through opacity-60">{e.fromVersion}</span>
                                )}
                                {e.fromVersion && e.toVersion && <ArrowRight className="inline h-3 w-3 mx-1 opacity-50" />}
                                {e.toVersion && (
                                  <span className={cn(meta.color, "font-semibold")}>{e.toVersion}</span>
                                )}
                                {!e.fromVersion && !e.toVersion && <span className="opacity-50">—</span>}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                </div>
              </>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function SummaryCard({
  label,
  value,
  delta,
  goodWhenPositive,
  goodWhenNegative,
}: {
  label: string;
  value: string;
  delta?: number;
  goodWhenPositive?: boolean;
  goodWhenNegative?: boolean;
}) {
  const showDelta = delta !== undefined && delta !== 0;
  const isGood = showDelta && (goodWhenPositive ? delta! > 0 : goodWhenNegative ? delta! < 0 : false);
  const isBad = showDelta && !isGood;
  const Icon = !showDelta ? NoChange : isGood ? TrendingUp : TrendingDown;
  const color = !showDelta
    ? "text-muted-foreground"
    : isGood
      ? "text-emerald-600 dark:text-emerald-400"
      : "text-red-600 dark:text-red-400";

  return (
    <div className="rounded-md border bg-card p-2.5">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
      <p className="text-sm font-bold tabular-nums mt-0.5">{value}</p>
      {showDelta && (
        <p className={cn("text-[10px] font-mono font-semibold flex items-center gap-0.5 mt-0.5", color)}>
          <Icon className="h-2.5 w-2.5" />
          {delta! > 0 ? `+${delta}` : delta}
        </p>
      )}
    </div>
  );
}

function Chip({ kind, count }: { kind: DiffEntry["kind"]; count: number }) {
  const meta = KIND_META[kind];
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium", meta.bg, meta.color)}>
      <meta.icon className="h-2.5 w-2.5" />
      {meta.label} {count}
    </span>
  );
}
