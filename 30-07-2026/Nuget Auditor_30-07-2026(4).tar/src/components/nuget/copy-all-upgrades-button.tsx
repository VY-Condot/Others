"use client";

import { Copy, Check, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useState } from "react";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult;
  shell?: "bash" | "powershell";
}

export function CopyAllUpgradesButton({ result, shell = "bash" }: Props) {
  const [copied, setCopied] = useState(false);

  const copyAll = async () => {
    const targets = result.packages.filter((p) => p.isOutdated && p.latestStableVersion);
    if (targets.length === 0) {
      toast.error("No outdated packages to upgrade");
      return;
    }
    const commands = targets
      .map((p) => `dotnet add package ${p.id} --version ${p.latestStableVersion}`)
      .join("\n");
    try {
      await navigator.clipboard.writeText(commands);
      setCopied(true);
      toast.success(`Copied ${targets.length} upgrade commands`);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Copy failed");
    }
  };

  return (
    <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={copyAll}>
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
      <span className="hidden sm:inline">Copy all commands</span>
    </Button>
  );
}
