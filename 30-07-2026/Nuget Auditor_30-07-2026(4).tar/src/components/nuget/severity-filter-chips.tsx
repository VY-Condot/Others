"use client";

import { ShieldAlert, ShieldCheck, ArrowUpCircle, Ban, Package } from "lucide-react";
import { cn } from "@/lib/utils";

export type SeverityFilter = "all" | "critical" | "high" | "moderate" | "low" | "outdated" | "deprecated" | "clean";

interface Props {
  active: SeverityFilter;
  onChange: (filter: SeverityFilter) => void;
  counts: Record<SeverityFilter, number>;
}

const FILTERS: Array<{ key: SeverityFilter; label: string; icon: React.ComponentType<{ className?: string }>; color: string }> = [
  { key: "all", label: "All", icon: Package, color: "" },
  { key: "critical", label: "Critical", icon: ShieldAlert, color: "border-red-600/40 text-red-700 dark:text-red-300 bg-red-600/10" },
  { key: "high", label: "High", icon: ShieldAlert, color: "border-red-500/40 text-red-600 dark:text-red-400 bg-red-500/10" },
  { key: "moderate", label: "Moderate", icon: ShieldAlert, color: "border-orange-500/40 text-orange-600 dark:text-orange-400 bg-orange-500/10" },
  { key: "low", label: "Low", icon: ShieldAlert, color: "border-yellow-500/40 text-yellow-600 dark:text-yellow-400 bg-yellow-500/10" },
  { key: "outdated", label: "Outdated", icon: ArrowUpCircle, color: "border-blue-500/40 text-blue-600 dark:text-blue-400 bg-blue-500/10" },
  { key: "deprecated", label: "Deprecated", icon: Ban, color: "border-amber-500/40 text-amber-600 dark:text-amber-400 bg-amber-500/10" },
  { key: "clean", label: "Clean", icon: ShieldCheck, color: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10" },
];

export function SeverityFilterChips({ active, onChange, counts }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {FILTERS.map((f) => {
        const count = counts[f.key] ?? 0;
        if (f.key !== "all" && count === 0) return null;
        return (
          <button
            key={f.key}
            onClick={() => onChange(f.key)}
            className={cn(
              "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-all",
              active === f.key
                ? f.color || "border-primary text-primary-foreground bg-primary"
                : "border-border text-muted-foreground hover:bg-muted/40",
            )}
          >
            <f.icon className="h-3 w-3" />
            {f.label}
            <span className="opacity-60 tabular-nums">{count}</span>
          </button>
        );
      })}
    </div>
  );
}
