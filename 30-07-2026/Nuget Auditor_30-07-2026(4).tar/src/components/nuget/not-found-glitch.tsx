"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Home, RotateCcw, Ghost, Compass } from "lucide-react";
import { Button } from "@/components/ui/button";

const GLITCH_MESSAGES = [
  "This page has been lost in the multiverse.",
  "404: The page you seek is in another dimension.",
  "This URL leads to the void. The void says hi.",
  "Page not found. But we found your lack of navigation skills disturbing.",
  "This page was kidnapped by rogue npm packages.",
  "Error 404: The page escaped during a force push.",
  "You've reached the end of the internet. Please turn back.",
  "This page is buffering… just kidding, it's gone.",
  "404: Page.exe has stopped responding.",
  "The page you're looking for is in a parallel universe where it actually exists.",
];

const FLOATING_TEXTS = ["404", "null", "undefined", "NaN", "void", "null_ref", "segfault", "ERROR"];

export function NotFoundGlitch() {
  const router = useRouter();
  const [message, setMessage] = useState(GLITCH_MESSAGES[0]);
  const [glitchActive, setGlitchActive] = useState(false);
  const [floaters, setFloaters] = useState<Array<{ id: number; text: string; x: number; y: number; duration: number; delay: number }>>([]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMessage(GLITCH_MESSAGES[Math.floor(Math.random() * GLITCH_MESSAGES.length)]);
     
    setFloaters(
      Array.from({ length: 8 }, (_, i) => ({
        id: i,
        text: FLOATING_TEXTS[Math.floor(Math.random() * FLOATING_TEXTS.length)],
        x: Math.random() * 100,
        y: Math.random() * 100,
        duration: 4 + Math.random() * 4,
        delay: Math.random() * 3,
      })),
    );

    const glitchInterval = setInterval(() => {
      setGlitchActive(true);
      setTimeout(() => setGlitchActive(false), 200);
    }, 2500);
    return () => clearInterval(glitchInterval);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden bg-background px-4">
      {/* Floating glitch texts */}
      {floaters.map((f) => (
        <div
          key={f.id}
          className="absolute font-mono text-xs md:text-sm text-muted-foreground/10 pointer-events-none animate-float"
          style={{ left: `${f.x}%`, top: `${f.y}%`, animationDuration: `${f.duration}s`, animationDelay: `${f.delay}s` }}
        >
          {f.text}
        </div>
      ))}

      {/* Grid background */}
      <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />

      {/* Glitch orbs */}
      <div className="absolute -top-20 -left-20 h-64 w-64 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

      <div className="relative z-10 text-center max-w-2xl">
        {/* Glitch 404 */}
        <div className="relative">
          <h1
            className={`text-[7rem] md:text-[10rem] font-black leading-none tracking-tighter transition-all ${
              glitchActive ? "text-cyan-500 blur-sm" : "text-foreground"
            }`}
            style={glitchActive ? { transform: "translate(2px, -1px)" } : {}}
          >
            4
            <span className="inline-block animate-pulse text-indigo-500">0</span>
            4
          </h1>
          {glitchActive && (
            <h1
              className="absolute inset-0 text-[7rem] md:text-[10rem] font-black leading-none tracking-tighter text-pink-500 opacity-70"
              style={{ transform: "translate(-2px, 1px)" }}
            >
              404
            </h1>
          )}
        </div>

        {/* Ghost icon */}
        <div className="flex justify-center -mt-4 mb-4">
          <div className="rounded-full bg-indigo-500/10 p-4">
            <Ghost className="h-8 w-8 text-indigo-500" />
          </div>
        </div>

        <h2 className="text-xl md:text-2xl font-bold mt-2">
          Page.exe has stopped responding
        </h2>

        <p className="text-base text-muted-foreground mt-3 max-w-md mx-auto leading-relaxed">
          {message}
        </p>

        {/* Terminal-style error */}
        <div className="mt-6 rounded-lg border bg-card/80 backdrop-blur p-4 font-mono text-xs text-left max-w-md mx-auto">
          <div className="flex items-center gap-1.5 mb-2 pb-2 border-b">
            <span className="h-2.5 w-2.5 rounded-full bg-red-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-yellow-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
            <span className="ml-2 text-muted-foreground">error.log</span>
          </div>
          <p className="text-red-500">FATAL: PageNotFoundException</p>
          <p className="text-muted-foreground">{'  at Router.match("/{unknown_path}")'}</p>
          <p className="text-muted-foreground">{'  at User.navigateTo("/' + (typeof window !== "undefined" ? window.location.pathname : "/unknown") + '")'}</p>
          <p className="text-yellow-500">  → Suggestion: Check your URL or go home</p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
          <Button
            size="lg"
            className="bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white border-0"
            onClick={() => router.push("/")}
          >
            <Home className="h-4 w-4 mr-2" />
            Go home
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => router.refresh()}
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>

        {/* Compass hint */}
        <div className="mt-8 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
          <Compass className="h-3.5 w-3.5" />
          <span>Tip: Use the navigation bar to find your way.</span>
        </div>
      </div>
    </div>
  );
}
