/**
 * .sln (Solution) file parser.
 * Extracts project paths from a Visual Studio solution file.
 *
 * Solution files have lines like:
 *   Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "ProjectName", "src\Project\Project.csproj", "{GUID}"
 */

export interface SlnProject {
  name: string;
  path: string;
  guid: string;
}

export function parseSln(content: string): SlnProject[] {
  const projects: SlnProject[] = [];
  const lines = content.split("\n");

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("Project(")) continue;

    // Parse: Project("{TYPE-GUID}") = "Name", "Path", "{PROJ-GUID}"
    const match = trimmed.match(/^Project\("\{[^"]+\}"\)\s*=\s*"([^"]+)",\s*"([^"]+)",\s*"\{[^"]+\}"/);
    if (match) {
      const [, name, path] = match;
      // Only include .csproj projects (skip .vcxproj, .fsproj, solution folders)
      if (path.toLowerCase().endsWith(".csproj")) {
        // Normalize backslashes to forward slashes
        const normalizedPath = path.replace(/\\/g, "/");
        projects.push({ name, path: normalizedPath, guid: "" });
      }
    }
  }

  return projects;
}
