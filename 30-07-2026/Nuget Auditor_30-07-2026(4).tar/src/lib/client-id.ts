/**
 * Client-side identity for data isolation.
 *
 * Each browser gets a unique, persistent clientId stored in localStorage.
 * This is sent with every audit save/load request so users only see their
 * own data — not other users' audits or diffs.
 *
 * The ID is a random UUID generated on first visit and persists across
 * sessions. It is NOT auth — it's a soft isolation mechanism for the
 * shared SQLite backend.
 */

const CLIENT_ID_KEY = "nuget-auditor-client-id";

/** Get or create the persistent client ID. Call from client-side only. */
export function getClientId(): string {
  if (typeof window === "undefined") return "anonymous";

  let id = localStorage.getItem(CLIENT_ID_KEY);
  if (!id) {
    // Generate a random ID
    id =
      "client-" +
      Date.now().toString(36) +
      "-" +
      Math.random().toString(36).slice(2, 10);
    localStorage.setItem(CLIENT_ID_KEY, id);
  }
  return id;
}
