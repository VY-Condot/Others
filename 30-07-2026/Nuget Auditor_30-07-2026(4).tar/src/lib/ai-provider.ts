/**
 * Flexible AI provider abstraction.
 *
 * Supports OpenAI (ChatGPT) and Google Gemini via server-side API keys.
 * The active provider is selected via the AI_PROVIDER env variable
 * ("openai" or "gemini"). Requests to the AI endpoint are authenticated
 * using a custom API key (AI_API_KEY env variable).
 *
 * This replaces the rigid third-party SDK with direct fetch calls to the
 * official provider REST APIs, giving full control over auth and model
 * switching.
 */

export type AIProvider = "openai" | "gemini";

interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface ChatOptions {
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
}

interface ChatResult {
  content: string;
  provider: AIProvider;
  model: string;
}

/**
 * Get the configured AI provider from env. Defaults to "openai".
 */
export function getActiveProvider(): AIProvider {
  const p = (process.env.AI_PROVIDER ?? "openai").toLowerCase().trim();
  return p === "gemini" ? "gemini" : "openai";
}

/**
 * Validate the custom API key sent by the client.
 */
export function validateApiKey(key: string | null | undefined): boolean {
  const expected = process.env.AI_API_KEY;
  if (!expected) return false;
  return key === expected;
}

/**
 * Call OpenAI Chat Completions API.
 * Docs: https://platform.openai.com/docs/api-reference/chat
 */
async function callOpenAI(opts: ChatOptions): Promise<ChatResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not configured. Set it in your environment.");
  }

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: opts.messages,
      temperature: opts.temperature ?? 0.4,
      max_tokens: opts.maxTokens ?? 1200,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenAI API error (${res.status}): ${errText.slice(0, 300)}`);
  }

  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content ?? "";
  return { content, provider: "openai", model };
}

/**
 * Call Google Gemini API (generateContent).
 * Docs: https://ai.google.dev/gemini-api/docs/text-generation
 */
async function callGemini(opts: ChatOptions): Promise<ChatResult> {
  const apiKey = process.env.GEMINI_API_KEY;
  const model = process.env.GEMINI_MODEL || "gemini-1.5-flash";

  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured. Set it in your environment.");
  }

  // Gemini uses a different message format. We combine system + user into "contents".
  const systemMsg = opts.messages.find((m) => m.role === "system")?.content ?? "";
  const userMsg = opts.messages.filter((m) => m.role !== "system").map((m) => m.content).join("\n\n");

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: systemMsg ? { parts: [{ text: systemMsg }] } : undefined,
      contents: [{ parts: [{ text: userMsg }] }],
      generationConfig: {
        temperature: opts.temperature ?? 0.4,
        maxOutputTokens: opts.maxTokens ?? 1200,
      },
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini API error (${res.status}): ${errText.slice(0, 300)}`);
  }

  const data = await res.json();
  const content = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  return { content, provider: "gemini", model };
}

/**
 * High-level chat completion that routes to the configured provider.
 * Falls back gracefully if the primary provider fails.
 */
export async function chat(opts: ChatOptions): Promise<ChatResult> {
  const provider = getActiveProvider();

  try {
    if (provider === "gemini") {
      return await callGemini(opts);
    }
    return await callOpenAI(opts);
  } catch (err) {
    // If the primary provider fails and the other is configured, try it as fallback
    const otherProvider: AIProvider = provider === "openai" ? "gemini" : "openai";
    const otherKey = otherProvider === "openai" ? process.env.OPENAI_API_KEY : process.env.GEMINI_API_KEY;

    if (otherKey) {
      try {
        return otherProvider === "openai"
          ? await callOpenAI(opts)
          : await callGemini(opts);
      } catch {
        // Both failed — throw the original error
      }
    }
    throw err;
  }
}
