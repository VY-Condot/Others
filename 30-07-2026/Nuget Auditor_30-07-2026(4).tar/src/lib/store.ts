import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { AuditResult } from "@/lib/audit";

interface ScanContext {
  url: string;
  branch: string;
  repo: string;
  slnFiles: string[];
  csprojFiles: Array<{ path: string; content: string; projectName: string }>;
}

interface AppStore {
  // The current audit result — persists across page navigation
  result: AuditResult | null;
  setResult: (result: AuditResult | null) => void;

  // Pending csproj content from the scan page — when set, the home page
  // auto-loads it into the uploader and optionally auto-audits
  pendingContent: string | null;
  pendingName: string | null;
  setPending: (content: string, name?: string) => void;
  clearPending: () => void;

  // Multi-project scan results — for the matrix page
  scannedProjects: Array<{ path: string; content: string; projectName: string }> | null;
  setScannedProjects: (projects: Array<{ path: string; content: string; projectName: string }>) => void;
  clearScannedProjects: () => void;

  // GitHub scan context — persists the scanned repo so users can return
  // to the scan page and pick another project without re-entering the URL
  scanContext: ScanContext | null;
  setScanContext: (ctx: ScanContext) => void;
  clearScanContext: () => void;

  // Active tab — persists across navigation
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const useAppStore = create<AppStore>()(
  persist(
    (set) => ({
      result: null,
      setResult: (result) => set({ result }),

      pendingContent: null,
      pendingName: null,
      setPending: (content, name) => set({ pendingContent: content, pendingName: name ?? null }),
      clearPending: () => set({ pendingContent: null, pendingName: null }),

      scannedProjects: null,
      setScannedProjects: (projects) => set({ scannedProjects: projects }),
      clearScannedProjects: () => set({ scannedProjects: null }),

      scanContext: null,
      setScanContext: (ctx) => set({ scanContext: ctx }),
      clearScanContext: () => set({ scanContext: null }),

      activeTab: "graph",
      setActiveTab: (tab) => set({ activeTab: tab }),
    }),
    {
      name: "nuget-auditor-store",
      partialize: (state) => ({
        activeTab: state.activeTab,
        pendingContent: state.pendingContent,
        pendingName: state.pendingName,
        scanContext: state.scanContext,
        // Note: result and scannedProjects are kept in-memory only (can be large)
      }),
    },
  ),
);
