import { PrismaClient } from '@prisma/client'
import { getDatabaseUrl, isAzure } from '@/lib/azure-config'

// Use Azure-aware database URL (falls back to local dev path)
// Note: DATABASE_URL env var takes precedence if already set.
if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = getDatabaseUrl()
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: isAzure() ? ['error', 'warn'] : ['query'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
