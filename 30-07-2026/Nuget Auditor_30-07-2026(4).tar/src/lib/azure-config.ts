/**
 * Azure Cloud readiness configuration.
 *
 * This file documents the Azure deployment setup and provides runtime
 * detection for Azure App Service / Azure Functions environments.
 *
 * Azure App Service:
 *   - Set WEBSITE_SITE_NAME env var is present (Azure injects this)
 *   - Use PORT env var (Azure sets this) or default to 3000
 *   - SQLite DB path should be /home/data or a mounted Azure Files share
 *
 * Azure Functions:
 *   - Set FUNCTIONS_WORKER_RUNTIME=node
 *   - Use a persistent Azure Files mount for SQLite (or switch to Azure SQL)
 *
 * Environment variables to configure in Azure:
 *   - DATABASE_URL (use /home/data/custom.db for App Service Linux)
 *   - ADMIN_TOKEN
 *   - AI_PROVIDER (openai|gemini)
 *   - OPENAI_API_KEY / OPENAI_MODEL
 *   - GEMINI_API_KEY / GEMINI_MODEL
 *   - AI_API_KEY
 *   - PORT (Azure sets this automatically)
 */

/** Detect if running in Azure App Service */
export function isAzureAppService(): boolean {
  return typeof process !== "undefined" && !!process.env.WEBSITE_SITE_NAME;
}

/** Detect if running in Azure Functions */
export function isAzureFunctions(): boolean {
  return typeof process !== "undefined" && !!process.env.FUNCTIONS_WORKER_RUNTIME;
}

/** Detect if running in any Azure environment */
export function isAzure(): boolean {
  return isAzureAppService() || isAzureFunctions();
}

/**
 * Get the runtime port. Azure App Service sets PORT automatically.
 * Falls back to 3000 for local development.
 */
export function getPort(): number {
  const p = process.env.PORT;
  if (p) return parseInt(p, 10);
  return 3000;
}

/**
 * Get the database URL. On Azure App Service Linux, use /home/data/
 * for persistent storage across restarts. Falls back to local path.
 */
export function getDatabaseUrl(): string {
  // Allow explicit override
  if (process.env.DATABASE_URL) return process.env.DATABASE_URL;
  // Azure App Service Linux persistent storage
  if (isAzureAppService()) return "file:/home/data/custom.db";
  // Local development
  return "file:./db/custom.db";
}
