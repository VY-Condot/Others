/**
 * Client-side fetch wrapper that automatically attaches the clientId header
 * to all API requests. This ensures data isolation between users — each
 * browser only sees its own audits, diffs, and shares.
 */

import { getClientId } from "@/lib/client-id";

/**
 * Wrapped fetch that adds `x-client-id` header for data isolation.
 * Use this for any API call that reads/writes user-scoped data
 * (history, diff, share, rename, delete).
 */
export function apiFetch(input: string, init?: RequestInit): Promise<Response> {
  const clientId = typeof window !== "undefined" ? getClientId() : "anonymous";
  const headers = new Headers(init?.headers);
  headers.set("x-client-id", clientId);
  return fetch(input, { ...init, headers });
}
