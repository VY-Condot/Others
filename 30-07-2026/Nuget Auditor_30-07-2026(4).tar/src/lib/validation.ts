import { z } from "zod";

/**
 * Zod validation schemas for all public API routes.
 * These are used at runtime to validate incoming request bodies,
 * preventing unexpected payloads or malicious data structures.
 */

// --- /api/audit ---
export const auditSchema = z.object({
  content: z.string().min(1, "csproj content is required").max(2_000_000, "Content too large (max 2MB)"),
});

// --- /api/feedback ---
export const feedbackSchema = z.object({
  type: z.enum(["bug", "feature", "feedback", "question"]),
  severity: z.enum(["low", "medium", "high", "critical"]),
  title: z.string().min(3, "Title must be at least 3 characters").max(200),
  description: z.string().min(10, "Description must be at least 10 characters").max(5000),
  screenshot: z.string().max(700_000).optional().nullable(),
  page: z.string().max(500).optional().nullable(),
  reporterName: z.string().max(100).optional().nullable(),
  reporterEmail: z.string().email().max(200).optional().nullable().or(z.literal("")),
});

// --- /api/feedback/[id] (PATCH) ---
export const feedbackUpdateSchema = z.object({
  status: z.enum(["open", "in-progress", "resolved", "closed"]).optional(),
  adminNote: z.string().max(2000).optional().nullable(),
});

// --- /api/feedback/[id]/rename ---
export const renameSchema = z.object({
  name: z.string().min(1, "Name is required").max(200),
});

// --- /api/share ---
export const shareSchema = z.object({
  result: z.record(z.unknown()), // Must be an object
});

// --- /api/github-scan ---
export const githubScanSchema = z.object({
  url: z.string().url("Invalid URL").refine(
    (url) => url.includes("github.com"),
    "URL must be a GitHub repository URL",
  ),
  branch: z.string().max(100).optional().default(""),
});

// --- /api/admin/auth ---
export const adminAuthSchema = z.object({
  token: z.string().min(1, "Token is required").max(200),
});

// --- /api/advise ---
export const adviseSchema = z.object({
  projectName: z.string().max(200).optional().nullable(),
  targetFrameworks: z.array(z.string().max(100)).optional().default([]),
  sdk: z.string().max(200).optional().nullable(),
  packages: z.array(
    z.object({
      id: z.string().min(1).max(300),
      declaredVersion: z.string().max(100),
      latestStableVersion: z.string().max(100).optional().nullable(),
      isOutdated: z.boolean(),
      isVulnerable: z.boolean(),
      isDeprecated: z.boolean(),
      maxSeverity: z.string().max(50).optional().nullable(),
      vulnerabilities: z.array(
        z.object({
          severity: z.string().max(50),
          advisoryTitle: z.string().max(500).optional().nullable(),
          range: z.string().max(200),
        }),
      ).optional().default([]),
    }),
  ),
});

/**
 * Safely parse and validate a JSON body against a Zod schema.
 * Returns { success: true, data } or { success: false, error }.
 */
export function validateBody<T>(schema: z.ZodSchema<T>, body: unknown):
  | { success: true; data: T }
  | { success: false; error: string } {
  const result = schema.safeParse(body);
  if (result.success) {
    return { success: true, data: result.data };
  }
  const firstError = result.error.issues[0];
  return { success: false, error: firstError?.message ?? "Invalid request body" };
}
