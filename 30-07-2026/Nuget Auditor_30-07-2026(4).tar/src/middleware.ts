import { NextRequest, NextResponse } from "next/server";

/**
 * IP-based rate limiting middleware using an in-memory token bucket.
 *
 * Limits:
 *   - /api/audit: 10 requests per minute per IP (expensive)
 *   - /api/advise: 5 requests per minute per IP (AI calls)
 *   - /api/feedback: 10 requests per minute per IP
 *   - /api/share: 20 requests per minute per IP
 *   - /api/github-scan: 5 requests per minute per IP (external API calls)
 *   - All other /api/: 60 requests per minute per IP
 *
 * Returns 429 Too Many Requests when exceeded.
 */

interface Bucket {
  tokens: number;
  lastRefill: number;
}

const buckets = new Map<string, Bucket>();
const LIMITS: Record<string, { capacity: number; refillPerMinute: number }> = {
  "/api/audit": { capacity: 10, refillPerMinute: 10 },
  "/api/advise": { capacity: 5, refillPerMinute: 5 },
  "/api/feedback": { capacity: 10, refillPerMinute: 10 },
  "/api/share": { capacity: 20, refillPerMinute: 20 },
  "/api/github-scan": { capacity: 5, refillPerMinute: 5 },
  "/api/history": { capacity: 30, refillPerMinute: 30 },
  "/api/diff": { capacity: 30, refillPerMinute: 30 },
};
const DEFAULT_LIMIT = { capacity: 60, refillPerMinute: 60 };

function getClientIp(req: NextRequest): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  const realIp = req.headers.get("x-real-ip");
  if (realIp) return realIp.trim();
  return "unknown";
}

function checkRateLimit(key: string, capacity: number, refillPerMinute: number): boolean {
  const now = Date.now();
  const bucket = buckets.get(key);

  if (!bucket) {
    buckets.set(key, { tokens: capacity, lastRefill: now });
    return true;
  }

  // Refill tokens based on elapsed time
  const elapsedMs = now - bucket.lastRefill;
  const tokensToAdd = (elapsedMs / 60000) * refillPerMinute;
  bucket.tokens = Math.min(capacity, bucket.tokens + tokensToAdd);
  bucket.lastRefill = now;

  if (bucket.tokens >= 1) {
    bucket.tokens -= 1;
    return true;
  }

  return false;
}

// Clean up old buckets every 5 minutes to prevent memory leaks
let lastCleanup = Date.now();
function cleanupOldBuckets() {
  const now = Date.now();
  if (now - lastCleanup < 300000) return; // 5 minutes
  lastCleanup = now;
  const cutoff = now - 600000; // Remove buckets older than 10 minutes
  for (const [key, bucket] of buckets.entries()) {
    if (bucket.lastRefill < cutoff) {
      buckets.delete(key);
    }
  }
}

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Only rate-limit API routes
  if (!pathname.startsWith("/api/")) {
    return NextResponse.next();
  }

  cleanupOldBuckets();

  const ip = getClientIp(req);
  const limit = LIMITS[pathname] ?? DEFAULT_LIMIT;
  const key = `${ip}:${pathname}`;

  if (!checkRateLimit(key, limit.capacity, limit.refillPerMinute)) {
    return NextResponse.json(
      {
        error: "Rate limit exceeded",
        message: `Too many requests to ${pathname}. Please wait a moment and try again.`,
        retryAfter: 60,
      },
      {
        status: 429,
        headers: {
          "Retry-After": "60",
          "X-RateLimit-Limit": String(limit.capacity),
          "X-RateLimit-Remaining": "0",
        },
      },
    );
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/api/:path*"],
};
