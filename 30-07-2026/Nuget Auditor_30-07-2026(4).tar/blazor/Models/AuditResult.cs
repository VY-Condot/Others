namespace NuGetAuditor.Models;

/// <summary>The full audit result for a .csproj file.</summary>
public class AuditResult
{
    public ParsedCsproj Parsed { get; set; } = new();
    public List<AuditedPackage> Packages { get; set; } = new();
    public DependencyTreeNode Tree { get; set; } = new();
    public AuditStats Stats { get; set; } = new();
    public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
    public long DurationMs { get; set; }
    public string RawCsproj { get; set; } = "";
}

public class AuditStats
{
    public int TotalPackages { get; set; }
    public int OutdatedCount { get; set; }
    public int VulnerableCount { get; set; }
    public int DeprecatedCount { get; set; }
    public int PrereleaseCount { get; set; }
    public string? MaxSeverity { get; set; }
    public SourceCounts Sources { get; set; } = new();
}

public class SourceCounts
{
    public int Live { get; set; }
    public int Fallback { get; set; }
    public int Error { get; set; }
}

public class AuditedPackage
{
    public string Id { get; set; } = "";
    public string DeclaredVersion { get; set; } = "";
    public string? ResolvedVersion { get; set; }
    public string? LatestStableVersion { get; set; }
    public string? LatestVersion { get; set; }
    public bool IsOutdated { get; set; }
    public bool IsPrerelease { get; set; }
    public bool IsVulnerable { get; set; }
    public bool IsDeprecated { get; set; }
    public List<string> DeprecationReasons { get; set; } = new();
    public List<AuditedVulnerability> Vulnerabilities { get; set; } = new();
    public string? MaxSeverity { get; set; }
    public List<TransitiveDep> TransitiveDependencies { get; set; } = new();
    public string? Description { get; set; }
    public List<string>? Authors { get; set; }
    public string? ProjectUrl { get; set; }
    public string? LicenseUrl { get; set; }
    public string? LicenseExpression { get; set; }
    public string? LicenseCategory { get; set; }
    public string? IconUrl { get; set; }
    public string? PrivateAssets { get; set; }
    public string Source { get; set; } = "live";
    public string? Error { get; set; }
}

public class AuditedVulnerability
{
    public string Severity { get; set; } = "";
    public string AdvisoryUrl { get; set; } = "";
    public string Range { get; set; } = "";
    public string? AdvisoryTitle { get; set; }
    public string MatchedVersion { get; set; } = "";
}

public class TransitiveDep
{
    public string Id { get; set; } = "";
    public string Range { get; set; } = "*";
}

public class DependencyTreeNode
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    public string Version { get; set; } = "";
    public string Kind { get; set; } = "root"; // root | direct | transitive
    public List<DependencyTreeNode> Children { get; set; } = new();
    public bool IsVulnerable { get; set; }
    public bool IsOutdated { get; set; }
    public string? MaxSeverity { get; set; }
}

/// <summary>Feedback/bug report model.</summary>
public class Feedback
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Type { get; set; } = "bug"; // bug | feature | feedback | question
    public string Severity { get; set; } = "medium"; // low | medium | high | critical
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string? Page { get; set; }
    public string? UserAgent { get; set; }
    public string? Screenshot { get; set; }
    public string Status { get; set; } = "open"; // open | in-progress | resolved | closed
    public string? AdminNote { get; set; }
    public string? ReporterName { get; set; }
    public string? ReporterEmail { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>Saved audit run for history/diff.</summary>
public class AuditRun
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string ClientId { get; set; } = "anonymous";
    public string ProjectName { get; set; } = "";
    public string? Sdk { get; set; }
    public string? TargetFramework { get; set; }
    public int TotalPackages { get; set; }
    public int OutdatedCount { get; set; }
    public int VulnerableCount { get; set; }
    public int DeprecatedCount { get; set; }
    public string? MaxSeverity { get; set; }
    public int HealthScore { get; set; }
    public string ResultJson { get; set; } = "{}";
    public string CsprojContent { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
