using System.Text.Json.Serialization;

namespace NuGetAuditor.Models;

/// <summary>Parsed .csproj file structure.</summary>
public class ParsedCsproj
{
    public string? Sdk { get; set; }
    public string? ProjectName { get; set; }
    public List<string> TargetFrameworks { get; set; } = new();
    public List<PackageReference> PackageReferences { get; set; } = new();
    public List<ProjectReference> ProjectReferences { get; set; } = new();
    public List<FrameworkReference> FrameworkReferences { get; set; } = new();
    public Dictionary<string, string> PropertyBag { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
    public int RawSizeBytes { get; set; }
}

public class PackageReference
{
    public string Id { get; set; } = "";
    public string Version { get; set; } = "";
    public string? PrivateAssets { get; set; }
    public string? IncludeAssets { get; set; }
    public string? ExcludeAssets { get; set; }
    public string? Condition { get; set; }
    public bool IsDevelopmentDependency { get; set; }
}

public class ProjectReference
{
    public string Path { get; set; } = "";
    public string? Condition { get; set; }
}

public class FrameworkReference
{
    public string Name { get; set; } = "";
}

/// <summary>NuGet vulnerability from the registration index.</summary>
public class NuGetVulnerability
{
    [JsonPropertyName("severity")]
    public string Severity { get; set; } = "moderate";
    [JsonPropertyName("advisoryUrl")]
    public string AdvisoryUrl { get; set; } = "";
    [JsonPropertyName("range")]
    public string Range { get; set; } = "";
    [JsonPropertyName("advisoryTitle")]
    public string? AdvisoryTitle { get; set; }
}

/// <summary>NuGet package version entry from the registration index.</summary>
public class NuGetVersionEntry
{
    public string Version { get; set; } = "";
    public bool Listed { get; set; } = true;
    public bool IsPrerelease { get; set; }
    public List<NuGetDepInfo> Dependencies { get; set; } = new();
    public string? Description { get; set; }
    public string? Authors { get; set; }
    public string? IconUrl { get; set; }
    public string? ProjectUrl { get; set; }
    public string? LicenseUrl { get; set; }
    public string? LicenseExpression { get; set; }
    public bool RequireLicenseAcceptance { get; set; }
    public string? Published { get; set; }
    public DeprecationInfo? Deprecation { get; set; }
}

public class NuGetDepInfo
{
    public string Id { get; set; } = "";
    public string Range { get; set; } = "*";
}

public class DeprecationInfo
{
    public List<string> Reasons { get; set; } = new();
    public string? Message { get; set; }
    public AlternatePackage? AlternatePackage { get; set; }
}

public class AlternatePackage
{
    public string Id { get; set; } = "";
    public string? Range { get; set; }
}

/// <summary>Full NuGet package info from the registration index.</summary>
public class NuGetPackageInfo
{
    public string Id { get; set; } = "";
    public bool Found { get; set; }
    public string? LatestStableVersion { get; set; }
    public string? LatestVersion { get; set; }
    public List<NuGetVersionEntry> Versions { get; set; } = new();
    public List<NuGetVulnerability> Vulnerabilities { get; set; } = new();
    public DateTime FetchedAt { get; set; } = DateTime.UtcNow;
    public string Source { get; set; } = "live"; // live | fallback | error
    public string? Error { get; set; }
}
