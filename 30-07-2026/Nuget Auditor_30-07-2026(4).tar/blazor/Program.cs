using NuGetAuditor.Data;
using NuGetAuditor.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// --- Blazor Server services ---
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor(options =>
{
    options.DetailedErrors = true;
});

// --- Database (SQLite via EF Core) ---
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")
        ?? "Data Source=nuget-auditor.db"));

// --- Application services ---
builder.Services.AddSingleton<CsprojParserService>();
builder.Services.AddScoped<NuGetApiService>();
builder.Services.AddScoped<AuditService>();
builder.Services.AddScoped<AiAdvisorService>();
builder.Services.AddScoped<FeedbackService>();
builder.Services.AddScoped<HistoryService>();
builder.Services.AddScoped<ShareService>();
builder.Services.AddScoped<ThemeService>();
builder.Services.AddScoped<JsInteropService>();
builder.Services.AddHttpClient();

// --- Configuration ---
builder.Configuration.AddJsonFile("appsettings.json", optional: true);
builder.Configuration.AddEnvironmentVariables();

var app = builder.Build();

// --- Auto-migrate database on startup ---
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
}

// --- Middleware pipeline ---
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

// PWA manifest + service worker
app.MapGet("/manifest.json", async (HttpContext ctx) =>
{
    ctx.Response.ContentType = "application/manifest+json";
    await ctx.Response.SendFileAsync("wwwroot/manifest.json");
});
app.MapGet("/sw.js", async (HttpContext ctx) =>
{
    ctx.Response.ContentType = "application/javascript";
    await ctx.Response.SendFileAsync("wwwroot/sw.js");
});

// API endpoints (for Blazor Server fetch calls or external consumers)
app.MapApiEndpoints();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
