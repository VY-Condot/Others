// Blazor PWA Service Worker
const CACHE = 'nuget-auditor-blazor-v1';
const PRECACHE = ['/', '/manifest.json', '/icon.svg', '/css/app.css'];

self.addEventListener('install', e => {
    e.waitUntil(caches.open(CACHE).then(c => c.addAll(PRECACHE).catch(() => {})));
    self.skipWaiting();
});
self.addEventListener('activate', e => {
    e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
    self.clients.claim();
});
self.addEventListener('fetch', e => {
    if (e.request.method !== 'GET') return;
    e.respondWith(
        fetch(e.request).then(res => {
            if (res.ok) { const c = res.clone(); caches.open(CACHE).then(cache => cache.put(e.request, c)); }
            return res;
        }).catch(() => caches.match(e.request).then(c => c || caches.match('/')))
    );
});
