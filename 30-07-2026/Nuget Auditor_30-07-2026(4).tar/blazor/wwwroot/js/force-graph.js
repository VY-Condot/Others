// Force-directed graph visualization using Canvas API (no external deps)
// Implements Coulomb repulsion, Hooke spring attraction, centering, damping,
// and collision detection — matching the Next.js version's physics.

(function () {
    const graphs = {};

    window.nugetAuditor = window.nugetAuditor || {};

    window.nugetAuditor.renderForceGraph = function (containerId, treeData, onSelectCallback) {
        const container = document.getElementById(containerId);
        if (!container) return;

        // Clean up existing graph
        if (graphs[containerId]) {
            if (graphs[containerId].raf) cancelAnimationFrame(graphs[containerId].raf);
        }

        const canvas = document.createElement('canvas');
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.cursor = 'grab';
        container.innerHTML = '';
        container.appendChild(canvas);

        const W = container.clientWidth;
        const H = container.clientHeight;
        canvas.width = W;
        canvas.height = H;
        const ctx = canvas.getContext('2d');

        // Flatten tree into nodes + edges
        const nodes = [];
        const edges = [];
        const cx = W / 2, cy = H / 2;

        function walk(node, depth, parentId, idx, total) {
            const key = node.kind === 'root' ? 'root' : `${node.id}::${node.version}`;
            if (nodes.find(n => n.id === key)) return;
            let x = cx, y = cy;
            if (depth === 1) {
                const angle = (idx / Math.max(total, 1)) * Math.PI * 2;
                x = cx + Math.cos(angle) * 160;
                y = cy + Math.sin(angle) * 160;
            } else if (depth >= 2) {
                x = cx + (Math.random() - 0.5) * 320;
                y = cy + (Math.random() - 0.5) * 240;
            }
            const r = node.kind === 'root' ? 22 : node.kind === 'direct' ? 12 : 7;
            nodes.push({
                id: key,
                label: node.label,
                version: node.version,
                kind: node.kind,
                x, y, vx: 0, vy: 0, r,
                isVulnerable: node.isVulnerable,
                isOutdated: node.isOutdated,
                maxSeverity: node.maxSeverity,
            });
            if (parentId) edges.push({ source: parentId, target: key });
            const children = node.children || [];
            children.forEach((c, i) => walk(c, depth + 1, key, i, children.length));
        }
        walk(treeData, 0, null, 0, 1);

        const state = { nodes, edges, running: true, raf: null, zoom: 1, pan: { x: 0, y: 0 }, hovered: null };

        const sevColor = { low: '#eab308', moderate: '#f97316', high: '#ef4444', critical: '#dc2626' };

        function step() {
            if (!state.running) return;
            const repulsion = 1400;
            const springLength = 70;
            const springK = 0.04;
            const centerK = 0.015;
            const damping = 0.82;

            // Repulsion
            for (let i = 0; i < nodes.length; i++) {
                for (let j = i + 1; j < nodes.length; j++) {
                    const a = nodes[i], b = nodes[j];
                    let dx = a.x - b.x, dy = a.y - b.y;
                    let d2 = dx * dx + dy * dy;
                    if (d2 < 1) d2 = 1;
                    const d = Math.sqrt(d2);
                    const f = repulsion / d2;
                    const fx = (dx / d) * f, fy = (dy / d) * f;
                    a.vx += fx; a.vy += fy;
                    b.vx -= fx; b.vy -= fy;
                }
            }

            // Collision
            for (let i = 0; i < nodes.length; i++) {
                for (let j = i + 1; j < nodes.length; j++) {
                    const a = nodes[i], b = nodes[j];
                    const dx = a.x - b.x, dy = a.y - b.y;
                    const d = Math.sqrt(dx * dx + dy * dy) || 0.01;
                    const minDist = a.r + b.r + 8;
                    if (d < minDist) {
                        const push = (minDist - d) / 2;
                        const nx = dx / d, ny = dy / d;
                        a.x += nx * push; a.y += ny * push;
                        b.x -= nx * push; b.y -= ny * push;
                    }
                }
            }

            // Spring
            const byId = new Map(nodes.map(n => [n.id, n]));
            for (const e of edges) {
                const a = byId.get(e.source), b = byId.get(e.target);
                if (!a || !b) continue;
                const dx = b.x - a.x, dy = b.y - a.y;
                const d = Math.sqrt(dx * dx + dy * dy) || 1;
                const f = (d - springLength) * springK;
                const fx = (dx / d) * f, fy = (dy / d) * f;
                a.vx += fx; a.vy += fy;
                b.vx -= fx; b.vy -= fy;
            }

            // Centering + integrate
            for (const n of nodes) {
                n.vx += (cx - n.x) * centerK;
                n.vy += (cy - n.y) * centerK;
                n.vx *= damping; n.vy *= damping;
                n.x += n.vx; n.y += n.vy;
                n.x = Math.max(20, Math.min(W - 20, n.x));
                n.y = Math.max(20, Math.min(H - 20, n.y));
            }

            // Draw
            ctx.clearRect(0, 0, W, H);
            ctx.save();
            ctx.translate(state.pan.x, state.pan.y);
            ctx.scale(state.zoom, state.zoom);

            // Edges
            ctx.strokeStyle = 'rgba(125,125,125,0.2)';
            ctx.lineWidth = 1;
            for (const e of edges) {
                const a = byId.get(e.source), b = byId.get(e.target);
                if (!a || !b) continue;
                ctx.beginPath();
                ctx.moveTo(a.x, a.y);
                ctx.lineTo(b.x, b.y);
                ctx.stroke();
            }

            // Nodes
            for (const n of nodes) {
                const fill = n.isVulnerable && n.maxSeverity
                    ? sevColor[n.maxSeverity] || '#ef4444'
                    : n.kind === 'root' ? '#6366f1'
                    : n.isOutdated ? '#3b82f6'
                    : n.kind === 'direct' ? '#fff'
                    : '#a1a1aa';
                const isHovered = state.hovered === n.id;
                if (isHovered) {
                    ctx.beginPath();
                    ctx.arc(n.x, n.y, n.r + 4, 0, Math.PI * 2);
                    ctx.strokeStyle = 'rgba(99,102,241,0.4)';
                    ctx.lineWidth = 1.5;
                    ctx.stroke();
                }
                ctx.beginPath();
                ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
                ctx.fillStyle = fill;
                ctx.fill();
                ctx.strokeStyle = n.kind === 'root' ? '#fff' : fill;
                ctx.lineWidth = n.kind === 'root' ? 2 : 1.5;
                ctx.stroke();

                if (n.kind !== 'transitive') {
                    ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--foreground') || '#000';
                    ctx.font = `${n.kind === 'root' ? 11 : 9}px sans-serif`;
                    ctx.textAlign = 'center';
                    const label = n.label.length > 22 ? n.label.slice(0, 21) + '…' : n.label;
                    ctx.fillText(label, n.x, n.y + n.r + 12);
                }
            }
            ctx.restore();

            state.raf = requestAnimationFrame(step);
        }

        // Mouse interaction
        let dragging = null;
        canvas.addEventListener('mousedown', (e) => {
            const rect = canvas.getBoundingClientRect();
            const mx = (e.clientX - rect.left - state.pan.x) / state.zoom;
            const my = (e.clientY - rect.top - state.pan.y) / state.zoom;
            for (const n of nodes) {
                const dx = mx - n.x, dy = my - n.y;
                if (dx * dx + dy * dy < n.r * n.r) {
                    dragging = n;
                    canvas.style.cursor = 'grabbing';
                    return;
                }
            }
        });
        canvas.addEventListener('mousemove', (e) => {
            const rect = canvas.getBoundingClientRect();
            const mx = (e.clientX - rect.left - state.pan.x) / state.zoom;
            const my = (e.clientY - rect.top - state.pan.y) / state.zoom;
            if (dragging) {
                dragging.x = mx; dragging.y = my;
                dragging.vx = 0; dragging.vy = 0;
            } else {
                let hovered = null;
                for (const n of nodes) {
                    const dx = mx - n.x, dy = my - n.y;
                    if (dx * dx + dy * dy < n.r * n.r) { hovered = n.id; break; }
                }
                state.hovered = hovered;
                canvas.style.cursor = hovered ? 'pointer' : 'grab';
            }
        });
        canvas.addEventListener('mouseup', (e) => {
            if (dragging) {
                const rect = canvas.getBoundingClientRect();
                const mx = (e.clientX - rect.left - state.pan.x) / state.zoom;
                const my = (e.clientY - rect.top - state.pan.y) / state.zoom;
                const dx = mx - dragging.x, dy = my - dragging.y;
                if (dx * dx + dy * dy < 4) {
                    // Click — trigger select callback
                    if (onSelectCallback && window[onSelectCallback]) {
                        window[onSelectCallback](dragging.id, dragging.label, dragging.version, dragging.kind, dragging.isVulnerable, dragging.isOutdated, dragging.maxSeverity);
                    }
                }
            }
            dragging = null;
            canvas.style.cursor = 'grab';
        });
        canvas.addEventListener('wheel', (e) => {
            e.preventDefault();
            const delta = -e.deltaY * 0.0015;
            state.zoom = Math.max(0.3, Math.min(3, state.zoom + delta));
        });

        state.raf = requestAnimationFrame(step);
        graphs[containerId] = state;
    };

    window.nugetAuditor.pauseForceGraph = function (containerId) {
        const g = graphs[containerId];
        if (g) { g.running = false; if (g.raf) cancelAnimationFrame(g.raf); }
    };

    window.nugetAuditor.resumeForceGraph = function (containerId) {
        const g = graphs[containerId];
        if (g && !g.running) { g.running = true; g.raf = requestAnimationFrame(step); }
    };

    window.nugetAuditor.resetForceGraphView = function (containerId) {
        const g = graphs[containerId];
        if (g) { g.zoom = 1; g.pan = { x: 0, y: 0 }; }
    };

    window.nugetAuditor.destroyForceGraph = function (containerId) {
        const g = graphs[containerId];
        if (g) { if (g.raf) cancelAnimationFrame(g.raf); delete graphs[containerId]; }
    };
})();
