// Blazor interop helpers

window.nugetAuditor = {
    // Scroll to element
    scrollToElement: function (selector) {
        const el = document.querySelector(selector);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    },

    // Copy to clipboard
    copyToClipboard: async function (text) {
        await navigator.clipboard.writeText(text);
        return true;
    },

    // Download file
    downloadFile: function (filename, content, mime) {
        const blob = new Blob([content], { type: mime || 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    // Get client ID from localStorage
    getClientId: function () {
        const key = 'nuget-auditor-client-id';
        let id = localStorage.getItem(key);
        if (!id) {
            id = 'client-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
            localStorage.setItem(key, id);
        }
        return id;
    },

    // Check if admin is authenticated
    getAdminAuth: function () {
        return sessionStorage.getItem('nuget-admin-auth') === 'ok';
    },

    setAdminAuth: function (value) {
        sessionStorage.setItem('nuget-admin-auth', value ? 'ok' : '');
    },

    // Get current path
    getCurrentPath: function () {
        return window.location.pathname + window.location.search;
    },

    // Trigger confetti
    confetti: function () {
        // Simple confetti via canvas
        const canvas = document.createElement('canvas');
        canvas.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:9999';
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        document.body.appendChild(canvas);
        const ctx = canvas.getContext('2d');
        const colors = ['#10b981', '#3b82f6', '#a855f7', '#ec4899', '#f59e0b'];
        const particles = [];
        for (let i = 0; i < 80; i++) {
            particles.push({
                x: canvas.width / 2 + (Math.random() - 0.5) * 200,
                y: canvas.height / 3,
                vx: (Math.random() - 0.5) * 12,
                vy: -Math.random() * 12 - 4,
                color: colors[Math.floor(Math.random() * colors.length)],
                size: Math.random() * 8 + 4,
                rot: Math.random() * Math.PI * 2,
                vr: (Math.random() - 0.5) * 0.3,
                life: 1,
            });
        }
        let raf;
        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            let alive = 0;
            particles.forEach(p => {
                if (p.life <= 0) return;
                alive++;
                p.vy += 0.35;
                p.x += p.vx;
                p.y += p.vy;
                p.rot += p.vr;
                p.life -= 0.012;
                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rot);
                ctx.globalAlpha = Math.max(0, p.life);
                ctx.fillStyle = p.color;
                ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
                ctx.restore();
            });
            if (alive > 0) raf = requestAnimationFrame(animate);
            else { cancelAnimationFrame(raf); canvas.remove(); }
        };
        raf = requestAnimationFrame(animate);
    },
};
