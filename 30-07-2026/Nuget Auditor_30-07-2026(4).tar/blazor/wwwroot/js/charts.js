// Chart visualization using Canvas API (no external dependencies)
// Implements donut, bar, radar, scatter, and sunburst charts.

(function () {
    window.nugetAuditor = window.nugetAuditor || {};
    const charts = {};

    function getCtx(containerId, w, h) {
        const container = document.getElementById(containerId);
        if (!container) return null;
        let canvas = container.querySelector('canvas');
        if (!canvas) {
            canvas = document.createElement('canvas');
            canvas.style.width = '100%';
            canvas.style.height = '100%';
            container.appendChild(canvas);
        }
        canvas.width = w || container.clientWidth;
        canvas.height = h || container.clientHeight;
        return canvas.getContext('2d');
    }

    function getColors() {
        const isDark = document.documentElement.classList.contains('dark');
        return {
            fg: isDark ? '#fafafa' : '#0a0a0a',
            muted: isDark ? '#a1a1aa' : '#71717a',
            border: isDark ? '#27272a' : '#e4e4e7',
            bg: isDark ? '#18181b' : '#ffffff',
        };
    }

    // --- Donut chart ---
    window.nugetAuditor.renderDonutChart = function (containerId, data) {
        const ctx = getCtx(containerId);
        if (!ctx) return;
        const W = ctx.canvas.width, H = ctx.canvas.height;
        const cx = W / 2, cy = H / 2;
        const r = Math.min(W, H) / 2 - 20;
        const innerR = r * 0.55;

        ctx.clearRect(0, 0, W, H);
        const total = data.reduce((s, d) => s + d.value, 0);
        let angle = -Math.PI / 2;

        for (const slice of data) {
            const sliceAngle = (slice.value / total) * Math.PI * 2;
            ctx.beginPath();
            ctx.arc(cx, cy, r, angle, angle + sliceAngle);
            ctx.arc(cx, cy, innerR, angle + sliceAngle, angle, true);
            ctx.closePath();
            ctx.fillStyle = slice.color;
            ctx.fill();
            angle += sliceAngle;
        }

        // Center label
        ctx.fillStyle = getColors().fg;
        ctx.font = 'bold 20px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(total, cx, cy + 5);
        ctx.font = '10px sans-serif';
        ctx.fillStyle = getColors().muted;
        ctx.fillText('packages', cx, cy + 20);
    };

    // --- Bar chart ---
    window.nugetAuditor.renderBarChart = function (containerId, data, orientation) {
        const ctx = getCtx(containerId);
        if (!ctx) return;
        const W = ctx.canvas.width, H = ctx.canvas.height;
        const colors = getColors();
        ctx.clearRect(0, 0, W, H);

        const maxVal = Math.max(...data.map(d => d.value), 1);

        if (orientation === 'horizontal') {
            const barH = H / data.length * 0.7;
            const gap = H / data.length * 0.3;
            data.forEach((d, i) => {
                const y = i * (barH + gap);
                const w = (d.value / maxVal) * (W - 120);
                ctx.fillStyle = d.color || colors.fg;
                ctx.fillRect(110, y, w, barH);
                ctx.fillStyle = colors.muted;
                ctx.font = '10px monospace';
                ctx.textAlign = 'right';
                ctx.fillText(d.name.length > 16 ? d.name.slice(0, 15) + '…' : d.name, 105, y + barH / 2 + 3);
                ctx.textAlign = 'left';
                ctx.fillText(d.value, 115 + w, y + barH / 2 + 3);
            });
        } else {
            const barW = W / data.length * 0.7;
            const gap = W / data.length * 0.3;
            data.forEach((d, i) => {
                const x = i * (barW + gap) + gap / 2;
                const h = (d.value / maxVal) * (H - 40);
                ctx.fillStyle = d.color || '#3b82f6';
                ctx.fillRect(x, H - 20 - h, barW, h);
                ctx.fillStyle = colors.muted;
                ctx.font = '10px sans-serif';
                ctx.textAlign = 'center';
                ctx.fillText(d.name, x + barW / 2, H - 5);
                ctx.fillText(d.value, x + barW / 2, H - 25 - h);
            });
        }
    };

    // --- Radar chart ---
    window.nugetAuditor.renderRadarChart = function (containerId, data) {
        const ctx = getCtx(containerId);
        if (!ctx) return;
        const W = ctx.canvas.width, H = ctx.canvas.height;
        const cx = W / 2, cy = H / 2;
        const r = Math.min(W, H) / 2 - 40;
        const colors = getColors();
        ctx.clearRect(0, 0, W, H);

        const n = data.length;
        // Grid circles
        ctx.strokeStyle = colors.border;
        ctx.lineWidth = 0.5;
        for (let i = 1; i <= 4; i++) {
            ctx.beginPath();
            for (let j = 0; j < n; j++) {
                const angle = (j / n) * Math.PI * 2 - Math.PI / 2;
                const x = cx + Math.cos(angle) * r * (i / 4);
                const y = cy + Math.sin(angle) * r * (i / 4);
                if (j === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.closePath();
            ctx.stroke();
        }

        // Axis lines + labels
        ctx.fillStyle = colors.muted;
        ctx.font = '10px sans-serif';
        ctx.textAlign = 'center';
        for (let i = 0; i < n; i++) {
            const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
            const x = cx + Math.cos(angle) * r;
            const y = cy + Math.sin(angle) * r;
            ctx.strokeStyle = colors.border;
            ctx.beginPath();
            ctx.moveTo(cx, cy);
            ctx.lineTo(x, y);
            ctx.stroke();
            ctx.fillText(data[i].axis, cx + Math.cos(angle) * (r + 12), cy + Math.sin(angle) * (r + 12) + 3);
        }

        // Data polygon
        ctx.beginPath();
        for (let i = 0; i < n; i++) {
            const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
            const val = (data[i].value / 100) * r;
            const x = cx + Math.cos(angle) * val;
            const y = cy + Math.sin(angle) * val;
            if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fillStyle = 'rgba(99,102,241,0.25)';
        ctx.fill();
        ctx.strokeStyle = '#6366f1';
        ctx.lineWidth = 2;
        ctx.stroke();
    };

    // --- Scatter chart ---
    window.nugetAuditor.renderScatterChart = function (containerId, data) {
        const ctx = getCtx(containerId);
        if (!ctx) return;
        const W = ctx.canvas.width, H = ctx.canvas.height;
        const colors = getColors();
        ctx.clearRect(0, 0, W, H);

        const padding = 40;
        const maxX = Math.max(...data.map(d => d.x), 1);
        const maxY = 4;

        // Axes
        ctx.strokeStyle = colors.border;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(padding, H - padding);
        ctx.lineTo(W - padding, H - padding);
        ctx.moveTo(padding, H - padding);
        ctx.lineTo(padding, padding);
        ctx.stroke();

        // Points
        for (const d of data) {
            const x = padding + (d.x / maxX) * (W - 2 * padding);
            const y = H - padding - (d.y / maxY) * (H - 2 * padding);
            const size = Math.max(4, Math.min(20, d.z || 8));
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fillStyle = d.color || '#3b82f6';
            ctx.globalAlpha = 0.7;
            ctx.fill();
            ctx.globalAlpha = 1;
        }
    };

    // --- Sunburst (dual-ring donut) ---
    window.nugetAuditor.renderSunburst = function (containerId, data) {
        const ctx = getCtx(containerId);
        if (!ctx) return;
        const W = ctx.canvas.width, H = ctx.canvas.height;
        const cx = W / 2, cy = H / 2;
        ctx.clearRect(0, 0, W, H);

        // Outer ring (namespaces)
        const outer = data.outer || [];
        const outerTotal = outer.reduce((s, d) => s + d.value, 0);
        let angle = -Math.PI / 2;
        const outerR = Math.min(W, H) / 2 - 10;
        const midR = outerR * 0.72;

        for (const slice of outer) {
            const sliceAngle = (slice.value / outerTotal) * Math.PI * 2;
            ctx.beginPath();
            ctx.arc(cx, cy, outerR, angle, angle + sliceAngle);
            ctx.arc(cx, cy, midR, angle + sliceAngle, angle, true);
            ctx.closePath();
            ctx.fillStyle = slice.color;
            ctx.fill();
            angle += sliceAngle;
        }

        // Inner ring (status)
        const inner = data.inner || [];
        const innerTotal = inner.reduce((s, d) => s + d.value, 0);
        angle = -Math.PI / 2;
        const innerR = midR * 0.6;

        for (const slice of inner) {
            const sliceAngle = (slice.value / innerTotal) * Math.PI * 2;
            ctx.beginPath();
            ctx.arc(cx, cy, midR - 2, angle, angle + sliceAngle);
            ctx.arc(cx, cy, innerR, angle + sliceAngle, angle, true);
            ctx.closePath();
            ctx.fillStyle = slice.color;
            ctx.fill();
            angle += sliceAngle;
        }
    };
})();
