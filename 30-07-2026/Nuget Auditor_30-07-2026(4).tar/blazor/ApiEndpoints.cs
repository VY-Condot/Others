using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Text.Json;
using NuGetAuditor.Models;
using NuGetAuditor.Services;

namespace NuGetAuditor;

public static class ApiEndpoints
{
    public static WebApplication MapApiEndpoints(this WebApplication app)
    {
        // --- Health check (for Azure) ---
        app.MapGet("/api/health", () => new
        {
            status = "healthy",
            timestamp = DateTime.UtcNow,
            azure = Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME") != null,
            uptime = Environment.ProcessStartTime,
        });

        // --- Audit ---
        app.MapPost("/api/audit", async (HttpContext ctx, AuditService auditService) =>
        {
            var body = await new StreamReader(ctx.Request.Body).ReadToEndAsync();
            var payload = JsonSerializer.Deserialize<JsonElement>(body);
            var content = payload.TryGetProperty("content", out var c) ? c.GetString() : null;
            if (string.IsNullOrEmpty(content))
                return Results.BadRequest(new { error = "No csproj content provided." });
            if (content.Length > 2_000_000)
                return Results.Json(new { error = "csproj content too large (max 2MB)." }, statusCode: 413);
            var result = await auditService.AuditCsprojAsync(content);
            return Results.Ok(new { ok = true, result });
        });

        // --- History ---
        app.MapGet("/api/history", async (HttpContext ctx, HistoryService history) =>
        {
            var clientId = ctx.Request.Headers["x-client-id"].ToString();
            if (string.IsNullOrEmpty(clientId)) clientId = "anonymous";
            var runs = await history.GetHistoryAsync(clientId);
            return Results.Ok(new { ok = true, runs });
        });

        app.MapPost("/api/history", async (HttpContext ctx, HistoryService history) =>
        {
            var clientId = ctx.Request.Headers["x-client-id"].ToString();
            if (string.IsNullOrEmpty(clientId)) clientId = "anonymous";
            var body = await new StreamReader(ctx.Request.Body).ReadToEndAsync();
            var payload = JsonSerializer.Deserialize<JsonElement>(body);
            var resultJson = payload.TryGetProperty("result", out var r) ? r.ToString() : null;
            if (string.IsNullOrEmpty(resultJson))
                return Results.BadRequest(new { error = "No audit result provided." });
            var result = JsonSerializer.Deserialize<AuditResult>(resultJson);
            if (result == null)
                return Results.BadRequest(new { error = "Invalid audit result." });
            var id = await history.SaveAuditAsync(result, clientId);
            return Results.Ok(new { ok = true, id });
        });

        app.MapGet("/api/history/{id}", async (string id, HttpContext ctx, HistoryService history) =>
        {
            var clientId = ctx.Request.Headers["x-client-id"].ToString();
            if (string.IsNullOrEmpty(clientId)) clientId = "anonymous";
            var run = await history.GetRunAsync(id, clientId);
            if (run == null) return Results.NotFound(new { error = "Not found." });
            var result = JsonSerializer.Deserialize<AuditResult>(run.ResultJson);
            if (result != null) result.RawCsproj = run.CsprojContent;
            return Results.Ok(new { ok = true, run, result });
        });

        app.MapDelete("/api/history/{id}", async (string id, HttpContext ctx, HistoryService history) =>
        {
            var clientId = ctx.Request.Headers["x-client-id"].ToString();
            if (string.IsNullOrEmpty(clientId)) clientId = "anonymous";
            var ok = await history.DeleteRunAsync(id, clientId);
            return ok ? Results.Ok(new { ok = true }) : Results.NotFound(new { error = "Not found." });
        });

        app.MapPatch("/api/history/{id}/rename", async (string id, HttpContext ctx, HistoryService history) =>
        {
            var clientId = ctx.Request.Headers["x-client-id"].ToString();
            if (string.IsNullOrEmpty(clientId)) clientId = "anonymous";
            var body = await new StreamReader(ctx.Request.Body).ReadToEndAsync();
            var payload = JsonSerializer.Deserialize<JsonElement>(body);
            var name = payload.TryGetProperty("name", out var n) ? n.GetString() : null;
            if (string.IsNullOrEmpty(name)) return Results.BadRequest(new { error = "Invalid name." });
            var ok = await history.RenameRunAsync(id, name, clientId);
            return ok ? Results.Ok(new { ok = true }) : Results.NotFound(new { error = "Not found." });
        });

        // --- Diff ---
        app.MapGet("/api/diff", async (HttpContext ctx, HistoryService history) =>
        {
            var aId = ctx.Request.Query["a"].ToString();
            var bId = ctx.Request.Query["b"].ToString();
            var clientId = ctx.Request.Headers["x-client-id"].ToString();
            if (string.IsNullOrEmpty(clientId)) clientId = "anonymous";
            if (string.IsNullOrEmpty(aId) || string.IsNullOrEmpty(bId))
                return Results.BadRequest(new { error = "Both `a` and `b` params required." });
            var diff = await history.GetDiffAsync(aId, bId, clientId);
            if (diff == null) return Results.NotFound(new { error = "Not found." });
            return Results.Ok(new { ok = true, entries = diff.Entries, summary = diff.Summary });
        });

        // --- Share ---
        app.MapPost("/api/share", async (HttpContext ctx, ShareService share) =>
        {
            var clientId = ctx.Request.Headers["x-client-id"].ToString();
            if (string.IsNullOrEmpty(clientId)) clientId = "anonymous";
            var body = await new StreamReader(ctx.Request.Body).ReadToEndAsync();
            var payload = JsonSerializer.Deserialize<JsonElement>(body);
            var resultJson = payload.TryGetProperty("result", out var r) ? r.ToString() : null;
            if (string.IsNullOrEmpty(resultJson))
                return Results.BadRequest(new { error = "No result provided." });
            var result = JsonSerializer.Deserialize<AuditResult>(resultJson);
            if (result == null) return Results.BadRequest(new { error = "Invalid result." });
            var id = await share.CreateShareAsync(result, clientId);
            return Results.Ok(new { ok = true, id });
        });

        app.MapGet("/api/share", async (HttpContext ctx, ShareService share) =>
        {
            var id = ctx.Request.Query["id"].ToString();
            if (string.IsNullOrEmpty(id)) return Results.BadRequest(new { error = "Share id required." });
            var result = await share.GetShareAsync(id);
            if (result == null) return Results.NotFound(new { error = "Share not found." });
            return Results.Ok(new { ok = true, result });
        });

        // --- AI Advise ---
        app.MapPost("/api/advise", async (HttpContext ctx, AiAdvisorService ai) =>
        {
            var body = await new StreamReader(ctx.Request.Body).ReadToEndAsync();
            var payload = JsonSerializer.Deserialize<JsonElement>(body);
            var summary = payload.ToString();
            var plan = await ai.GetRemediationPlanAsync(summary);
            return Results.Text(plan, "text/plain", System.Text.Encoding.UTF8);
        });

        // --- Feedback ---
        app.MapGet("/api/feedback", async (FeedbackService feedback) =>
        {
            var items = await feedback.GetAllAsync();
            return Results.Ok(new { ok = true, items });
        });

        app.MapPost("/api/feedback", async (HttpContext ctx, FeedbackService feedback) =>
        {
            var body = await new StreamReader(ctx.Request.Body).ReadToEndAsync();
            var item = JsonSerializer.Deserialize<Feedback>(body);
            if (item == null || string.IsNullOrEmpty(item.Title) || string.IsNullOrEmpty(item.Description))
                return Results.BadRequest(new { error = "Title and description required." });
            item.UserAgent = ctx.Request.Headers.UserAgent.ToString();
            item.Page = ctx.Request.Headers.Referer.ToString();
            var id = await feedback.CreateAsync(item);
            return Results.Ok(new { ok = true, id });
        });

        app.MapPatch("/api/feedback/{id}", async (string id, HttpContext ctx, FeedbackService feedback) =>
        {
            var body = await new StreamReader(ctx.Request.Body).ReadToEndAsync();
            var payload = JsonSerializer.Deserialize<JsonElement>(body);
            if (payload.TryGetProperty("status", out var status))
            {
                await feedback.UpdateStatusAsync(id, status.GetString() ?? "");
            }
            if (payload.TryGetProperty("adminNote", out var note))
            {
                await feedback.UpdateAdminNoteAsync(id, note.GetString() ?? "");
            }
            return Results.Ok(new { ok = true });
        });

        app.MapDelete("/api/feedback/{id}", async (string id, FeedbackService feedback) =>
        {
            var ok = await feedback.DeleteAsync(id);
            return ok ? Results.Ok(new { ok = true }) : Results.NotFound(new { error = "Not found." });
        });

        // --- Admin auth ---
        app.MapPost("/api/admin/auth", async (HttpContext ctx, IConfiguration config) =>
        {
            var body = await new StreamReader(ctx.Request.Body).ReadToEndAsync();
            var payload = JsonSerializer.Deserialize<JsonElement>(body);
            var token = payload.TryGetProperty("token", out var t) ? t.GetString() : null;
            var expected = config["Admin:Token"];
            if (string.IsNullOrEmpty(expected) || token != expected)
                return Results.Json(new { error = "Invalid token." }, statusCode: 401);
            return Results.Ok(new { ok = true });
        });

        // --- Changelog (proxied to NuGet) ---
        app.MapGet("/api/changelog", async (string id, NuGetApiService nuget) =>
        {
            var info = await nuget.GetPackageInfoAsync(id);
            var releases = info.Versions
                .OrderByDescending(v => v.Version)
                .Take(10)
                .Select(v => new { v.Version, v.Published, v.Description })
                .ToList();
            return Results.Ok(new { ok = true, id, releases });
        });

        // --- Popularity ---
        app.MapGet("/api/popularity", async (string ids, NuGetApiService nuget) =>
        {
            var idList = ids.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var counts = await nuget.GetDownloadCountsAsync(idList);
            return Results.Ok(new { ok = true, popularity = counts });
        });

        return app;
    }
}
