using Microsoft.EntityFrameworkCore;
using NuGetAuditor.Data;
using NuGetAuditor.Models;

namespace NuGetAuditor.Services;

public class FeedbackService
{
    private readonly AppDbContext _db;

    public FeedbackService(AppDbContext db) => _db = db;

    public async Task<List<Feedback>> GetAllAsync(string? statusFilter = null, string? typeFilter = null)
    {
        var query = _db.Feedback.AsQueryable();
        if (!string.IsNullOrEmpty(statusFilter)) query = query.Where(f => f.Status == statusFilter);
        if (!string.IsNullOrEmpty(typeFilter)) query = query.Where(f => f.Type == typeFilter);
        return await query.OrderByDescending(f => f.CreatedAt).Take(200).ToListAsync();
    }

    public async Task<Feedback?> GetByIdAsync(string id) =>
        await _db.Feedback.FirstOrDefaultAsync(f => f.Id == id);

    public async Task<string> CreateAsync(Feedback feedback)
    {
        feedback.Id = Guid.NewGuid().ToString();
        feedback.CreatedAt = DateTime.UtcNow;
        feedback.UpdatedAt = DateTime.UtcNow;
        feedback.Status = "open";
        _db.Feedback.Add(feedback);
        await _db.SaveChangesAsync();
        return feedback.Id;
    }

    public async Task<bool> UpdateStatusAsync(string id, string status)
    {
        var item = await _db.Feedback.FindAsync(id);
        if (item == null) return false;
        item.Status = status;
        item.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> UpdateAdminNoteAsync(string id, string note)
    {
        var item = await _db.Feedback.FindAsync(id);
        if (item == null) return false;
        item.AdminNote = note;
        item.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteAsync(string id)
    {
        var item = await _db.Feedback.FindAsync(id);
        if (item == null) return false;
        _db.Feedback.Remove(item);
        await _db.SaveChangesAsync();
        return true;
    }
}

public class ShareService
{
    private readonly AppDbContext _db;
    private readonly HistoryService _history;

    public ShareService(AppDbContext db, HistoryService history)
    {
        _db = db;
        _history = history;
    }

    public async Task<string> CreateShareAsync(AuditResult result, string clientId)
    {
        return await _history.SaveAuditAsync(result, clientId);
    }

    public async Task<AuditResult?> GetShareAsync(string id)
    {
        var run = await _db.AuditRuns.FirstOrDefaultAsync(r => r.Id == id);
        if (run == null) return null;
        var result = System.Text.Json.JsonSerializer.Deserialize<AuditResult>(run.ResultJson);
        if (result != null) result.RawCsproj = run.CsprojContent;
        return result;
    }
}

public class ThemeService
{
    public string CurrentTheme { get; private set; } = "light";

    public event Action? OnChange;

    public void ToggleTheme()
    {
        CurrentTheme = CurrentTheme == "dark" ? "light" : "dark";
        OnChange?.Invoke();
    }

    public void SetTheme(string theme)
    {
        CurrentTheme = theme;
        OnChange?.Invoke();
    }
}
