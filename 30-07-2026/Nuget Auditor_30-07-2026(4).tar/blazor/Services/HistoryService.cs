using Microsoft.EntityFrameworkCore;
using NuGetAuditor.Data;
using NuGetAuditor.Models;
using System.Text.Json;

namespace NuGetAuditor.Services;

public class HistoryService
{
    private readonly AppDbContext _db;
    private readonly ILogger<HistoryService> _logger;

    public HistoryService(AppDbContext db, ILogger<HistoryService> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<List<AuditRun>> GetHistoryAsync(string clientId)
    {
        return await _db.AuditRuns
            .Where(r => r.ClientId == clientId)
            .OrderByDescending(r => r.CreatedAt)
            .Take(50)
            .ToListAsync();
    }

    public async Task<AuditRun?> GetRunAsync(string id, string clientId)
    {
        return await _db.AuditRuns
            .FirstOrDefaultAsync(r => r.Id == id && r.ClientId == clientId);
    }

    public async Task<string> SaveAuditAsync(AuditResult result, string clientId)
    {
        var sevPenalty = new Dictionary<string, int> { ["low"] = 8, ["moderate"] = 18, ["high"] = 35, ["critical"] = 60 };
        int score = 100;
        if (result.Stats.MaxSeverity != null && sevPenalty.TryGetValue(result.Stats.MaxSeverity, out var pen))
            score -= pen;
        score -= Math.Max(0, result.Stats.VulnerableCount - 1) * 6;
        if (result.Stats.TotalPackages > 0)
            score -= (int)Math.Round((double)result.Stats.OutdatedCount / result.Stats.TotalPackages * 25);
        score -= result.Stats.DeprecatedCount * 4;
        score = Math.Max(0, Math.Min(100, score));

        var run = new AuditRun
        {
            ClientId = clientId,
            ProjectName = result.Parsed.ProjectName ?? "unnamed",
            Sdk = result.Parsed.Sdk,
            TargetFramework = string.Join(", ", result.Parsed.TargetFrameworks),
            TotalPackages = result.Stats.TotalPackages,
            OutdatedCount = result.Stats.OutdatedCount,
            VulnerableCount = result.Stats.VulnerableCount,
            DeprecatedCount = result.Stats.DeprecatedCount,
            MaxSeverity = result.Stats.MaxSeverity,
            HealthScore = score,
            ResultJson = JsonSerializer.Serialize(result),
            CsprojContent = result.RawCsproj ?? "",
        };

        _db.AuditRuns.Add(run);
        await _db.SaveChangesAsync();
        return run.Id;
    }

    public async Task<bool> DeleteRunAsync(string id, string clientId)
    {
        var run = await _db.AuditRuns.FirstOrDefaultAsync(r => r.Id == id && r.ClientId == clientId);
        if (run == null) return false;
        _db.AuditRuns.Remove(run);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> RenameRunAsync(string id, string name, string clientId)
    {
        var run = await _db.AuditRuns.FirstOrDefaultAsync(r => r.Id == id && r.ClientId == clientId);
        if (run == null) return false;
        run.ProjectName = name;
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<DiffResult?> GetDiffAsync(string aId, string bId, string clientId)
    {
        var runA = await _db.AuditRuns.FirstOrDefaultAsync(r => r.Id == aId && r.ClientId == clientId);
        var runB = await _db.AuditRuns.FirstOrDefaultAsync(r => r.Id == bId && r.ClientId == clientId);
        if (runA == null || runB == null) return null;

        var resultA = JsonSerializer.Deserialize<AuditResult>(runA.ResultJson);
        var resultB = JsonSerializer.Deserialize<AuditResult>(runB.ResultJson);
        if (resultA == null || resultB == null) return null;

        var pkgsA = resultA.Packages.ToDictionary(p => p.Id.ToLowerInvariant());
        var pkgsB = resultB.Packages.ToDictionary(p => p.Id.ToLowerInvariant());
        var allIds = new HashSet<string>(pkgsA.Keys.Concat(pkgsB.Keys));
        var entries = new List<DiffEntry>();

        foreach (var id in allIds)
        {
            pkgsA.TryGetValue(id, out var a);
            pkgsB.TryGetValue(id, out var b);

            if (a != null && b == null)
                entries.Add(new DiffEntry { Id = a.Id, Kind = "removed", FromVersion = a.DeclaredVersion });
            else if (a == null && b != null)
                entries.Add(new DiffEntry { Id = b.Id, Kind = "added", ToVersion = b.DeclaredVersion });
            else if (a != null && b != null)
            {
                var kind = a.DeclaredVersion != b.DeclaredVersion ? "upgraded" : "unchanged";
                if (a.IsVulnerable && !b.IsVulnerable) kind = "vuln-fixed";
                else if (!a.IsVulnerable && b.IsVulnerable) kind = "vuln-introduced";
                entries.Add(new DiffEntry { Id = a.Id, Kind = kind, FromVersion = a.DeclaredVersion, ToVersion = b.DeclaredVersion });
            }
        }

        return new DiffResult
        {
            Entries = entries,
            Summary = new DiffSummary
            {
                Added = entries.Count(e => e.Kind == "added"),
                Removed = entries.Count(e => e.Kind == "removed"),
                Upgraded = entries.Count(e => e.Kind == "upgraded"),
                Unchanged = entries.Count(e => e.Kind == "unchanged"),
                VulnFixed = entries.Count(e => e.Kind == "vuln-fixed"),
                VulnIntroduced = entries.Count(e => e.Kind == "vuln-introduced"),
                HealthScoreA = runA.HealthScore,
                HealthScoreB = runB.HealthScore,
                ScoreDelta = runB.HealthScore - runA.HealthScore,
                ProjectNameA = runA.ProjectName,
                ProjectNameB = runB.ProjectName,
                OutdatedA = runA.OutdatedCount,
                OutdatedB = runB.OutdatedCount,
                VulnerableA = runA.VulnerableCount,
                VulnerableB = runB.VulnerableCount,
            },
        };
    }
}

public class DiffResult
{
    public List<DiffEntry> Entries { get; set; } = new();
    public DiffSummary Summary { get; set; } = new();
}

public class DiffEntry
{
    public string Id { get; set; } = "";
    public string Kind { get; set; } = "";
    public string? FromVersion { get; set; }
    public string? ToVersion { get; set; }
}

public class DiffSummary
{
    public int Added { get; set; }
    public int Removed { get; set; }
    public int Upgraded { get; set; }
    public int Unchanged { get; set; }
    public int VulnFixed { get; set; }
    public int VulnIntroduced { get; set; }
    public int HealthScoreA { get; set; }
    public int HealthScoreB { get; set; }
    public int ScoreDelta { get; set; }
    public string ProjectNameA { get; set; } = "";
    public string ProjectNameB { get; set; } = "";
    public int OutdatedA { get; set; }
    public int OutdatedB { get; set; }
    public int VulnerableA { get; set; }
    public int VulnerableB { get; set; }
}
