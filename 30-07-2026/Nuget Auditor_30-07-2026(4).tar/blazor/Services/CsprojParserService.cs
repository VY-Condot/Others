using System.Xml.Linq;
using NuGetAuditor.Models;

namespace NuGetAuditor.Services;

/// <summary>
/// Parses .csproj (MSBuild XML) files into a structured ParsedCsproj object.
/// Handles both attribute-form and child-element-form PackageReference entries.
/// </summary>
public class CsprojParserService
{
    /// <summary>The sample csproj used for the "Load sample" button.</summary>
    public const string SampleCsproj = """
        <?xml version="1.0" encoding="utf-8"?>
        <Project Sdk="Microsoft.NET.Sdk.Web">
          <PropertyGroup>
            <TargetFramework>net8.0</TargetFramework>
            <AssemblyName>Contoso.WebApi</AssemblyName>
            <Nullable>enable</Nullable>
            <ImplicitUsings>enable</ImplicitUsings>
          </PropertyGroup>
          <ItemGroup>
            <PackageReference Include="Microsoft.Extensions.Configuration" Version="8.0.0" />
            <PackageReference Include="Microsoft.Extensions.DependencyInjection" Version="8.0.0" />
            <PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.0" />
            <PackageReference Include="Swashbuckle.AspNetCore" Version="6.5.0" />
            <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.0" />
            <PackageReference Include="Microsoft.EntityFrameworkCore.Design" Version="8.0.0">
              <PrivateAssets>all</PrivateAssets>
            </PackageReference>
            <PackageReference Include="Dapper" Version="2.0.123" />
            <PackageReference Include="Npgsql" Version="4.0.4" />
            <PackageReference Include="Serilog.AspNetCore" Version="6.1.0" />
            <PackageReference Include="Serilog.Sinks.Console" Version="4.1.0" />
            <PackageReference Include="OpenTelemetry.Extensions.Hosting" Version="1.5.1" />
            <PackageReference Include="System.IdentityModel.Tokens.Jwt" Version="6.10.0" />
            <PackageReference Include="Microsoft.AspNetCore.Authentication.OpenIdConnect" Version="7.0.5" />
            <PackageReference Include="AutoMapper" Version="12.0.1" />
            <PackageReference Include="MediatR" Version="11.0.0" />
            <PackageReference Include="FluentValidation" Version="11.5.0" />
            <PackageReference Include="Polly" Version="7.2.3" />
            <PackageReference Include="Newtonsoft.Json" Version="13.0.1" />
            <PackageReference Include="CsvHelper" Version="30.0.1" />
          </ItemGroup>
          <ItemGroup>
            <ProjectReference Include="..\Contoso.Domain\Contoso.Domain.csproj" />
            <ProjectReference Include="..\Contoso.Infrastructure\Contoso.Infrastructure.csproj" />
          </ItemGroup>
          <ItemGroup>
            <FrameworkReference Include="Microsoft.AspNetCore.App" />
          </ItemGroup>
        </Project>
        """;

    public ParsedCsproj Parse(string raw)
    {
        var result = new ParsedCsproj { RawSizeBytes = raw.Length };
        var trimmed = raw.Trim();
        if (string.IsNullOrEmpty(trimmed))
        {
            result.Warnings.Add("Empty csproj content.");
            return result;
        }

        try
        {
            var doc = XDocument.Parse(trimmed);
            var projectEl = doc.Root;
            if (projectEl == null) return result;

            // SDK attribute
            result.Sdk = projectEl.Attribute("Sdk")?.Value;

            // PropertyGroup
            foreach (var pg in projectEl.Elements("PropertyGroup"))
            {
                foreach (var child in pg.Elements())
                {
                    var tag = child.Name.LocalName;
                    var value = child.Value.Trim();
                    if (string.IsNullOrEmpty(value)) continue;
                    result.PropertyBag[tag] = value;

                    if (tag == "TargetFramework")
                        result.TargetFrameworks.Add(value);
                    else if (tag == "TargetFrameworks")
                        result.TargetFrameworks.AddRange(value.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries));
                    else if (tag == "AssemblyName" && string.IsNullOrEmpty(result.ProjectName))
                        result.ProjectName = value;
                }
            }

            // ItemGroup
            foreach (var ig in projectEl.Elements("ItemGroup"))
            {
                foreach (var child in ig.Elements())
                {
                    var tag = child.Name.LocalName;
                    switch (tag)
                    {
                        case "PackageReference":
                            var pr = ParsePackageReference(child);
                            if (pr != null) result.PackageReferences.Add(pr);
                            break;
                        case "ProjectReference":
                            var inc = child.Attribute("Include")?.Value ?? child.Attribute("Update")?.Value ?? "";
                            if (!string.IsNullOrEmpty(inc))
                                result.ProjectReferences.Add(new ProjectReference { Path = inc.Trim(), Condition = child.Attribute("Condition")?.Value });
                            break;
                        case "FrameworkReference":
                            var fName = child.Attribute("Include")?.Value ?? "";
                            if (!string.IsNullOrEmpty(fName))
                                result.FrameworkReferences.Add(new FrameworkReference { Name = fName.Trim() });
                            break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            result.Warnings.Add($"XML parse error: {ex.Message}");
        }

        if (string.IsNullOrEmpty(result.ProjectName) && result.PropertyBag.TryGetValue("PackageId", out var pkgId))
            result.ProjectName = pkgId;

        return result;
    }

    private PackageReference? ParsePackageReference(XElement el)
    {
        var id = (el.Attribute("Include")?.Value ?? el.Attribute("Update")?.Value ?? "").Trim();
        if (string.IsNullOrEmpty(id)) return null;

        var version = el.Attribute("Version")?.Value ?? "";
        if (string.IsNullOrEmpty(version))
        {
            var verChild = el.Element("Version");
            version = verChild?.Value.Trim() ?? "";
        }

        return new PackageReference
        {
            Id = id,
            Version = version,
            PrivateAssets = el.Attribute("PrivateAssets")?.Value,
            IncludeAssets = el.Attribute("IncludeAssets")?.Value,
            ExcludeAssets = el.Attribute("ExcludeAssets")?.Value,
            Condition = el.Attribute("Condition")?.Value,
            IsDevelopmentDependency = el.Attribute("DevelopmentDependency")?.Value == "true",
        };
    }
}
