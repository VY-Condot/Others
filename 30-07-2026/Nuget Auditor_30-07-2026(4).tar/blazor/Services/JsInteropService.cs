using Microsoft.JSInterop;

namespace NuGetAuditor.Services;

/// <summary>
/// JS interop service for visualization components (force graph, charts,
/// command palette, confetti, clipboard). Bridges Blazor C# and the
/// JavaScript visualization libraries loaded in wwwroot.
/// </summary>
public class JsInteropService
{
    private readonly IJSRuntime _js;
    private readonly ILogger<JsInteropService> _logger;

    public JsInteropService(IJSRuntime js, ILogger<JsInteropService> logger)
    {
        _js = js;
        _logger = logger;
    }

    // --- Clipboard ---
    public async Task CopyToClipboardAsync(string text)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.copyToClipboard", text); }
        catch (Exception ex) { _logger.LogWarning(ex, "Clipboard copy failed"); }
    }

    // --- Confetti ---
    public async Task TriggerConfettiAsync()
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.confetti"); }
        catch (Exception ex) { _logger.LogWarning(ex, "Confetti failed"); }
    }

    // --- Client ID (localStorage) ---
    public async Task<string> GetClientIdAsync()
    {
        try { return await _js.InvokeAsync<string>("nugetAuditor.getClientId"); }
        catch { return "blazor-fallback"; }
    }

    // --- Admin auth (sessionStorage) ---
    public async Task<bool> GetAdminAuthAsync()
    {
        try { return await _js.InvokeAsync<bool>("nugetAuditor.getAdminAuth"); }
        catch { return false; }
    }

    public async Task SetAdminAuthAsync(bool value)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.setAdminAuth", value); }
        catch { }
    }

    // --- File download ---
    public async Task DownloadFileAsync(string filename, string content, string? mime = null)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.downloadFile", filename, content, mime ?? "text/plain"); }
        catch (Exception ex) { _logger.LogWarning(ex, "Download failed"); }
    }

    // --- Scroll to element ---
    public async Task ScrollToElementAsync(string selector)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.scrollToElement", selector); }
        catch { }
    }

    // --- Force-directed graph ---
    public async Task RenderForceGraphAsync(string containerId, object treeData, string onSelectCallbackName)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.renderForceGraph", containerId, treeData, onSelectCallbackName); }
        catch (Exception ex) { _logger.LogWarning(ex, "Force graph render failed"); }
    }

    public async Task PauseForceGraphAsync(string containerId)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.pauseForceGraph", containerId); }
        catch { }
    }

    public async Task ResumeForceGraphAsync(string containerId)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.resumeForceGraph", containerId); }
        catch { }
    }

    public async Task ResetForceGraphViewAsync(string containerId)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.resetForceGraphView", containerId); }
        catch { }
    }

    // --- Charts ---
    public async Task RenderDonutChartAsync(string containerId, object data)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.renderDonutChart", containerId, data); }
        catch (Exception ex) { _logger.LogWarning(ex, "Donut chart render failed"); }
    }

    public async Task RenderBarChartAsync(string containerId, object data, string orientation)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.renderBarChart", containerId, data, orientation); }
        catch (Exception ex) { _logger.LogWarning(ex, "Bar chart render failed"); }
    }

    public async Task RenderRadarChartAsync(string containerId, object data)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.renderRadarChart", containerId, data); }
        catch (Exception ex) { _logger.LogWarning(ex, "Radar chart render failed"); }
    }

    public async Task RenderScatterChartAsync(string containerId, object data)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.renderScatterChart", containerId, data); }
        catch (Exception ex) { _logger.LogWarning(ex, "Scatter chart render failed"); }
    }

    public async Task RenderSunburstChartAsync(string containerId, object data)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.renderSunburst", containerId, data); }
        catch (Exception ex) { _logger.LogWarning(ex, "Sunburst render failed"); }
    }

    // --- Command palette ---
    public async Task OpenCommandPaletteAsync()
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.openCommandPalette"); }
        catch { }
    }

    // --- Theme ---
    public async Task<string> GetThemeAsync()
    {
        try { return await _js.InvokeAsync<string>("nugetAuditor.getTheme"); }
        catch { return "light"; }
    }

    public async Task SetThemeAsync(string theme)
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.setTheme", theme); }
        catch { }
    }

    public async Task ToggleThemeAsync()
    {
        try { await _js.InvokeVoidAsync("nugetAuditor.toggleTheme"); }
        catch { }
    }
}
