using System.Text.Json;
using NuGetAuditor.Models;

namespace NuGetAuditor.Services;

/// <summary>
/// Orchestrates the full audit: parses csproj, fetches NuGet data for each
/// package, checks for vulnerabilities, outdated versions, deprecations,
/// and builds the dependency tree.
/// </summary>
public class AuditService
{
    private readonly CsprojParserService _parser;
    private readonly NuGetApiService _nuget;
    private readonly ILogger<AuditService> _logger;

    private static readonly Dictionary<string, int> SeverityPenalty = new()
    {
        ["low"] = 8, ["moderate"] = 18, ["high"] = 35, ["critical"] = 60
    };

    public AuditService(CsprojParserService parser, NuGetApiService nuget, ILogger<AuditService> logger)
    {
        _parser = parser;
        _nuget = nuget;
        _logger = logger;
    }

    public async Task<AuditResult> AuditCsprojAsync(string raw)
    {
        var start = DateTime.UtcNow;
        var parsed = _parser.Parse(raw);
        var packages = new List<AuditedPackage>();
        var sem = new SemaphoreSlim(6);

        var tasks = parsed.PackageReferences.Select(async pr =>
        {
            await sem.WaitAsync();
            try { packages.Add(await AuditPackageAsync(pr)); }
            catch (Exception ex)
            {
                packages.Add(new AuditedPackage
                {
                    Id = pr.Id,
                    DeclaredVersion = pr.Version,
                    Source = "error",
                    Error = ex.Message,
                });
            }
            finally { sem.Release(); }
        });
        await Task.WhenAll(tasks);

        // Deduplicate by ID (case-insensitive)
        var seen = new HashSet<string>();
        packages = packages.Where(p => seen.Add(p.Id.ToLowerInvariant())).ToList();

        // Build dependency tree
        var tree = BuildTree(parsed, packages);

        // Compute stats
        var stats = new AuditStats
        {
            TotalPackages = packages.Count,
            OutdatedCount = packages.Count(p => p.IsOutdated),
            VulnerableCount = packages.Count(p => p.IsVulnerable),
            DeprecatedCount = packages.Count(p => p.IsDeprecated),
            PrereleaseCount = packages.Count(p => p.IsPrerelease),
            MaxSeverity = packages.Where(p => p.MaxSeverity != null)
                .Select(p => p.MaxSeverity!)
                .OrderByDescending(s => SeverityRank.GetValueOrDefault(s, 0))
                .FirstOrDefault(),
            Sources = new SourceCounts
            {
                Live = packages.Count(p => p.Source == "live"),
                Fallback = packages.Count(p => p.Source == "fallback"),
                Error = packages.Count(p => p.Source == "error"),
            },
        };

        return new AuditResult
        {
            Parsed = parsed,
            Packages = packages,
            Tree = tree,
            Stats = stats,
            GeneratedAt = DateTime.UtcNow,
            DurationMs = (long)(DateTime.UtcNow - start).TotalMilliseconds,
            RawCsproj = raw,
        };
    }

    private async Task<AuditedPackage> AuditPackageAsync(PackageReference pr)
    {
        var info = await _nuget.GetPackageInfoAsync(pr.Id);
        var declaredVersion = pr.Version.Trim();
        var isPrerelease = declaredVersion.Contains("-");
        var latestStable = info.LatestStableVersion;

        var isOutdated = false;
        if (!string.IsNullOrEmpty(latestStable))
        {
            var declaredV = TryGetSemVer(declaredVersion);
            var latestV = TryGetSemVer(latestStable);
            if (declaredV != null && latestV != null && declaredV < latestV)
                isOutdated = true;
        }

        // Match vulnerabilities
        var matchedVulns = info.Vulnerabilities
            .Where(v => VersionMatchesRange(declaredVersion, v.Range))
            .Select(v => new AuditedVulnerability
            {
                Severity = v.Severity,
                AdvisoryUrl = v.AdvisoryUrl,
                Range = v.Range,
                AdvisoryTitle = v.AdvisoryTitle,
                MatchedVersion = declaredVersion,
            }).ToList();

        var declaredEntry = info.Versions.FirstOrDefault(v => v.Version == declaredVersion);
        var isDeprecated = declaredEntry?.Deprecation != null;

        var authors = declaredEntry?.Authors?.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();

        return new AuditedPackage
        {
            Id = pr.Id,
            DeclaredVersion = declaredVersion,
            ResolvedVersion = declaredVersion,
            LatestStableVersion = latestStable,
            LatestVersion = info.LatestVersion,
            IsOutdated = isOutdated,
            IsPrerelease = isPrerelease,
            IsVulnerable = matchedVulns.Count > 0,
            IsDeprecated = isDeprecated,
            DeprecationReasons = declaredEntry?.Deprecation?.Reasons ?? new(),
            Vulnerabilities = matchedVulns,
            MaxSeverity = matchedVulns.Count > 0
                ? matchedVulns.Select(v => v.Severity).OrderByDescending(s => SeverityRank.GetValueOrDefault(s, 0)).First()
                : null,
            TransitiveDependencies = declaredEntry?.Dependencies ?? new(),
            Description = declaredEntry?.Description,
            Authors = authors,
            ProjectUrl = declaredEntry?.ProjectUrl,
            LicenseUrl = declaredEntry?.LicenseUrl,
            LicenseExpression = declaredEntry?.LicenseExpression,
            LicenseCategory = ClassifyLicense(declaredEntry?.LicenseExpression, declaredEntry?.LicenseUrl),
            IconUrl = declaredEntry?.IconUrl,
            PrivateAssets = pr.PrivateAssets,
            Source = info.Source,
            Error = info.Error,
        };
    }

    private DependencyTreeNode BuildTree(ParsedCsproj parsed, List<AuditedPackage> audited)
    {
        var byId = audited.ToDictionary(p => p.Id.ToLowerInvariant());
        var root = new DependencyTreeNode
        {
            Id = "root",
            Label = parsed.ProjectName ?? "Project",
            Version = string.Join(", ", parsed.TargetFrameworks),
            Kind = "root",
        };

        foreach (var pr in parsed.PackageReferences)
        {
            var audit = byId.TryGetValue(pr.Id.ToLowerInvariant(), out var a) ? a : null;
            var node = new DependencyTreeNode
            {
                Id = pr.Id,
                Label = pr.Id,
                Version = pr.Version,
                Kind = "direct",
                IsVulnerable = audit?.IsVulnerable ?? false,
                IsOutdated = audit?.IsOutdated ?? false,
                MaxSeverity = audit?.MaxSeverity,
            };
            if (audit?.TransitiveDependencies.Count > 0)
            {
                foreach (var dep in audit.TransitiveDependencies.Take(25))
                {
                    var depAudit = byId.TryGetValue(dep.Id.ToLowerInvariant(), out var da) ? da : null;
                    node.Children.Add(new DependencyTreeNode
                    {
                        Id = dep.Id,
                        Label = dep.Id,
                        Version = dep.Range,
                        Kind = "transitive",
                        IsVulnerable = depAudit?.IsVulnerable ?? false,
                        IsOutdated = depAudit?.IsOutdated ?? false,
                        MaxSeverity = depAudit?.MaxSeverity,
                    });
                }
            }
            root.Children.Add(node);
        }

        foreach (var projRef in parsed.ProjectReferences)
        {
            root.Children.Add(new DependencyTreeNode
            {
                Id = projRef.Path,
                Label = System.IO.Path.GetFileName(projRef.Path),
                Version = "project",
                Kind = "transitive",
            });
        }

        return root;
    }

    private bool VersionMatchesRange(string version, string range)
    {
        try
        {
            var v = TryGetSemVer(version);
            if (v == null) return false;
            var r = range.Trim();
            if (string.IsNullOrEmpty(r) || r == "*") return true;
            // NuGet ranges like "[,6.35.0)" or "[1.0.0,2.0.0)"
            if (r.StartsWith("[,") || r.StartsWith("(,")) r = $"{r[0]}0.0.0,{r[2..]}";
            // Simple check: if range is "[,X)", match if version < X
            var m = System.Text.RegularExpressions.Regex.Match(r, @"\[(.+?),(.+?)\)");
            if (m.Success)
            {
                var low = TryGetSemVer(m.Groups[1].Value) ?? new System.Version(0, 0, 0);
                var high = TryGetSemVer(m.Groups[2].Value);
                return v >= low && (high == null || v < high);
            }
            return false;
        }
        catch { return false; }
    }

    private System.Version? TryGetSemVer(string? version)
    {
        if (string.IsNullOrEmpty(version)) return null;
        try { return new System.Version(version.Split('-')[0].Split('+')[0]); }
        catch { return null; }
    }

    private string ClassifyLicense(string? expression, string? url)
    {
        var raw = $"{expression ?? ""} {url ?? ""}".ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(raw)) return "none";
        if (new[] { "AGPL", "GPL-3.0", "GPL-2.0" }.Any(raw.Contains)) return "copyleft-strong";
        if (new[] { "LGPL", "MPL", "CDDL", "EPL" }.Any(raw.Contains)) return "copyleft";
        if (new[] { "MIT", "APACHE", "BSD", "ISC", "MS-PL" }.Any(raw.Contains)) return "permissive";
        if (new[] { "PROPRIETARY", "COMMERCIAL", "ALL RIGHTS RESERVED" }.Any(raw.Contains)) return "restrictive";
        if (new[] { "GPL" }.Any(raw.Contains)) return "copyleft-strong";
        return "unknown";
    }

    private static readonly Dictionary<string, int> SeverityRank = new()
    {
        ["low"] = 1, ["moderate"] = 2, ["high"] = 3, ["critical"] = 4
    };
}
