using System.Text.Json;
using NuGetAuditor.Models;

namespace NuGetAuditor.Services;

/// <summary>
/// NuGet v3 API client. Fetches registration index data (versions, vulnerabilities,
/// dependencies) and search data (download counts) from nuget.org.
/// Includes an in-memory cache and offline fallback data.
/// </summary>
public class NuGetApiService
{
    private readonly HttpClient _http;
    private readonly IConfiguration _config;
    private readonly ILogger<NuGetApiService> _logger;
    private static readonly Dictionary<string, (DateTime ts, NuGetPackageInfo data)> _cache = new();

    private string RegistrationBase => _config["NuGet:RegistrationBaseUrl"] ?? "https://api.nuget.org/v3/registration5-gz-semver2";
    private string SearchBase => _config["NuGet:SearchBaseUrl"] ?? "https://azuresearch-usnc.nuget.org/query";
    private int TimeoutSec => int.TryParse(_config["NuGet:TimeoutSeconds"], out var t) ? t : 10;
    private int CacheTtlMin => int.TryParse(_config["NuGet:CacheTtlMinutes"], out var c) ? c : 10;

    public NuGetApiService(HttpClient http, IConfiguration config, ILogger<NuGetApiService> logger)
    {
        _http = http;
        _config = config;
        _logger = logger;
        _http.Timeout = TimeSpan.FromSeconds(TimeoutSec);
    }

    public async Task<NuGetPackageInfo> GetPackageInfoAsync(string id)
    {
        var key = id.ToLowerInvariant();
        if (_cache.TryGetValue(key, out var cached) && DateTime.UtcNow - cached.ts < TimeSpan.FromMinutes(CacheTtlMin))
            return cached.data;

        var url = $"{RegistrationBase}/{Uri.EscapeDataString(key)}/index.json";
        try
        {
            var res = await _http.GetAsync(url);
            if (res.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                var info = new NuGetPackageInfo { Id = id, Found = false, Source = "live", Error = "Package not found on nuget.org." };
                _cache[key] = (DateTime.UtcNow, info);
                return info;
            }
            res.EnsureSuccessStatusCode();
            var json = await res.Content.ReadAsStringAsync();
            var info = ParseRegistrationIndex(id, json, "live");
            _cache[key] = (DateTime.UtcNow, info);
            return info;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to fetch NuGet info for {Id}", id);
            var fallback = GetFallback(id);
            if (fallback != null)
            {
                _cache[key] = (DateTime.UtcNow, fallback);
                return fallback;
            }
            var errInfo = new NuGetPackageInfo { Id = id, Found = false, Source = "error", Error = ex.Message };
            _cache[key] = (DateTime.UtcNow, errInfo);
            return errInfo;
        }
    }

    public async Task<Dictionary<string, long>> GetDownloadCountsAsync(IEnumerable<string> ids)
    {
        var results = new Dictionary<string, long>();
        var idList = ids.Take(30).ToList();
        var sem = new SemaphoreSlim(6);

        var tasks = idList.Select(async id =>
        {
            await sem.WaitAsync();
            try
            {
                var searchUrl = $"{SearchBase}?q=packageId:{Uri.EscapeDataString(id)}&take=1&prerelease=false";
                var res = await _http.GetAsync(searchUrl);
                if (!res.IsSuccessStatusCode) return;
                var json = await res.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(json);
                var data = doc.RootElement.GetProperty("data");
                if (data.GetArrayLength() > 0)
                {
                    var first = data[0];
                    var downloads = first.TryGetProperty("totalDownloads", out var td) ? td.GetInt64() : 0L;
                    results[id.ToLowerInvariant()] = downloads;
                }
            }
            catch { }
            finally { sem.Release(); }
        });
        await Task.WhenAll(tasks);
        return results;
    }

    private NuGetPackageInfo ParseRegistrationIndex(string id, string json, string source)
    {
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;
        var versions = new List<NuGetVersionEntry>();
        var vulnerabilities = new List<NuGetVulnerability>();

        // Pages → items
        if (root.TryGetProperty("items", out var items))
        {
            foreach (var page in items.EnumerateArray())
            {
                if (page.TryGetProperty("items", out var pageItems))
                {
                    foreach (var entry in pageItems.EnumerateArray())
                    {
                        if (!entry.TryGetProperty("catalogEntry", out var cat)) continue;
                        var version = cat.TryGetProperty("version", out var v) ? v.GetString() ?? "" : "";
                        if (string.IsNullOrEmpty(version)) continue;

                        var deps = new List<NuGetDepInfo>();
                        if (cat.TryGetProperty("dependencyGroups", out var depGroups))
                        {
                            foreach (var dg in depGroups.EnumerateArray())
                            {
                                if (dg.TryGetProperty("dependencies", out var depsArr))
                                {
                                    foreach (var d in depsArr.EnumerateArray())
                                    {
                                        deps.Add(new NuGetDepInfo
                                        {
                                            Id = d.TryGetProperty("id", out var did) ? did.GetString() ?? "" : "",
                                            Range = d.TryGetProperty("range", out var dr) ? dr.GetString() ?? "*" : "*",
                                        });
                                    }
                                }
                            }
                        }

                        var verEntry = new NuGetVersionEntry
                        {
                            Version = version,
                            Listed = cat.TryGetProperty("listed", out var listed) ? listed.GetBoolean() : true,
                            IsPrerelease = version.Contains('-'),
                            Dependencies = deps,
                            Description = cat.TryGetProperty("description", out var desc) ? desc.GetString() : null,
                            Authors = cat.TryGetProperty("authors", out var auth) ? auth.GetString() : null,
                            IconUrl = cat.TryGetProperty("iconUrl", out var icon) ? icon.GetString() : null,
                            ProjectUrl = cat.TryGetProperty("projectUrl", out var proj) ? proj.GetString() : null,
                            LicenseUrl = cat.TryGetProperty("licenseUrl", out var lic) ? lic.GetString() : null,
                            LicenseExpression = cat.TryGetProperty("licenseExpression", out var lexp) ? lexp.GetString() : null,
                            Published = cat.TryGetProperty("published", out var pub) ? pub.GetString() : null,
                        };

                        // Parse deprecation
                        if (cat.TryGetProperty("deprecation", out var dep))
                        {
                            var reasons = new List<string>();
                            if (dep.TryGetProperty("reasons", out var reasonArr))
                                reasons.AddRange(reasonArr.EnumerateArray().Select(r => r.GetString() ?? ""));
                            verEntry.Deprecation = new DeprecationInfo
                            {
                                Reasons = reasons,
                                Message = dep.TryGetProperty("message", out var msg) ? msg.GetString() : null,
                            };
                        }

                        versions.Add(verEntry);
                    }
                }
            }
        }

        // Vulnerabilities (top-level array)
        if (root.TryGetProperty("vulnerabilities", out var vulns))
        {
            foreach (var v in vulns.EnumerateArray())
            {
                vulnerabilities.Add(new NuGetVulnerability
                {
                    Severity = v.TryGetProperty("severity", out var sev) ? sev.GetString() ?? "moderate" : "moderate",
                    AdvisoryUrl = v.TryGetProperty("advisoryUrl", out var au) ? au.GetString() ?? "" : "",
                    Range = v.TryGetProperty("range", out var rng) ? rng.GetString() ?? "" : "",
                    AdvisoryTitle = v.TryGetProperty("@id", out var aid) ? aid.GetString() : null,
                });
            }
        }

        // Sort versions (newest first by semver)
        var sorted = versions.OrderByDescending(v => TryGetSemVer(v.Version)).ToList();
        var latestStable = sorted.FirstOrDefault(v => !v.IsPrerelease && v.Listed);
        var latest = sorted.FirstOrDefault();

        return new NuGetPackageInfo
        {
            Id = id,
            Found = versions.Count > 0,
            LatestStableVersion = latestStable?.Version,
            LatestVersion = latest?.Version,
            Versions = versions,
            Vulnerabilities = vulnerabilities,
            FetchedAt = DateTime.UtcNow,
            Source = source,
        };
    }

    private System.Version? TryGetSemVer(string version)
    {
        try { return new System.Version(version.Split('-')[0].Split('+')[0]); }
        catch { return new System.Version(0, 0, 0); }
    }

    /// <summary>Bundled offline fallback for ~18 common packages.</summary>
    private NuGetPackageInfo? GetFallback(string id)
    {
        var key = id.ToLowerInvariant();
        var fallbackData = new Dictionary<string, string>
        {
            ["system.identitymodel.tokens.jwt"] = """{"items":[{"items":[{"catalogEntry":{"version":"6.10.0"}},{"catalogEntry":{"version":"7.5.0"}}]}],"vulnerabilities":[{"severity":"high","advisoryUrl":"https://github.com/advisories/GHSA-9rr5-rm7p-m2r2","range":"[,7.0.0)"}]}""",
            ["newtonsoft.json"] = """{"items":[{"items":[{"catalogEntry":{"version":"13.0.1"}},{"catalogEntry":{"version":"13.0.3"}}]}],"vulnerabilities":[]}""",
            ["npgsql"] = """{"items":[{"items":[{"catalogEntry":{"version":"4.0.4"}},{"catalogEntry":{"version":"8.0.3"}}]}],"vulnerabilities":[{"severity":"high","advisoryUrl":"https://github.com/advisories/GHSA-7mjr-rgj7-pg2x","range":"[,4.0.5)"}]}""",
            ["dapper"] = """{"items":[{"items":[{"catalogEntry":{"version":"2.0.123"}},{"catalogEntry":{"version":"2.1.35"}}]}],"vulnerabilities":[]}""",
            ["mediatr"] = """{"items":[{"items":[{"catalogEntry":{"version":"11.0.0"}},{"catalogEntry":{"version":"12.2.0"}}]}],"vulnerabilities":[]}""",
        };

        if (!fallbackData.TryGetValue(key, out var json)) return null;
        try { return ParseRegistrationIndex(id, json, "fallback"); }
        catch { return null; }
    }
}
