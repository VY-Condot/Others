using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace NuGetAuditor.Services;

/// <summary>
/// Flexible AI provider that supports OpenAI (ChatGPT) and Google Gemini.
/// The active provider is configured via appsettings.json or env vars.
/// Auto-falls back to the other provider on failure.
/// </summary>
public class AiAdvisorService
{
    private readonly HttpClient _http;
    private readonly IConfiguration _config;
    private readonly ILogger<AiAdvisorService> _logger;

    public AiAdvisorService(HttpClient http, IConfiguration config, ILogger<AiAdvisorService> logger)
    {
        _http = http;
        _config = config;
        _logger = logger;
    }

    public string GetActiveProvider() => (_config["AI:Provider"] ?? "openai").ToLowerInvariant();

    public bool ValidateApiKey(string? key)
    {
        var expected = _config["AI:ApiKey"];
        if (string.IsNullOrEmpty(expected)) return false;
        return key == expected;
    }

    public async Task<string> GetRemediationPlanAsync(string auditSummary)
    {
        var systemPrompt = @"You are a senior .NET security and dependency management advisor. You analyze NuGet audit summaries and produce a concise, prioritized remediation plan in Markdown.

Rules:
- Be direct and specific. No generic platitudes.
- Prioritize: (1) critical/high vulnerabilities first, (2) moderate/low vulnerabilities, (3) major-version outdated packages, (4) deprecated packages, (5) minor/patch updates.
- For each actionable item, include a ready-to-run `dotnet add package` command with the recommended version.
- Flag any known breaking-change risks when upgrading major versions.
- Keep the response under ~500 words. Use tight Markdown with short sections.
- If everything is healthy, say so confidently in one line.";

        var provider = GetActiveProvider();
        try
        {
            return provider == "gemini"
                ? await CallGeminiAsync(systemPrompt, auditSummary)
                : await CallOpenAiAsync(systemPrompt, auditSummary);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Primary AI provider ({Provider}) failed, trying fallback", provider);
            // Try fallback provider
            var otherProvider = provider == "openai" ? "gemini" : "openai";
            var otherKey = otherProvider == "openai" ? _config["AI:OpenAI:ApiKey"] : _config["AI:Gemini:ApiKey"];
            if (!string.IsNullOrEmpty(otherKey))
            {
                try
                {
                    return otherProvider == "openai"
                        ? await CallOpenAiAsync(systemPrompt, auditSummary)
                        : await CallGeminiAsync(systemPrompt, auditSummary);
                }
                catch (Exception ex2)
                {
                    _logger.LogError(ex2, "Fallback AI provider also failed");
                }
            }
            return $"> ⚠️ The AI advisor is temporarily unavailable ({ex.Message}).\n\nPlease review the audit results manually and prioritize upgrading vulnerable packages first.";
        }
    }

    private async Task<string> CallOpenAiAsync(string systemPrompt, string userPrompt)
    {
        var apiKey = _config["AI:OpenAI:ApiKey"];
        var model = _config["AI:OpenAI:Model"] ?? "gpt-4o-mini";
        if (string.IsNullOrEmpty(apiKey))
            throw new InvalidOperationException("OPENAI_API_KEY is not configured.");

        var body = new
        {
            model,
            messages = new[]
            {
                new { role = "system", content = systemPrompt },
                new { role = "user", content = userPrompt },
            },
            temperature = 0.4,
            max_tokens = 1200,
        };

        var req = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions")
        {
            Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json")
        };
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

        var res = await _http.SendAsync(req);
        res.EnsureSuccessStatusCode();
        var json = await res.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement
            .GetProperty("choices")[0]
            .GetProperty("message")
            .GetProperty("content")
            .GetString() ?? "";
    }

    private async Task<string> CallGeminiAsync(string systemPrompt, string userPrompt)
    {
        var apiKey = _config["AI:Gemini:ApiKey"];
        var model = _config["AI:Gemini:Model"] ?? "gemini-1.5-flash";
        if (string.IsNullOrEmpty(apiKey))
            throw new InvalidOperationException("GEMINI_API_KEY is not configured.");

        var body = new
        {
            systemInstruction = new { parts = new[] { new { text = systemPrompt } } },
            contents = new[] { new { parts = new[] { new { text = userPrompt } } } },
            generationConfig = new { temperature = 0.4, maxOutputTokens = 1200 },
        };

        var url = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}";
        var req = new HttpRequestMessage(HttpMethod.Post, url)
        {
            Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json")
        };

        var res = await _http.SendAsync(req);
        res.EnsureSuccessStatusCode();
        var json = await res.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString() ?? "";
    }
}
