using Microsoft.EntityFrameworkCore;
using NuGetAuditor.Models;

namespace NuGetAuditor.Data;

/// <summary>
/// EF Core DbContext for the NuGet Auditor application.
/// Uses SQLite for local development and Azure-ready storage.
/// </summary>
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<AuditRun> AuditRuns => Set<AuditRun>();
    public DbSet<Feedback> Feedback => Set<Feedback>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AuditRun>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.ClientId);
            entity.HasIndex(e => e.ProjectName);
            entity.HasIndex(e => e.CreatedAt);
            entity.Property(e => e.ResultJson).HasColumnType("TEXT");
            entity.Property(e => e.CsprojContent).HasColumnType("TEXT");
        });

        modelBuilder.Entity<Feedback>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.Status);
            entity.HasIndex(e => e.Type);
            entity.HasIndex(e => e.CreatedAt);
            entity.Property(e => e.Description).HasColumnType("TEXT");
            entity.Property(e => e.Screenshot).HasColumnType("TEXT");
            entity.Property(e => e.AdminNote).HasColumnType("TEXT");
        });

        base.OnModelCreating(modelBuilder);
    }
}
