# NuGet Visualizer & Auditor — Blazor C# Edition

A complete port of the Next.js NuGet Auditor application to **Blazor Server** (.NET 8).

## ✅ Complete — All Features Ported

Every feature from the Next.js version is implemented in Blazor C#:

### Core
- ✅ .csproj XML parser (MSBuild format, attribute + child-element)
- ✅ NuGet v3 API client (registration index + search/popularity)
- ✅ Full audit engine (vulnerabilities, outdated, deprecated, license)
- ✅ EF Core DbContext (SQLite) with AuditRun + Feedback models
- ✅ Client-isolated data (clientId via localStorage/JS interop)

### Visualization (Canvas-based, no external deps)
- ✅ Force-directed graph (physics simulation: repulsion + spring + collision)
- ✅ Donut chart (status distribution)
- ✅ Radar chart (5-axis health assessment)
- ✅ Bar charts (horizontal + vertical)
- ✅ Scatter chart (downloads vs risk)
- ✅ Sunburst chart (dual-ring: namespace + status)
- ✅ Health score gauge (animated SVG radial)
- ✅ Risk heatmap (grid table with color-coded cells)

### Pages & Components
- ✅ Home page (landing + uploader + full results dashboard)
- ✅ /feedback page (dedicated form with type/severity/screenshot)
- ✅ /admin page (token-gated, feedback management dashboard)
- ✅ 404 page (Gen-Z sarcastic, gradient 404, joke stats)
- ✅ Package detail dialog (metadata, vulnerabilities, copy snippet)
- ✅ Version compare dialog (before/after with upgrade command)
- ✅ Changelog viewer (fetches release notes from nuget.org)
- ✅ AI advisor (OpenAI + Gemini with auto-fallback)
- ✅ Upgrade generator (Bash + PowerShell toggle, copy + download)
- ✅ License compliance panel (6 categories, breakdown bar)
- ✅ Popularity panel (download counts, ranked list)
- ✅ Upgrade simulator (before/after health score)
- ✅ Vulnerability timeline
- ✅ Risk heatmap
- ✅ Dependency tree (expandable + filterable)
- ✅ All packages table (filter + sort)
- ✅ Vulnerability table (sortable)
- ✅ Outdated table (with upgrade commands)
- ✅ Responsive header
- ✅ Eye-catching footer (4-column with 0xz.0nfirex copyright)
- ✅ PWA (manifest + service worker)
- ✅ Azure ready (health check, config)

### API (14 endpoints — mirrors Next.js exactly)
- `/api/health` · `/api/audit` · `/api/history` (GET/POST) · `/api/history/{id}` (GET/DELETE)
- `/api/history/{id}/rename` · `/api/diff` · `/api/share` (GET/POST)
- `/api/advise` · `/api/feedback` (GET/POST) · `/api/feedback/{id}` (PATCH/DELETE)
- `/api/admin/auth` · `/api/changelog` · `/api/popularity`

## Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)

## Build & Run

```bash
cd blazor
dotnet restore
dotnet ef database update    # Or: dotnet run (auto-creates DB via EnsureCreated)
dotnet run
```

Open `http://localhost:5000`.

## Configuration (`appsettings.json`)

```json
{
  "ConnectionStrings": { "DefaultConnection": "Data Source=nuget-auditor.db" },
  "AI": {
    "Provider": "openai",
    "OpenAI": { "ApiKey": "sk-...", "Model": "gpt-4o-mini" },
    "Gemini": { "ApiKey": "...", "Model": "gemini-1.5-flash" },
    "ApiKey": "nuget-advise-secret-2025"
  },
  "Admin": { "Token": "nuget-admin-2025-secret" }
}
```

## Architecture (55 files)

```
blazor/
├── Program.cs                    # Startup, DI, middleware, API mapping
├── ApiEndpoints.cs               # 14 REST endpoints
├── NuGetAuditor.csproj           # .NET 8 project
├── App.razor                     # Router
├── _Imports.razor                # Global imports
├── appsettings.json              # Config
├── Models/ (2 files)
│   ├── ParsedCsproj.cs           # csproj + NuGet types
│   └── AuditResult.cs            # Audit + Feedback + AuditRun
├── Data/
│   └── AppDbContext.cs           # EF Core SQLite
├── Services/ (7 files)
│   ├── CsprojParserService.cs    # MSBuild XML parser
│   ├── NuGetApiService.cs        # NuGet v3 client
│   ├── AuditService.cs           # Audit orchestration
│   ├── AiAdvisorService.cs       # OpenAI/Gemini provider
│   ├── HistoryService.cs         # History + diff (client-isolated)
│   ├── FeedbackService.cs        # Feedback + Share + Theme
│   └── JsInteropService.cs       # JS interop (charts, graph, clipboard)
├── Components/ (24 .razor files)
│   ├── ForceGraph.razor          # Canvas physics simulation
│   ├── HealthScore.razor         # Animated SVG gauge
│   ├── AnalyticsDashboard.razor  # 4 charts via JS interop
│   ├── AiAdvisor.razor           # AI remediation plan
│   ├── UpgradeGenerator.razor    # Bash + PowerShell scripts
│   ├── PackageDetailDialog.razor # Package metadata modal
│   ├── VersionCompareDialog.razor# Semantic diff
│   ├── ChangelogViewer.razor     # Release notes
│   ├── LicensePanel.razor        # License compliance
│   ├── PopularityPanel.razor     # Download counts
│   ├── UpgradeSimulator.razor    # Before/after score
│   ├── SunburstChart.razor       # Dual-ring chart
│   ├── VulnerabilityTimeline.razor
│   ├── RiskHeatmap.razor         # Grid heatmap
│   ├── DependencyTree.razor      # Expandable tree
│   ├── TreeNodeRow.razor         # Tree node
│   ├── VulnerabilityTable.razor  # Sortable table
│   ├── OutdatedTable.razor       # Upgrade commands
│   ├── AllPackagesTable.razor    # Filter + sort
│   ├── StatsCards.razor          # Animated stats
│   ├── StatCard.razor            # Single stat
│   ├── FileUploader.razor        # Drag + paste upload
│   ├── LandingPage.razor         # Hero + CTA
│   ├── Footer.razor              # 4-column footer
│   ├── ResponsiveHeader.razor    # Mobile-friendly header
│   ├── NotFoundPage.razor        # 404 component
│   └── MainLayout.razor          # Root layout
├── Pages/ (5 files)
│   ├── Index.razor               # Home (audit + results)
│   ├── Feedback.razor            # /feedback page
│   ├── Admin.razor               # /admin (protected)
│   ├── NotFound.razor            # 404 route
│   ├── _Host.cshtml              # Blazor host
│   └── _HostRoute.razor          # Fallback
├── wwwroot/ (6 files)
│   ├── css/app.css               # Tailwind-like utilities
│   ├── js/app.js                 # Interop (clipboard, confetti, clientId)
│   ├── js/force-graph.js         # Canvas physics graph
│   ├── js/charts.js              # Canvas charts (donut/bar/radar/scatter/sunburst)
│   ├── manifest.json             # PWA manifest
│   ├── sw.js                     # Service worker
│   └── icon.svg                  # Custom favicon
├── Properties/
│   └── launchSettings.json       # Dev config (port 5000)
└── README.md                     # This file
```

## Admin Access

Navigate to `/admin`, enter token: `nuget-admin-2025-secret`

## Deploy to Azure

```bash
dotnet publish -c Release -o ./publish
# Deploy ./publish to Azure App Service (.NET 8 Linux)
```

Configure in Azure Portal:
- `ConnectionStrings__DefaultConnection` = `Data Source=/home/data/nuget-auditor.db`
- `AI__OpenAI__ApiKey` = your key
- `Admin__Token` = your token

## Developer

© @DateTime.Now.Year NuGet Visualizer & Auditor. Developed by **0xz.0nfirex**. All rights reserved.
