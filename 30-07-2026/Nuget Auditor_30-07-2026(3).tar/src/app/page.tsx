"use client";

import { useCallback, useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  PackageSearch,
  Github,
  ShieldCheck,
  Network,
  Zap,
  FileCode2,
  AlertCircle,
  RefreshCw,
  GitGraph,
  Bot,
  Terminal,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";

import { ThemeToggle } from "@/components/nuget/theme-toggle";
import { FileUploader } from "@/components/nuget/file-uploader";
import { StatsCards } from "@/components/nuget/stats-cards";
import { DependencyTree } from "@/components/nuget/dependency-tree";
import { VulnerabilityTable } from "@/components/nuget/vulnerability-table";
import { OutdatedTable } from "@/components/nuget/outdated-table";
import { AllPackagesTable } from "@/components/nuget/all-packages-table";
import { PackageDetailDialog } from "@/components/nuget/package-detail-dialog";
import { HealthScore } from "@/components/nuget/health-score";
import dynamic from "next/dynamic";

// Lazy-load heavy visualization components for better initial page load
const ForceGraph = dynamic(() => import("@/components/nuget/force-graph").then(m => m.ForceGraph), { ssr: false, loading: () => <div className="h-[460px] rounded-lg border bg-muted/20 animate-pulse" /> });
const AiAdvisor = dynamic(() => import("@/components/nuget/ai-advisor").then(m => m.AiAdvisor), { ssr: false, loading: () => <div className="h-[200px] rounded-lg border bg-muted/20 animate-pulse" /> });
const UpgradeGenerator = dynamic(() => import("@/components/nuget/upgrade-generator").then(m => m.UpgradeGenerator), { ssr: false });
const AnalyticsDashboard = dynamic(() => import("@/components/nuget/analytics-dashboard").then(m => m.AnalyticsDashboard), { ssr: false, loading: () => <div className="h-[300px] rounded-lg border bg-muted/20 animate-pulse" /> });
const LicensePanel = dynamic(() => import("@/components/nuget/license-panel").then(m => m.LicensePanel), { ssr: false });
const PopularityPanel = dynamic(() => import("@/components/nuget/popularity-panel").then(m => m.PopularityPanel), { ssr: false });
const UpgradeSimulator = dynamic(() => import("@/components/nuget/upgrade-simulator").then(m => m.UpgradeSimulator), { ssr: false });
const SunburstChart = dynamic(() => import("@/components/nuget/sunburst-chart").then(m => m.SunburstChart), { ssr: false, loading: () => <div className="h-[240px] rounded-lg border bg-muted/20 animate-pulse" /> });
import { LandingPage } from "@/components/nuget/landing-page";
import { ResponsiveHeader } from "@/components/nuget/responsive-header";
import { VersionCompareDialog } from "@/components/nuget/version-compare-dialog";
import { AuditHistory } from "@/components/nuget/audit-history";
import { KeyboardShortcuts } from "@/components/nuget/keyboard-shortcuts";
import { AuditDiffView } from "@/components/nuget/audit-diff-view";
import { ChangelogViewer } from "@/components/nuget/changelog-viewer";
import { CommandPalette } from "@/components/nuget/command-palette";
import { ShareButton } from "@/components/nuget/share-button";
import { Confetti } from "@/components/nuget/confetti";
import { VulnerabilityTimeline } from "@/components/nuget/vulnerability-timeline";
import { RiskHeatmap } from "@/components/nuget/risk-heatmap";
import { ExportJsonButton } from "@/components/nuget/export-json-button";
import { CopyAllUpgradesButton } from "@/components/nuget/copy-all-upgrades-button";
import { IgnoreListButton } from "@/components/nuget/ignore-list-button";
import { QuickStatsBar } from "@/components/nuget/quick-stats-bar";
import { SeverityFilterChips, type SeverityFilter } from "@/components/nuget/severity-filter-chips";
import { BadgeGenerator } from "@/components/nuget/badge-generator";
import { BarChart3, GitCompare, History, Save, BookOpen, Command, ExternalLink, MessageSquare, Bug, Pencil, Check, X } from "lucide-react";

import type { AuditResult, AuditedPackage, DependencyTreeNode } from "@/lib/audit";
import { SAMPLE_CSPROJ } from "@/lib/csproj-parser";
import { apiFetch } from "@/lib/api-fetch";
import { useAppStore } from "@/lib/store";

export default function Home() {
  const router = useRouter();
  const uploadRef = useRef<HTMLElement>(null);
  const pendingContent = useAppStore((s) => s.pendingContent);
  const clearPending = useAppStore((s) => s.clearPending);
  const scanContext = useAppStore((s) => s.scanContext);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedPkg, setSelectedPkg] = useState<AuditedPackage | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [comparePkg, setComparePkg] = useState<AuditedPackage | null>(null);
  const [compareOpen, setCompareOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [historyRefreshKey, setHistoryRefreshKey] = useState(0);
  const [activeTab, setActiveTab] = useState("graph");
  const [renaming, setRenaming] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [severityFilter, setSeverityFilter] = useState<SeverityFilter>("all");
  const [diffOpen, setDiffOpen] = useState(false);
  const [historyRuns, setHistoryRuns] = useState<Array<{
    id: string; projectName: string; createdAt: string; healthScore: number;
    totalPackages: number; outdatedCount: number; vulnerableCount: number;
  }>>([]);
  const [changelogPkg, setChangelogPkg] = useState<{ id: string; version: string } | null>(null);
  const [changelogOpen, setChangelogOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [confettiTrigger, setConfettiTrigger] = useState(false);

  // Cmd+K / Ctrl+K to open command palette
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Fire confetti when an audit completes with 0 vulnerabilities
  useEffect(() => {
    if (result && result.stats.vulnerableCount === 0 && result.stats.totalPackages > 0) {
      setConfettiTrigger(false);
      // small delay so state settles
      const t = setTimeout(() => setConfettiTrigger(true), 400);
      return () => clearTimeout(t);
    }
  }, [result]);

  const onAudit = useCallback(async (content: string, filename?: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || `Audit failed (HTTP ${res.status})`);
      }
      setResult(data.result as AuditResult);
      const r = data.result as AuditResult;
      toast.success(
        `Audited ${r.stats.totalPackages} packages — ${r.stats.vulnerableCount} vulnerable, ${r.stats.outdatedCount} outdated`,
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
      toast.error("Audit failed", { description: msg });
    } finally {
      setLoading(false);
      // void filename to satisfy lint if unused
      void filename;
    }
  }, []);

  // Load a shared audit on mount if ?share=<id> is in the URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shareId = params.get("share");
    if (!shareId) return;
    setLoading(true);
    fetch(`/api/share?id=${shareId}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.ok && data.result) {
          setResult(data.result as AuditResult);
          toast.success("Loaded shared audit");
        } else {
          toast.error("Shared audit not found or expired");
        }
      })
      .catch(() => toast.error("Failed to load shared audit"))
      .finally(() => {
        setLoading(false);
        // Clean the URL so refresh doesn't re-fetch
        const url = new URL(window.location.href);
        url.searchParams.delete("share");
        window.history.replaceState({}, "", url.toString());
      });
  }, []);

  // Auto-audit pending content from the scan page
  useEffect(() => {
    if (pendingContent) {
      onAudit(pendingContent);
      clearPending();
    }
  }, [pendingContent, onAudit, clearPending]);

  const onPkgSelect = useCallback((pkg: AuditedPackage) => {
    setSelectedPkg(pkg);
    setDialogOpen(true);
  }, []);

  const onCompare = useCallback((pkg: AuditedPackage) => {
    setComparePkg(pkg);
    setCompareOpen(true);
  }, []);

  const saveAudit = useCallback(async () => {
    if (!result) return;
    setSaving(true);
    try {
      const res = await apiFetch("/api/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result }),
      });
      const data = await res.json();
      if (data.ok) {
        toast.success("Audit saved to history");
        setHistoryRefreshKey((k) => k + 1);
      } else {
        toast.error("Save failed", { description: data.error });
      }
    } catch (err) {
      toast.error("Save failed", { description: String(err) });
    } finally {
      setSaving(false);
    }
  }, [result]);

  const startRename = useCallback(() => {
    setRenameValue(result?.parsed.projectName ?? "Unnamed project");
    setRenaming(true);
  }, [result]);

  const confirmRename = useCallback(() => {
    const name = renameValue.trim();
    if (name && result) {
      // Mutate the result in-place to update the displayed name
      result.parsed.projectName = name;
      setHistoryRefreshKey((k) => k + 1);
      toast.success("Project renamed");
    }
    setRenaming(false);
  }, [renameValue, result]);

  const handleShortcut = useCallback(
    (key: string) => {
      const tabMap: Record<string, string> = {
        "g f": "graph",
        "g t": "tree",
        "g v": "vulns",
        "g o": "outdated",
        "g a": "analytics",
        "g p": "all",
        "g u": "upgrade",
      };
      if (tabMap[key]) {
        setActiveTab(tabMap[key]);
        return;
      }
      if (key === "h") setHistoryOpen(true);
      else if (key === "s") saveAudit();
      else if (key === "n") {
        setResult(null);
        setError(null);
      } else if (key === "/") {
        const search = document.querySelector('input[placeholder*="Filter"]') as HTMLInputElement | null;
        search?.focus();
      }
    },
    [saveAudit],
  );

  const openDiff = useCallback(async () => {
    try {
      const res = await apiFetch("/api/history");
      const data = await res.json();
      if (data.ok) setHistoryRuns(data.runs);
    } catch {
      // ignore
    }
    setDiffOpen(true);
  }, []);

  const openChangelog = useCallback((pkg: AuditedPackage) => {
    setChangelogPkg({ id: pkg.id, version: pkg.declaredVersion });
    setChangelogOpen(true);
  }, []);

  const onTreeNodeSelect = useCallback(
    (node: DependencyTreeNode) => {
      if (node.kind === "root") return;
      // find matching audited package by id (case-insensitive)
      const match = result?.packages.find((p) => p.id.toLowerCase() === node.id.toLowerCase());
      if (match) {
        setSelectedPkg(match);
        setDialogOpen(true);
      } else {
        // Transitive dependency or unmatched node — open dialog with a
        // constructed minimal package so the user still gets feedback.
        setSelectedPkg({
          id: node.id,
          declaredVersion: node.version,
          resolvedVersion: null,
          latestStableVersion: null,
          latestVersion: null,
          isOutdated: node.isOutdated,
          isPrerelease: false,
          isVulnerable: node.isVulnerable,
          isDeprecated: false,
          deprecationReasons: [],
          vulnerabilities: [],
          maxSeverity: node.maxSeverity,
          transitiveDependencies: [],
          source: "live",
          error: "This is a transitive dependency. Limited metadata available — click a direct dependency for full details.",
        });
        setDialogOpen(true);
      }
    },
    [result],
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ResponsiveHeader
        result={result}
        saving={saving}
        onSave={saveAudit}
        onOpenHistory={() => setHistoryOpen(true)}
        onOpenDiff={openDiff}
        onOpenFeedback={() => router.push("/feedback")}
        onOpenPalette={() => setPaletteOpen(true)}
      />

      {/* Landing page (shown before any audit) */}
      {!result && (
        <LandingPage
          onLoadSample={() => {
            // Load sample into the uploader and scroll to it
            const ta = document.querySelector("textarea");
            if (ta) {
              const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
              setter?.call(ta, SAMPLE_CSPROJ);
              ta.dispatchEvent(new Event("input", { bubbles: true }));
            }
            setTimeout(() => uploadRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
          }}
          onScrollToUpload={() => uploadRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })}
        />
      )}

      {/* Main content */}
      <main ref={uploadRef} className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-6 md:py-8 space-y-6 scroll-mt-16">
        {/* Uploader card */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FileCode2 className="h-4 w-4" />
              {result ? "Re-run audit" : "Provide your .csproj"}
            </CardTitle>
            <CardDescription className="text-xs">
              Drag &amp; drop, browse, paste XML, or load the sample project to get started.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <FileUploader onAudit={onAudit} loading={loading} />
          </CardContent>
        </Card>

        {/* Error banner */}
        {error && (
          <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-red-700 dark:text-red-300">Audit failed</p>
              <p className="text-muted-foreground mt-0.5 font-mono text-xs break-all">{error}</p>
            </div>
            <Button variant="ghost" size="sm" className="ml-auto" onClick={() => setError(null)}>
              Dismiss
            </Button>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-6">
            {/* Project meta header */}
            <div className="flex flex-wrap items-center gap-3 rounded-xl border bg-card p-4">
              <div className="rounded-lg bg-primary/10 p-2">
                <FileCode2 className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  {renaming ? (
                    <div className="flex items-center gap-1">
                      <input
                        autoFocus
                        value={renameValue}
                        onChange={(e) => setRenameValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") confirmRename();
                          if (e.key === "Escape") setRenaming(false);
                        }}
                        className="text-sm font-semibold bg-background border rounded px-2 py-0.5 outline-none focus:border-primary min-w-[200px]"
                      />
                      <button onClick={confirmRename} className="text-emerald-500 hover:text-emerald-600 p-0.5" aria-label="Confirm rename">
                        <Check className="h-4 w-4" />
                      </button>
                      <button onClick={() => setRenaming(false)} className="text-muted-foreground hover:text-foreground p-0.5" aria-label="Cancel rename">
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ) : (
                    <h3 className="font-semibold truncate group/title">
                      {result.parsed.projectName ?? "Unnamed project"}
                      <button
                        onClick={startRename}
                        className="ml-1.5 inline-flex items-center opacity-0 group-hover/title:opacity-100 transition-opacity text-muted-foreground hover:text-primary"
                        aria-label="Rename project"
                        title="Rename project"
                      >
                        <Pencil className="h-3 w-3" />
                      </button>
                    </h3>
                  )}
                  {result.parsed.sdk && (
                    <Badge variant="secondary" className="text-[10px] font-mono">
                      SDK: {result.parsed.sdk}
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {result.parsed.targetFrameworks.length > 0 ? (
                    <>Target: <span className="font-mono">{result.parsed.targetFrameworks.join(" · ")}</span></>
                  ) : (
                    "No target framework declared"
                  )}
                  {result.parsed.projectReferences.length > 0 && (
                    <> · {result.parsed.projectReferences.length} project reference(s)</>
                  )}
                  {result.parsed.frameworkReferences.length > 0 && (
                    <> · {result.parsed.frameworkReferences.length} framework ref(s)</>
                  )}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="ml-auto"
                onClick={() => {
                  setResult(null);
                  setError(null);
                }}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                New audit
              </Button>
              {scanContext && (
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs gap-1.5"
                  onClick={() => router.push("/scan")}
                >
                  <Github className="h-3.5 w-3.5" />
                  Back to scan
                </Button>
              )}
            </div>

            {/* Quick stats bar + action buttons */}
            <div className="flex flex-wrap items-center gap-2">
              <QuickStatsBar result={result} />
              <div className="flex items-center gap-1.5 ml-auto flex-wrap">
                <IgnoreListButton />
                <CopyAllUpgradesButton result={result} />
                <ExportJsonButton result={result} />
                <BadgeGenerator result={result} />
              </div>
            </div>

            {/* Severity filter chips */}
            <SeverityFilterChips active={severityFilter} onChange={setSeverityFilter} counts={getSeverityCounts(result)} />

            {/* Stats + Health score */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="lg:col-span-2">
                <StatsCards stats={result.stats} durationMs={result.durationMs} />
              </div>
              <Card className="lg:col-span-1">
                <CardContent className="pt-6">
                  <HealthScore
                    totalPackages={result.stats.totalPackages}
                    outdatedCount={result.stats.outdatedCount}
                    vulnerableCount={result.stats.vulnerableCount}
                    deprecatedCount={result.stats.deprecatedCount}
                    maxSeverity={result.stats.maxSeverity}
                  />
                </CardContent>
              </Card>
            </div>

            {/* AI Advisor — always visible after audit */}
            <AiAdvisor result={result} />

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="flex w-full md:grid md:grid-cols-7 h-auto overflow-x-auto no-scrollbar gap-1.5 px-2 py-1.5">
                <TabsTrigger value="graph" className="text-xs shrink-0 px-3">
                  <GitGraph className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Force graph</span>
                  <span className="md:hidden">Graph</span>
                </TabsTrigger>
                <TabsTrigger value="tree" className="text-xs shrink-0 px-3">
                  <Network className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Tree</span>
                  <span className="md:hidden">Tree</span>
                </TabsTrigger>
                <TabsTrigger value="vulns" className="text-xs shrink-0 px-3">
                  <ShieldCheck className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Vulnerabilities</span>
                  <span className="md:hidden">Vulns</span>
                  {result.stats.vulnerableCount > 0 && (
                    <Badge variant="destructive" className="ml-1.5 h-4 px-1 text-[10px]">
                      {result.stats.vulnerableCount}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="outdated" className="text-xs shrink-0 px-3">
                  <Zap className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Outdated</span>
                  <span className="md:hidden">Old</span>
                  {result.stats.outdatedCount > 0 && (
                    <span className="ml-1.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-blue-500 px-1 text-[10px] font-bold text-white">
                      {result.stats.outdatedCount}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="analytics" className="text-xs shrink-0 px-3">
                  <BarChart3 className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Analytics</span>
                  <span className="md:hidden">Stats</span>
                </TabsTrigger>
                <TabsTrigger value="all" className="text-xs shrink-0 px-3">
                  <PackageSearch className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">All packages</span>
                  <span className="md:hidden">All</span>
                </TabsTrigger>
                <TabsTrigger value="upgrade" className="text-xs shrink-0 px-3">
                  <Terminal className="h-3.5 w-3.5 md:mr-1.5" />
                  <span className="hidden md:inline">Upgrade &amp; export</span>
                  <span className="md:hidden">Export</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="graph" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <GitGraph className="h-4 w-4" />
                      Interactive force-directed graph
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Live physics simulation. Drag nodes to pin them, scroll to zoom, hover for details. Red = vulnerable, blue = outdated.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ForceGraph tree={result.tree} onSelect={onTreeNodeSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="tree" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Network className="h-4 w-4" />
                      Dependency tree
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Click any node for full metadata. Direct dependencies are resolved one level deep into transitive deps.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <DependencyTree tree={result.tree} onSelect={onTreeNodeSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="vulns" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4" />
                      Vulnerability audit
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Declared versions matched against the GitHub Advisory ranges embedded in nuget.org registration data.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <VulnerabilityTable packages={result.packages} onSelect={onPkgSelect} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="outdated" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Zap className="h-4 w-4" />
                      Outdated packages
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Compared against the latest stable (non-prerelease) release on nuget.org.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <OutdatedTable packages={result.packages} onSelect={onPkgSelect} onCompare={onCompare} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="analytics" className="mt-4 space-y-4">
                <AnalyticsDashboard result={result} />
                <UpgradeSimulator result={result} />
                <SunburstChart result={result} />
                <VulnerabilityTimeline result={result} />
                <RiskHeatmap result={result} />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <LicensePanel result={result} />
                  <PopularityPanel result={result} />
                </div>
              </TabsContent>

              <TabsContent value="all" className="mt-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <PackageSearch className="h-4 w-4" />
                      All packages
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Every declared PackageReference with its resolved status. Filter &amp; sort to dig in.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <AllPackagesTable packages={result.packages} onSelect={onPkgSelect} onCompare={onCompare} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="upgrade" className="mt-4">
                <UpgradeGenerator result={result} />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </main>

      <Separator />

      {/* Footer */}
      <footer className="relative border-t bg-gradient-to-b from-muted/20 to-muted/40 overflow-hidden">
        <div className="absolute -top-px left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
        <div className="absolute -bottom-20 -right-20 h-40 w-40 rounded-full bg-primary/5 blur-3xl pointer-events-none" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5">
                  <PackageSearch className="h-4 w-4 text-white" />
                </div>
                <span className="font-bold text-sm">NuGet Auditor</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Parse, visualize, and audit your .NET dependencies. Open-source, no signup, no data stored.
              </p>
            </div>

            {/* Resources */}
            <div>
              <p className="text-xs font-semibold mb-3 uppercase tracking-wide text-muted-foreground">Resources</p>
              <ul className="space-y-2 text-xs">
                <li><a href="/scan" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><Github className="h-3 w-3" /> GitHub Repository Scanner</a></li>
                <li><a href="/matrix" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><GitCompare className="h-3 w-3" /> Version Drift Matrix</a></li>
                <li><a href="https://learn.microsoft.com/en-us/nuget/" target="_blank" rel="noreferrer noopener" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><ExternalLink className="h-3 w-3" /> NuGet documentation</a></li>
                <li><a href="https://github.com/advisories?query=type%3Areviewed+ecosystem%3Anuget" target="_blank" rel="noreferrer noopener" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><Github className="h-3 w-3" /> GitHub Advisories</a></li>
                <li><a href="https://www.nuget.org/" target="_blank" rel="noreferrer noopener" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><ExternalLink className="h-3 w-3" /> nuget.org</a></li>
              </ul>
            </div>

            {/* Features */}
            <div>
              <p className="text-xs font-semibold mb-3 uppercase tracking-wide text-muted-foreground">Features</p>
              <ul className="space-y-2 text-xs text-muted-foreground">
                <li className="flex items-center gap-1.5"><ShieldCheck className="h-3 w-3 text-emerald-500" /> CVE vulnerability auditing</li>
                <li className="flex items-center gap-1.5"><GitGraph className="h-3 w-3 text-blue-500" /> Force-directed graph</li>
                <li className="flex items-center gap-1.5"><Bot className="h-3 w-3 text-purple-500" /> AI remediation advisor</li>
                <li className="flex items-center gap-1.5"><Terminal className="h-3 w-3 text-orange-500" /> Upgrade script generator</li>
              </ul>
            </div>

            {/* Privacy */}
            <div>
              <p className="text-xs font-semibold mb-3 uppercase tracking-wide text-muted-foreground">Privacy</p>
              <ul className="space-y-2 text-xs text-muted-foreground">
                <li className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> No signup required</li>
                <li className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Parsed locally in browser</li>
                <li className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> No tracking, no cookies</li>
                <li className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Shares expire automatically</li>
              </ul>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-muted-foreground">
            <p>© {new Date().getFullYear()} NuGet Visualizer &amp; Auditor v{process.env.NEXT_PUBLIC_APP_VERSION || "1.0.0"}. Developed by <span className="font-semibold text-foreground">0xz.0nfirex</span>. All rights reserved.</p>
            <p className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              All systems operational
            </p>
          </div>
        </div>
      </footer>

      <PackageDetailDialog
        pkg={selectedPkg}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onChangelog={openChangelog}
      />
      <VersionCompareDialog
        pkg={comparePkg}
        open={compareOpen}
        onOpenChange={setCompareOpen}
      />
      <AuditHistory
        open={historyOpen}
        onOpenChange={setHistoryOpen}
        currentResult={result}
        onLoadRun={setResult}
        refreshKey={historyRefreshKey}
      />
      <AuditDiffView
        open={diffOpen}
        onOpenChange={setDiffOpen}
        runs={historyRuns}
      />
      <ChangelogViewer
        packageId={changelogPkg?.id ?? null}
        version={changelogPkg?.version ?? null}
        open={changelogOpen}
        onOpenChange={setChangelogOpen}
      />
      <KeyboardShortcuts onShortcut={handleShortcut} />
      <CommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onNavigate={setActiveTab}
        onSave={saveAudit}
        onOpenHistory={() => setHistoryOpen(true)}
        onOpenShortcuts={() => handleShortcut("?")}
        onToggleTheme={() => {
          const el = document.querySelector("[data-theme-toggle]") as HTMLButtonElement | null;
          el?.click();
        }}
        onLoadSample={() => {
          const ta = document.querySelector("textarea");
          if (ta) {
            const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
            setter?.call(ta, SAMPLE_CSPROJ);
            ta.dispatchEvent(new Event("input", { bubbles: true }));
          }
          setTimeout(() => uploadRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
        }}
        hasResult={!!result}
      />
      <Confetti trigger={confettiTrigger} />
    </div>
  );
}

function getSeverityCounts(result: AuditResult): Record<SeverityFilter, number> {
  const pkgs = result.packages;
  return {
    all: pkgs.length,
    critical: pkgs.filter((p) => p.maxSeverity === "critical").length,
    high: pkgs.filter((p) => p.maxSeverity === "high").length,
    moderate: pkgs.filter((p) => p.maxSeverity === "moderate").length,
    low: pkgs.filter((p) => p.maxSeverity === "low").length,
    outdated: pkgs.filter((p) => p.isOutdated).length,
    deprecated: pkgs.filter((p) => p.isDeprecated).length,
    clean: pkgs.filter((p) => !p.isVulnerable && !p.isOutdated && !p.isDeprecated).length,
  };
}
