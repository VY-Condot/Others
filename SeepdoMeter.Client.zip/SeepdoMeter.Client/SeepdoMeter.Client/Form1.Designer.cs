﻿namespace SeepdoMeter.Client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            //modernDataGridView1 = new UltraModernUI.Controls.ModernDataGridView();
            SuspendLayout();
            
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1029, 570);
            //Controls.Add(modernDataGridView1);
            Name = "Form1";
            Text = "Form1";
            //Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        //private UltraModernUI.Controls.ModernDataGridView modernDataGridView1;
    }
}