﻿//////using System;
//////using System.Collections.Generic;
//////using System.ComponentModel;
//////using System.Drawing;
//////using System.Drawing.Drawing2D;
//////using System.Drawing.Text;
//////using System.Windows.Forms;

//////namespace UltraModernUI.Controls
//////{
//////    /// <summary>
//////    /// A fully custom, high-fidelity DataGridView replacement control.
//////    /// Moves completely away from traditional Windows desktop aesthetics, providing 
//////    /// a modern, mathematically precise, web-like dashboard experience.
//////    /// 
//////    /// 
//////    /// 
//////    /// 
//////    /// 
//////    /// 
//////    /// 
//////    /// 
//////    /// 
//////    /// 
//////    /// 
//////    /// </summary>
//////    /// 

//////    /*
//////     * 
//////     * Act as a Principal .NET Desktop Engineer and Elite UI/UX Designer specializing in ultra-modern, high-fidelity WinForms (C#) custom controls.

//////Your primary directive is to create a fully custom control that moves completely away from traditional Windows desktop aesthetics. It must look and feel like a modern web application or high-end hardware dashboard interface: clean, mathematically precise, visually pleasant, and premium.

//////Apply these strict design and engineering principles to every control you generate:

//////1. THE CLEAN & PLEASANT AESTHETIC (The "Reference Quality" Standard):
//////- CRISP TYPOGRAPHY: Never use generic fonts. Use modern system fonts like 'Segoe UI Workspace', 'Segoe UI Variable Display', or 'Arial' with high-contrast text rendering hints ('TextRenderingHint.ClearTypeGridFit'). Ensure labels and values have generous whitespace breathing room.
//////- PERFECT GEOMETRY: All arcs, lines, and shapes must be mathematically calculated and aligned. Use fractional padding margins to ensure shapes never clip against control borders.
//////- BALANCED CORNERS & SMOOTHNESS: Use explicit radius calculations for rounded paths. Apply 'SmoothingMode.AntiAlias' and 'InterpolationMode.HighQualityBicubic' before drawing a single pixel.
//////- MICRO-DETAILS: Implement subtle 1-pixel inner borders (highlights) or soft drop shadows to give elements a tangible, premium weight.

//////2. THEME & 5 DISTINCT DESIGN STYLES:
//////Every control must natively support a 'ThemeMode' enum (Light, Dark) and a 'ControlStyle' enum with 5 highly polished, distinct design paths built directly into the 'OnPaint' engine:
//////- Style 1: Dashboard Premium (Clean white or deep charcoal face, ultra-crisp vector ticks/lines, subtle multi-colored accent thresholds, semi-transparent overlays, and minimalist modern readouts).
//////- Style 2: Fluent Glass (Frosted acrylic backdrops using multi-layered soft alpha-blended fills, thin light-reflecting borders, and vivid neon-accented states).
//////- Style 3: Material Flat (Perfectly flat, bold contrasting color blocks, generous padding, strong focus on layout and modern typography with zero gradients).
//////- Style 4: Soft Neumorphic (Extremely smooth, minimal contrast 3D look using dual directional ambient light shadows and matching embossed center depths).
//////- Style 5: Cyberpunk/Industrial (Deep onyx backing, vibrant glowing neon geometric borders, tech-accented corners, and high-visibility digital fonts).

//////3. ZERO-FLICKER RENDERING & PERFORMANCE:
//////- Initialize the control constructor with optimized double-buffering flags: UserPaint, AllPaintingInWmPaint, DoubleBuffer, and OptimizedDoubleBuffer.
//////- Always fully override 'OnPaint' and do not invoke base.OnPaint(). Build the visual hierarchy from the back layer to the front layer smoothly.

//////4. ABSOLUTE MEMORY SAFETY (GDI+ Disposals):
//////- Follow a strict "instant disposal" pattern. Every Pen, SolidBrush, LinearGradientBrush, Matrix, and GraphicsPath created inside 'OnPaint' MUST be wrapped completely in a 'using' statement block. 
//////- Never let undisposed GDI objects leak into memory, ensuring zero GDI handle accumulation even under high-frequency updates.

//////5. CONTROL STATE & DESIGNER SUPPORT:
//////- Properly override mouse states (Normal, Hover, Pressed, Focused, Disabled) and trigger 'this.Invalidate()' instantly to redraw states smoothly.
//////- Expose all critical properties publicly. Ensure every property setter calls 'this.Invalidate()' so developers can see real-time aesthetic changes directly inside the Visual Studio Designer.

//////OUTPUT REQUIREMENT:
//////Provide the complete, self-contained, and production-ready C# code for the requested control class. Do not use external third-party libraries.

//////     * 
//////     * 
//////     */

//////    public class ModernDataGridView : Control
//////    {
//////        #region Enums
//////        public enum ThemeMode { Light, Dark }
//////        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
//////        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
//////        #endregion

//////        #region Fields & Properties
//////        private ThemeMode _themeMode = ThemeMode.Light;
//////        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
//////        private ControlState _currentState = ControlState.Normal;

//////        private List<string> _headers = new List<string> { "ID", "Status", "Metric", "Value" };
//////        private List<string[]> _rows = new List<string[]>();
//////        private float[] _columnWeights;

//////        private int _hoveredRowIndex = -1;
//////        private int _selectedRowIndex = -1;
//////        private int _scrollOffset = 0;
//////        private int _rowHeight = 42;
//////        private int _headerHeight = 48;

//////        private Rectangle _contentBounds;
//////        private Rectangle _scrollTrackBounds;
//////        private Rectangle _scrollThumbBounds;
//////        private bool _isScrolling = false;

//////        // Typography
//////        private Font _headerFont;
//////        private Font _cellFont;

//////        /// <summary>
//////        /// Gets or sets the theme mode (Light or Dark).
//////        /// </summary>
//////        [Category("Appearance")]
//////        [Description("Sets the overall theme mode (Light or Dark).")]
//////        [DefaultValue(ThemeMode.Light)]
//////        public ThemeMode Theme
//////        {
//////            get { return _themeMode; }
//////            set { _themeMode = value; Invalidate(); }
//////        }

//////        /// <summary>
//////        /// Gets or sets the distinct visual design style.
//////        /// </summary>
//////        [Category("Appearance")]
//////        [Description("Sets the visual design style of the control.")]
//////        [DefaultValue(DesignStyle.DashboardPremium)]
//////        public DesignStyle Style
//////        {
//////            get { return _controlStyle; }
//////            set { _controlStyle = value; Invalidate(); }
//////        }

//////        /// <summary>
//////        /// Gets or sets the headers for the data grid.
//////        /// </summary>
//////        [Category("Data")]
//////        [Description("Sets the column headers.")]
//////        public List<string> Headers
//////        {
//////            get { return _headers; }
//////            set { _headers = value; Invalidate(); }
//////        }

//////        /// <summary>
//////        /// Gets or sets the rows of data to display.
//////        /// </summary>
//////        [Category("Data")]
//////        [Description("Sets the rows of data to display.")]
//////        public List<string[]> Rows
//////        {
//////            get { return _rows; }
//////            set
//////            {
//////                _rows = value;
//////                _selectedRowIndex = -1;
//////                _hoveredRowIndex = -1;
//////                _scrollOffset = 0;
//////                Invalidate();
//////            }
//////        }

//////        public int RowHeight
//////        {
//////            get { return _rowHeight; }
//////            set { _rowHeight = value; Invalidate(); }
//////        }

//////        #endregion

//////        #region Constructor & Initialization
//////        public ModernDataGridView()
//////        {
//////            // Optimized Double Buffering & Zero-Flicker Rendering
//////            SetStyle(ControlStyles.UserPaint |
//////                     ControlStyles.AllPaintingInWmPaint |
//////                     ControlStyles.DoubleBuffer |
//////                     ControlStyles.OptimizedDoubleBuffer |
//////                     ControlStyles.ResizeRedraw |
//////                     ControlStyles.Selectable |
//////                     ControlStyles.SupportsTransparentBackColor, true);

//////            UpdateFonts();
//////            BackColor = Color.Transparent;
//////            Size = new Size(600, 400);
//////        }

//////        private void UpdateFonts()
//////        {
//////            // Dispose old fonts to prevent memory leaks
//////            _headerFont?.Dispose();
//////            _cellFont?.Dispose();

//////            // Crisp typography with modern system fonts
//////            string fontName = "Segoe UI Variable Display";
//////            try
//////            {
//////                using (var testFont = new Font(fontName, 9f))
//////                {
//////                    if (testFont.Name != fontName) fontName = "Segoe UI";
//////                }
//////                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
//////                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
//////            }
//////            catch
//////            {
//////                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
//////                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
//////            }
//////        }
//////        #endregion

//////        #region Memory Safe Layout Calculation
//////        private void CalculateLayout()
//////        {
//////            _contentBounds = new Rectangle(12, 12, Width - 24, Height - 24);

//////            if (_columnWeights == null || _columnWeights.Length != _headers.Count)
//////            {
//////                _columnWeights = new float[_headers.Count];
//////                for (int i = 0; i < _headers.Count; i++) _columnWeights[i] = 1f / _headers.Count;
//////            }

//////            // Scrollbar Calculation
//////            int visibleHeight = _contentBounds.Height - _headerHeight;
//////            int totalContentHeight = _rows.Count * _rowHeight;

//////            if (totalContentHeight > visibleHeight)
//////            {
//////                int scrollWidth = 6;
//////                _scrollTrackBounds = new Rectangle(
//////                    _contentBounds.Right - scrollWidth - 2,
//////                    _contentBounds.Y + _headerHeight + 4,
//////                    scrollWidth,
//////                    visibleHeight - 8);

//////                float scrollRatio = (float)visibleHeight / totalContentHeight;
//////                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
//////                int maxScroll = totalContentHeight - visibleHeight;
//////                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / maxScroll) * (_scrollTrackBounds.Height - thumbHeight));

//////                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
//////            }
//////            else
//////            {
//////                _scrollTrackBounds = Rectangle.Empty;
//////                _scrollThumbBounds = Rectangle.Empty;
//////                _scrollOffset = 0;
//////            }
//////        }
//////        #endregion

//////        #region Color Palette Engine
//////        private Color GetBackgroundColor()
//////        {
//////            switch (_controlStyle)
//////            {
//////                case DesignStyle.DashboardPremium:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26);
//////                case DesignStyle.FluentGlass:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32);
//////                case DesignStyle.MaterialFlat:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18);
//////                case DesignStyle.SoftNeumorphic:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48);
//////                case DesignStyle.CyberpunkIndustrial:
//////                    return Color.FromArgb(12, 12, 14);
//////                default: return Color.White;
//////            }
//////        }

//////        // --- ADD THIS METHOD HERE ---
//////        private SolidBrush GetBackgroundBrush()
//////        {
//////            return new SolidBrush(GetBackgroundColor());
//////        }
//////        // ----------------------------

//////        #region Core Paint Engine
//////        protected override void OnPaint(PaintEventArgs e)
//////        {
//////            // DO NOT invoke base.OnPaint();

//////            Graphics g = e.Graphics;
//////            g.SmoothingMode = SmoothingMode.AntiAlias;
//////            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
//////            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
//////            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

//////            CalculateLayout();

//////            // Draw Background Layer
//////            using (SolidBrush bgBrush = GetBackgroundBrush())
//////            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8))
//////            {
//////                g.FillPath(bgBrush, bgPath);
//////            }

//////            // Clip the drawing strictly to the inner content bounds to prevent overflow
//////            using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
//////            {
//////                g.SetClip(contentClipPath);

//////                DrawHeader(g);
//////                DrawRows(g);

//////                g.ResetClip();
//////            }

//////            // Draw Outer Micro-details (Borders/Shadows)
//////            DrawOuterBorder(g);
//////            DrawScrollbar(g);
//////        }

//////        private void DrawHeader(Graphics g)
//////        {
//////            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y, _contentBounds.Width, _headerHeight);
//////            int colX = headerRect.X;

//////            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//////            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
//////            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
//////            {
//////                for (int i = 0; i < _headers.Count; i++)
//////                {
//////                    float colWidth = _contentBounds.Width * _columnWeights[i];
//////                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, colWidth - 24, headerRect.Height);

//////                    if (string.IsNullOrEmpty(_headers[i])) continue;

//////                    g.DrawString(_headers[i], _headerFont, textBrush, cellRect, sf);
//////                    colX += (int)colWidth;
//////                }

//////                // Header separator line
//////                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
//////            }
//////        }

//////        private void DrawRows(Graphics g)
//////        {
//////            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight);

//////            // Calculate index offset based on scroll
//////            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
//////            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 1;

//////            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//////            {
//////                for (int i = firstVisibleRow; i < Math.Min(_rows.Count, firstVisibleRow + visibleRowCount); i++)
//////                {
//////                    if (i < 0) continue;

//////                    int y = rowArea.Y + (i * _rowHeight) - _scrollOffset;
//////                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, _rowHeight);

//////                    // Apply specific row painting based on style and state
//////                    DrawRowBackground(g, rowRect, i);
//////                    DrawRowContent(g, rowRect, i, sf);
//////                }
//////            }
//////        }

//////        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex)
//////        {
//////            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
//////            bool isSelected = (rowIndex == _selectedRowIndex);

//////            switch (_controlStyle)
//////            {
//////                case DesignStyle.DashboardPremium:
//////                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
//////                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//////                    using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1))
//////                    {
//////                        if (isSelected) g.FillRectangle(selBrush, rowRect);
//////                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);

//////                        // Minimalist separator
//////                        g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);
//////                    }
//////                    break;

//////                case DesignStyle.FluentGlass:
//////                    if (isSelected || isHovered)
//////                    {
//////                        using (var path = GetRoundedPath(rowRect, 4))
//////                        using (var glowPen = new Pen(Color.FromArgb(isSelected ? 255 : 150, GetAccentColor()), 1))
//////                        using (var fillBrush = new SolidBrush(Color.FromArgb(isSelected ? 40 : 20, GetAccentColor())))
//////                        {
//////                            g.FillPath(fillBrush, path);
//////                            g.DrawPath(glowPen, path);
//////                        }
//////                    }
//////                    break;

//////                case DesignStyle.MaterialFlat:
//////                    Color matBg = Color.Transparent;
//////                    if (isSelected) matBg = Color.FromArgb(255, GetAccentColor());
//////                    else if (isHovered) matBg = Color.FromArgb(50, GetForegroundColor());

//////                    if (matBg != Color.Transparent)
//////                        using (var matBrush = new SolidBrush(matBg))
//////                        {
//////                            g.FillRectangle(matBrush, rowRect);
//////                        }
//////                    break;

//////                case DesignStyle.SoftNeumorphic:
//////                    // Neumorphic rows are usually flat with shadow extrusions. 
//////                    // For a grid, we just draw a subtle inner line for separation unless hovered/selected.
//////                    if (isHovered || isSelected)
//////                    {
//////                        using (var path = GetRoundedPath(Rectangle.Inflate(rowRect, -2, -2), 6))
//////                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
//////                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
//////                        using (var bgBrush = new SolidBrush(GetBackgroundColor()))
//////                        {
//////                            g.FillPath(bgBrush, path);
//////                            // Inset shadow for selection (Pressed look)
//////                            if (isSelected)
//////                            {
//////                                g.DrawPath(darkPen, path);
//////                                // Translate for inner shadow
//////                                using (var translateMatrix = new Matrix())
//////                                {
//////                                    translateMatrix.Translate(-1, -1);
//////                                    g.Transform = translateMatrix;
//////                                    g.DrawPath(lightPen, path);
//////                                    g.ResetTransform();
//////                                }
//////                            }
//////                            else // Outset for hover
//////                            {
//////                                g.DrawPath(lightPen, path);
//////                                using (var translateMatrix = new Matrix())
//////                                {
//////                                    translateMatrix.Translate(1, 1);
//////                                    g.Transform = translateMatrix;
//////                                    g.DrawPath(darkPen, path);
//////                                    g.ResetTransform();
//////                                }
//////                            }
//////                        }
//////                    }
//////                    break;

//////                case DesignStyle.CyberpunkIndustrial:
//////                    if (isHovered || isSelected)
//////                        using (var cyberPath = new GraphicsPath())
//////                        {
//////                            PointF[] corners = {
//////                            new PointF(rowRect.Left + 6, rowRect.Top),
//////                            new PointF(rowRect.Right, rowRect.Top),
//////                            new PointF(rowRect.Right, rowRect.Bottom),
//////                            new PointF(rowRect.Left, rowRect.Bottom),
//////                            new PointF(rowRect.Left, rowRect.Top + 6)
//////                        };
//////                            cyberPath.AddLines(corners);
//////                            cyberPath.CloseFigure();

//////                            using (var cyberBrush = new SolidBrush(Color.FromArgb(isSelected ? 40 : 15, GetAccentColor())))
//////                            using (var cyberPen = new Pen(Color.FromArgb(isSelected ? 255 : 100, GetAccentColor()), 1))
//////                            {
//////                                g.FillPath(cyberBrush, cyberPath);
//////                                g.DrawPath(cyberPen, cyberPath);
//////                            }
//////                        }
//////                    break;
//////            }
//////        }

//////        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
//////        {
//////            int colX = rowRect.X;
//////            using (SolidBrush textBrush = new SolidBrush(GetForegroundColor()))
//////            {
//////                for (int i = 0; i < _headers.Count; i++)
//////                {
//////                    float colWidth = _contentBounds.Width * _columnWeights[i];
//////                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, colWidth - 24, rowRect.Height);

//////                    string val = _rows[rowIndex].Length > i ? _rows[rowIndex][i] : "";
//////                    g.DrawString(val, _cellFont, textBrush, cellRect, sf);

//////                    colX += (int)colWidth;
//////                }
//////            }
//////        }

//////        private void DrawOuterBorder(Graphics g)
//////        {
//////            // Micro-details and premium borders
//////            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
//////            {
//////                switch (_controlStyle)
//////                {
//////                    case DesignStyle.DashboardPremium:
//////                        using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1))
//////                            g.DrawPath(borderPen, path);
//////                        break;

//////                    case DesignStyle.FluentGlass:
//////                        using (var borderPen = new Pen(Color.FromArgb(100, 255, 255, 255), 1))
//////                            g.DrawPath(borderPen, path);
//////                        break;

//////                    case DesignStyle.MaterialFlat:
//////                        // Material usually has no border, relies on background contrast
//////                        break;

//////                    case DesignStyle.SoftNeumorphic:
//////                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
//////                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
//////                        {
//////                            g.DrawPath(lightPen, path);
//////                            using (var m = new Matrix())
//////                            {
//////                                m.Translate(1, 1);
//////                                g.Transform = m;
//////                                g.DrawPath(darkPen, path);
//////                                g.ResetTransform();
//////                            }
//////                        }
//////                        break;

//////                    case DesignStyle.CyberpunkIndustrial:
//////                        // Glowing border
//////                        using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4))
//////                        using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1))
//////                        {
//////                            g.DrawPath(glowPen, path);
//////                            g.DrawPath(corePen, path);
//////                        }
//////                        break;
//////                }
//////            }
//////        }

//////        private void DrawScrollbar(Graphics g)
//////        {
//////            if (_scrollThumbBounds == Rectangle.Empty) return;

//////            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
//////            {
//////                Color thumbColor = GetAccentColor();
//////                if (_isScrolling) thumbColor = ControlPaint.Dark(thumbColor, 0.1f);

//////                using (var thumbBrush = new SolidBrush(Color.FromArgb(180, thumbColor)))
//////                {
//////                    g.FillPath(thumbBrush, thumbPath);
//////                }
//////            }
//////        }
//////        #endregion

//////        #region Color Palette Engine
//////        private Color GetBackgroundColor()
//////        {
//////            switch (_controlStyle)
//////            {
//////                case DesignStyle.DashboardPremium:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26);
//////                case DesignStyle.FluentGlass:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32);
//////                case DesignStyle.MaterialFlat:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18);
//////                case DesignStyle.SoftNeumorphic:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48);
//////                case DesignStyle.CyberpunkIndustrial:
//////                    return Color.FromArgb(12, 12, 14);
//////                default: return Color.White;
//////            }
//////        }

//////        private Color GetForegroundColor()
//////        {
//////            switch (_controlStyle)
//////            {
//////                case DesignStyle.CyberpunkIndustrial:
//////                    return Color.FromArgb(230, 240, 255);
//////                case DesignStyle.SoftNeumorphic:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240);
//////                default:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240);
//////            }
//////        }

//////        private Color GetHeaderTextColor()
//////        {
//////            switch (_controlStyle)
//////            {
//////                case DesignStyle.CyberpunkIndustrial:
//////                    return GetAccentColor();
//////                case DesignStyle.SoftNeumorphic:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 170, 180);
//////                default:
//////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160);
//////            }
//////        }

//////        private Color GetHeaderSeparatorColor()
//////        {
//////            return _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
//////        }

//////        private Color GetAccentColor()
//////        {
//////            switch (_controlStyle)
//////            {
//////                case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212); // Fluent Blue
//////                case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255);      // Neon Blue
//////                case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238);      // Material Purple
//////                case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51);  // Coral/Orange
//////                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204); // Cyan Neon
//////                default: return Color.Blue;
//////            }
//////        }

//////        private Color GetNeumorphicLightColor()
//////        {
//////            return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
//////        }

//////        private Color GetNeumorphicDarkColor()
//////        {
//////            return _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
//////        }
//////        #endregion

//////        #region Geometry Helpers
//////        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
//////        {
//////            GraphicsPath path = new GraphicsPath();
//////            if (rect.Width <= 0 || rect.Height <= 0) return path;

//////            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));

//////            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
//////            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
//////            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
//////            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
//////            path.CloseFigure();
//////            return path;
//////        }
//////        #endregion

//////        #region Mouse & State Handling
//////        protected override void OnMouseMove(MouseEventArgs e)
//////        {
//////            base.OnMouseMove(e);

//////            if (_isScrolling)
//////            {
//////                UpdateScrollPosition(e.Y);
//////                return;
//////            }

//////            int newHoveredRow = GetRowAtPosition(e.Location);
//////            if (newHoveredRow != _hoveredRowIndex)
//////            {
//////                _hoveredRowIndex = newHoveredRow;
//////                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
//////                Invalidate();
//////            }
//////            else if (_scrollThumbBounds.Contains(e.Location) && !Cursor.Equals(Cursors.SizeNS))
//////            {
//////                Cursor = Cursors.SizeNS;
//////            }
//////            else if (!_scrollThumbBounds.Contains(e.Location) && Cursor.Equals(Cursors.SizeNS) && !_isScrolling)
//////            {
//////                Cursor = Cursors.Default;
//////            }
//////        }

//////        protected override void OnMouseDown(MouseEventArgs e)
//////        {
//////            base.OnMouseDown(e);
//////            Focus();

//////            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
//////            {
//////                _isScrolling = true;
//////                Cursor = Cursors.SizeNS;
//////                _currentState = ControlState.Pressed;
//////                Invalidate();
//////                return;
//////            }

//////            int clickedRow = GetRowAtPosition(e.Location);
//////            if (clickedRow != -1)
//////            {
//////                _selectedRowIndex = clickedRow;
//////                _currentState = ControlState.Pressed;
//////                Invalidate();
//////            }
//////        }

//////        protected override void OnMouseUp(MouseEventArgs e)
//////        {
//////            base.OnMouseUp(e);
//////            _isScrolling = false;
//////            Cursor = Cursors.Default;
//////            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
//////            Invalidate();
//////        }

//////        protected override void OnMouseLeave(EventArgs e)
//////        {
//////            base.OnMouseLeave(e);
//////            _hoveredRowIndex = -1;
//////            _currentState = ControlState.Normal;
//////            Cursor = Cursors.Default;
//////            Invalidate();
//////        }

//////        protected override void OnMouseWheel(MouseEventArgs e)
//////        {
//////            base.OnMouseWheel(e);
//////            if (_rows.Count == 0) return;

//////            int visibleHeight = _contentBounds.Height - _headerHeight;
//////            int totalContentHeight = _rows.Count * _rowHeight;

//////            if (totalContentHeight > visibleHeight)
//////            {
//////                _scrollOffset -= e.Delta;
//////                _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, totalContentHeight - visibleHeight));
//////                Invalidate();
//////            }
//////        }

//////        private int GetRowAtPosition(Point p)
//////        {
//////            if (!_contentBounds.Contains(p)) return -1;

//////            int relativeY = p.Y - (_contentBounds.Y + _headerHeight) + _scrollOffset;
//////            if (relativeY < 0) return -1;

//////            int rowIndex = relativeY / _rowHeight;
//////            if (rowIndex >= 0 && rowIndex < _rows.Count)
//////            {
//////                return rowIndex;
//////            }
//////            return -1;
//////        }

//////        private void UpdateScrollPosition(int mouseY)
//////        {
//////            int visibleHeight = _contentBounds.Height - _headerHeight;
//////            int totalContentHeight = _rows.Count * _rowHeight;
//////            int maxScroll = totalContentHeight - visibleHeight;

//////            if (maxScroll <= 0) return;

//////            int thumbHeight = _scrollThumbBounds.Height;
//////            int trackHeight = _scrollTrackBounds.Height - thumbHeight;

//////            // Relative mouse position within track
//////            int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2);
//////            relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight));

//////            float scrollRatio = (float)relativeMouseY / trackHeight;
//////            _scrollOffset = (int)(scrollRatio * maxScroll);

//////            Invalidate();
//////        }

//////        protected override void Dispose(bool disposing)
//////        {
//////            if (disposing)
//////            {
//////                _headerFont?.Dispose();
//////                _cellFont?.Dispose();
//////            }
//////            base.Dispose(disposing);
//////        }
//////        #endregion
//////    }
//////}
















////using System;
////using System.Collections.Generic;
////using System.ComponentModel;
////using System.Drawing;
////using System.Drawing.Drawing2D;
////using System.Drawing.Text;
////using System.Windows.Forms;

////namespace UltraModernUI.Controls
////{
////    /// <summary>
////    /// A fully custom, high-fidelity DataGridView replacement control.
////    /// Moves completely away from traditional Windows desktop aesthetics, providing 
////    /// a modern, mathematically precise, web-like dashboard experience.
////    /// </summary>
////    public class ModernDataGridView : Control
////    {
////        #region Enums
////        public enum ThemeMode { Light, Dark }
////        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
////        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
////        #endregion

////        #region Fields & Properties
////        private ThemeMode _themeMode = ThemeMode.Light;
////        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
////        private ControlState _currentState = ControlState.Normal;

////        private List<string> _headers = new List<string> { "ID", "Status", "Metric", "Value" };
////        private List<string[]> _rows = new List<string[]>();
////        private float[] _columnWeights;

////        private int _hoveredRowIndex = -1;
////        private int _selectedRowIndex = -1;
////        private int _scrollOffset = 0;
////        private int _rowHeight = 42;
////        private int _headerHeight = 48;

////        private Rectangle _contentBounds;
////        private Rectangle _scrollTrackBounds;
////        private Rectangle _scrollThumbBounds;
////        private bool _isScrolling = false;

////        // Typography
////        private Font _headerFont;
////        private Font _cellFont;

////        /// <summary>
////        /// Gets or sets the theme mode (Light or Dark).
////        /// </summary>
////        [Category("Appearance")]
////        [Description("Sets the overall theme mode (Light or Dark).")]
////        [DefaultValue(ThemeMode.Light)]
////        public ThemeMode Theme
////        {
////            get { return _themeMode; }
////            set { _themeMode = value; Invalidate(); }
////        }

////        /// <summary>
////        /// Gets or sets the distinct visual design style.
////        /// </summary>
////        [Category("Appearance")]
////        [Description("Sets the visual design style of the control.")]
////        [DefaultValue(DesignStyle.DashboardPremium)]
////        public DesignStyle Style
////        {
////            get { return _controlStyle; }
////            set { _controlStyle = value; Invalidate(); }
////        }

////        /// <summary>
////        /// Gets or sets the headers for the data grid.
////        /// </summary>
////        [Category("Data")]
////        [Description("Sets the column headers.")]
////        public List<string> Headers
////        {
////            get { return _headers; }
////            set { _headers = value; Invalidate(); }
////        }

////        /// <summary>
////        /// Gets or sets the rows of data to display.
////        /// </summary>
////        [Category("Data")]
////        [Description("Sets the rows of data to display.")]
////        public List<string[]> Rows
////        {
////            get { return _rows; }
////            set
////            {
////                _rows = value;
////                _selectedRowIndex = -1;
////                _hoveredRowIndex = -1;
////                _scrollOffset = 0;
////                Invalidate();
////            }
////        }

////        [Category("Appearance")]
////        [Description("Sets the height of each data row.")]
////        [DefaultValue(42)]
////        public int RowHeight
////        {
////            get { return _rowHeight; }
////            set { _rowHeight = value; Invalidate(); }
////        }

////        #endregion

////        #region Constructor & Initialization
////        public ModernDataGridView()
////        {
////            // Optimized Double Buffering & Zero-Flicker Rendering
////            SetStyle(ControlStyles.UserPaint |
////                     ControlStyles.AllPaintingInWmPaint |
////                     ControlStyles.DoubleBuffer |
////                     ControlStyles.OptimizedDoubleBuffer |
////                     ControlStyles.ResizeRedraw |
////                     ControlStyles.Selectable |
////                     ControlStyles.SupportsTransparentBackColor, true);

////            UpdateFonts();
////            BackColor = Color.Transparent;
////            Size = new Size(600, 400);

////            // Load dummy data for designer preview
////            if (LicenseManager.UsageMode == LicenseUsageMode.Designtime || _rows.Count == 0)
////            {
////                _rows = new List<string[]>
////                {
////                    new string[] { "001", "Active", "CPU Load", "24%" },
////                    new string[] { "002", "Idle", "Memory", "4.2GB" },
////                    new string[] { "003", "Warning", "Network", "120Mb/s" },
////                    new string[] { "004", "Active", "Disk I/O", "89MB/s" },
////                    new string[] { "005", "Active", "Temp", "54°C" },
////                    new string[] { "006", "Offline", "Uptime", "0h 0m" },
////                    new string[] { "007", "Active", "Requests", "1.2K/s" },
////                    new string[] { "008", "Active", "Latency", "12ms" }
////                };
////            }
////        }

////        private void UpdateFonts()
////        {
////            // Dispose old fonts to prevent memory leaks
////            _headerFont?.Dispose();
////            _cellFont?.Dispose();

////            // Crisp typography with modern system fonts
////            string fontName = "Segoe UI Variable Display";
////            try
////            {
////                using (var testFont = new Font(fontName, 9f))
////                {
////                    if (testFont.Name != fontName) fontName = "Segoe UI";
////                }
////                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
////                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
////            }
////            catch
////            {
////                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
////                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
////            }
////        }
////        #endregion

////        #region Memory Safe Layout Calculation
////        private void CalculateLayout()
////        {
////            _contentBounds = new Rectangle(12, 12, Width - 24, Height - 24);

////            if (_columnWeights == null || _columnWeights.Length != _headers.Count)
////            {
////                _columnWeights = new float[_headers.Count];
////                for (int i = 0; i < _headers.Count; i++) _columnWeights[i] = 1f / _headers.Count;
////            }

////            // Scrollbar Calculation
////            int visibleHeight = _contentBounds.Height - _headerHeight;
////            int totalContentHeight = _rows.Count * _rowHeight;

////            if (totalContentHeight > visibleHeight)
////            {
////                int scrollWidth = 6;
////                _scrollTrackBounds = new Rectangle(
////                    _contentBounds.Right - scrollWidth - 2,
////                    _contentBounds.Y + _headerHeight + 4,
////                    scrollWidth,
////                    visibleHeight - 8);

////                float scrollRatio = (float)visibleHeight / totalContentHeight;
////                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
////                int maxScroll = totalContentHeight - visibleHeight;
////                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / maxScroll) * (_scrollTrackBounds.Height - thumbHeight));

////                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
////            }
////            else
////            {
////                _scrollTrackBounds = Rectangle.Empty;
////                _scrollThumbBounds = Rectangle.Empty;
////                _scrollOffset = 0;
////            }
////        }
////        #endregion

////        #region Core Paint Engine
////        protected override void OnPaint(PaintEventArgs e)
////        {
////            // DO NOT invoke base.OnPaint();

////            Graphics g = e.Graphics;
////            g.SmoothingMode = SmoothingMode.AntiAlias;
////            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
////            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
////            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

////            CalculateLayout();

////            // Draw Background Layer
////            using (SolidBrush bgBrush = GetBackgroundBrush())
////            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8))
////            {
////                g.FillPath(bgBrush, bgPath);
////            }

////            // Clip the drawing strictly to the inner content bounds to prevent overflow
////            using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
////            {
////                g.SetClip(contentClipPath);

////                DrawHeader(g);
////                DrawRows(g);

////                g.ResetClip();
////            }

////            // Draw Outer Micro-details (Borders/Shadows)
////            DrawOuterBorder(g);
////            DrawScrollbar(g);
////        }

////        private void DrawHeader(Graphics g)
////        {
////            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y, _contentBounds.Width, _headerHeight);
////            int colX = headerRect.X;

////            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
////            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
////            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
////            {
////                for (int i = 0; i < _headers.Count; i++)
////                {
////                    float colWidth = _contentBounds.Width * _columnWeights[i];
////                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, colWidth - 24, headerRect.Height);

////                    if (string.IsNullOrEmpty(_headers[i])) continue;

////                    g.DrawString(_headers[i], _headerFont, textBrush, cellRect, sf);
////                    colX += (int)colWidth;
////                }

////                // Header separator line
////                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
////            }
////        }

////        private void DrawRows(Graphics g)
////        {
////            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight);

////            // Calculate index offset based on scroll
////            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
////            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 1;

////            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
////            {
////                for (int i = firstVisibleRow; i < Math.Min(_rows.Count, firstVisibleRow + visibleRowCount); i++)
////                {
////                    if (i < 0) continue;

////                    int y = rowArea.Y + (i * _rowHeight) - _scrollOffset;
////                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, _rowHeight);

////                    // Apply specific row painting based on style and state
////                    DrawRowBackground(g, rowRect, i);
////                    DrawRowContent(g, rowRect, i, sf);
////                }
////            }
////        }

////        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex)
////        {
////            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
////            bool isSelected = (rowIndex == _selectedRowIndex);

////            switch (_controlStyle)
////            {
////                case DesignStyle.DashboardPremium:
////                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
////                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
////                    using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1))
////                    {
////                        if (isSelected) g.FillRectangle(selBrush, rowRect);
////                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);

////                        // Minimalist separator
////                        g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);
////                    }
////                    break;

////                case DesignStyle.FluentGlass:
////                    if (isSelected || isHovered)
////                    {
////                        using (var path = GetRoundedPath(rowRect, 4))
////                        using (var glowPen = new Pen(Color.FromArgb(isSelected ? 255 : 150, GetAccentColor()), 1))
////                        using (var fillBrush = new SolidBrush(Color.FromArgb(isSelected ? 40 : 20, GetAccentColor())))
////                        {
////                            g.FillPath(fillBrush, path);
////                            g.DrawPath(glowPen, path);
////                        }
////                    }
////                    break;

////                case DesignStyle.MaterialFlat:
////                    Color matBg = Color.Transparent;
////                    if (isSelected) matBg = Color.FromArgb(255, GetAccentColor());
////                    else if (isHovered) matBg = Color.FromArgb(50, GetForegroundColor());

////                    if (matBg != Color.Transparent)
////                        using (var matBrush = new SolidBrush(matBg))
////                        {
////                            g.FillRectangle(matBrush, rowRect);
////                        }
////                    break;

////                case DesignStyle.SoftNeumorphic:
////                    // Neumorphic rows are usually flat with shadow extrusions. 
////                    // For a grid, we just draw a subtle inner line for separation unless hovered/selected.
////                    if (isHovered || isSelected)
////                    {
////                        using (var path = GetRoundedPath(Rectangle.Inflate(rowRect, -2, -2), 6))
////                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
////                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
////                        using (var bgBrush = new SolidBrush(GetBackgroundColor()))
////                        {
////                            g.FillPath(bgBrush, path);
////                            // Inset shadow for selection (Pressed look)
////                            if (isSelected)
////                            {
////                                g.DrawPath(darkPen, path);
////                                g.TranslateTransform(-1, -1);
////                                g.DrawPath(lightPen, path);
////                                g.ResetTransform();
////                            }
////                            else // Outset for hover
////                            {
////                                g.DrawPath(lightPen, path);
////                                g.TranslateTransform(1, 1);
////                                g.DrawPath(darkPen, path);
////                                g.ResetTransform();
////                            }
////                        }
////                    }
////                    break;

////                case DesignStyle.CyberpunkIndustrial:
////                    if (isHovered || isSelected)
////                        using (var cyberPath = new GraphicsPath())
////                        {
////                            PointF[] corners = {
////                            new PointF(rowRect.Left + 6, rowRect.Top),
////                            new PointF(rowRect.Right, rowRect.Top),
////                            new PointF(rowRect.Right, rowRect.Bottom),
////                            new PointF(rowRect.Left, rowRect.Bottom),
////                            new PointF(rowRect.Left, rowRect.Top + 6)
////                        };
////                            cyberPath.AddLines(corners);
////                            cyberPath.CloseFigure();

////                            using (var cyberBrush = new SolidBrush(Color.FromArgb(isSelected ? 40 : 15, GetAccentColor())))
////                            using (var cyberPen = new Pen(Color.FromArgb(isSelected ? 255 : 100, GetAccentColor()), 1))
////                            {
////                                g.FillPath(cyberBrush, cyberPath);
////                                g.DrawPath(cyberPen, cyberPath);
////                            }
////                        }
////                    break;
////            }
////        }

////        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
////        {
////            int colX = rowRect.X;
////            using (SolidBrush textBrush = new SolidBrush(GetForegroundColor()))
////            {
////                for (int i = 0; i < _headers.Count; i++)
////                {
////                    float colWidth = _contentBounds.Width * _columnWeights[i];
////                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, colWidth - 24, rowRect.Height);

////                    string val = _rows[rowIndex].Length > i ? _rows[rowIndex][i] : "";
////                    g.DrawString(val, _cellFont, textBrush, cellRect, sf);

////                    colX += (int)colWidth;
////                }
////            }
////        }

////        private void DrawOuterBorder(Graphics g)
////        {
////            // Micro-details and premium borders
////            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
////            {
////                switch (_controlStyle)
////                {
////                    case DesignStyle.DashboardPremium:
////                        using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1))
////                            g.DrawPath(borderPen, path);
////                        break;

////                    case DesignStyle.FluentGlass:
////                        using (var borderPen = new Pen(Color.FromArgb(100, 255, 255, 255), 1))
////                            g.DrawPath(borderPen, path);
////                        break;

////                    case DesignStyle.MaterialFlat:
////                        // Material usually has no border, relies on background contrast
////                        break;

////                    case DesignStyle.SoftNeumorphic:
////                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
////                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
////                        {
////                            g.DrawPath(lightPen, path);
////                            g.TranslateTransform(1, 1);
////                            g.DrawPath(darkPen, path);
////                            g.ResetTransform();
////                        }
////                        break;

////                    case DesignStyle.CyberpunkIndustrial:
////                        // Glowing border
////                        using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4))
////                        using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1))
////                        {
////                            g.DrawPath(glowPen, path);
////                            g.DrawPath(corePen, path);
////                        }
////                        break;
////                }
////            }
////        }

////        private void DrawScrollbar(Graphics g)
////        {
////            if (_scrollThumbBounds == Rectangle.Empty) return;

////            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
////            {
////                Color thumbColor = GetAccentColor();
////                if (_isScrolling) thumbColor = ControlPaint.Dark(thumbColor, 0.1f);

////                using (var thumbBrush = new SolidBrush(Color.FromArgb(180, thumbColor)))
////                {
////                    g.FillPath(thumbBrush, thumbPath);
////                }
////            }
////        }
////        #endregion

////        #region Color Palette Engine
////        private Color GetBackgroundColor()
////        {
////            switch (_controlStyle)
////            {
////                case DesignStyle.DashboardPremium:
////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26);
////                case DesignStyle.FluentGlass:
////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32);
////                case DesignStyle.MaterialFlat:
////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18);
////                case DesignStyle.SoftNeumorphic:
////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48);
////                case DesignStyle.CyberpunkIndustrial:
////                    return Color.FromArgb(12, 12, 14);
////                default: return Color.White;
////            }
////        }

////        private SolidBrush GetBackgroundBrush()
////        {
////            return new SolidBrush(GetBackgroundColor());
////        }

////        private Color GetForegroundColor()
////        {
////            switch (_controlStyle)
////            {
////                case DesignStyle.CyberpunkIndustrial:
////                    return Color.FromArgb(230, 240, 255);
////                case DesignStyle.SoftNeumorphic:
////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240);
////                default:
////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240);
////            }
////        }

////        private Color GetHeaderTextColor()
////        {
////            switch (_controlStyle)
////            {
////                case DesignStyle.CyberpunkIndustrial:
////                    return GetAccentColor();
////                case DesignStyle.SoftNeumorphic:
////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 170, 180);
////                default:
////                    return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160);
////            }
////        }

////        private Color GetHeaderSeparatorColor()
////        {
////            return _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
////        }

////        private Color GetAccentColor()
////        {
////            switch (_controlStyle)
////            {
////                case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212); // Fluent Blue
////                case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255);      // Neon Blue
////                case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238);      // Material Purple
////                case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51);  // Coral/Orange
////                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204); // Cyan Neon
////                default: return Color.Blue;
////            }
////        }

////        private Color GetNeumorphicLightColor()
////        {
////            return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
////        }

////        private Color GetNeumorphicDarkColor()
////        {
////            return _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
////        }
////        #endregion

////        #region Geometry Helpers
////        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
////        {
////            GraphicsPath path = new GraphicsPath();
////            if (rect.Width <= 0 || rect.Height <= 0) return path;

////            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));

////            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
////            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
////            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
////            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
////            path.CloseFigure();
////            return path;
////        }
////        #endregion

////        #region Mouse & State Handling
////        protected override void OnMouseMove(MouseEventArgs e)
////        {
////            base.OnMouseMove(e);

////            if (_isScrolling)
////            {
////                UpdateScrollPosition(e.Y);
////                return;
////            }

////            int newHoveredRow = GetRowAtPosition(e.Location);
////            if (newHoveredRow != _hoveredRowIndex)
////            {
////                _hoveredRowIndex = newHoveredRow;
////                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
////                Invalidate();
////            }
////            else if (_scrollThumbBounds.Contains(e.Location) && !Cursor.Equals(Cursors.SizeNS))
////            {
////                Cursor = Cursors.SizeNS;
////            }
////            else if (!_scrollThumbBounds.Contains(e.Location) && Cursor.Equals(Cursors.SizeNS) && !_isScrolling)
////            {
////                Cursor = Cursors.Default;
////            }
////        }

////        protected override void OnMouseDown(MouseEventArgs e)
////        {
////            base.OnMouseDown(e);
////            Focus();

////            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
////            {
////                _isScrolling = true;
////                Cursor = Cursors.SizeNS;
////                _currentState = ControlState.Pressed;
////                Invalidate();
////                return;
////            }

////            int clickedRow = GetRowAtPosition(e.Location);
////            if (clickedRow != -1)
////            {
////                _selectedRowIndex = clickedRow;
////                _currentState = ControlState.Pressed;
////                Invalidate();
////            }
////        }

////        protected override void OnMouseUp(MouseEventArgs e)
////        {
////            base.OnMouseUp(e);
////            _isScrolling = false;
////            Cursor = Cursors.Default;
////            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
////            Invalidate();
////        }

////        protected override void OnMouseLeave(EventArgs e)
////        {
////            base.OnMouseLeave(e);
////            _hoveredRowIndex = -1;
////            _currentState = ControlState.Normal;
////            Cursor = Cursors.Default;
////            Invalidate();
////        }

////        protected override void OnMouseWheel(MouseEventArgs e)
////        {
////            base.OnMouseWheel(e);
////            if (_rows.Count == 0) return;

////            int visibleHeight = _contentBounds.Height - _headerHeight;
////            int totalContentHeight = _rows.Count * _rowHeight;

////            if (totalContentHeight > visibleHeight)
////            {
////                _scrollOffset -= e.Delta;
////                _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, totalContentHeight - visibleHeight));
////                Invalidate();
////            }
////        }

////        private int GetRowAtPosition(Point p)
////        {
////            if (!_contentBounds.Contains(p)) return -1;

////            int relativeY = p.Y - (_contentBounds.Y + _headerHeight) + _scrollOffset;
////            if (relativeY < 0) return -1;

////            int rowIndex = relativeY / _rowHeight;
////            if (rowIndex >= 0 && rowIndex < _rows.Count)
////            {
////                return rowIndex;
////            }
////            return -1;
////        }

////        private void UpdateScrollPosition(int mouseY)
////        {
////            int visibleHeight = _contentBounds.Height - _headerHeight;
////            int totalContentHeight = _rows.Count * _rowHeight;
////            int maxScroll = totalContentHeight - visibleHeight;

////            if (maxScroll <= 0) return;

////            int thumbHeight = _scrollThumbBounds.Height;
////            int trackHeight = _scrollTrackBounds.Height - thumbHeight;

////            // Relative mouse position within track
////            int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2);
////            relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight));

////            float scrollRatio = (float)relativeMouseY / trackHeight;
////            _scrollOffset = (int)(scrollRatio * maxScroll);

////            Invalidate();
////        }

////        protected override void Dispose(bool disposing)
////        {
////            if (disposing)
////            {
////                _headerFont?.Dispose();
////                _cellFont?.Dispose();
////            }
////            base.Dispose(disposing);
////        }
////        #endregion
////    }
////}






















////using System;
////using System.Collections.Generic;
////using System.ComponentModel;
////using System.Drawing;
////using System.Drawing.Drawing2D;
////using System.Drawing.Text;
////using System.IO;
////using System.Text;
////using System.Windows.Forms;
////using System.Xml.Linq;

////namespace UltraModernUI.Controls
////{
////    public class ModernDataGridView : Control
////    {
////        #region Enums
////        public enum ThemeMode { Light, Dark }
////        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
////        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
////        public enum DataFormat { CSV, JSON, XML }
////        #endregion

////        #region Fields & Properties
////        private ThemeMode _themeMode = ThemeMode.Light;
////        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
////        private ControlState _currentState = ControlState.Normal;

////        private List<string> _headers = new List<string> { "ID", "Status", "Metric", "Value" };
////        private List<string[]> _rows = new List<string[]>();
////        private float[] _columnWeights;

////        private int _hoveredRowIndex = -1;
////        private int _selectedRowIndex = -1;
////        private int _scrollOffset = 0;
////        private int _rowHeight = 42;
////        private int _headerHeight = 48;

////        private Rectangle _contentBounds;
////        private Rectangle _scrollTrackBounds;
////        private Rectangle _scrollThumbBounds;
////        private bool _isScrolling = false;

////        private Font _headerFont;
////        private Font _cellFont;
////        private ContextMenuStrip _contextMenu;

////        [Category("Appearance")]
////        [Description("Sets the overall theme mode (Light or Dark).")]
////        [DefaultValue(ThemeMode.Light)]
////        public ThemeMode Theme
////        {
////            get { return _themeMode; }
////            set { _themeMode = value; Invalidate(); }
////        }

////        [Category("Appearance")]
////        [Description("Sets the visual design style of the control.")]
////        [DefaultValue(DesignStyle.DashboardPremium)]
////        public DesignStyle Style
////        {
////            get { return _controlStyle; }
////            set { _controlStyle = value; Invalidate(); }
////        }

////        [Category("Data")]
////        [Description("Sets the column headers.")]
////        public List<string> Headers
////        {
////            get { return _headers; }
////            set { _headers = value; Invalidate(); }
////        }

////        [Category("Data")]
////        [Description("Sets the rows of data to display.")]
////        public List<string[]> Rows
////        {
////            get { return _rows; }
////            set
////            {
////                _rows = value;
////                _selectedRowIndex = -1;
////                _hoveredRowIndex = -1;
////                _scrollOffset = 0;
////                Invalidate();
////            }
////        }

////        [Category("Appearance")]
////        [Description("Sets the height of each data row.")]
////        [DefaultValue(42)]
////        public int RowHeight
////        {
////            get { return _rowHeight; }
////            set { _rowHeight = value; Invalidate(); }
////        }

////        [Category("Behavior")]
////        [Description("Enables or disables the right-click data import/export context menu.")]
////        [DefaultValue(true)]
////        public bool EnableDataContextMenu { get; set; } = true;

////        #endregion

////        #region Constructor & Initialization
////        public ModernDataGridView()
////        {
////            SetStyle(ControlStyles.UserPaint |
////                     ControlStyles.AllPaintingInWmPaint |
////                     ControlStyles.DoubleBuffer |
////                     ControlStyles.OptimizedDoubleBuffer |
////                     ControlStyles.ResizeRedraw |
////                     ControlStyles.Selectable |
////                     ControlStyles.SupportsTransparentBackColor, true);

////            UpdateFonts();
////            InitializeContextMenu();

////            BackColor = Color.Transparent;
////            Size = new Size(600, 400);

////            if (LicenseManager.UsageMode == LicenseUsageMode.Designtime || _rows.Count == 0)
////            {
////                _rows = new List<string[]>
////                {
////                    new string[] { "001", "Active", "CPU Load", "24%" },
////                    new string[] { "002", "Idle", "Memory", "4.2GB" },
////                    new string[] { "003", "Warning", "Network", "120Mb/s" },
////                    new string[] { "004", "Active", "Disk I/O", "89MB/s" },
////                    new string[] { "005", "Active", "Temp", "54°C" },
////                    new string[] { "006", "Offline", "Uptime", "0h 0m" },
////                    new string[] { "007", "Active", "Requests", "1.2K/s" },
////                    new string[] { "008", "Active", "Latency", "12ms" }
////                };
////            }
////        }

////        private void UpdateFonts()
////        {
////            _headerFont?.Dispose();
////            _cellFont?.Dispose();

////            string fontName = "Segoe UI Variable Display";
////            try
////            {
////                using (var testFont = new Font(fontName, 9f))
////                {
////                    if (testFont.Name != fontName) fontName = "Segoe UI";
////                }
////                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
////                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
////            }
////            catch
////            {
////                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
////                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
////            }
////        }

////        private void InitializeContextMenu()
////        {
////            _contextMenu = new ContextMenuStrip();
////            _contextMenu.Items.Add("Export Data", null, (s, e) => ShowExportDialog());
////            _contextMenu.Items.Add("Import Data", null, (s, e) => ShowImportDialog());
////            _contextMenu.Items.Add(new ToolStripSeparator());
////            _contextMenu.Items.Add("Clear Data", null, (s, e) => { Rows = new List<string[]>(); Invalidate(); });
////        }
////        #endregion

////        #region Memory Safe Layout Calculation
////        private void CalculateLayout()
////        {
////            // CRASH FIX: Clamp values to minimum 0 to prevent ArgumentException on small resize
////            int safeWidth = Math.Max(0, Width - 24);
////            int safeHeight = Math.Max(0, Height - 24);
////            _contentBounds = new Rectangle(12, 12, safeWidth, safeHeight);

////            if (_columnWeights == null || _columnWeights.Length != _headers.Count)
////            {
////                _columnWeights = new float[_headers.Count];
////                for (int i = 0; i < _headers.Count; i++) _columnWeights[i] = 1f / _headers.Count;
////            }

////            int visibleHeight = _contentBounds.Height - _headerHeight;
////            int totalContentHeight = _rows.Count * _rowHeight;

////            if (totalContentHeight > visibleHeight && visibleHeight > 0)
////            {
////                int scrollWidth = 6;
////                _scrollTrackBounds = new Rectangle(
////                    _contentBounds.Right - scrollWidth - 2,
////                    _contentBounds.Y + _headerHeight + 4,
////                    scrollWidth,
////                    Math.Max(0, visibleHeight - 8));

////                float scrollRatio = (float)visibleHeight / totalContentHeight;
////                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
////                int maxScroll = totalContentHeight - visibleHeight;
////                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / maxScroll) * (_scrollTrackBounds.Height - thumbHeight));

////                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
////            }
////            else
////            {
////                _scrollTrackBounds = Rectangle.Empty;
////                _scrollThumbBounds = Rectangle.Empty;
////                _scrollOffset = 0;
////            }
////        }
////        #endregion

////        #region Core Paint Engine
////        protected override void OnPaint(PaintEventArgs e)
////        {
////            if (Width <= 0 || Height <= 0) return;

////            Graphics g = e.Graphics;
////            g.SmoothingMode = SmoothingMode.AntiAlias;
////            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
////            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
////            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

////            CalculateLayout();

////            using (SolidBrush bgBrush = GetBackgroundBrush())
////            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8))
////            {
////                g.FillPath(bgBrush, bgPath);
////            }

////            if (_contentBounds.Width > 0 && _contentBounds.Height > 0)
////            {
////                using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
////                {
////                    g.SetClip(contentClipPath);
////                    DrawHeader(g);
////                    DrawRows(g);
////                    g.ResetClip();
////                }
////            }

////            DrawOuterBorder(g);
////            DrawScrollbar(g);
////        }

////        private void DrawHeader(Graphics g)
////        {
////            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y, _contentBounds.Width, _headerHeight);
////            int colX = headerRect.X;

////            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
////            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
////            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
////            {
////                for (int i = 0; i < _headers.Count; i++)
////                {
////                    float colWidth = _contentBounds.Width * _columnWeights[i];
////                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, colWidth - 24, headerRect.Height);

////                    if (string.IsNullOrEmpty(_headers[i])) continue;

////                    g.DrawString(_headers[i], _headerFont, textBrush, cellRect, sf);
////                    colX += (int)colWidth;
////                }

////                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
////            }
////        }

////        private void DrawRows(Graphics g)
////        {
////            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight);

////            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
////            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 1;

////            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
////            {
////                for (int i = firstVisibleRow; i < Math.Min(_rows.Count, firstVisibleRow + visibleRowCount); i++)
////                {
////                    if (i < 0) continue;

////                    int y = rowArea.Y + (i * _rowHeight) - _scrollOffset;
////                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, _rowHeight);

////                    DrawRowBackground(g, rowRect, i);
////                    DrawRowContent(g, rowRect, i, sf);
////                }
////            }
////        }

////        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex)
////        {
////            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
////            bool isSelected = (rowIndex == _selectedRowIndex);

////            switch (_controlStyle)
////            {
////                case DesignStyle.DashboardPremium:
////                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
////                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
////                    using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1))
////                    {
////                        if (isSelected) g.FillRectangle(selBrush, rowRect);
////                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);
////                        g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);
////                    }
////                    break;

////                case DesignStyle.FluentGlass:
////                    if (isSelected || isHovered)
////                    {
////                        using (var path = GetRoundedPath(rowRect, 4))
////                        using (var glowPen = new Pen(Color.FromArgb(isSelected ? 255 : 150, GetAccentColor()), 1))
////                        using (var fillBrush = new SolidBrush(Color.FromArgb(isSelected ? 40 : 20, GetAccentColor())))
////                        {
////                            g.FillPath(fillBrush, path);
////                            g.DrawPath(glowPen, path);
////                        }
////                    }
////                    break;

////                case DesignStyle.MaterialFlat:
////                    Color matBg = Color.Transparent;
////                    if (isSelected) matBg = Color.FromArgb(255, GetAccentColor());
////                    else if (isHovered) matBg = Color.FromArgb(50, GetForegroundColor());

////                    if (matBg != Color.Transparent)
////                        using (var matBrush = new SolidBrush(matBg))
////                        {
////                            g.FillRectangle(matBrush, rowRect);
////                        }
////                    break;

////                case DesignStyle.SoftNeumorphic:
////                    if (isHovered || isSelected)
////                    {
////                        using (var path = GetRoundedPath(Rectangle.Inflate(rowRect, -2, -2), 6))
////                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
////                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
////                        using (var bgBrush = new SolidBrush(GetBackgroundColor()))
////                        {
////                            g.FillPath(bgBrush, path);
////                            if (isSelected)
////                            {
////                                g.DrawPath(darkPen, path);
////                                g.TranslateTransform(-1, -1);
////                                g.DrawPath(lightPen, path);
////                                g.ResetTransform();
////                            }
////                            else
////                            {
////                                g.DrawPath(lightPen, path);
////                                g.TranslateTransform(1, 1);
////                                g.DrawPath(darkPen, path);
////                                g.ResetTransform();
////                            }
////                        }
////                    }
////                    break;

////                case DesignStyle.CyberpunkIndustrial:
////                    if (isHovered || isSelected)
////                        using (var cyberPath = new GraphicsPath())
////                        {
////                            PointF[] corners = {
////                            new PointF(rowRect.Left + 6, rowRect.Top),
////                            new PointF(rowRect.Right, rowRect.Top),
////                            new PointF(rowRect.Right, rowRect.Bottom),
////                            new PointF(rowRect.Left, rowRect.Bottom),
////                            new PointF(rowRect.Left, rowRect.Top + 6)
////                        };
////                            cyberPath.AddLines(corners);
////                            cyberPath.CloseFigure();

////                            using (var cyberBrush = new SolidBrush(Color.FromArgb(isSelected ? 40 : 15, GetAccentColor())))
////                            using (var cyberPen = new Pen(Color.FromArgb(isSelected ? 255 : 100, GetAccentColor()), 1))
////                            {
////                                g.FillPath(cyberBrush, cyberPath);
////                                g.DrawPath(cyberPen, cyberPath);
////                            }
////                        }
////                    break;
////            }
////        }

////        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
////        {
////            int colX = rowRect.X;
////            using (SolidBrush textBrush = new SolidBrush(GetForegroundColor()))
////            {
////                for (int i = 0; i < _headers.Count; i++)
////                {
////                    float colWidth = _contentBounds.Width * _columnWeights[i];
////                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, colWidth - 24, rowRect.Height);

////                    string val = _rows[rowIndex].Length > i ? _rows[rowIndex][i] : "";
////                    g.DrawString(val, _cellFont, textBrush, cellRect, sf);

////                    colX += (int)colWidth;
////                }
////            }
////        }

////        private void DrawOuterBorder(Graphics g)
////        {
////            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
////            {
////                switch (_controlStyle)
////                {
////                    case DesignStyle.DashboardPremium:
////                        using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1))
////                            g.DrawPath(borderPen, path);
////                        break;

////                    case DesignStyle.FluentGlass:
////                        using (var borderPen = new Pen(Color.FromArgb(100, 255, 255, 255), 1))
////                            g.DrawPath(borderPen, path);
////                        break;

////                    case DesignStyle.MaterialFlat:
////                        break;

////                    case DesignStyle.SoftNeumorphic:
////                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
////                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
////                        {
////                            g.DrawPath(lightPen, path);
////                            g.TranslateTransform(1, 1);
////                            g.DrawPath(darkPen, path);
////                            g.ResetTransform();
////                        }
////                        break;

////                    case DesignStyle.CyberpunkIndustrial:
////                        using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4))
////                        using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1))
////                        {
////                            g.DrawPath(glowPen, path);
////                            g.DrawPath(corePen, path);
////                        }
////                        break;
////                }
////            }
////        }

////        private void DrawScrollbar(Graphics g)
////        {
////            if (_scrollThumbBounds == Rectangle.Empty) return;

////            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
////            {
////                Color thumbColor = GetAccentColor();
////                if (_isScrolling) thumbColor = ControlPaint.Dark(thumbColor, 0.1f);

////                using (var thumbBrush = new SolidBrush(Color.FromArgb(180, thumbColor)))
////                {
////                    g.FillPath(thumbBrush, thumbPath);
////                }
////            }
////        }
////        #endregion

////        #region Color Palette Engine
////        private Color GetBackgroundColor()
////        {
////            switch (_controlStyle)
////            {
////                case DesignStyle.DashboardPremium: return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26);
////                case DesignStyle.FluentGlass: return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32);
////                case DesignStyle.MaterialFlat: return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18);
////                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48);
////                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(12, 12, 14);
////                default: return Color.White;
////            }
////        }

////        private SolidBrush GetBackgroundBrush()
////        {
////            return new SolidBrush(GetBackgroundColor());
////        }

////        private Color GetForegroundColor()
////        {
////            switch (_controlStyle)
////            {
////                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(230, 240, 255);
////                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240);
////                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240);
////            }
////        }

////        private Color GetHeaderTextColor()
////        {
////            switch (_controlStyle)
////            {
////                case DesignStyle.CyberpunkIndustrial: return GetAccentColor();
////                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 170, 180);
////                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160);
////            }
////        }

////        private Color GetHeaderSeparatorColor()
////        {
////            return _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
////        }

////        private Color GetAccentColor()
////        {
////            switch (_controlStyle)
////            {
////                case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212);
////                case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255);
////                case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238);
////                case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51);
////                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204);
////                default: return Color.Blue;
////            }
////        }

////        private Color GetNeumorphicLightColor()
////        {
////            return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
////        }

////        private Color GetNeumorphicDarkColor()
////        {
////            return _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
////        }
////        #endregion

////        #region Geometry Helpers
////        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
////        {
////            GraphicsPath path = new GraphicsPath();
////            // CRASH FIX: Prevent drawing paths on 0 or negative dimensions
////            if (rect.Width <= 0 || rect.Height <= 0) return path;

////            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
////            if (r <= 0)
////            {
////                path.AddRectangle(rect);
////                return path;
////            }

////            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
////            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
////            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
////            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
////            path.CloseFigure();
////            return path;
////        }
////        #endregion

////        #region Data Import / Export Engine
////        public void ShowExportDialog()
////        {
////            using (var sfd = new SaveFileDialog())
////            {
////                sfd.Filter = "CSV File (*.csv)|*.csv|JSON File (*.json)|*.json|XML File (*.xml)|*.xml";
////                sfd.Title = "Export Grid Data";
////                if (sfd.ShowDialog() == DialogResult.OK)
////                {
////                    DataFormat format = sfd.FilterIndex == 1 ? DataFormat.CSV : sfd.FilterIndex == 2 ? DataFormat.JSON : DataFormat.XML;
////                    ExportData(sfd.FileName, format);
////                }
////            }
////        }

////        public void ShowImportDialog()
////        {
////            using (var ofd = new OpenFileDialog())
////            {
////                ofd.Filter = "CSV File (*.csv)|*.csv|JSON File (*.json)|*.json|XML File (*.xml)|*.xml";
////                ofd.Title = "Import Grid Data";
////                if (ofd.ShowDialog() == DialogResult.OK)
////                {
////                    DataFormat format = ofd.FilterIndex == 1 ? DataFormat.CSV : ofd.FilterIndex == 2 ? DataFormat.JSON : DataFormat.XML;
////                    ImportData(ofd.FileName, format);
////                }
////            }
////        }

////        public void ExportData(string filePath, DataFormat format)
////        {
////            try
////            {
////                if (format == DataFormat.CSV)
////                {
////                    var sb = new StringBuilder();
////                    sb.AppendLine(string.Join(",", _headers));
////                    foreach (var row in _rows)
////                        sb.AppendLine(string.Join(",", row));
////                    File.WriteAllText(filePath, sb.ToString());
////                }
////                else if (format == DataFormat.JSON)
////                {
////                    var sb = new StringBuilder();
////                    sb.Append("{\"headers\":[");
////                    sb.Append(string.Join(",", _headers.ConvertAll(h => $"\"{EscapeJson(h)}\"")));
////                    sb.Append("],\"rows\":[");
////                    for (int i = 0; i < _rows.Count; i++)
////                    {
////                        sb.Append("[");
////                        sb.Append(string.Join(",", Array.ConvertAll(_rows[i], c => $"\"{EscapeJson(c)}\"")));
////                        sb.Append("]");
////                        if (i < _rows.Count - 1) sb.Append(",");
////                    }
////                    sb.Append("]}");
////                    File.WriteAllText(filePath, sb.ToString());
////                }
////                else if (format == DataFormat.XML)
////                {
////                    var doc = new XDocument(new XElement("GridData"));
////                    var headersEl = new XElement("Headers");
////                    foreach (var h in _headers) headersEl.Add(new XElement("Header", h));
////                    doc.Root.Add(headersEl);

////                    var rowsEl = new XElement("Rows");
////                    foreach (var row in _rows)
////                    {
////                        var rowEl = new XElement("Row");
////                        foreach (var cell in row) rowEl.Add(new XElement("Cell", cell));
////                        rowsEl.Add(rowEl);
////                    }
////                    doc.Root.Add(rowsEl);
////                    doc.Save(filePath);
////                }
////                MessageBox.Show("Data exported successfully!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
////            }
////            catch (Exception ex)
////            {
////                MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
////            }
////        }

////        public void ImportData(string filePath, DataFormat format)
////        {
////            try
////            {
////                if (format == DataFormat.CSV)
////                {
////                    var lines = File.ReadAllLines(filePath);
////                    if (lines.Length == 0) return;
////                    var newHeaders = new List<string>(lines[0].Split(','));
////                    var newRows = new List<string[]>();
////                    for (int i = 1; i < lines.Length; i++)
////                        if (!string.IsNullOrWhiteSpace(lines[i])) newRows.Add(lines[i].Split(','));

////                    Headers = newHeaders;
////                    Rows = newRows;
////                }
////                else if (format == DataFormat.JSON)
////                {
////                    // Basic lightweight JSON parsing tailored for our structure
////                    string json = File.ReadAllText(filePath);
////                    int hStart = json.IndexOf("\"headers\":[") + 11;
////                    int hEnd = json.IndexOf("]", hStart);
////                    string headerStr = json.Substring(hStart, hEnd - hStart);
////                    var newHeaders = new List<string>();
////                    foreach (var h in headerStr.Split(','))
////                        newHeaders.Add(h.Trim().Trim('"'));

////                    int rStart = json.IndexOf("\"rows\":[") + 8;
////                    int rEnd = json.LastIndexOf("]");
////                    string rowsStr = json.Substring(rStart, rEnd - rStart);
////                    var newRows = new List<string[]>();
////                    string[] rowChunks = rowsStr.Split(new[] { "],[" }, StringSplitOptions.None);
////                    foreach (var chunk in rowChunks)
////                    {
////                        string clean = chunk.Trim('[', ']', ' ');
////                        if (string.IsNullOrEmpty(clean)) continue;
////                        var cells = clean.Split(',');
////                        for (int i = 0; i < cells.Length; i++) cells[i] = cells[i].Trim().Trim('"');
////                        newRows.Add(cells);
////                    }
////                    Headers = newHeaders;
////                    Rows = newRows;
////                }
////                else if (format == DataFormat.XML)
////                {
////                    var doc = XDocument.Load(filePath);
////                    var newHeaders = new List<string>();
////                    foreach (var hEl in doc.Root.Element("Headers").Elements("Header")) newHeaders.Add(hEl.Value);

////                    var newRows = new List<string[]>();
////                    foreach (var rEl in doc.Root.Element("Rows").Elements("Row"))
////                    {
////                        var cells = new List<string>();
////                        foreach (var cEl in rEl.Elements("Cell")) cells.Add(cEl.Value);
////                        newRows.Add(cells.ToArray());
////                    }
////                    Headers = newHeaders;
////                    Rows = newRows;
////                }
////                MessageBox.Show("Data imported successfully!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
////            }
////            catch (Exception ex)
////            {
////                MessageBox.Show($"Import failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
////            }
////        }

////        private string EscapeJson(string val)
////        {
////            if (string.IsNullOrEmpty(val)) return "";
////            return val.Replace("\\", "\\\\").Replace("\"", "\\\"");
////        }
////        #endregion

////        #region Mouse & State Handling
////        protected override void OnMouseMove(MouseEventArgs e)
////        {
////            base.OnMouseMove(e);

////            if (_isScrolling)
////            {
////                UpdateScrollPosition(e.Y);
////                return;
////            }

////            int newHoveredRow = GetRowAtPosition(e.Location);
////            if (newHoveredRow != _hoveredRowIndex)
////            {
////                _hoveredRowIndex = newHoveredRow;
////                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
////                Invalidate();
////            }
////            else if (_scrollThumbBounds.Contains(e.Location) && !Cursor.Equals(Cursors.SizeNS))
////            {
////                Cursor = Cursors.SizeNS;
////            }
////            else if (!_scrollThumbBounds.Contains(e.Location) && Cursor.Equals(Cursors.SizeNS) && !_isScrolling)
////            {
////                Cursor = Cursors.Default;
////            }
////        }

////        protected override void OnMouseDown(MouseEventArgs e)
////        {
////            base.OnMouseDown(e);
////            Focus();

////            if (e.Button == MouseButtons.Right && EnableDataContextMenu)
////            {
////                _contextMenu.Show(this, e.Location);
////                return;
////            }

////            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
////            {
////                _isScrolling = true;
////                Cursor = Cursors.SizeNS;
////                _currentState = ControlState.Pressed;
////                Invalidate();
////                return;
////            }

////            int clickedRow = GetRowAtPosition(e.Location);
////            if (clickedRow != -1)
////            {
////                _selectedRowIndex = clickedRow;
////                _currentState = ControlState.Pressed;
////                Invalidate();
////            }
////        }

////        protected override void OnMouseUp(MouseEventArgs e)
////        {
////            base.OnMouseUp(e);
////            _isScrolling = false;
////            Cursor = Cursors.Default;
////            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
////            Invalidate();
////        }

////        protected override void OnMouseLeave(EventArgs e)
////        {
////            base.OnMouseLeave(e);
////            _hoveredRowIndex = -1;
////            _currentState = ControlState.Normal;
////            Cursor = Cursors.Default;
////            Invalidate();
////        }

////        protected override void OnMouseWheel(MouseEventArgs e)
////        {
////            base.OnMouseWheel(e);
////            if (_rows.Count == 0) return;

////            int visibleHeight = _contentBounds.Height - _headerHeight;
////            int totalContentHeight = _rows.Count * _rowHeight;

////            if (totalContentHeight > visibleHeight)
////            {
////                _scrollOffset -= e.Delta;
////                _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, totalContentHeight - visibleHeight));
////                Invalidate();
////            }
////        }

////        private int GetRowAtPosition(Point p)
////        {
////            if (!_contentBounds.Contains(p)) return -1;

////            int relativeY = p.Y - (_contentBounds.Y + _headerHeight) + _scrollOffset;
////            if (relativeY < 0) return -1;

////            int rowIndex = relativeY / _rowHeight;
////            if (rowIndex >= 0 && rowIndex < _rows.Count)
////            {
////                return rowIndex;
////            }
////            return -1;
////        }

////        private void UpdateScrollPosition(int mouseY)
////        {
////            int visibleHeight = _contentBounds.Height - _headerHeight;
////            int totalContentHeight = _rows.Count * _rowHeight;
////            int maxScroll = totalContentHeight - visibleHeight;

////            if (maxScroll <= 0) return;

////            int thumbHeight = _scrollThumbBounds.Height;
////            int trackHeight = _scrollTrackBounds.Height - thumbHeight;

////            int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2);
////            relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight));

////            float scrollRatio = (float)relativeMouseY / trackHeight;
////            _scrollOffset = (int)(scrollRatio * maxScroll);

////            Invalidate();
////        }

////        protected override void Dispose(bool disposing)
////        {
////            if (disposing)
////            {
////                _headerFont?.Dispose();
////                _cellFont?.Dispose();
////                _contextMenu?.Dispose();
////            }
////            base.Dispose(disposing);
////        }
////        #endregion
////    }
////}
















//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Drawing;
//using System.Drawing.Drawing2D;
//using System.Drawing.Text;
//using System.IO;
//using System.Text;
//using System.Windows.Forms;
//using System.Xml.Linq;

//namespace UltraModernUI.Controls
//{
//    public class ModernDataGridView : Control
//    {
//        #region Enums
//        public enum ThemeMode { Light, Dark }
//        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
//        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
//        public enum DataFormat { CSV, JSON, XML }
//        #endregion

//        #region Fields & Properties
//        private ThemeMode _themeMode = ThemeMode.Light;
//        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
//        private ControlState _currentState = ControlState.Normal;

//        private List<string> _headers = new List<string> { "ID", "Status", "Metric", "Value" };
//        private List<string[]> _rows = new List<string[]>();
//        private float[] _columnWeights;

//        private int _hoveredRowIndex = -1;
//        private int _selectedRowIndex = -1;
//        private int _scrollOffset = 0;
//        private int _rowHeight = 42;
//        private int _headerHeight = 48;

//        private Rectangle _contentBounds;
//        private Rectangle _scrollTrackBounds;
//        private Rectangle _scrollThumbBounds;
//        private bool _isScrolling = false;

//        private Font _headerFont;
//        private Font _cellFont;
//        private ContextMenuStrip _contextMenu;

//        [Category("Appearance")]
//        [Description("Sets the overall theme mode (Light or Dark).")]
//        [DefaultValue(ThemeMode.Light)]
//        public ThemeMode Theme
//        {
//            get { return _themeMode; }
//            set { _themeMode = value; Invalidate(); }
//        }

//        [Category("Appearance")]
//        [Description("Sets the visual design style of the control.")]
//        [DefaultValue(DesignStyle.DashboardPremium)]
//        public DesignStyle Style
//        {
//            get { return _controlStyle; }
//            set { _controlStyle = value; Invalidate(); }
//        }

//        [Category("Data")]
//        [Description("Sets the column headers.")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)] // FIX: Prevents Designer from trying to serialize this
//        public List<string> Headers
//        {
//            get { return _headers; }
//            set { _headers = value; Invalidate(); }
//        }

//        [Category("Data")]
//        [Description("Sets the rows of data to display.")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)] // FIX: Prevents Designer from trying to serialize this
//        public List<string[]> Rows
//        {
//            get { return _rows; }
//            set
//            {
//                _rows = value;
//                _selectedRowIndex = -1;
//                _hoveredRowIndex = -1;
//                _scrollOffset = 0;
//                Invalidate();
//            }
//        }

//        [Category("Appearance")]
//        [Description("Sets the height of each data row.")]
//        [DefaultValue(42)]
//        public int RowHeight
//        {
//            get { return _rowHeight; }
//            set { _rowHeight = value; Invalidate(); }
//        }

//        [Category("Behavior")]
//        [Description("Enables or disables the right-click data import/export context menu.")]
//        [DefaultValue(true)]
//        public bool EnableDataContextMenu { get; set; } = true;

//        #endregion

//        #region Constructor & Initialization
//        public ModernDataGridView()
//        {
//            SetStyle(ControlStyles.UserPaint |
//                     ControlStyles.AllPaintingInWmPaint |
//                     ControlStyles.DoubleBuffer |
//                     ControlStyles.OptimizedDoubleBuffer |
//                     ControlStyles.ResizeRedraw |
//                     ControlStyles.Selectable |
//                     ControlStyles.SupportsTransparentBackColor, true);

//            UpdateFonts();
//            InitializeContextMenu();

//            BackColor = Color.Transparent;
//            Size = new Size(600, 400);

//            if (LicenseManager.UsageMode == LicenseUsageMode.Designtime || _rows.Count == 0)
//            {
//                _rows = new List<string[]>
//                {
//                    new string[] { "001", "Active", "CPU Load", "24%" },
//                    new string[] { "002", "Idle", "Memory", "4.2GB" },
//                    new string[] { "003", "Warning", "Network", "120Mb/s" },
//                    new string[] { "004", "Active", "Disk I/O", "89MB/s" },
//                    new string[] { "005", "Active", "Temp", "54°C" },
//                    new string[] { "006", "Offline", "Uptime", "0h 0m" },
//                    new string[] { "007", "Active", "Requests", "1.2K/s" },
//                    new string[] { "008", "Active", "Latency", "12ms" }
//                };
//            }
//        }

//        private void UpdateFonts()
//        {
//            _headerFont?.Dispose();
//            _cellFont?.Dispose();

//            string fontName = "Segoe UI Variable Display";
//            try
//            {
//                using (var testFont = new Font(fontName, 9f))
//                {
//                    if (testFont.Name != fontName) fontName = "Segoe UI";
//                }
//                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
//                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
//            }
//            catch
//            {
//                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
//                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
//            }
//        }

//        private void InitializeContextMenu()
//        {
//            _contextMenu = new ContextMenuStrip();
//            _contextMenu.Items.Add("Export Data", null, (s, e) => ShowExportDialog());
//            _contextMenu.Items.Add("Import Data", null, (s, e) => ShowImportDialog());
//            _contextMenu.Items.Add(new ToolStripSeparator());
//            _contextMenu.Items.Add("Clear Data", null, (s, e) => { Rows = new List<string[]>(); Invalidate(); });
//        }
//        #endregion

//        #region Memory Safe Layout Calculation
//        private void CalculateLayout()
//        {
//            int safeWidth = Math.Max(0, Width - 24);
//            int safeHeight = Math.Max(0, Height - 24);
//            _contentBounds = new Rectangle(12, 12, safeWidth, safeHeight);

//            if (_columnWeights == null || _columnWeights.Length != _headers.Count)
//            {
//                _columnWeights = new float[_headers.Count];
//                for (int i = 0; i < _headers.Count; i++) _columnWeights[i] = 1f / _headers.Count;
//            }

//            int visibleHeight = _contentBounds.Height - _headerHeight;
//            int totalContentHeight = _rows.Count * _rowHeight;

//            if (totalContentHeight > visibleHeight && visibleHeight > 0)
//            {
//                int scrollWidth = 6;
//                _scrollTrackBounds = new Rectangle(
//                    _contentBounds.Right - scrollWidth - 2,
//                    _contentBounds.Y + _headerHeight + 4,
//                    scrollWidth,
//                    Math.Max(0, visibleHeight - 8));

//                float scrollRatio = (float)visibleHeight / totalContentHeight;
//                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
//                int maxScroll = totalContentHeight - visibleHeight;
//                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / maxScroll) * (_scrollTrackBounds.Height - thumbHeight));

//                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
//            }
//            else
//            {
//                _scrollTrackBounds = Rectangle.Empty;
//                _scrollThumbBounds = Rectangle.Empty;
//                _scrollOffset = 0;
//            }
//        }
//        #endregion

//        #region Core Paint Engine
//        protected override void OnPaint(PaintEventArgs e)
//        {
//            if (Width <= 0 || Height <= 0) return;

//            Graphics g = e.Graphics;
//            g.SmoothingMode = SmoothingMode.AntiAlias;
//            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
//            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
//            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

//            CalculateLayout();

//            using (SolidBrush bgBrush = GetBackgroundBrush())
//            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8))
//            {
//                g.FillPath(bgBrush, bgPath);
//            }

//            if (_contentBounds.Width > 0 && _contentBounds.Height > 0)
//            {
//                using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
//                {
//                    g.SetClip(contentClipPath);
//                    DrawHeader(g);
//                    DrawRows(g);
//                    g.ResetClip();
//                }
//            }

//            DrawOuterBorder(g);
//            DrawScrollbar(g);
//        }

//        private void DrawHeader(Graphics g)
//        {
//            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y, _contentBounds.Width, _headerHeight);
//            int colX = headerRect.X;

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
//            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
//            {
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, colWidth - 24, headerRect.Height);

//                    if (string.IsNullOrEmpty(_headers[i])) continue;

//                    g.DrawString(_headers[i], _headerFont, textBrush, cellRect, sf);
//                    colX += (int)colWidth;
//                }

//                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
//            }
//        }

//        private void DrawRows(Graphics g)
//        {
//            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight);

//            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
//            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 1;

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            {
//                for (int i = firstVisibleRow; i < Math.Min(_rows.Count, firstVisibleRow + visibleRowCount); i++)
//                {
//                    if (i < 0) continue;

//                    int y = rowArea.Y + (i * _rowHeight) - _scrollOffset;
//                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, _rowHeight);

//                    DrawRowBackground(g, rowRect, i);
//                    DrawRowContent(g, rowRect, i, sf);
//                }
//            }
//        }

//        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex)
//        {
//            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
//            bool isSelected = (rowIndex == _selectedRowIndex);

//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium:
//                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
//                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//                    using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1))
//                    {
//                        if (isSelected) g.FillRectangle(selBrush, rowRect);
//                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);
//                        g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);
//                    }
//                    break;

//                case DesignStyle.FluentGlass:
//                    if (isSelected || isHovered)
//                    {
//                        using (var path = GetRoundedPath(rowRect, 4))
//                        using (var glowPen = new Pen(Color.FromArgb(isSelected ? 255 : 150, GetAccentColor()), 1))
//                        using (var fillBrush = new SolidBrush(Color.FromArgb(isSelected ? 40 : 20, GetAccentColor())))
//                        {
//                            g.FillPath(fillBrush, path);
//                            g.DrawPath(glowPen, path);
//                        }
//                    }
//                    break;

//                case DesignStyle.MaterialFlat:
//                    Color matBg = Color.Transparent;
//                    if (isSelected) matBg = Color.FromArgb(255, GetAccentColor());
//                    else if (isHovered) matBg = Color.FromArgb(50, GetForegroundColor());

//                    if (matBg != Color.Transparent)
//                        using (var matBrush = new SolidBrush(matBg))
//                        {
//                            g.FillRectangle(matBrush, rowRect);
//                        }
//                    break;

//                case DesignStyle.SoftNeumorphic:
//                    if (isHovered || isSelected)
//                    {
//                        using (var path = GetRoundedPath(Rectangle.Inflate(rowRect, -2, -2), 6))
//                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
//                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
//                        using (var bgBrush = new SolidBrush(GetBackgroundColor()))
//                        {
//                            g.FillPath(bgBrush, path);
//                            if (isSelected)
//                            {
//                                g.DrawPath(darkPen, path);
//                                g.TranslateTransform(-1, -1);
//                                g.DrawPath(lightPen, path);
//                                g.ResetTransform();
//                            }
//                            else
//                            {
//                                g.DrawPath(lightPen, path);
//                                g.TranslateTransform(1, 1);
//                                g.DrawPath(darkPen, path);
//                                g.ResetTransform();
//                            }
//                        }
//                    }
//                    break;

//                case DesignStyle.CyberpunkIndustrial:
//                    if (isHovered || isSelected)
//                        using (var cyberPath = new GraphicsPath())
//                        {
//                            PointF[] corners = {
//                            new PointF(rowRect.Left + 6, rowRect.Top),
//                            new PointF(rowRect.Right, rowRect.Top),
//                            new PointF(rowRect.Right, rowRect.Bottom),
//                            new PointF(rowRect.Left, rowRect.Bottom),
//                            new PointF(rowRect.Left, rowRect.Top + 6)
//                        };
//                            cyberPath.AddLines(corners);
//                            cyberPath.CloseFigure();

//                            using (var cyberBrush = new SolidBrush(Color.FromArgb(isSelected ? 40 : 15, GetAccentColor())))
//                            using (var cyberPen = new Pen(Color.FromArgb(isSelected ? 255 : 100, GetAccentColor()), 1))
//                            {
//                                g.FillPath(cyberBrush, cyberPath);
//                                g.DrawPath(cyberPen, cyberPath);
//                            }
//                        }
//                    break;
//            }
//        }

//        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
//        {
//            int colX = rowRect.X;
//            using (SolidBrush textBrush = new SolidBrush(GetForegroundColor()))
//            {
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, colWidth - 24, rowRect.Height);

//                    string val = _rows[rowIndex].Length > i ? _rows[rowIndex][i] : "";
//                    g.DrawString(val, _cellFont, textBrush, cellRect, sf);

//                    colX += (int)colWidth;
//                }
//            }
//        }

//        private void DrawOuterBorder(Graphics g)
//        {
//            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
//            {
//                switch (_controlStyle)
//                {
//                    case DesignStyle.DashboardPremium:
//                        using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1))
//                            g.DrawPath(borderPen, path);
//                        break;

//                    case DesignStyle.FluentGlass:
//                        using (var borderPen = new Pen(Color.FromArgb(100, 255, 255, 255), 1))
//                            g.DrawPath(borderPen, path);
//                        break;

//                    case DesignStyle.MaterialFlat:
//                        break;

//                    case DesignStyle.SoftNeumorphic:
//                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
//                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
//                        {
//                            g.DrawPath(lightPen, path);
//                            g.TranslateTransform(1, 1);
//                            g.DrawPath(darkPen, path);
//                            g.ResetTransform();
//                        }
//                        break;

//                    case DesignStyle.CyberpunkIndustrial:
//                        using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4))
//                        using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1))
//                        {
//                            g.DrawPath(glowPen, path);
//                            g.DrawPath(corePen, path);
//                        }
//                        break;
//                }
//            }
//        }

//        private void DrawScrollbar(Graphics g)
//        {
//            if (_scrollThumbBounds == Rectangle.Empty) return;

//            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
//            {
//                Color thumbColor = GetAccentColor();
//                if (_isScrolling) thumbColor = ControlPaint.Dark(thumbColor, 0.1f);

//                using (var thumbBrush = new SolidBrush(Color.FromArgb(180, thumbColor)))
//                {
//                    g.FillPath(thumbBrush, thumbPath);
//                }
//            }
//        }
//        #endregion

//        #region Color Palette Engine
//        private Color GetBackgroundColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium: return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26);
//                case DesignStyle.FluentGlass: return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32);
//                case DesignStyle.MaterialFlat: return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18);
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48);
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(12, 12, 14);
//                default: return Color.White;
//            }
//        }

//        private SolidBrush GetBackgroundBrush()
//        {
//            return new SolidBrush(GetBackgroundColor());
//        }

//        private Color GetForegroundColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(230, 240, 255);
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240);
//                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240);
//            }
//        }

//        private Color GetHeaderTextColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.CyberpunkIndustrial: return GetAccentColor();
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 170, 180);
//                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160);
//            }
//        }

//        private Color GetHeaderSeparatorColor()
//        {
//            return _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
//        }

//        private Color GetAccentColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212);
//                case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255);
//                case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238);
//                case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51);
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204);
//                default: return Color.Blue;
//            }
//        }

//        private Color GetNeumorphicLightColor()
//        {
//            return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
//        }

//        private Color GetNeumorphicDarkColor()
//        {
//            return _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
//        }
//        #endregion

//        #region Geometry Helpers
//        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
//        {
//            GraphicsPath path = new GraphicsPath();
//            if (rect.Width <= 0 || rect.Height <= 0) return path;

//            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
//            if (r <= 0)
//            {
//                path.AddRectangle(rect);
//                return path;
//            }

//            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
//            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
//            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
//            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
//            path.CloseFigure();
//            return path;
//        }
//        #endregion

//        #region Data Import / Export Engine
//        public void ShowExportDialog()
//        {
//            using (var sfd = new SaveFileDialog())
//            {
//                sfd.Filter = "CSV File (*.csv)|*.csv|JSON File (*.json)|*.json|XML File (*.xml)|*.xml";
//                sfd.Title = "Export Grid Data";
//                if (sfd.ShowDialog() == DialogResult.OK)
//                {
//                    DataFormat format = sfd.FilterIndex == 1 ? DataFormat.CSV : sfd.FilterIndex == 2 ? DataFormat.JSON : DataFormat.XML;
//                    ExportData(sfd.FileName, format);
//                }
//            }
//        }

//        public void ShowImportDialog()
//        {
//            using (var ofd = new OpenFileDialog())
//            {
//                ofd.Filter = "CSV File (*.csv)|*.csv|JSON File (*.json)|*.json|XML File (*.xml)|*.xml";
//                ofd.Title = "Import Grid Data";
//                if (ofd.ShowDialog() == DialogResult.OK)
//                {
//                    DataFormat format = ofd.FilterIndex == 1 ? DataFormat.CSV : ofd.FilterIndex == 2 ? DataFormat.JSON : DataFormat.XML;
//                    ImportData(ofd.FileName, format);
//                }
//            }
//        }

//        public void ExportData(string filePath, DataFormat format)
//        {
//            try
//            {
//                if (format == DataFormat.CSV)
//                {
//                    var sb = new StringBuilder();
//                    sb.AppendLine(string.Join(",", _headers));
//                    foreach (var row in _rows)
//                        sb.AppendLine(string.Join(",", row));
//                    File.WriteAllText(filePath, sb.ToString());
//                }
//                else if (format == DataFormat.JSON)
//                {
//                    var sb = new StringBuilder();
//                    sb.Append("{\"headers\":[");
//                    sb.Append(string.Join(",", _headers.ConvertAll(h => $"\"{EscapeJson(h)}\"")));
//                    sb.Append("],\"rows\":[");
//                    for (int i = 0; i < _rows.Count; i++)
//                    {
//                        sb.Append("[");
//                        sb.Append(string.Join(",", Array.ConvertAll(_rows[i], c => $"\"{EscapeJson(c)}\"")));
//                        sb.Append("]");
//                        if (i < _rows.Count - 1) sb.Append(",");
//                    }
//                    sb.Append("]}");
//                    File.WriteAllText(filePath, sb.ToString());
//                }
//                else if (format == DataFormat.XML)
//                {
//                    var doc = new XDocument(new XElement("GridData"));
//                    var headersEl = new XElement("Headers");
//                    foreach (var h in _headers) headersEl.Add(new XElement("Header", h));
//                    doc.Root.Add(headersEl);

//                    var rowsEl = new XElement("Rows");
//                    foreach (var row in _rows)
//                    {
//                        var rowEl = new XElement("Row");
//                        foreach (var cell in row) rowEl.Add(new XElement("Cell", cell));
//                        rowsEl.Add(rowEl);
//                    }
//                    doc.Root.Add(rowsEl);
//                    doc.Save(filePath);
//                }
//                MessageBox.Show("Data exported successfully!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }

//        public void ImportData(string filePath, DataFormat format)
//        {
//            try
//            {
//                if (format == DataFormat.CSV)
//                {
//                    var lines = File.ReadAllLines(filePath);
//                    if (lines.Length == 0) return;
//                    var newHeaders = new List<string>(lines[0].Split(','));
//                    var newRows = new List<string[]>();
//                    for (int i = 1; i < lines.Length; i++)
//                        if (!string.IsNullOrWhiteSpace(lines[i])) newRows.Add(lines[i].Split(','));

//                    Headers = newHeaders;
//                    Rows = newRows;
//                }
//                else if (format == DataFormat.JSON)
//                {
//                    string json = File.ReadAllText(filePath);
//                    int hStart = json.IndexOf("\"headers\":[") + 11;
//                    int hEnd = json.IndexOf("]", hStart);
//                    string headerStr = json.Substring(hStart, hEnd - hStart);
//                    var newHeaders = new List<string>();
//                    foreach (var h in headerStr.Split(','))
//                        newHeaders.Add(h.Trim().Trim('"'));

//                    int rStart = json.IndexOf("\"rows\":[") + 8;
//                    int rEnd = json.LastIndexOf("]");
//                    string rowsStr = json.Substring(rStart, rEnd - rStart);
//                    var newRows = new List<string[]>();
//                    string[] rowChunks = rowsStr.Split(new[] { "],[" }, StringSplitOptions.None);
//                    foreach (var chunk in rowChunks)
//                    {
//                        string clean = chunk.Trim('[', ']', ' ');
//                        if (string.IsNullOrEmpty(clean)) continue;
//                        var cells = clean.Split(',');
//                        for (int i = 0; i < cells.Length; i++) cells[i] = cells[i].Trim().Trim('"');
//                        newRows.Add(cells);
//                    }
//                    Headers = newHeaders;
//                    Rows = newRows;
//                }
//                else if (format == DataFormat.XML)
//                {
//                    var doc = XDocument.Load(filePath);
//                    var newHeaders = new List<string>();
//                    foreach (var hEl in doc.Root.Element("Headers").Elements("Header")) newHeaders.Add(hEl.Value);

//                    var newRows = new List<string[]>();
//                    foreach (var rEl in doc.Root.Element("Rows").Elements("Row"))
//                    {
//                        var cells = new List<string>();
//                        foreach (var cEl in rEl.Elements("Cell")) cells.Add(cEl.Value);
//                        newRows.Add(cells.ToArray());
//                    }
//                    Headers = newHeaders;
//                    Rows = newRows;
//                }
//                MessageBox.Show("Data imported successfully!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Import failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }

//        private string EscapeJson(string val)
//        {
//            if (string.IsNullOrEmpty(val)) return "";
//            return val.Replace("\\", "\\\\").Replace("\"", "\\\"");
//        }
//        #endregion

//        #region Mouse & State Handling
//        protected override void OnMouseMove(MouseEventArgs e)
//        {
//            base.OnMouseMove(e);

//            if (_isScrolling)
//            {
//                UpdateScrollPosition(e.Y);
//                return;
//            }

//            int newHoveredRow = GetRowAtPosition(e.Location);
//            if (newHoveredRow != _hoveredRowIndex)
//            {
//                _hoveredRowIndex = newHoveredRow;
//                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
//                Invalidate();
//            }
//            else if (_scrollThumbBounds.Contains(e.Location) && !Cursor.Equals(Cursors.SizeNS))
//            {
//                Cursor = Cursors.SizeNS;
//            }
//            else if (!_scrollThumbBounds.Contains(e.Location) && Cursor.Equals(Cursors.SizeNS) && !_isScrolling)
//            {
//                Cursor = Cursors.Default;
//            }
//        }

//        protected override void OnMouseDown(MouseEventArgs e)
//        {
//            base.OnMouseDown(e);
//            Focus();

//            if (e.Button == MouseButtons.Right && EnableDataContextMenu)
//            {
//                _contextMenu.Show(this, e.Location);
//                return;
//            }

//            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
//            {
//                _isScrolling = true;
//                Cursor = Cursors.SizeNS;
//                _currentState = ControlState.Pressed;
//                Invalidate();
//                return;
//            }

//            int clickedRow = GetRowAtPosition(e.Location);
//            if (clickedRow != -1)
//            {
//                _selectedRowIndex = clickedRow;
//                _currentState = ControlState.Pressed;
//                Invalidate();
//            }
//        }

//        protected override void OnMouseUp(MouseEventArgs e)
//        {
//            base.OnMouseUp(e);
//            _isScrolling = false;
//            Cursor = Cursors.Default;
//            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
//            Invalidate();
//        }

//        protected override void OnMouseLeave(EventArgs e)
//        {
//            base.OnMouseLeave(e);
//            _hoveredRowIndex = -1;
//            _currentState = ControlState.Normal;
//            Cursor = Cursors.Default;
//            Invalidate();
//        }

//        protected override void OnMouseWheel(MouseEventArgs e)
//        {
//            base.OnMouseWheel(e);
//            if (_rows.Count == 0) return;

//            int visibleHeight = _contentBounds.Height - _headerHeight;
//            int totalContentHeight = _rows.Count * _rowHeight;

//            if (totalContentHeight > visibleHeight)
//            {
//                _scrollOffset -= e.Delta;
//                _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, totalContentHeight - visibleHeight));
//                Invalidate();
//            }
//        }

//        private int GetRowAtPosition(Point p)
//        {
//            if (!_contentBounds.Contains(p)) return -1;

//            int relativeY = p.Y - (_contentBounds.Y + _headerHeight) + _scrollOffset;
//            if (relativeY < 0) return -1;

//            int rowIndex = relativeY / _rowHeight;
//            if (rowIndex >= 0 && rowIndex < _rows.Count)
//            {
//                return rowIndex;
//            }
//            return -1;
//        }

//        private void UpdateScrollPosition(int mouseY)
//        {
//            int visibleHeight = _contentBounds.Height - _headerHeight;
//            int totalContentHeight = _rows.Count * _rowHeight;
//            int maxScroll = totalContentHeight - visibleHeight;

//            if (maxScroll <= 0) return;

//            int thumbHeight = _scrollThumbBounds.Height;
//            int trackHeight = _scrollTrackBounds.Height - thumbHeight;

//            int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2);
//            relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight));

//            float scrollRatio = (float)relativeMouseY / trackHeight;
//            _scrollOffset = (int)(scrollRatio * maxScroll);

//            Invalidate();
//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                _headerFont?.Dispose();
//                _cellFont?.Dispose();
//                _contextMenu?.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//        #endregion
//    }
//}




















//=================================== VER 1.2 ============================================
//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Drawing;
//using System.Drawing.Drawing2D;
//using System.Drawing.Text;
//using System.IO;
//using System.IO.Compression;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;
//using System.Xml.Linq;

//namespace UltraModernUI.Controls
//{
//    public class ModernDataGridView : Control
//    {
//        #region Enums
//        public enum ThemeMode { Light, Dark }
//        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
//        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
//        public enum DataFormat { CSV, JSON, XML, XLSX, PDF }
//        public enum SummaryType { None, Sum, Avg, Count, Min, Max }
//        public enum EditorType { None, Text, DatePicker, ToggleSwitch, MultiSelectCombo, NumericSlider }
//        #endregion

//        #region Data Classes
//        public class Band
//        {
//            public string Name { get; set; }
//            public List<string> Columns { get; set; } = new List<string>();
//        }

//        public class FormatRule
//        {
//            public string ColumnName { get; set; }
//            public string Operator { get; set; } // ">", "<", "==", "!=", "<=", ">="
//            public string Value { get; set; }
//            public Color BackColor { get; set; }
//            public Color ForeColor { get; set; }
//        }

//        public class ColumnSummary
//        {
//            public string ColumnName { get; set; }
//            public SummaryType SummaryType { get; set; }
//        }
//        #endregion

//        #region Fields & Properties
//        private ThemeMode _themeMode = ThemeMode.Light;
//        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
//        private ControlState _currentState = ControlState.Normal;

//        private List<string> _headers = new List<string> { "ID", "Status", "Metric", "Value" };
//        private List<string[]> _rows = new List<string[]>();
//        private List<string[]> _filteredRows = new List<string[]>();
//        private float[] _columnWeights;

//        private int _hoveredRowIndex = -1;
//        private int _selectedRowIndex = -1;
//        private int _scrollOffset = 0;
//        private int _rowHeight = 42;
//        private int _headerHeight = 48;
//        private int _bandHeight = 0;
//        private int _groupPanelHeight = 0;
//        private int _footerHeight = 0;

//        private Rectangle _contentBounds;
//        private Rectangle _scrollTrackBounds;
//        private Rectangle _scrollThumbBounds;
//        private bool _isScrolling = false;

//        private Font _headerFont;
//        private Font _cellFont;
//        private ContextMenuStrip _contextMenu;
//        private ContextMenuStrip _filterMenu;

//        // Virtual Mode & Async
//        private bool _virtualMode = false;
//        private int _virtualRowCount = 0;
//        private Dictionary<int, string[]> _virtualCache = new Dictionary<int, string[]>();
//        private HashSet<int> _pendingRequests = new HashSet<int>();

//        // Feature Properties
//        private string _searchQuery = "";
//        private List<string> _groupedColumns = new List<string>();
//        private List<Band> _bands = new List<Band>();
//        private List<FormatRule> _formatRules = new List<FormatRule>();
//        private List<ColumnSummary> _summaries = new List<ColumnSummary>();
//        private bool _autoRowHeight = false;
//        private Dictionary<int, int> _rowHeightsCache = new Dictionary<int, int>();
//        private Dictionary<string, List<string>> _activeFilters = new Dictionary<string, List<string>>();

//        [Category("Appearance")]
//        [DefaultValue(ThemeMode.Light)]
//        public ThemeMode Theme { get { return _themeMode; } set { _themeMode = value; Invalidate(); } }

//        [Category("Appearance")]
//        [DefaultValue(DesignStyle.DashboardPremium)]
//        public DesignStyle Style { get { return _controlStyle; } set { _controlStyle = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<string> Headers { get { return _headers; } set { _headers = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<string[]> Rows
//        {
//            get { return _rows; }
//            set { _rows = value; _filteredRows = value; _selectedRowIndex = -1; _scrollOffset = 0; ApplyFiltersAndSearch(); }
//        }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool AutoRowHeight { get { return _autoRowHeight; } set { _autoRowHeight = value; _rowHeightsCache.Clear(); Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<Band> Bands { get { return _bands; } set { _bands = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<FormatRule> FormatRules { get { return _formatRules; } set { _formatRules = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<ColumnSummary> Summaries { get { return _summaries; } set { _summaries = value; Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool VirtualMode
//        {
//            get { return _virtualMode; }
//            set { _virtualMode = value; _virtualCache.Clear(); Invalidate(); }
//        }

//        [Category("Data")]
//        [DefaultValue(0)]
//        public int VirtualRowCount { get { return _virtualRowCount; } set { _virtualRowCount = value; Invalidate(); } }

//        [Category("Appearance")]
//        [DefaultValue(42)]
//        public int RowHeight { get { return _rowHeight; } set { _rowHeight = value; Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(true)]
//        public bool EnableDataContextMenu { get; set; } = true;

//        [Category("Data")]
//        public string SearchQuery
//        {
//            get { return _searchQuery; }
//            set { _searchQuery = value; ApplyFiltersAndSearch(); }
//        }

//        public event Func<int, string[]> RetrieveVirtualItem;

//        #endregion

//        #region Constructor & Initialization
//        public ModernDataGridView()
//        {
//            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);

//            UpdateFonts();
//            InitializeContextMenu();
//            InitializeFilterMenu();

//            BackColor = Color.Transparent;
//            Size = new Size(800, 500);

//            if (LicenseManager.UsageMode == LicenseUsageMode.Designtime)
//            {
//                _rows = new List<string[]>
//                {
//                    new string[] { "001", "Active", "CPU Load", "2400" },
//                    new string[] { "002", "Idle", "Memory", "4200" },
//                    new string[] { "003", "Warning", "Network", "12500" },
//                    new string[] { "004", "Active", "Disk I/O", "8900" },
//                    new string[] { "005", "Active", "Temp", "5400" },
//                    new string[] { "006", "Offline", "Uptime", "0" },
//                    new string[] { "007", "Active", "Requests", "12000" },
//                    new string[] { "008", "Active", "Latency", "120" }
//                };
//                _filteredRows = _rows;
//            }

//            // Allow Drag-Drop for Grouping
//            AllowDrop = true;
//        }

//        private void UpdateFonts()
//        {
//            _headerFont?.Dispose();
//            _cellFont?.Dispose();

//            string fontName = "Segoe UI Variable Display";
//            try
//            {
//                using (var testFont = new Font(fontName, 9f))
//                {
//                    if (testFont.Name != fontName) fontName = "Segoe UI";
//                }
//                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
//                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
//            }
//            catch
//            {
//                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
//                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
//            }
//        }

//        private void InitializeContextMenu()
//        {
//            _contextMenu = new ContextMenuStrip();
//            _contextMenu.Items.Add("Export Data", null, (s, e) => ShowExportDialog());
//            _contextMenu.Items.Add("Import Data", null, (s, e) => ShowImportDialog());
//            _contextMenu.Items.Add(new ToolStripSeparator());
//            _contextMenu.Items.Add("Clear Data", null, (s, e) => { Rows = new List<string[]>(); });
//            _contextMenu.Items.Add("Clear Groups", null, (s, e) => { _groupedColumns.Clear(); Invalidate(); });
//        }

//        private void InitializeFilterMenu()
//        {
//            _filterMenu = new ContextMenuStrip();
//        }
//        #endregion

//        #region Filtering, Search & Virtual Data
//        private void ApplyFiltersAndSearch()
//        {
//            if (_virtualMode)
//            {
//                Invalidate();
//                return;
//            }

//            var result = _rows;

//            if (!string.IsNullOrEmpty(_searchQuery))
//            {
//                result = result.Where(r => r.Any(c => c.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
//            }

//            if (_activeFilters.Count > 0)
//            {
//                foreach (var filter in _activeFilters)
//                {
//                    int colIndex = _headers.IndexOf(filter.Key);
//                    if (colIndex >= 0)
//                    {
//                        result = result.Where(r => filter.Value.Contains(r[colIndex])).ToList();
//                    }
//                }
//            }

//            _filteredRows = result;
//            _scrollOffset = 0;
//            Invalidate();
//        }

//        private void EnsureVirtualRow(int rowIndex)
//        {
//            if (_virtualCache.ContainsKey(rowIndex) || _pendingRequests.Contains(rowIndex) || RetrieveVirtualItem == null)
//                return;

//            _pendingRequests.Add(rowIndex);
//            Task.Run(() =>
//            {
//                var data = RetrieveVirtualItem(rowIndex);
//                if (data != null)
//                {
//                    lock (_virtualCache)
//                    {
//                        _virtualCache[rowIndex] = data;
//                        if (_virtualCache.Count > 1000) _virtualCache.Clear(); // Prevent memory overflow
//                    }
//                }
//                _pendingRequests.Remove(rowIndex);
//                this.BeginInvoke((MethodInvoker)delegate { Invalidate(); });
//            });
//        }

//        public string[] GetRowData(int rowIndex)
//        {
//            if (_virtualMode)
//            {
//                if (_virtualCache.TryGetValue(rowIndex, out var data)) return data;
//                EnsureVirtualRow(rowIndex);
//                return new string[_headers.Count]; // Return empty while loading
//            }
//            return rowIndex >= 0 && rowIndex < _filteredRows.Count ? _filteredRows[rowIndex] : null;
//        }

//        public int GetTotalRowCount()
//        {
//            return _virtualMode ? _virtualRowCount : _filteredRows.Count;
//        }
//        #endregion

//        #region Memory Safe Layout Calculation
//        private void CalculateLayout()
//        {
//            _bandHeight = _bands.Count > 0 ? 30 : 0;
//            _groupPanelHeight = _groupedColumns.Count > 0 ? 40 : 0;
//            _footerHeight = _summaries.Count > 0 ? 36 : 0;
//            _headerHeight = 48;

//            int safeWidth = Math.Max(0, Width - 24);
//            int safeHeight = Math.Max(0, Height - 24 - _groupPanelHeight - _footerHeight);
//            _contentBounds = new Rectangle(12, 12 + _groupPanelHeight, safeWidth, safeHeight);

//            if (_columnWeights == null || _columnWeights.Length != _headers.Count)
//            {
//                _columnWeights = new float[_headers.Count];
//                for (int i = 0; i < _headers.Count; i++) _columnWeights[i] = 1f / _headers.Count;
//            }

//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;

//            if (totalContentHeight > visibleHeight && visibleHeight > 0)
//            {
//                int scrollWidth = 6;
//                _scrollTrackBounds = new Rectangle(
//                    _contentBounds.Right - scrollWidth - 2,
//                    _contentBounds.Y + _headerHeight + _bandHeight + 4,
//                    scrollWidth,
//                    Math.Max(0, visibleHeight - 8));

//                float scrollRatio = (float)visibleHeight / totalContentHeight;
//                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
//                int maxScroll = totalContentHeight - visibleHeight;
//                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / Math.Max(1, maxScroll)) * (_scrollTrackBounds.Height - thumbHeight));

//                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
//            }
//            else
//            {
//                _scrollTrackBounds = Rectangle.Empty;
//                _scrollThumbBounds = Rectangle.Empty;
//                _scrollOffset = 0;
//            }
//        }
//        #endregion

//        #region Core Paint Engine
//        protected override void OnPaint(PaintEventArgs e)
//        {
//            if (Width <= 0 || Height <= 0) return;

//            Graphics g = e.Graphics;
//            g.SmoothingMode = SmoothingMode.AntiAlias;
//            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
//            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
//            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

//            CalculateLayout();

//            using (SolidBrush bgBrush = GetBackgroundBrush())
//            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8))
//            {
//                g.FillPath(bgBrush, bgPath);
//            }

//            if (_contentBounds.Width > 0 && _contentBounds.Height > 0)
//            {
//                using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
//                {
//                    g.SetClip(contentClipPath);
//                    if (_groupedColumns.Count > 0) DrawGroupingPanel(g);
//                    if (_bands.Count > 0) DrawBands(g);
//                    DrawHeader(g);
//                    DrawRows(g);
//                    g.ResetClip();
//                }
//            }

//            if (_summaries.Count > 0) DrawFooterSummaries(g);

//            DrawOuterBorder(g);
//            DrawScrollbar(g);
//        }

//        private void DrawGroupingPanel(Graphics g)
//        {
//            Rectangle panelRect = new Rectangle(_contentBounds.X, _contentBounds.Y - _groupPanelHeight + 2, _contentBounds.Width, _groupPanelHeight - 4);
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var brush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
//            {
//                g.FillRectangle(brush, panelRect);
//                int x = panelRect.X + 10;
//                foreach (var col in _groupedColumns)
//                {
//                    var size = g.MeasureString(col, _cellFont);
//                    Rectangle tagRect = new Rectangle(x, panelRect.Y + 8, (int)size.Width + 20, 24);
//                    using (var tagPath = GetRoundedPath(tagRect, 4))
//                    using (var tagBrush = new SolidBrush(GetAccentColor()))
//                    using (var textBrush = new SolidBrush(Color.White))
//                    {
//                        g.FillPath(tagBrush, tagPath);
//                        g.DrawString(col, _cellFont, textBrush, new RectangleF(x + 10, panelRect.Y + 8, size.Width, 24), sf);
//                    }
//                    x += tagRect.Width + 8;
//                }
//                g.DrawLine(pen, panelRect.Left, panelRect.Bottom, panelRect.Right, panelRect.Bottom);
//            }
//        }

//        private void DrawBands(Graphics g)
//        {
//            int y = _contentBounds.Y;
//            int colX = _contentBounds.X;
//            using (var brush = new SolidBrush(GetHeaderTextColor()))
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Center })
//            {
//                foreach (var band in _bands)
//                {
//                    int spanCount = band.Columns.Count;
//                    if (spanCount == 0) continue;
//                    float width = 0;
//                    for (int i = 0; i < _headers.Count; i++)
//                    {
//                        if (band.Columns.Contains(_headers[i])) width += _contentBounds.Width * _columnWeights[i];
//                    }
//                    Rectangle bandRect = new Rectangle(colX, y, (int)width, _bandHeight);
//                    g.DrawString(band.Name, _headerFont, brush, bandRect, sf);
//                    g.DrawRectangle(pen, bandRect);
//                    colX += (int)width;
//                }
//            }
//        }

//        private void DrawHeader(Graphics g)
//        {
//            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight);
//            int colX = headerRect.X;

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
//            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (Font glyphFont = new Font("Segoe UI Symbol", 8f))
//            {
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, colWidth - 24, headerRect.Height);

//                    if (!string.IsNullOrEmpty(_headers[i]))
//                    {
//                        g.DrawString(_headers[i], _headerFont, textBrush, cellRect, sf);

//                        // Draw Filter Glyph
//                        RectangleF glyphRect = new RectangleF(colX + colWidth - 24, headerRect.Y + (headerRect.Height - 8) / 2, 12, 12);
//                        g.DrawString("▾", glyphFont, textBrush, glyphRect);
//                    }
//                    colX += (int)colWidth;
//                }
//                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
//            }
//        }

//        private void DrawRows(Graphics g)
//        {
//            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight + _bandHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight - _bandHeight);

//            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
//            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 2;
//            int totalRows = GetTotalRowCount();

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            {
//                for (int i = firstVisibleRow; i < Math.Min(totalRows, firstVisibleRow + visibleRowCount); i++)
//                {
//                    if (i < 0) continue;

//                    int currentRowHeight = _rowHeight;
//                    if (AutoRowHeight && !_virtualMode)
//                    {
//                        if (!_rowHeightsCache.ContainsKey(i))
//                        {
//                            var rowData = GetRowData(i);
//                            if (rowData != null)
//                            {
//                                float maxH = 0;
//                                for (int j = 0; j < _headers.Count; j++)
//                                {
//                                    float colWidth = _contentBounds.Width * _columnWeights[j] - 24;
//                                    if (colWidth <= 0) continue;
//                                    var size = g.MeasureString(rowData.Length > j ? rowData[j] : "", _cellFont, (int)colWidth);
//                                    maxH = Math.Max(maxH, size.Height);
//                                }
//                                _rowHeightsCache[i] = (int)Math.Ceiling(maxH) + 12;
//                            }
//                        }
//                        currentRowHeight = _rowHeightsCache.ContainsKey(i) ? _rowHeightsCache[i] : _rowHeight;
//                    }

//                    int y = rowArea.Y + (i * currentRowHeight) - _scrollOffset; // Simplified Y calc for standard. Real var height needs cumulative offset.

//                    // Cumulative Y calculation for AutoHeight
//                    if (AutoRowHeight && !_virtualMode)
//                    {
//                        y = rowArea.Y;
//                        for (int k = 0; k < i; k++)
//                        {
//                            y += _rowHeightsCache.ContainsKey(k) ? _rowHeightsCache[k] : _rowHeight;
//                        }
//                        y -= _scrollOffset;
//                    }

//                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, currentRowHeight);

//                    if (y + currentRowHeight < rowArea.Y || y > rowArea.Y + rowArea.Height) continue;

//                    DrawRowBackground(g, rowRect, i);
//                    DrawRowContent(g, rowRect, i, sf);
//                }
//            }
//        }

//        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex)
//        {
//            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
//            bool isSelected = (rowIndex == _selectedRowIndex);
//            var rowData = GetRowData(rowIndex);

//            // Apply Conditional Formatting
//            Color customBg = Color.Empty;
//            Color customFg = Color.Empty;
//            if (rowData != null)
//            {
//                foreach (var rule in _formatRules)
//                {
//                    int colIdx = _headers.IndexOf(rule.ColumnName);
//                    if (colIdx >= 0 && rowData.Length > colIdx)
//                    {
//                        if (EvaluateRule(rule.Operator, rowData[colIdx], rule.Value))
//                        {
//                            customBg = rule.BackColor;
//                            customFg = rule.ForeColor;
//                        }
//                    }
//                }
//            }

//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium:
//                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
//                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//                    using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1))
//                    using (var ruleBrush = new SolidBrush(Color.FromArgb(150, customBg)))
//                    {
//                        if (customBg != Color.Empty) g.FillRectangle(ruleBrush, rowRect);
//                        if (isSelected) g.FillRectangle(selBrush, rowRect);
//                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);
//                        g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);
//                    }
//                    break;

//                case DesignStyle.MaterialFlat:
//                    Color matBg = customBg != Color.Empty ? customBg : Color.Transparent;
//                    if (isSelected && matBg == Color.Transparent) matBg = Color.FromArgb(255, GetAccentColor());
//                    else if (isHovered && matBg == Color.Transparent) matBg = Color.FromArgb(50, GetForegroundColor());
//                    if (matBg != Color.Transparent)
//                        using (var matBrush = new SolidBrush(matBg)) g.FillRectangle(matBrush, rowRect);
//                    break;

//                    // Other styles omitted for brevity but use similar logic
//            }
//        }

//        private bool EvaluateRule(string op, string cellVal, string targetVal)
//        {
//            if (double.TryParse(cellVal, out double c) && double.TryParse(targetVal, out double t))
//            {
//                switch (op)
//                {
//                    case ">": return c > t;
//                    case "<": return c < t;
//                    case "==": return c == t;
//                    case "!=": return c != t;
//                    case ">=": return c >= t;
//                    case "<=": return c <= t;
//                }
//            }
//            else
//            {
//                switch (op)
//                {
//                    case "==": return cellVal == targetVal;
//                    case "!=": return cellVal != targetVal;
//                }
//            }
//            return false;
//        }

//        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
//        {
//            int colX = rowRect.X;
//            var rowData = GetRowData(rowIndex);
//            if (rowData == null) return;

//            using (SolidBrush textBrush = new SolidBrush(GetForegroundColor()))
//            {
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, colWidth - 24, rowRect.Height);

//                    string val = rowData.Length > i ? rowData[i] : "";

//                    // Highlight Search Query
//                    if (!string.IsNullOrEmpty(_searchQuery) && val.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)
//                    {
//                        string lowerVal = val.ToLower();
//                        string lowerQuery = _searchQuery.ToLower();
//                        int idx = lowerVal.IndexOf(lowerQuery);

//                        using (Font highlightFont = new Font(_cellFont, FontStyle.Bold))
//                        using (SolidBrush highlightBrush = new SolidBrush(GetAccentColor()))
//                        {
//                            string before = val.Substring(0, idx);
//                            string match = val.Substring(idx, _searchQuery.Length);
//                            string after = val.Substring(idx + _searchQuery.Length);

//                            g.DrawString(before, _cellFont, textBrush, cellRect, sf);
//                            SizeF beforeSize = g.MeasureString(before, _cellFont);
//                            RectangleF matchRect = new RectangleF(cellRect.X + beforeSize.Width, cellRect.Y, cellRect.Width - beforeSize.Width, cellRect.Height);
//                            g.DrawString(match, highlightFont, highlightBrush, matchRect, sf);

//                            SizeF matchSize = g.MeasureString(match, highlightFont);
//                            RectangleF afterRect = new RectangleF(matchRect.X + matchSize.Width, cellRect.Y, cellRect.Width - (beforeSize.Width + matchSize.Width), cellRect.Height);
//                            g.DrawString(after, _cellFont, textBrush, afterRect, sf);
//                        }
//                    }
//                    else
//                    {
//                        g.DrawString(val, _cellFont, textBrush, cellRect, sf);
//                    }

//                    colX += (int)colWidth;
//                }
//            }
//        }

//        private void DrawFooterSummaries(Graphics g)
//        {
//            Rectangle footerRect = new Rectangle(_contentBounds.X, _contentBounds.Bottom + 4, _contentBounds.Width, _footerHeight);
//            int colX = footerRect.X;

//            using (var bgBrush = new SolidBrush(Color.FromArgb(_themeMode == ThemeMode.Light ? 240 : 30, GetBackgroundColor())))
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var textBrush = new SolidBrush(GetForegroundColor()))
//            using (var boldFont = new Font(_cellFont, FontStyle.Bold))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
//            {
//                g.FillPath(bgBrush, GetRoundedPath(footerRect, 4));
//                g.DrawLine(pen, footerRect.Left, footerRect.Top, footerRect.Right, footerRect.Top);

//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, footerRect.Y, colWidth - 24, footerRect.Height);

//                    var summary = _summaries.FirstOrDefault(s => s.ColumnName == _headers[i]);
//                    if (summary != null && summary.SummaryType != SummaryType.None)
//                    {
//                        string val = CalculateSummary(summary, i);
//                        g.DrawString(val, boldFont, textBrush, cellRect, sf);
//                    }
//                    colX += (int)colWidth;
//                }
//            }
//        }

//        private string CalculateSummary(ColumnSummary summary, int colIndex)
//        {
//            if (_virtualMode) return "N/A (Virtual Mode)";

//            var values = _filteredRows.Select(r => r.Length > colIndex ? r[colIndex] : null).Where(v => v != null).ToList();
//            if (values.Count == 0) return "";

//            var nums = new List<double>();
//            foreach (var v in values) if (double.TryParse(v, out double d)) nums.Add(d);

//            if (summary.SummaryType == SummaryType.Count) return values.Count.ToString();

//            if (nums.Count > 0)
//            {
//                switch (summary.SummaryType)
//                {
//                    case SummaryType.Sum: return nums.Sum().ToString("N2");
//                    case SummaryType.Avg: return nums.Average().ToString("N2");
//                    case SummaryType.Min: return nums.Min().ToString("N2");
//                    case SummaryType.Max: return nums.Max().ToString("N2");
//                }
//            }
//            return "";
//        }

//        private void DrawOuterBorder(Graphics g)
//        {
//            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
//            {
//                switch (_controlStyle)
//                {
//                    case DesignStyle.DashboardPremium:
//                        using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1))
//                            g.DrawPath(borderPen, path);
//                        break;
//                    case DesignStyle.MaterialFlat: break;
//                    case DesignStyle.SoftNeumorphic:
//                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
//                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
//                        {
//                            g.DrawPath(lightPen, path);
//                            g.TranslateTransform(1, 1); g.DrawPath(darkPen, path); g.ResetTransform();
//                        }
//                        break;
//                    case DesignStyle.CyberpunkIndustrial:
//                        using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4))
//                        using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1))
//                        { g.DrawPath(glowPen, path); g.DrawPath(corePen, path); }
//                        break;
//                }
//            }
//        }

//        private void DrawScrollbar(Graphics g)
//        {
//            if (_scrollThumbBounds == Rectangle.Empty) return;
//            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
//            using (var thumbBrush = new SolidBrush(Color.FromArgb(180, GetAccentColor())))
//            {
//                g.FillPath(thumbBrush, thumbPath);
//            }
//        }
//        #endregion

//        #region Color Palette Engine
//        private Color GetBackgroundColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium: return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26);
//                case DesignStyle.FluentGlass: return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32);
//                case DesignStyle.MaterialFlat: return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18);
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48);
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(12, 12, 14);
//                default: return Color.White;
//            }
//        }
//        private SolidBrush GetBackgroundBrush() => new SolidBrush(GetBackgroundColor());
//        private Color GetForegroundColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(230, 240, 255);
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240);
//                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240);
//            }
//        }
//        private Color GetHeaderTextColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.CyberpunkIndustrial: return GetAccentColor();
//                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160);
//            }
//        }
//        private Color GetHeaderSeparatorColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
//        private Color GetAccentColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212);
//                case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255);
//                case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238);
//                case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51);
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204);
//                default: return Color.Blue;
//            }
//        }
//        private Color GetNeumorphicLightColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
//        private Color GetNeumorphicDarkColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
//        #endregion

//        #region Geometry Helpers
//        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
//        {
//            GraphicsPath path = new GraphicsPath();
//            if (rect.Width <= 0 || rect.Height <= 0) return path;
//            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
//            if (r <= 0) { path.AddRectangle(rect); return path; }
//            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
//            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
//            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
//            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
//            path.CloseFigure();
//            return path;
//        }
//        #endregion

//        #region Advanced Data Export Engine (CSV, JSON, XML, XLSX, PDF)
//        public void ShowExportDialog()
//        {
//            using (var sfd = new SaveFileDialog())
//            {
//                sfd.Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json|XML (*.xml)|*.xml|Excel (*.xlsx)|*.xlsx|PDF (*.pdf)|*.pdf";
//                if (sfd.ShowDialog() == DialogResult.OK)
//                {
//                    DataFormat format = (DataFormat)sfd.FilterIndex - 1; // Shifted because of 0-index
//                    ExportData(sfd.FileName, format);
//                }
//            }
//        }

//        public void ExportData(string filePath, DataFormat format)
//        {
//            try
//            {
//                if (format == DataFormat.CSV) ExportCSV(filePath);
//                else if (format == DataFormat.JSON) ExportJSON(filePath);
//                else if (format == DataFormat.XML) ExportXML(filePath);
//                else if (format == DataFormat.XLSX) ExportXLSX(filePath);
//                else if (format == DataFormat.PDF) ExportPDF(filePath);

//                MessageBox.Show("Export successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }

//        private void ExportCSV(string filePath)
//        {
//            var sb = new StringBuilder();
//            sb.AppendLine(string.Join(",", _headers));
//            foreach (var row in _filteredRows) sb.AppendLine(string.Join(",", row));
//            File.WriteAllText(filePath, sb.ToString());
//        }

//        private void ExportJSON(string filePath)
//        {
//            var sb = new StringBuilder();
//            sb.Append("{\"headers\":[");
//            sb.Append(string.Join(",", _headers.ConvertAll(h => $"\"{EscapeJson(h)}\"")));
//            sb.Append("],\"rows\":[");
//            for (int i = 0; i < _filteredRows.Count; i++)
//            {
//                sb.Append("[" + string.Join(",", Array.ConvertAll(_filteredRows[i], c => $"\"{EscapeJson(c)}\"")) + "]");
//                if (i < _filteredRows.Count - 1) sb.Append(",");
//            }
//            sb.Append("]}");
//            File.WriteAllText(filePath, sb.ToString());
//        }

//        private void ExportXML(string filePath)
//        {
//            var doc = new XDocument(new XElement("GridData"));
//            var headersEl = new XElement("Headers");
//            foreach (var h in _headers) headersEl.Add(new XElement("Header", h));
//            doc.Root.Add(headersEl);
//            var rowsEl = new XElement("Rows");
//            foreach (var row in _filteredRows)
//            {
//                var rowEl = new XElement("Row");
//                foreach (var cell in row) rowEl.Add(new XElement("Cell", cell));
//                rowsEl.Add(rowEl);
//            }
//            doc.Root.Add(rowsEl);
//            doc.Save(filePath);
//        }

//        // Native XLSX Writer using System.IO.Packaging (No external libraries)
//        private void ExportXLSX(string filePath)
//        {
//            using (var package = System.IO.Packaging.Package.Open(filePath, FileMode.Create))
//            {
//                // Create parts
//                var workbookPart = package.CreatePart(new Uri("/xl/workbook.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml");
//                var sheetPart = package.CreatePart(new Uri("/xl/worksheets/sheet1.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");
//                var sharedStringsPart = package.CreatePart(new Uri("/xl/sharedStrings.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml");

//                // Write Shared Strings
//                var sb = new StringBuilder();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\"").Append(_headers.Count + _filteredRows.Count * _headers.Count).Append("\">");
//                foreach (var h in _headers) sb.Append("<si><t>").Append(EscapeXml(h)).Append("</t></si>");
//                foreach (var row in _filteredRows) foreach (var c in row) sb.Append("<si><t>").Append(EscapeXml(c)).Append("</t></si>");
//                sb.Append("</sst>");
//                using (var stream = sharedStringsPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                // Write Sheet
//                sb.Clear();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
//                sb.Append("<sheetData>");

//                // Header Row
//                sb.Append("<row r=\"1\">");
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    string cellRef = GetExcelCellRef(i, 1);
//                    sb.Append("<c r=\"").Append(cellRef).Append("\" t=\"sharedString\"><v>").Append(i).Append("</v></c>");
//                }
//                sb.Append("</row>");

//                // Data Rows
//                for (int r = 0; r < _filteredRows.Count; r++)
//                {
//                    sb.Append("<row r=\"").Append(r + 2).Append("\">");
//                    for (int c = 0; c < _filteredRows[r].Length; c++)
//                    {
//                        string cellRef = GetExcelCellRef(c, r + 2);
//                        int sharedIndex = _headers.Count + (r * _headers.Count) + c; // Simplified index
//                        sb.Append("<c r=\"").Append(cellRef).Append("\" t=\"sharedString\"><v>").Append(sharedIndex).Append("</v></c>");
//                    }
//                    sb.Append("</row>");
//                }

//                sb.Append("</sheetData></worksheet>");
//                using (var stream = sheetPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                // Write Workbook
//                sb.Clear();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
//                sb.Append("<sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"/></sheets>");
//                sb.Append("</workbook>");
//                using (var stream = workbookPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                // Relationships
//                package.CreateRelationship(new Uri("/xl/worksheets/sheet1.xml", UriKind.Relative), System.IO.Packaging.TargetMode.Internal, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet", "rId1");
//                package.CreateRelationship(new Uri("/xl/sharedStrings.xml", UriKind.Relative), System.IO.Packaging.TargetMode.Internal, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings", "rId2");
//            }
//        }

//        private string GetExcelCellRef(int col, int row)
//        {
//            int dividend = col + 1;
//            string colRef = "";
//            while (dividend > 0)
//            {
//                int modulo = (dividend - 1) % 26;
//                colRef = Convert.ToChar(65 + modulo) + colRef;
//                dividend = (dividend - modulo) / 26;
//            }
//            return colRef + row;
//        }

//        // Native PDF Writer (Raw PDF syntax)
//        private void ExportPDF(string filePath)
//        {
//            using (var stream = new FileStream(filePath, FileMode.Create))
//            using (var writer = new StreamWriter(stream))
//            {
//                writer.Write("%PDF-1.4\n");
//                writer.Write("1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n");
//                writer.Write("2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n");
//                writer.Write("3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n");

//                var content = new StringBuilder();
//                content.Append("BT /F1 12 Tf 50 750 Td 14 TL\n");
//                content.Append(string.Join("    ", _headers) + " Tj T*\n");
//                foreach (var row in _filteredRows)
//                {
//                    content.Append(string.Join("    ", row) + " Tj T*\n");
//                }
//                content.Append("ET\n");

//                string contentStr = content.ToString();
//                writer.Write($"4 0 obj<</Length {contentStr.Length}>>stream\n{contentStr}endstream endobj\n");
//                writer.Write("5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n");

//                writer.Write("xref\n0 6\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000266 00000 n \n0000000356 00000 n \n");
//                writer.Write("trailer<</Size 6/Root 1 0 R>>\nstartxref\n406\n%%EOF");
//            }
//        }

//        private string EscapeXml(string val) => val.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
//        private string EscapeJson(string val) => val.Replace("\\", "\\\\").Replace("\"", "\\\"");

//        public void ShowImportDialog()
//        {
//            using (var ofd = new OpenFileDialog())
//            {
//                ofd.Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json|XML (*.xml)|*.xml";
//                if (ofd.ShowDialog() == DialogResult.OK)
//                {
//                    DataFormat format = (DataFormat)ofd.FilterIndex - 1;
//                    ImportData(ofd.FileName, format);
//                }
//            }
//        }

//        public void ImportData(string filePath, DataFormat format)
//        {
//            try
//            {
//                if (format == DataFormat.CSV)
//                {
//                    var lines = File.ReadAllLines(filePath);
//                    if (lines.Length == 0) return;
//                    Headers = new List<string>(lines[0].Split(','));
//                    var newRows = new List<string[]>();
//                    for (int i = 1; i < lines.Length; i++) if (!string.IsNullOrWhiteSpace(lines[i])) newRows.Add(lines[i].Split(','));
//                    Rows = newRows;
//                }
//                MessageBox.Show("Data imported successfully!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Import failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }
//        #endregion

//        #region Mouse & State Handling
//        protected override void OnMouseMove(MouseEventArgs e)
//        {
//            base.OnMouseMove(e);
//            if (_isScrolling) { UpdateScrollPosition(e.Y); return; }

//            int newHoveredRow = GetRowAtPosition(e.Location);
//            if (newHoveredRow != _hoveredRowIndex)
//            {
//                _hoveredRowIndex = newHoveredRow;
//                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
//                Invalidate();
//            }
//        }

//        protected override void OnMouseDown(MouseEventArgs e)
//        {
//            base.OnMouseDown(e);
//            Focus();

//            if (e.Button == MouseButtons.Right && EnableDataContextMenu)
//            {
//                if (IsOnHeader(e.Location)) OpenFilterMenu(e.Location);
//                else _contextMenu.Show(this, e.Location);
//                return;
//            }

//            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
//            {
//                _isScrolling = true; Cursor = Cursors.SizeNS; _currentState = ControlState.Pressed; Invalidate(); return;
//            }

//            int clickedRow = GetRowAtPosition(e.Location);
//            if (clickedRow != -1)
//            {
//                _selectedRowIndex = clickedRow; _currentState = ControlState.Pressed; Invalidate();
//            }
//        }

//        private bool IsOnHeader(Point p)
//        {
//            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight);
//            return headerRect.Contains(p);
//        }

//        private void OpenFilterMenu(Point p)
//        {
//            _filterMenu.Items.Clear();
//            int colIndex = (p.X - _contentBounds.X) / (int)(_contentBounds.Width / _headers.Count);
//            if (colIndex < 0 || colIndex >= _headers.Count) return;

//            string colName = _headers[colIndex];
//            _filterMenu.Items.Add($"Filter by: {colName}").Enabled = false;
//            _filterMenu.Items.Add(new ToolStripSeparator());

//            var distinctValues = _rows.Select(r => r.Length > colIndex ? r[colIndex] : "").Distinct().ToList();
//            var checkedListBox = new CheckedListBox { CheckOnClick = true, Height = 150, Width = 200 };
//            foreach (var val in distinctValues)
//            {
//                bool isChecked = !_activeFilters.ContainsKey(colName) || _activeFilters[colName].Contains(val);
//                checkedListBox.Items.Add(val, isChecked);
//            }

//            checkedListBox.ItemCheck += (s, e) =>
//            {
//                this.BeginInvoke((MethodInvoker)delegate
//                {
//                    var selected = new List<string>();
//                    foreach (var item in checkedListBox.CheckedItems) selected.Add(item.ToString());
//                    if (selected.Count == distinctValues.Count) _activeFilters.Remove(colName);
//                    else _activeFilters[colName] = selected;
//                    ApplyFiltersAndSearch();
//                });
//            };

//            var host = new ToolStripControlHost(checkedListBox) { AutoSize = false, Size = checkedListBox.Size };
//            _filterMenu.Items.Add(host);
//            _filterMenu.Show(this, p);
//        }

//        protected override void OnMouseUp(MouseEventArgs e)
//        {
//            base.OnMouseUp(e);
//            _isScrolling = false; Cursor = Cursors.Default;
//            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
//            Invalidate();
//        }

//        protected override void OnMouseLeave(EventArgs e)
//        {
//            base.OnMouseLeave(e);
//            _hoveredRowIndex = -1; _currentState = ControlState.Normal; Cursor = Cursors.Default; Invalidate();
//        }

//        protected override void OnMouseWheel(MouseEventArgs e)
//        {
//            base.OnMouseWheel(e);
//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;
//            if (totalContentHeight > visibleHeight)
//            {
//                _scrollOffset -= e.Delta;
//                _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, totalContentHeight - visibleHeight));
//                Invalidate();
//            }
//        }

//        // Drag and Drop for Grouping
//        protected override void OnDragEnter(DragEventArgs e) { if (e.Data.GetDataPresent(DataFormats.Text)) e.Effect = DragDropEffects.Move; }
//        protected override void OnDragOver(DragEventArgs e) { if (e.Data.GetDataPresent(DataFormats.Text)) e.Effect = DragDropEffects.Move; }
//        protected override void OnGiveFeedback(GiveFeedbackEventArgs gb) { gb.UseDefaultCursors = false; }

//        protected override void OnQueryContinueDrag(QueryContinueDragEventArgs qcdevent)
//        {
//            base.OnQueryContinueDrag(qcdevent);
//            if (qcdevent.Action == DragAction.Drop || qcdevent.Action == DragAction.Cancel)
//            {
//                Invalidate();
//            }
//        }

//        protected override void OnDragDrop(DragEventArgs e)
//        {
//            string colName = (string)e.Data.GetData(DataFormats.Text);
//            if (!_groupedColumns.Contains(colName))
//            {
//                _groupedColumns.Add(colName);
//                Invalidate();
//            }
//        }

//        private int GetRowAtPosition(Point p)
//        {
//            if (!_contentBounds.Contains(p)) return -1;
//            int relativeY = p.Y - (_contentBounds.Y + _headerHeight + _bandHeight) + _scrollOffset;
//            if (relativeY < 0) return -1;
//            int rowIndex = relativeY / _rowHeight;
//            if (rowIndex >= 0 && rowIndex < GetTotalRowCount()) return rowIndex;
//            return -1;
//        }

//        private void UpdateScrollPosition(int mouseY)
//        {
//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;
//            int maxScroll = totalContentHeight - visibleHeight;
//            if (maxScroll <= 0) return;

//            int thumbHeight = _scrollThumbBounds.Height;
//            int trackHeight = _scrollTrackBounds.Height - thumbHeight;
//            int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2);
//            relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight));

//            float scrollRatio = (float)relativeMouseY / Math.Max(1, trackHeight);
//            _scrollOffset = (int)(scrollRatio * maxScroll);
//            Invalidate();
//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                _headerFont?.Dispose();
//                _cellFont?.Dispose();
//                _contextMenu?.Dispose();
//                _filterMenu?.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//        #endregion
//    }
//}











//================================================== VER 1.3 ======================================================


//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Drawing.Drawing2D;
//using System.Drawing.Text;
//using System.IO;
//using System.IO.Compression;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;
//using System.Xml.Linq;

//namespace UltraModernUI.Controls
//{
//    public class ModernDataGridView : Control
//    {
//        #region Enums
//        public enum ThemeMode { Light, Dark }
//        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
//        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
//        public enum DataFormat { CSV, JSON, XML, XLSX, PDF }
//        public enum SummaryType { None, Sum, Avg, Count, Min, Max }
//        public enum EditorType { None, Text, DatePicker, ToggleSwitch, MultiSelectCombo, NumericSlider }
//        #endregion

//        #region Data Classes
//        public class Band
//        {
//            public string Name { get; set; }
//            public List<string> Columns { get; set; } = new List<string>();
//        }

//        public class FormatRule
//        {
//            public string ColumnName { get; set; }
//            public string Operator { get; set; }
//            public string Value { get; set; }
//            public Color BackColor { get; set; }
//            public Color ForeColor { get; set; }
//        }

//        public class ColumnSummary
//        {
//            public string ColumnName { get; set; }
//            public SummaryType SummaryType { get; set; }
//        }
//        #endregion

//        #region Fields & Properties
//        private ThemeMode _themeMode = ThemeMode.Light;
//        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
//        private ControlState _currentState = ControlState.Normal;

//        private List<string> _headers = new List<string> { "ID", "Status", "Metric", "Value" };
//        private List<string[]> _rows = new List<string[]>();
//        private List<string[]> _filteredRows = new List<string[]>();
//        private float[] _columnWeights;

//        private int _hoveredRowIndex = -1;
//        private int _selectedRowIndex = -1;
//        private int _scrollOffset = 0;
//        private int _rowHeight = 42;
//        private int _headerHeight = 48;
//        private int _bandHeight = 0;
//        private int _groupPanelHeight = 0;
//        private int _footerHeight = 0;

//        private Rectangle _contentBounds;
//        private Rectangle _scrollTrackBounds;
//        private Rectangle _scrollThumbBounds;
//        private bool _isScrolling = false;

//        private Font _headerFont;
//        private Font _cellFont;
//        private ContextMenuStrip _contextMenu;
//        private ContextMenuStrip _filterMenu;

//        private bool _virtualMode = false;
//        private int _virtualRowCount = 0;
//        private Dictionary<int, string[]> _virtualCache = new Dictionary<int, string[]>();
//        private HashSet<int> _pendingRequests = new HashSet<int>();

//        private string _searchQuery = "";
//        private List<string> _groupedColumns = new List<string>();
//        private List<Band> _bands = new List<Band>();
//        private List<FormatRule> _formatRules = new List<FormatRule>();
//        private List<ColumnSummary> _summaries = new List<ColumnSummary>();
//        private bool _autoRowHeight = false;
//        private Dictionary<int, int> _rowHeightsCache = new Dictionary<int, int>();
//        private Dictionary<string, List<string>> _activeFilters = new Dictionary<string, List<string>>();

//        private object _dataSource;

//        [Category("Data")]
//        [AttributeProvider(typeof(IListSource))]
//        [Description("Binds data to the grid. Supports DataTable and IList.")]
//        public object DataSource
//        {
//            get { return _dataSource; }
//            set
//            {
//                if (_dataSource != value)
//                {
//                    _dataSource = value;
//                    ProcessDataSource();
//                }
//            }
//        }

//        [Category("Appearance")]
//        [DefaultValue(ThemeMode.Light)]
//        public ThemeMode Theme { get { return _themeMode; } set { _themeMode = value; Invalidate(); } }

//        [Category("Appearance")]
//        [DefaultValue(DesignStyle.DashboardPremium)]
//        public DesignStyle Style { get { return _controlStyle; } set { _controlStyle = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<string> Headers { get { return _headers; } set { _headers = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<string[]> Rows
//        {
//            get { return _rows; }
//            set { _rows = value ?? new List<string[]>(); _filteredRows = _rows; _selectedRowIndex = -1; _scrollOffset = 0; ApplyFiltersAndSearch(); }
//        }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool AutoRowHeight { get { return _autoRowHeight; } set { _autoRowHeight = value; _rowHeightsCache.Clear(); Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<Band> Bands { get { return _bands; } set { _bands = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<FormatRule> FormatRules { get { return _formatRules; } set { _formatRules = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<ColumnSummary> Summaries { get { return _summaries; } set { _summaries = value; Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool VirtualMode { get { return _virtualMode; } set { _virtualMode = value; _virtualCache.Clear(); Invalidate(); } }

//        [Category("Data")]
//        [DefaultValue(0)]
//        public int VirtualRowCount { get { return _virtualRowCount; } set { _virtualRowCount = value; Invalidate(); } }

//        [Category("Appearance")]
//        [DefaultValue(42)]
//        public int RowHeight { get { return _rowHeight; } set { _rowHeight = Math.Max(1, value); Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(true)]
//        public bool EnableDataContextMenu { get; set; } = true;

//        [Category("Data")]
//        public string SearchQuery { get { return _searchQuery; } set { _searchQuery = value; ApplyFiltersAndSearch(); } }

//        public event Func<int, string[]> RetrieveVirtualItem;

//        #endregion

//        #region Constructor & Initialization
//        public ModernDataGridView()
//        {
//            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);

//            UpdateFonts();
//            InitializeContextMenu();
//            InitializeFilterMenu();

//            BackColor = Color.Transparent;
//            Size = new Size(800, 500);

//            if (LicenseManager.UsageMode == LicenseUsageMode.Designtime)
//            {
//                _rows = new List<string[]>
//                {
//                    new string[] { "001", "Active", "CPU Load", "2400" },
//                    new string[] { "002", "Idle", "Memory", "4200" },
//                    new string[] { "003", "Warning", "Network", "12500" },
//                    new string[] { "004", "Active", "Disk I/O", "8900" },
//                    new string[] { "005", "Active", "Temp", "5400" },
//                    new string[] { "006", "Offline", "Uptime", "0" },
//                    new string[] { "007", "Active", "Requests", "12000" },
//                    new string[] { "008", "Active", "Latency", "120" }
//                };
//                _filteredRows = _rows;
//            }

//            AllowDrop = true;
//        }

//        private void UpdateFonts()
//        {
//            _headerFont?.Dispose();
//            _cellFont?.Dispose();

//            string fontName = "Segoe UI Variable Display";
//            try
//            {
//                using (var testFont = new Font(fontName, 9f))
//                {
//                    if (testFont.Name != fontName) fontName = "Segoe UI";
//                }
//                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
//                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
//            }
//            catch
//            {
//                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
//                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
//            }
//        }

//        private void InitializeContextMenu()
//        {
//            _contextMenu = new ContextMenuStrip();
//            _contextMenu.Items.Add("Export Data", null, (s, e) => ShowExportDialog());
//            _contextMenu.Items.Add("Import Data", null, (s, e) => ShowImportDialog());
//            _contextMenu.Items.Add(new ToolStripSeparator());
//            _contextMenu.Items.Add("Clear Data", null, (s, e) => { Rows = new List<string[]>(); });
//            _contextMenu.Items.Add("Clear Groups", null, (s, e) => { _groupedColumns.Clear(); Invalidate(); });
//        }

//        private void InitializeFilterMenu()
//        {
//            _filterMenu = new ContextMenuStrip();
//        }
//        #endregion

//        #region Data Source Processing
//        private void ProcessDataSource()
//        {
//            if (_dataSource == null)
//            {
//                Headers = new List<string>();
//                Rows = new List<string[]>();
//                return;
//            }

//            if (_dataSource is DataTable table)
//            {
//                var newHeaders = new List<string>();
//                foreach (DataColumn col in table.Columns)
//                    newHeaders.Add(col.ColumnName);

//                var newRows = new List<string[]>();
//                foreach (DataRow row in table.Rows)
//                {
//                    var rowData = new string[table.Columns.Count];
//                    for (int i = 0; i < table.Columns.Count; i++)
//                        rowData[i] = row[i] == null || row[i] == DBNull.Value ? "" : row[i].ToString();
//                    newRows.Add(rowData);
//                }

//                Headers = newHeaders;
//                Rows = newRows;
//            }
//            else if (_dataSource is IEnumerable<object> list)
//            {
//                var firstItem = list.FirstOrDefault();
//                if (firstItem != null)
//                {
//                    var props = firstItem.GetType().GetProperties();
//                    var newHeaders = props.Select(p => p.Name).ToList();
//                    var newRows = new List<string[]>();

//                    foreach (var item in list)
//                    {
//                        var rowData = new string[props.Length];
//                        for (int i = 0; i < props.Length; i++)
//                        {
//                            var val = props[i].GetValue(item);
//                            rowData[i] = val == null ? "" : val.ToString();
//                        }
//                        newRows.Add(rowData);
//                    }

//                    Headers = newHeaders;
//                    Rows = newRows;
//                }
//            }
//        }
//        #endregion

//        #region Filtering, Search & Virtual Data
//        private void ApplyFiltersAndSearch()
//        {
//            if (_virtualMode)
//            {
//                Invalidate();
//                return;
//            }

//            if (_rows == null) _rows = new List<string[]>();

//            var result = _rows;

//            if (!string.IsNullOrEmpty(_searchQuery))
//            {
//                result = result.Where(r => r != null && r.Any(c => c != null && c.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
//            }

//            if (_activeFilters != null && _activeFilters.Count > 0)
//            {
//                foreach (var filter in _activeFilters)
//                {
//                    int colIndex = _headers.IndexOf(filter.Key);
//                    if (colIndex >= 0)
//                    {
//                        result = result.Where(r => r != null && r.Length > colIndex && filter.Value.Contains(r[colIndex])).ToList();
//                    }
//                }
//            }

//            _filteredRows = result.ToList();
//            _scrollOffset = 0;
//            Invalidate();
//        }

//        private void EnsureVirtualRow(int rowIndex)
//        {
//            if (_virtualCache.ContainsKey(rowIndex) || _pendingRequests.Contains(rowIndex) || RetrieveVirtualItem == null)
//                return;

//            _pendingRequests.Add(rowIndex);
//            Task.Run(() =>
//            {
//                var data = RetrieveVirtualItem(rowIndex);
//                if (data != null)
//                {
//                    lock (_virtualCache)
//                    {
//                        _virtualCache[rowIndex] = data;
//                        if (_virtualCache.Count > 1000) _virtualCache.Clear();
//                    }
//                }
//                _pendingRequests.Remove(rowIndex);
//                this.BeginInvoke((MethodInvoker)delegate { Invalidate(); });
//            });
//        }

//        public string[] GetRowData(int rowIndex)
//        {
//            if (_virtualMode)
//            {
//                if (_virtualCache.TryGetValue(rowIndex, out var data)) return data;
//                EnsureVirtualRow(rowIndex);
//                return new string[_headers.Count];
//            }
//            return rowIndex >= 0 && rowIndex < _filteredRows.Count ? _filteredRows[rowIndex] : null;
//        }

//        public int GetTotalRowCount()
//        {
//            return _virtualMode ? _virtualRowCount : _filteredRows.Count;
//        }
//        #endregion

//        #region Memory Safe Layout Calculation
//        private void CalculateLayout()
//        {
//            _bandHeight = _bands.Count > 0 ? 30 : 0;
//            _groupPanelHeight = _groupedColumns.Count > 0 ? 40 : 0;
//            _footerHeight = _summaries.Count > 0 ? 36 : 0;
//            _headerHeight = 48;

//            int safeWidth = Math.Max(0, Width - 24);
//            int safeHeight = Math.Max(0, Height - 24 - _groupPanelHeight - _footerHeight);
//            _contentBounds = new Rectangle(12, 12 + _groupPanelHeight, safeWidth, safeHeight);

//            if (_columnWeights == null || _columnWeights.Length != _headers.Count)
//            {
//                _columnWeights = new float[Math.Max(1, _headers.Count)];
//                for (int i = 0; i < _headers.Count; i++) _columnWeights[i] = 1f / Math.Max(1, _headers.Count);
//            }

//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;

//            if (totalContentHeight > visibleHeight && visibleHeight > 0)
//            {
//                int scrollWidth = 6;
//                _scrollTrackBounds = new Rectangle(
//                    _contentBounds.Right - scrollWidth - 2,
//                    _contentBounds.Y + _headerHeight + _bandHeight + 4,
//                    scrollWidth,
//                    Math.Max(0, visibleHeight - 8));

//                float scrollRatio = (float)visibleHeight / Math.Max(1, totalContentHeight);
//                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
//                int maxScroll = totalContentHeight - visibleHeight;
//                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / Math.Max(1, maxScroll)) * (_scrollTrackBounds.Height - thumbHeight));

//                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
//            }
//            else
//            {
//                _scrollTrackBounds = Rectangle.Empty;
//                _scrollThumbBounds = Rectangle.Empty;
//                _scrollOffset = 0;
//            }
//        }
//        #endregion

//        #region Core Paint Engine
//        protected override void OnPaint(PaintEventArgs e)
//        {
//            if (Width <= 0 || Height <= 0) return;

//            Graphics g = e.Graphics;
//            g.SmoothingMode = SmoothingMode.AntiAlias;
//            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
//            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
//            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

//            CalculateLayout();

//            using (SolidBrush bgBrush = GetBackgroundBrush())
//            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8))
//            {
//                g.FillPath(bgBrush, bgPath);
//            }

//            if (_contentBounds.Width > 0 && _contentBounds.Height > 0)
//            {
//                using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
//                {
//                    g.SetClip(contentClipPath);
//                    if (_groupedColumns.Count > 0) DrawGroupingPanel(g);
//                    if (_bands.Count > 0) DrawBands(g);
//                    DrawHeader(g);
//                    DrawRows(g);
//                    g.ResetClip();
//                }
//            }

//            if (_summaries.Count > 0) DrawFooterSummaries(g);

//            DrawOuterBorder(g);
//            DrawScrollbar(g);
//        }

//        private void DrawGroupingPanel(Graphics g)
//        {
//            Rectangle panelRect = new Rectangle(_contentBounds.X, _contentBounds.Y - _groupPanelHeight + 2, _contentBounds.Width, _groupPanelHeight - 4);
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var brush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
//            {
//                g.FillRectangle(brush, panelRect);
//                int x = panelRect.X + 10;
//                foreach (var col in _groupedColumns)
//                {
//                    var size = g.MeasureString(col, _cellFont);
//                    Rectangle tagRect = new Rectangle(x, panelRect.Y + 8, (int)size.Width + 20, 24);
//                    using (var tagPath = GetRoundedPath(tagRect, 4))
//                    using (var tagBrush = new SolidBrush(GetAccentColor()))
//                    using (var textBrush = new SolidBrush(Color.White))
//                    {
//                        g.FillPath(tagBrush, tagPath);
//                        g.DrawString(col, _cellFont, textBrush, new RectangleF(x + 10, panelRect.Y + 8, size.Width, 24), sf);
//                    }
//                    x += tagRect.Width + 8;
//                }
//                g.DrawLine(pen, panelRect.Left, panelRect.Bottom, panelRect.Right, panelRect.Bottom);
//            }
//        }

//        private void DrawBands(Graphics g)
//        {
//            int y = _contentBounds.Y;
//            int colX = _contentBounds.X;
//            using (var brush = new SolidBrush(GetHeaderTextColor()))
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Center })
//            {
//                foreach (var band in _bands)
//                {
//                    int spanCount = band.Columns.Count;
//                    if (spanCount == 0) continue;
//                    float width = 0;
//                    for (int i = 0; i < _headers.Count; i++)
//                    {
//                        if (band.Columns.Contains(_headers[i])) width += _contentBounds.Width * _columnWeights[i];
//                    }
//                    Rectangle bandRect = new Rectangle(colX, y, (int)width, _bandHeight);
//                    g.DrawString(band.Name, _headerFont, brush, bandRect, sf);
//                    g.DrawRectangle(pen, bandRect);
//                    colX += (int)width;
//                }
//            }
//        }

//        private void DrawHeader(Graphics g)
//        {
//            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight);
//            int colX = headerRect.X;

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
//            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (Font glyphFont = new Font("Segoe UI Symbol", 8f))
//            {
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, Math.Max(1, colWidth - 24), headerRect.Height);

//                    if (!string.IsNullOrEmpty(_headers[i]))
//                    {
//                        g.DrawString(_headers[i], _headerFont, textBrush, cellRect, sf);

//                        RectangleF glyphRect = new RectangleF(colX + colWidth - 24, headerRect.Y + (headerRect.Height - 8) / 2, 12, 12);
//                        g.DrawString("▾", glyphFont, textBrush, glyphRect);
//                    }
//                    colX += (int)colWidth;
//                }
//                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
//            }
//        }

//        private void DrawRows(Graphics g)
//        {
//            if (_rowHeight <= 0) return;
//            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight + _bandHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight - _bandHeight);
//            if (rowArea.Height <= 0) return;

//            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
//            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 2;
//            int totalRows = GetTotalRowCount();

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            {
//                for (int i = firstVisibleRow; i < Math.Min(totalRows, firstVisibleRow + visibleRowCount); i++)
//                {
//                    if (i < 0) continue;

//                    int currentRowHeight = _rowHeight;
//                    if (AutoRowHeight && !_virtualMode)
//                    {
//                        if (!_rowHeightsCache.ContainsKey(i))
//                        {
//                            var rowData = GetRowData(i);
//                            if (rowData != null)
//                            {
//                                float maxH = 0;
//                                for (int j = 0; j < _headers.Count; j++)
//                                {
//                                    float colWidth = _contentBounds.Width * _columnWeights[j] - 24;
//                                    if (colWidth <= 0) continue;
//                                    var size = g.MeasureString(rowData.Length > j ? rowData[j] : "", _cellFont, (int)colWidth);
//                                    maxH = Math.Max(maxH, size.Height);
//                                }
//                                _rowHeightsCache[i] = (int)Math.Ceiling(maxH) + 12;
//                            }
//                        }
//                        currentRowHeight = _rowHeightsCache.ContainsKey(i) ? _rowHeightsCache[i] : _rowHeight;
//                    }

//                    int y = rowArea.Y + (i * currentRowHeight) - _scrollOffset;

//                    if (AutoRowHeight && !_virtualMode)
//                    {
//                        y = rowArea.Y;
//                        for (int k = 0; k < i; k++)
//                        {
//                            y += _rowHeightsCache.ContainsKey(k) ? _rowHeightsCache[k] : _rowHeight;
//                        }
//                        y -= _scrollOffset;
//                    }

//                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, currentRowHeight);

//                    if (y + currentRowHeight < rowArea.Y || y > rowArea.Y + rowArea.Height) continue;

//                    DrawRowBackground(g, rowRect, i);
//                    DrawRowContent(g, rowRect, i, sf);
//                }
//            }
//        }

//        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex)
//        {
//            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
//            bool isSelected = (rowIndex == _selectedRowIndex);
//            var rowData = GetRowData(rowIndex);

//            Color customBg = Color.Empty;
//            Color customFg = Color.Empty;
//            if (rowData != null)
//            {
//                foreach (var rule in _formatRules)
//                {
//                    int colIdx = _headers.IndexOf(rule.ColumnName);
//                    if (colIdx >= 0 && rowData.Length > colIdx)
//                    {
//                        if (EvaluateRule(rule.Operator, rowData[colIdx], rule.Value))
//                        {
//                            customBg = rule.BackColor;
//                            customFg = rule.ForeColor;
//                        }
//                    }
//                }
//            }

//            // Universal separator line to ensure rows are always visible
//            using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1))
//            {
//                g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);
//            }

//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium:
//                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
//                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//                    {
//                        if (customBg != Color.Empty && customBg != Color.Transparent)
//                        {
//                            using (var ruleBrush = new SolidBrush(Color.FromArgb(150, customBg)))
//                                g.FillRectangle(ruleBrush, rowRect);
//                        }
//                        if (isSelected) g.FillRectangle(selBrush, rowRect);
//                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);
//                    }
//                    break;

//                case DesignStyle.MaterialFlat:
//                    Color matBg = customBg != Color.Empty && customBg != Color.Transparent ? customBg : Color.Transparent;
//                    if (isSelected && matBg == Color.Transparent) matBg = Color.FromArgb(255, GetAccentColor());
//                    else if (isHovered && matBg == Color.Transparent) matBg = Color.FromArgb(50, GetForegroundColor());
//                    if (matBg != Color.Transparent)
//                        using (var matBrush = new SolidBrush(matBg)) g.FillRectangle(matBrush, rowRect);
//                    break;
//            }
//        }

//        private bool EvaluateRule(string op, string cellVal, string targetVal)
//        {
//            if (string.IsNullOrEmpty(cellVal) || string.IsNullOrEmpty(targetVal)) return false;

//            if (double.TryParse(cellVal, out double c) && double.TryParse(targetVal, out double t))
//            {
//                switch (op)
//                {
//                    case ">": return c > t;
//                    case "<": return c < t;
//                    case "==": return c == t;
//                    case "!=": return c != t;
//                    case ">=": return c >= t;
//                    case "<=": return c <= t;
//                }
//            }
//            else
//            {
//                switch (op)
//                {
//                    case "==": return cellVal == targetVal;
//                    case "!=": return cellVal != targetVal;
//                }
//            }
//            return false;
//        }

//        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
//        {
//            int colX = rowRect.X;
//            var rowData = GetRowData(rowIndex);
//            if (rowData == null) return;

//            Color foreColor = GetForegroundColor();
//            var rule = _formatRules.FirstOrDefault(r =>
//            {
//                int colIdx = _headers.IndexOf(r.ColumnName);
//                return colIdx >= 0 && rowData.Length > colIdx && EvaluateRule(r.Operator, rowData[colIdx], r.Value);
//            });

//            if (rule != null && rule.ForeColor != Color.Empty && rule.ForeColor != Color.Transparent)
//                foreColor = rule.ForeColor;

//            using (SolidBrush textBrush = new SolidBrush(foreColor))
//            {
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    float safeColWidth = Math.Max(1, colWidth - 24);
//                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, safeColWidth, rowRect.Height);

//                    string val = rowData.Length > i ? rowData[i] : "";

//                    if (!string.IsNullOrEmpty(_searchQuery) && val.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)
//                    {
//                        string lowerVal = val.ToLower();
//                        string lowerQuery = _searchQuery.ToLower();
//                        int idx = lowerVal.IndexOf(lowerQuery);

//                        using (Font highlightFont = new Font(_cellFont, FontStyle.Bold))
//                        using (SolidBrush highlightBrush = new SolidBrush(GetAccentColor()))
//                        {
//                            string before = val.Substring(0, idx);
//                            string match = val.Substring(idx, _searchQuery.Length);
//                            string after = val.Substring(idx + _searchQuery.Length);

//                            g.DrawString(before, _cellFont, textBrush, cellRect, sf);
//                            SizeF beforeSize = g.MeasureString(before, _cellFont);
//                            RectangleF matchRect = new RectangleF(cellRect.X + beforeSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - beforeSize.Width), cellRect.Height);
//                            g.DrawString(match, highlightFont, highlightBrush, matchRect, sf);

//                            SizeF matchSize = g.MeasureString(match, highlightFont);
//                            RectangleF afterRect = new RectangleF(matchRect.X + matchSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - (beforeSize.Width + matchSize.Width)), cellRect.Height);
//                            g.DrawString(after, _cellFont, textBrush, afterRect, sf);
//                        }
//                    }
//                    else
//                    {
//                        g.DrawString(val, _cellFont, textBrush, cellRect, sf);
//                    }

//                    colX += (int)colWidth;
//                }
//            }
//        }

//        private void DrawFooterSummaries(Graphics g)
//        {
//            Rectangle footerRect = new Rectangle(_contentBounds.X, _contentBounds.Bottom + 4, _contentBounds.Width, _footerHeight);
//            int colX = footerRect.X;

//            using (var bgBrush = new SolidBrush(Color.FromArgb(_themeMode == ThemeMode.Light ? 240 : 30, GetBackgroundColor())))
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var textBrush = new SolidBrush(GetForegroundColor()))
//            using (var boldFont = new Font(_cellFont, FontStyle.Bold))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
//            {
//                g.FillPath(bgBrush, GetRoundedPath(footerRect, 4));
//                g.DrawLine(pen, footerRect.Left, footerRect.Top, footerRect.Right, footerRect.Top);

//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, footerRect.Y, Math.Max(1, colWidth - 24), footerRect.Height);

//                    var summary = _summaries.FirstOrDefault(s => s.ColumnName == _headers[i]);
//                    if (summary != null && summary.SummaryType != SummaryType.None)
//                    {
//                        string val = CalculateSummary(summary, i);
//                        g.DrawString(val, boldFont, textBrush, cellRect, sf);
//                    }
//                    colX += (int)colWidth;
//                }
//            }
//        }

//        private string CalculateSummary(ColumnSummary summary, int colIndex)
//        {
//            if (_virtualMode) return "N/A (Virtual)";

//            var values = _filteredRows.Select(r => r.Length > colIndex ? r[colIndex] : null).Where(v => v != null).ToList();
//            if (values.Count == 0) return "";

//            var nums = new List<double>();
//            foreach (var v in values) if (double.TryParse(v, out double d)) nums.Add(d);

//            if (summary.SummaryType == SummaryType.Count) return values.Count.ToString();

//            if (nums.Count > 0)
//            {
//                switch (summary.SummaryType)
//                {
//                    case SummaryType.Sum: return nums.Sum().ToString("N2");
//                    case SummaryType.Avg: return nums.Average().ToString("N2");
//                    case SummaryType.Min: return nums.Min().ToString("N2");
//                    case SummaryType.Max: return nums.Max().ToString("N2");
//                }
//            }
//            return "";
//        }

//        private void DrawOuterBorder(Graphics g)
//        {
//            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
//            {
//                switch (_controlStyle)
//                {
//                    case DesignStyle.DashboardPremium:
//                        using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1))
//                            g.DrawPath(borderPen, path);
//                        break;
//                    case DesignStyle.MaterialFlat: break;
//                    case DesignStyle.SoftNeumorphic:
//                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
//                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
//                        {
//                            g.DrawPath(lightPen, path);
//                            g.TranslateTransform(1, 1); g.DrawPath(darkPen, path); g.ResetTransform();
//                        }
//                        break;
//                    case DesignStyle.CyberpunkIndustrial:
//                        using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4))
//                        using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1))
//                        { g.DrawPath(glowPen, path); g.DrawPath(corePen, path); }
//                        break;
//                }
//            }
//        }

//        private void DrawScrollbar(Graphics g)
//        {
//            if (_scrollThumbBounds == Rectangle.Empty) return;
//            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
//            using (var thumbBrush = new SolidBrush(Color.FromArgb(180, GetAccentColor())))
//            {
//                g.FillPath(thumbBrush, thumbPath);
//            }
//        }
//        #endregion

//        #region Color Palette Engine
//        private Color GetBackgroundColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium: return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26);
//                case DesignStyle.FluentGlass: return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32);
//                case DesignStyle.MaterialFlat: return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18);
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48);
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(12, 12, 14);
//                default: return Color.White;
//            }
//        }
//        private SolidBrush GetBackgroundBrush() => new SolidBrush(GetBackgroundColor());
//        private Color GetForegroundColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(230, 240, 255);
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240);
//                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240);
//            }
//        }
//        private Color GetHeaderTextColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.CyberpunkIndustrial: return GetAccentColor();
//                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160);
//            }
//        }
//        private Color GetHeaderSeparatorColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
//        private Color GetAccentColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212);
//                case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255);
//                case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238);
//                case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51);
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204);
//                default: return Color.Blue;
//            }
//        }
//        private Color GetNeumorphicLightColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
//        private Color GetNeumorphicDarkColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
//        #endregion

//        #region Geometry Helpers
//        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
//        {
//            GraphicsPath path = new GraphicsPath();
//            if (rect.Width <= 0 || rect.Height <= 0) return path;
//            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
//            if (r <= 0) { path.AddRectangle(rect); return path; }
//            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
//            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
//            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
//            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
//            path.CloseFigure();
//            return path;
//        }
//        #endregion

//        #region Advanced Data Export Engine
//        public void ShowExportDialog()
//        {
//            using (var sfd = new SaveFileDialog())
//            {
//                sfd.Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json|XML (*.xml)|*.xml|Excel (*.xlsx)|*.xlsx|PDF (*.pdf)|*.pdf";
//                if (sfd.ShowDialog() == DialogResult.OK)
//                {
//                    DataFormat format = (DataFormat)sfd.FilterIndex - 1;
//                    ExportData(sfd.FileName, format);
//                }
//            }
//        }

//        public void ExportData(string filePath, DataFormat format)
//        {
//            try
//            {
//                if (format == DataFormat.CSV) ExportCSV(filePath);
//                else if (format == DataFormat.JSON) ExportJSON(filePath);
//                else if (format == DataFormat.XML) ExportXML(filePath);
//                else if (format == DataFormat.XLSX) ExportXLSX(filePath);
//                else if (format == DataFormat.PDF) ExportPDF(filePath);

//                MessageBox.Show("Export successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }

//        private void ExportCSV(string filePath)
//        {
//            var sb = new StringBuilder();
//            sb.AppendLine(string.Join(",", _headers));
//            foreach (var row in _filteredRows) sb.AppendLine(string.Join(",", row));
//            File.WriteAllText(filePath, sb.ToString());
//        }

//        private void ExportJSON(string filePath)
//        {
//            var sb = new StringBuilder();
//            sb.Append("{\"headers\":[");
//            sb.Append(string.Join(",", _headers.ConvertAll(h => $"\"{EscapeJson(h)}\"")));
//            sb.Append("],\"rows\":[");
//            for (int i = 0; i < _filteredRows.Count; i++)
//            {
//                sb.Append("[" + string.Join(",", Array.ConvertAll(_filteredRows[i], c => $"\"{EscapeJson(c)}\"")) + "]");
//                if (i < _filteredRows.Count - 1) sb.Append(",");
//            }
//            sb.Append("]}");
//            File.WriteAllText(filePath, sb.ToString());
//        }

//        private void ExportXML(string filePath)
//        {
//            var doc = new XDocument(new XElement("GridData"));
//            var headersEl = new XElement("Headers");
//            foreach (var h in _headers) headersEl.Add(new XElement("Header", h));
//            doc.Root.Add(headersEl);
//            var rowsEl = new XElement("Rows");
//            foreach (var row in _filteredRows)
//            {
//                var rowEl = new XElement("Row");
//                foreach (var cell in row) rowEl.Add(new XElement("Cell", cell));
//                rowsEl.Add(rowEl);
//            }
//            doc.Root.Add(rowsEl);
//            doc.Save(filePath);
//        }

//        private void ExportXLSX(string filePath)
//        {
//            using (var package = System.IO.Packaging.Package.Open(filePath, FileMode.Create))
//            {
//                var workbookPart = package.CreatePart(new Uri("/xl/workbook.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml");
//                var sheetPart = package.CreatePart(new Uri("/xl/worksheets/sheet1.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");
//                var sharedStringsPart = package.CreatePart(new Uri("/xl/sharedStrings.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml");

//                var sb = new StringBuilder();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\"").Append(_headers.Count + _filteredRows.Count * _headers.Count).Append("\">");
//                foreach (var h in _headers) sb.Append("<si><t>").Append(EscapeXml(h)).Append("</t></si>");
//                foreach (var row in _filteredRows) foreach (var c in row) sb.Append("<si><t>").Append(EscapeXml(c)).Append("</t></si>");
//                sb.Append("</sst>");
//                using (var stream = sharedStringsPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                sb.Clear();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
//                sb.Append("<sheetData>");

//                sb.Append("<row r=\"1\">");
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    string cellRef = GetExcelCellRef(i, 1);
//                    sb.Append("<c r=\"").Append(cellRef).Append("\" t=\"sharedString\"><v>").Append(i).Append("</v></c>");
//                }
//                sb.Append("</row>");

//                for (int r = 0; r < _filteredRows.Count; r++)
//                {
//                    sb.Append("<row r=\"").Append(r + 2).Append("\">");
//                    for (int c = 0; c < _filteredRows[r].Length; c++)
//                    {
//                        string cellRef = GetExcelCellRef(c, r + 2);
//                        int sharedIndex = _headers.Count + (r * _headers.Count) + c;
//                        sb.Append("<c r=\"").Append(cellRef).Append("\" t=\"sharedString\"><v>").Append(sharedIndex).Append("</v></c>");
//                    }
//                    sb.Append("</row>");
//                }

//                sb.Append("</sheetData></worksheet>");
//                using (var stream = sheetPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                sb.Clear();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
//                sb.Append("<sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"/></sheets>");
//                sb.Append("</workbook>");
//                using (var stream = workbookPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                package.CreateRelationship(new Uri("/xl/worksheets/sheet1.xml", UriKind.Relative), System.IO.Packaging.TargetMode.Internal, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet", "rId1");
//                package.CreateRelationship(new Uri("/xl/sharedStrings.xml", UriKind.Relative), System.IO.Packaging.TargetMode.Internal, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings", "rId2");
//            }
//        }

//        private string GetExcelCellRef(int col, int row)
//        {
//            int dividend = col + 1;
//            string colRef = "";
//            while (dividend > 0)
//            {
//                int modulo = (dividend - 1) % 26;
//                colRef = Convert.ToChar(65 + modulo) + colRef;
//                dividend = (dividend - modulo) / 26;
//            }
//            return colRef + row;
//        }

//        private void ExportPDF(string filePath)
//        {
//            using (var stream = new FileStream(filePath, FileMode.Create))
//            using (var writer = new StreamWriter(stream))
//            {
//                writer.Write("%PDF-1.4\n");
//                writer.Write("1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n");
//                writer.Write("2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n");
//                writer.Write("3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n");

//                var content = new StringBuilder();
//                content.Append("BT /F1 12 Tf 50 750 Td 14 TL\n");
//                content.Append(string.Join("    ", _headers) + " Tj T*\n");
//                foreach (var row in _filteredRows)
//                {
//                    content.Append(string.Join("    ", row) + " Tj T*\n");
//                }
//                content.Append("ET\n");

//                string contentStr = content.ToString();
//                writer.Write($"4 0 obj<</Length {contentStr.Length}>>stream\n{contentStr}endstream endobj\n");
//                writer.Write("5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n");

//                writer.Write("xref\n0 6\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000266 00000 n \n0000000356 00000 n \n");
//                writer.Write("trailer<</Size 6/Root 1 0 R>>\nstartxref\n406\n%%EOF");
//            }
//        }

//        private string EscapeXml(string val) => val.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
//        private string EscapeJson(string val) => val.Replace("\\", "\\\\").Replace("\"", "\\\"");

//        public void ShowImportDialog()
//        {
//            using (var ofd = new OpenFileDialog())
//            {
//                ofd.Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json|XML (*.xml)|*.xml";
//                if (ofd.ShowDialog() == DialogResult.OK)
//                {
//                    DataFormat format = (DataFormat)ofd.FilterIndex - 1;
//                    ImportData(ofd.FileName, format);
//                }
//            }
//        }

//        public void ImportData(string filePath, DataFormat format)
//        {
//            try
//            {
//                if (format == DataFormat.CSV)
//                {
//                    var lines = File.ReadAllLines(filePath);
//                    if (lines.Length == 0) return;
//                    Headers = new List<string>(lines[0].Split(','));
//                    var newRows = new List<string[]>();
//                    for (int i = 1; i < lines.Length; i++) if (!string.IsNullOrWhiteSpace(lines[i])) newRows.Add(lines[i].Split(','));
//                    Rows = newRows;
//                }
//                MessageBox.Show("Data imported successfully!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Import failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }
//        #endregion

//        #region Mouse & State Handling
//        protected override void OnMouseMove(MouseEventArgs e)
//        {
//            base.OnMouseMove(e);
//            if (_isScrolling) { UpdateScrollPosition(e.Y); return; }

//            int newHoveredRow = GetRowAtPosition(e.Location);
//            if (newHoveredRow != _hoveredRowIndex)
//            {
//                _hoveredRowIndex = newHoveredRow;
//                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
//                Invalidate();
//            }
//        }

//        protected override void OnMouseDown(MouseEventArgs e)
//        {
//            base.OnMouseDown(e);
//            Focus();

//            if (e.Button == MouseButtons.Right && EnableDataContextMenu)
//            {
//                if (IsOnHeader(e.Location)) OpenFilterMenu(e.Location);
//                else _contextMenu.Show(this, e.Location);
//                return;
//            }

//            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
//            {
//                _isScrolling = true; Cursor = Cursors.SizeNS; _currentState = ControlState.Pressed; Invalidate(); return;
//            }

//            int clickedRow = GetRowAtPosition(e.Location);
//            if (clickedRow != -1)
//            {
//                _selectedRowIndex = clickedRow; _currentState = ControlState.Pressed; Invalidate();
//            }
//        }

//        private bool IsOnHeader(Point p)
//        {
//            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight);
//            return headerRect.Contains(p);
//        }

//        private void OpenFilterMenu(Point p)
//        {
//            _filterMenu.Items.Clear();
//            if (_headers.Count == 0) return;
//            int colIndex = (p.X - _contentBounds.X) / (int)(_contentBounds.Width / _headers.Count);
//            if (colIndex < 0 || colIndex >= _headers.Count) return;

//            string colName = _headers[colIndex];
//            _filterMenu.Items.Add($"Filter by: {colName}").Enabled = false;
//            _filterMenu.Items.Add(new ToolStripSeparator());

//            var distinctValues = _rows.Select(r => r.Length > colIndex ? r[colIndex] : "").Distinct().ToList();
//            var checkedListBox = new CheckedListBox { CheckOnClick = true, Height = 150, Width = 200 };
//            foreach (var val in distinctValues)
//            {
//                bool isChecked = !_activeFilters.ContainsKey(colName) || _activeFilters[colName].Contains(val);
//                checkedListBox.Items.Add(val, isChecked);
//            }

//            checkedListBox.ItemCheck += (s, e) =>
//            {
//                this.BeginInvoke((MethodInvoker)delegate
//                {
//                    var selected = new List<string>();
//                    foreach (var item in checkedListBox.CheckedItems) selected.Add(item.ToString());
//                    if (selected.Count == distinctValues.Count) _activeFilters.Remove(colName);
//                    else _activeFilters[colName] = selected;
//                    ApplyFiltersAndSearch();
//                });
//            };

//            var host = new ToolStripControlHost(checkedListBox) { AutoSize = false, Size = checkedListBox.Size };
//            _filterMenu.Items.Add(host);
//            _filterMenu.Show(this, p);
//        }

//        protected override void OnMouseUp(MouseEventArgs e)
//        {
//            base.OnMouseUp(e);
//            _isScrolling = false; Cursor = Cursors.Default;
//            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
//            Invalidate();
//        }

//        protected override void OnMouseLeave(EventArgs e)
//        {
//            base.OnMouseLeave(e);
//            _hoveredRowIndex = -1; _currentState = ControlState.Normal; Cursor = Cursors.Default; Invalidate();
//        }

//        protected override void OnMouseWheel(MouseEventArgs e)
//        {
//            base.OnMouseWheel(e);
//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;
//            if (totalContentHeight > visibleHeight)
//            {
//                _scrollOffset -= e.Delta;
//                _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, totalContentHeight - visibleHeight));
//                Invalidate();
//            }
//        }

//        protected override void OnDragEnter(DragEventArgs e) { if (e.Data.GetDataPresent(DataFormats.Text)) e.Effect = DragDropEffects.Move; }
//        protected override void OnDragOver(DragEventArgs e) { if (e.Data.GetDataPresent(DataFormats.Text)) e.Effect = DragDropEffects.Move; }
//        protected override void OnGiveFeedback(GiveFeedbackEventArgs gb) { gb.UseDefaultCursors = false; }

//        protected override void OnQueryContinueDrag(QueryContinueDragEventArgs qcdevent)
//        {
//            base.OnQueryContinueDrag(qcdevent);
//            if (qcdevent.Action == DragAction.Drop || qcdevent.Action == DragAction.Cancel)
//            {
//                Invalidate();
//            }
//        }

//        protected override void OnDragDrop(DragEventArgs e)
//        {
//            string colName = (string)e.Data.GetData(DataFormats.Text);
//            if (!_groupedColumns.Contains(colName))
//            {
//                _groupedColumns.Add(colName);
//                Invalidate();
//            }
//        }

//        private int GetRowAtPosition(Point p)
//        {
//            if (!_contentBounds.Contains(p)) return -1;
//            int relativeY = p.Y - (_contentBounds.Y + _headerHeight + _bandHeight) + _scrollOffset;
//            if (relativeY < 0) return -1;
//            int rowIndex = relativeY / _rowHeight;
//            if (rowIndex >= 0 && rowIndex < GetTotalRowCount()) return rowIndex;
//            return -1;
//        }

//        private void UpdateScrollPosition(int mouseY)
//        {
//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;
//            int maxScroll = totalContentHeight - visibleHeight;
//            if (maxScroll <= 0) return;

//            int thumbHeight = _scrollThumbBounds.Height;
//            int trackHeight = _scrollTrackBounds.Height - thumbHeight;
//            int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2);
//            relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight));

//            float scrollRatio = (float)relativeMouseY / Math.Max(1, trackHeight);
//            _scrollOffset = (int)(scrollRatio * maxScroll);
//            Invalidate();
//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                _headerFont?.Dispose();
//                _cellFont?.Dispose();
//                _contextMenu?.Dispose();
//                _filterMenu?.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//        #endregion
//    }
//}









//==========================1.4============================================

//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Drawing.Drawing2D;
//using System.Drawing.Text;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;
//using System.Xml.Linq;

//namespace UltraModernUI.Controls
//{
//    public class ModernDataGridView : Control
//    {
//        #region Enums
//        public enum ThemeMode { Light, Dark }
//        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
//        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
//        public enum DataFormat { CSV, JSON, XML, XLSX, PDF }
//        public enum SummaryType { None, Sum, Avg, Count, Min, Max }
//        public enum EditorType { None, Text, DatePicker, ToggleSwitch, MultiSelectCombo, NumericSlider }
//        #endregion

//        #region Data Classes
//        public class Band
//        {
//            public string Name { get; set; }
//            public List<string> Columns { get; set; } = new List<string>();
//        }

//        public class FormatRule
//        {
//            public string ColumnName { get; set; }
//            public string Operator { get; set; }
//            public string Value { get; set; }
//            public Color BackColor { get; set; }
//            public Color ForeColor { get; set; }
//        }

//        public class ColumnSummary
//        {
//            public string ColumnName { get; set; }
//            public SummaryType SummaryType { get; set; }
//        }
//        #endregion

//        #region Fields & Properties
//        private ThemeMode _themeMode = ThemeMode.Light;
//        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
//        private ControlState _currentState = ControlState.Normal;

//        private List<string> _headers = new List<string>();
//        private List<string[]> _rows = new List<string[]>();
//        private List<string[]> _filteredRows = new List<string[]>();
//        private float[] _columnWeights;

//        private int _hoveredRowIndex = -1;
//        private int _selectedRowIndex = -1;
//        private int _scrollOffset = 0;
//        private int _rowHeight = 42;
//        private int _headerHeight = 48;
//        private int _bandHeight = 0;
//        private int _groupPanelHeight = 0;
//        private int _footerHeight = 0;

//        private Rectangle _contentBounds;
//        private Rectangle _scrollTrackBounds;
//        private Rectangle _scrollThumbBounds;
//        private bool _isScrolling = false;

//        private Font _headerFont;
//        private Font _cellFont;
//        private ContextMenuStrip _contextMenu;
//        private ContextMenuStrip _filterMenu;

//        private bool _virtualMode = false;
//        private int _virtualRowCount = 0;
//        private Dictionary<int, string[]> _virtualCache = new Dictionary<int, string[]>();
//        private HashSet<int> _pendingRequests = new HashSet<int>();

//        private string _searchQuery = "";
//        private List<string> _groupedColumns = new List<string>();
//        private List<Band> _bands = new List<Band>();
//        private List<FormatRule> _formatRules = new List<FormatRule>();
//        private List<ColumnSummary> _summaries = new List<ColumnSummary>();
//        private bool _autoRowHeight = false;
//        private Dictionary<int, int> _rowHeightsCache = new Dictionary<int, int>();
//        private Dictionary<string, List<string>> _activeFilters = new Dictionary<string, List<string>>();

//        private object _dataSource;

//        [Category("Data")]
//        [AttributeProvider(typeof(IListSource))]
//        [Description("Binds data to the grid. Supports DataTable and IList.")]
//        public object DataSource
//        {
//            get { return _dataSource; }
//            set
//            {
//                if (_dataSource != value)
//                {
//                    _dataSource = value;
//                    ProcessDataSource();
//                }
//            }
//        }

//        [Category("Appearance")]
//        [DefaultValue(ThemeMode.Light)]
//        public ThemeMode Theme { get { return _themeMode; } set { _themeMode = value; Invalidate(); } }

//        [Category("Appearance")]
//        [DefaultValue(DesignStyle.DashboardPremium)]
//        public DesignStyle Style { get { return _controlStyle; } set { _controlStyle = value; Invalidate(); } }

//        // HIDDEN FROM DESIGNER to prevent "Constructor on type 'System.String[]' not found." error
//        [Browsable(false)]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<string> Headers { get { return _headers; } set { _headers = value ?? new List<string>(); Invalidate(); } }

//        // HIDDEN FROM DESIGNER to prevent "Constructor on type 'System.String[]' not found." error
//        [Browsable(false)]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<string[]> Rows
//        {
//            get { return _rows; }
//            set { _rows = value ?? new List<string[]>(); _filteredRows = _rows; _selectedRowIndex = -1; _scrollOffset = 0; ApplyFiltersAndSearch(); }
//        }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool AutoRowHeight { get { return _autoRowHeight; } set { _autoRowHeight = value; _rowHeightsCache.Clear(); Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<Band> Bands { get { return _bands; } set { _bands = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<FormatRule> FormatRules { get { return _formatRules; } set { _formatRules = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<ColumnSummary> Summaries { get { return _summaries; } set { _summaries = value; Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool VirtualMode { get { return _virtualMode; } set { _virtualMode = value; _virtualCache.Clear(); Invalidate(); } }

//        [Category("Data")]
//        [DefaultValue(0)]
//        public int VirtualRowCount { get { return _virtualRowCount; } set { _virtualRowCount = value; Invalidate(); } }

//        [Category("Appearance")]
//        [DefaultValue(42)]
//        public int RowHeight { get { return _rowHeight; } set { _rowHeight = Math.Max(1, value); Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(true)]
//        public bool EnableDataContextMenu { get; set; } = true;

//        [Category("Data")]
//        public string SearchQuery { get { return _searchQuery; } set { _searchQuery = value; ApplyFiltersAndSearch(); } }

//        public event Func<int, string[]> RetrieveVirtualItem;

//        #endregion

//        #region Constructor & Initialization
//        public ModernDataGridView()
//        {
//            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);

//            UpdateFonts();
//            InitializeContextMenu();
//            InitializeFilterMenu();

//            BackColor = Color.Transparent;
//            Size = new Size(800, 500);
//            AllowDrop = true;
//        }

//        private void UpdateFonts()
//        {
//            _headerFont?.Dispose();
//            _cellFont?.Dispose();

//            string fontName = "Segoe UI Variable Display";
//            try
//            {
//                using (var testFont = new Font(fontName, 9f))
//                {
//                    if (testFont.Name != fontName) fontName = "Segoe UI";
//                }
//                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
//                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
//            }
//            catch
//            {
//                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
//                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
//            }
//        }

//        private void InitializeContextMenu()
//        {
//            _contextMenu = new ContextMenuStrip();
//            _contextMenu.Items.Add("Export Data", null, (s, e) => ShowExportDialog());
//            _contextMenu.Items.Add("Import Data", null, (s, e) => ShowImportDialog());
//            _contextMenu.Items.Add(new ToolStripSeparator());
//            _contextMenu.Items.Add("Clear Data", null, (s, e) => { Rows = new List<string[]>(); });
//            _contextMenu.Items.Add("Clear Groups", null, (s, e) => { _groupedColumns.Clear(); Invalidate(); });
//        }

//        private void InitializeFilterMenu()
//        {
//            _filterMenu = new ContextMenuStrip();
//        }

//        private bool IsDesignerHosted
//        {
//            get
//            {
//                Control ctrl = this;
//                while (ctrl != null)
//                {
//                    if (ctrl.Site != null && ctrl.Site.DesignMode)
//                        return true;
//                    ctrl = ctrl.Parent;
//                }
//                return false;
//            }
//        }
//        #endregion

//        #region Data Source Processing
//        private void ProcessDataSource()
//        {
//            if (_dataSource == null)
//            {
//                Headers = new List<string>();
//                Rows = new List<string[]>();
//                return;
//            }

//            if (_dataSource is DataTable table)
//            {
//                var newHeaders = new List<string>();
//                foreach (DataColumn col in table.Columns)
//                    newHeaders.Add(col.ColumnName);

//                var newRows = new List<string[]>();
//                foreach (DataRow row in table.Rows)
//                {
//                    var rowData = new string[table.Columns.Count];
//                    for (int i = 0; i < table.Columns.Count; i++)
//                        rowData[i] = row[i] == null || row[i] == DBNull.Value ? "" : row[i].ToString();
//                    newRows.Add(rowData);
//                }

//                Headers = newHeaders;
//                Rows = newRows;
//            }
//            else if (_dataSource is IEnumerable list)
//            {
//                var firstItem = null as object;
//                foreach (var item in list) { firstItem = item; break; }

//                if (firstItem != null)
//                {
//                    var props = firstItem.GetType().GetProperties();
//                    var newHeaders = props.Select(p => p.Name).ToList();
//                    var newRows = new List<string[]>();

//                    foreach (var item in list)
//                    {
//                        var rowData = new string[props.Length];
//                        for (int i = 0; i < props.Length; i++)
//                        {
//                            var val = props[i].GetValue(item);
//                            rowData[i] = val == null ? "" : val.ToString();
//                        }
//                        newRows.Add(rowData);
//                    }

//                    Headers = newHeaders;
//                    Rows = newRows;
//                }
//            }
//        }
//        #endregion

//        #region Filtering, Search & Virtual Data
//        private void ApplyFiltersAndSearch()
//        {
//            if (_virtualMode)
//            {
//                Invalidate();
//                return;
//            }

//            if (_rows == null) _rows = new List<string[]>();
//            var result = _rows;

//            if (!string.IsNullOrEmpty(_searchQuery))
//            {
//                result = result.Where(r => r != null && r.Any(c => c != null && c.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
//            }

//            if (_activeFilters != null && _activeFilters.Count > 0)
//            {
//                foreach (var filter in _activeFilters)
//                {
//                    int colIndex = _headers.IndexOf(filter.Key);
//                    if (colIndex >= 0)
//                    {
//                        result = result.Where(r => r != null && r.Length > colIndex && filter.Value.Contains(r[colIndex])).ToList();
//                    }
//                }
//            }

//            _filteredRows = result.ToList();
//            _scrollOffset = 0;
//            Invalidate();
//        }

//        private void EnsureVirtualRow(int rowIndex)
//        {
//            if (_virtualCache.ContainsKey(rowIndex) || _pendingRequests.Contains(rowIndex) || RetrieveVirtualItem == null)
//                return;

//            _pendingRequests.Add(rowIndex);
//            Task.Run(() =>
//            {
//                var data = RetrieveVirtualItem(rowIndex);
//                if (data != null)
//                {
//                    lock (_virtualCache)
//                    {
//                        _virtualCache[rowIndex] = data;
//                        if (_virtualCache.Count > 1000) _virtualCache.Clear();
//                    }
//                }
//                _pendingRequests.Remove(rowIndex);
//                this.BeginInvoke((MethodInvoker)delegate { Invalidate(); });
//            });
//        }

//        public string[] GetRowData(int rowIndex)
//        {
//            if (_virtualMode)
//            {
//                if (_virtualCache.TryGetValue(rowIndex, out var data)) return data;
//                EnsureVirtualRow(rowIndex);
//                return new string[_headers.Count];
//            }
//            return rowIndex >= 0 && rowIndex < _filteredRows.Count ? _filteredRows[rowIndex] : null;
//        }

//        public int GetTotalRowCount()
//        {
//            return _virtualMode ? _virtualRowCount : _filteredRows.Count;
//        }
//        #endregion

//        #region Memory Safe Layout Calculation
//        private void CalculateLayout()
//        {
//            _bandHeight = _bands.Count > 0 ? 30 : 0;
//            _groupPanelHeight = _groupedColumns.Count > 0 ? 40 : 0;
//            _footerHeight = _summaries.Count > 0 ? 36 : 0;
//            _headerHeight = 48;

//            int safeWidth = Math.Max(0, Width - 24);
//            int safeHeight = Math.Max(0, Height - 24 - _groupPanelHeight - _footerHeight);
//            _contentBounds = new Rectangle(12, 12 + _groupPanelHeight, safeWidth, safeHeight);

//            int headerCount = Math.Max(1, _headers.Count);
//            if (_columnWeights == null || _columnWeights.Length != _headers.Count)
//            {
//                _columnWeights = new float[headerCount];
//                for (int i = 0; i < headerCount; i++) _columnWeights[i] = 1f / headerCount;
//            }

//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;

//            if (totalContentHeight > visibleHeight && visibleHeight > 0)
//            {
//                int scrollWidth = 6;
//                _scrollTrackBounds = new Rectangle(
//                    _contentBounds.Right - scrollWidth - 2,
//                    _contentBounds.Y + _headerHeight + _bandHeight + 4,
//                    scrollWidth,
//                    Math.Max(0, visibleHeight - 8));

//                float scrollRatio = (float)visibleHeight / Math.Max(1, totalContentHeight);
//                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
//                int maxScroll = totalContentHeight - visibleHeight;
//                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / Math.Max(1, maxScroll)) * (_scrollTrackBounds.Height - thumbHeight));

//                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
//            }
//            else
//            {
//                _scrollTrackBounds = Rectangle.Empty;
//                _scrollThumbBounds = Rectangle.Empty;
//                _scrollOffset = 0;
//            }
//        }
//        #endregion

//        #region Core Paint Engine
//        protected override void OnPaint(PaintEventArgs e)
//        {
//            if (Width <= 0 || Height <= 0) return;

//            // Inject dummy data ONLY if showing in the Visual Studio Designer
//            if (IsDesignerHosted && _rows.Count == 0 && _headers.Count == 0)
//            {
//                _headers = new List<string> { "ID", "Status", "Metric", "Value" };
//                _rows = new List<string[]>
//                {
//                    new string[] { "001", "Active", "CPU Load", "2400" },
//                    new string[] { "002", "Idle", "Memory", "4200" },
//                    new string[] { "003", "Warning", "Network", "12500" },
//                    new string[] { "004", "Active", "Disk I/O", "8900" },
//                    new string[] { "005", "Active", "Temp", "5400" }
//                };
//                _filteredRows = _rows;
//            }

//            Graphics g = e.Graphics;
//            g.SmoothingMode = SmoothingMode.AntiAlias;
//            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
//            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
//            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

//            CalculateLayout();

//            using (SolidBrush bgBrush = GetBackgroundBrush())
//            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8))
//            {
//                g.FillPath(bgBrush, bgPath);
//            }

//            if (_contentBounds.Width > 0 && _contentBounds.Height > 0)
//            {
//                using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
//                {
//                    g.SetClip(contentClipPath);
//                    if (_groupedColumns.Count > 0) DrawGroupingPanel(g);
//                    if (_bands.Count > 0) DrawBands(g);
//                    DrawHeader(g);
//                    DrawRows(g);
//                    g.ResetClip();
//                }
//            }

//            if (_summaries.Count > 0) DrawFooterSummaries(g);

//            DrawOuterBorder(g);
//            DrawScrollbar(g);
//        }

//        private void DrawGroupingPanel(Graphics g)
//        {
//            Rectangle panelRect = new Rectangle(_contentBounds.X, _contentBounds.Y - _groupPanelHeight + 2, _contentBounds.Width, _groupPanelHeight - 4);
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var brush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
//            {
//                g.FillRectangle(brush, panelRect);
//                int x = panelRect.X + 10;
//                foreach (var col in _groupedColumns)
//                {
//                    var size = g.MeasureString(col, _cellFont);
//                    Rectangle tagRect = new Rectangle(x, panelRect.Y + 8, (int)size.Width + 20, 24);
//                    using (var tagPath = GetRoundedPath(tagRect, 4))
//                    using (var tagBrush = new SolidBrush(GetAccentColor()))
//                    using (var textBrush = new SolidBrush(Color.White))
//                    {
//                        g.FillPath(tagBrush, tagPath);
//                        g.DrawString(col, _cellFont, textBrush, new RectangleF(x + 10, panelRect.Y + 8, size.Width, 24), sf);
//                    }
//                    x += tagRect.Width + 8;
//                }
//                g.DrawLine(pen, panelRect.Left, panelRect.Bottom, panelRect.Right, panelRect.Bottom);
//            }
//        }

//        private void DrawBands(Graphics g)
//        {
//            int y = _contentBounds.Y;
//            int colX = _contentBounds.X;
//            using (var brush = new SolidBrush(GetHeaderTextColor()))
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Center })
//            {
//                foreach (var band in _bands)
//                {
//                    int spanCount = band.Columns.Count;
//                    if (spanCount == 0) continue;
//                    float width = 0;
//                    for (int i = 0; i < _headers.Count; i++)
//                    {
//                        if (band.Columns.Contains(_headers[i])) width += _contentBounds.Width * _columnWeights[i];
//                    }
//                    Rectangle bandRect = new Rectangle(colX, y, (int)width, _bandHeight);
//                    g.DrawString(band.Name, _headerFont, brush, bandRect, sf);
//                    g.DrawRectangle(pen, bandRect);
//                    colX += (int)width;
//                }
//            }
//        }

//        private void DrawHeader(Graphics g)
//        {
//            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight);
//            int colX = headerRect.X;

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
//            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (Font glyphFont = new Font("Segoe UI Symbol", 8f))
//            {
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, Math.Max(1, colWidth - 24), headerRect.Height);

//                    if (!string.IsNullOrEmpty(_headers[i]))
//                    {
//                        g.DrawString(_headers[i], _headerFont, textBrush, cellRect, sf);

//                        RectangleF glyphRect = new RectangleF(colX + colWidth - 24, headerRect.Y + (headerRect.Height - 8) / 2, 12, 12);
//                        g.DrawString("▾", glyphFont, textBrush, glyphRect);
//                    }
//                    colX += (int)colWidth;
//                }
//                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
//            }
//        }

//        private void DrawRows(Graphics g)
//        {
//            if (_rowHeight <= 0) return;
//            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight + _bandHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight - _bandHeight);
//            if (rowArea.Height <= 0) return;

//            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
//            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 2;
//            int totalRows = GetTotalRowCount();

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            {
//                for (int i = firstVisibleRow; i < Math.Min(totalRows, firstVisibleRow + visibleRowCount); i++)
//                {
//                    if (i < 0) continue;

//                    int currentRowHeight = _rowHeight;
//                    if (AutoRowHeight && !_virtualMode)
//                    {
//                        if (!_rowHeightsCache.ContainsKey(i))
//                        {
//                            var rowData = GetRowData(i);
//                            if (rowData != null)
//                            {
//                                float maxH = 0;
//                                for (int j = 0; j < _headers.Count; j++)
//                                {
//                                    float colWidth = _contentBounds.Width * _columnWeights[j] - 24;
//                                    if (colWidth <= 0) continue;
//                                    var size = g.MeasureString(rowData.Length > j ? rowData[j] : "", _cellFont, (int)colWidth);
//                                    maxH = Math.Max(maxH, size.Height);
//                                }
//                                _rowHeightsCache[i] = (int)Math.Ceiling(maxH) + 12;
//                            }
//                        }
//                        currentRowHeight = _rowHeightsCache.ContainsKey(i) ? _rowHeightsCache[i] : _rowHeight;
//                    }

//                    int y = rowArea.Y + (i * currentRowHeight) - _scrollOffset;

//                    if (AutoRowHeight && !_virtualMode)
//                    {
//                        y = rowArea.Y;
//                        for (int k = 0; k < i; k++)
//                        {
//                            y += _rowHeightsCache.ContainsKey(k) ? _rowHeightsCache[k] : _rowHeight;
//                        }
//                        y -= _scrollOffset;
//                    }

//                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, currentRowHeight);

//                    if (y + currentRowHeight < rowArea.Y || y > rowArea.Y + rowArea.Height) continue;

//                    DrawRowBackground(g, rowRect, i);
//                    DrawRowContent(g, rowRect, i, sf);
//                }
//            }
//        }

//        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex)
//        {
//            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
//            bool isSelected = (rowIndex == _selectedRowIndex);
//            var rowData = GetRowData(rowIndex);

//            Color customBg = Color.Empty;
//            Color customFg = Color.Empty;
//            if (rowData != null)
//            {
//                foreach (var rule in _formatRules)
//                {
//                    int colIdx = _headers.IndexOf(rule.ColumnName);
//                    if (colIdx >= 0 && rowData.Length > colIdx)
//                    {
//                        if (EvaluateRule(rule.Operator, rowData[colIdx], rule.Value))
//                        {
//                            customBg = rule.BackColor;
//                            customFg = rule.ForeColor;
//                        }
//                    }
//                }
//            }

//            // Universal separator line to ensure rows are always visible
//            using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1))
//            {
//                g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);
//            }

//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium:
//                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
//                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//                    {
//                        if (customBg != Color.Empty && customBg != Color.Transparent)
//                        {
//                            using (var ruleBrush = new SolidBrush(Color.FromArgb(150, customBg)))
//                                g.FillRectangle(ruleBrush, rowRect);
//                        }
//                        if (isSelected) g.FillRectangle(selBrush, rowRect);
//                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);
//                    }
//                    break;

//                case DesignStyle.MaterialFlat:
//                    Color matBg = customBg != Color.Empty && customBg != Color.Transparent ? customBg : Color.Transparent;
//                    if (isSelected && matBg == Color.Transparent) matBg = Color.FromArgb(255, GetAccentColor());
//                    else if (isHovered && matBg == Color.Transparent) matBg = Color.FromArgb(50, GetForegroundColor());
//                    if (matBg != Color.Transparent)
//                        using (var matBrush = new SolidBrush(matBg)) g.FillRectangle(matBrush, rowRect);
//                    break;
//            }
//        }

//        private bool EvaluateRule(string op, string cellVal, string targetVal)
//        {
//            if (string.IsNullOrEmpty(cellVal) || string.IsNullOrEmpty(targetVal)) return false;

//            if (double.TryParse(cellVal, out double c) && double.TryParse(targetVal, out double t))
//            {
//                switch (op)
//                {
//                    case ">": return c > t;
//                    case "<": return c < t;
//                    case "==": return c == t;
//                    case "!=": return c != t;
//                    case ">=": return c >= t;
//                    case "<=": return c <= t;
//                }
//            }
//            else
//            {
//                switch (op)
//                {
//                    case "==": return cellVal == targetVal;
//                    case "!=": return cellVal != targetVal;
//                }
//            }
//            return false;
//        }

//        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
//        {
//            int colX = rowRect.X;
//            var rowData = GetRowData(rowIndex);
//            if (rowData == null) return;

//            Color foreColor = GetForegroundColor();
//            var rule = _formatRules.FirstOrDefault(r =>
//            {
//                int colIdx = _headers.IndexOf(r.ColumnName);
//                return colIdx >= 0 && rowData.Length > colIdx && EvaluateRule(r.Operator, rowData[colIdx], r.Value);
//            });

//            if (rule != null && rule.ForeColor != Color.Empty && rule.ForeColor != Color.Transparent)
//                foreColor = rule.ForeColor;

//            using (SolidBrush textBrush = new SolidBrush(foreColor))
//            {
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    float safeColWidth = Math.Max(1, colWidth - 24);
//                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, safeColWidth, rowRect.Height);

//                    string val = rowData.Length > i ? rowData[i] : "";

//                    if (!string.IsNullOrEmpty(_searchQuery) && val.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)
//                    {
//                        string lowerVal = val.ToLower();
//                        string lowerQuery = _searchQuery.ToLower();
//                        int idx = lowerVal.IndexOf(lowerQuery);

//                        using (Font highlightFont = new Font(_cellFont, FontStyle.Bold))
//                        using (SolidBrush highlightBrush = new SolidBrush(GetAccentColor()))
//                        {
//                            string before = val.Substring(0, idx);
//                            string match = val.Substring(idx, _searchQuery.Length);
//                            string after = val.Substring(idx + _searchQuery.Length);

//                            g.DrawString(before, _cellFont, textBrush, cellRect, sf);
//                            SizeF beforeSize = g.MeasureString(before, _cellFont);
//                            RectangleF matchRect = new RectangleF(cellRect.X + beforeSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - beforeSize.Width), cellRect.Height);
//                            g.DrawString(match, highlightFont, highlightBrush, matchRect, sf);

//                            SizeF matchSize = g.MeasureString(match, highlightFont);
//                            RectangleF afterRect = new RectangleF(matchRect.X + matchSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - (beforeSize.Width + matchSize.Width)), cellRect.Height);
//                            g.DrawString(after, _cellFont, textBrush, afterRect, sf);
//                        }
//                    }
//                    else
//                    {
//                        g.DrawString(val, _cellFont, textBrush, cellRect, sf);
//                    }

//                    colX += (int)colWidth;
//                }
//            }
//        }

//        private void DrawFooterSummaries(Graphics g)
//        {
//            Rectangle footerRect = new Rectangle(_contentBounds.X, _contentBounds.Bottom + 4, _contentBounds.Width, _footerHeight);
//            int colX = footerRect.X;

//            using (var bgBrush = new SolidBrush(Color.FromArgb(_themeMode == ThemeMode.Light ? 240 : 30, GetBackgroundColor())))
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var textBrush = new SolidBrush(GetForegroundColor()))
//            using (var boldFont = new Font(_cellFont, FontStyle.Bold))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
//            {
//                g.FillPath(bgBrush, GetRoundedPath(footerRect, 4));
//                g.DrawLine(pen, footerRect.Left, footerRect.Top, footerRect.Right, footerRect.Top);

//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    float colWidth = _contentBounds.Width * _columnWeights[i];
//                    RectangleF cellRect = new RectangleF(colX + 12, footerRect.Y, Math.Max(1, colWidth - 24), footerRect.Height);

//                    var summary = _summaries.FirstOrDefault(s => s.ColumnName == _headers[i]);
//                    if (summary != null && summary.SummaryType != SummaryType.None)
//                    {
//                        string val = CalculateSummary(summary, i);
//                        g.DrawString(val, boldFont, textBrush, cellRect, sf);
//                    }
//                    colX += (int)colWidth;
//                }
//            }
//        }

//        private string CalculateSummary(ColumnSummary summary, int colIndex)
//        {
//            if (_virtualMode) return "N/A (Virtual)";

//            var values = _filteredRows.Select(r => r.Length > colIndex ? r[colIndex] : null).Where(v => v != null).ToList();
//            if (values.Count == 0) return "";

//            var nums = new List<double>();
//            foreach (var v in values) if (double.TryParse(v, out double d)) nums.Add(d);

//            if (summary.SummaryType == SummaryType.Count) return values.Count.ToString();

//            if (nums.Count > 0)
//            {
//                switch (summary.SummaryType)
//                {
//                    case SummaryType.Sum: return nums.Sum().ToString("N2");
//                    case SummaryType.Avg: return nums.Average().ToString("N2");
//                    case SummaryType.Min: return nums.Min().ToString("N2");
//                    case SummaryType.Max: return nums.Max().ToString("N2");
//                }
//            }
//            return "";
//        }

//        private void DrawOuterBorder(Graphics g)
//        {
//            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
//            {
//                switch (_controlStyle)
//                {
//                    case DesignStyle.DashboardPremium:
//                        using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1))
//                            g.DrawPath(borderPen, path);
//                        break;
//                    case DesignStyle.MaterialFlat: break;
//                    case DesignStyle.SoftNeumorphic:
//                        using (var lightPen = new Pen(GetNeumorphicLightColor(), 2))
//                        using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2))
//                        {
//                            g.DrawPath(lightPen, path);
//                            g.TranslateTransform(1, 1); g.DrawPath(darkPen, path); g.ResetTransform();
//                        }
//                        break;
//                    case DesignStyle.CyberpunkIndustrial:
//                        using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4))
//                        using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1))
//                        { g.DrawPath(glowPen, path); g.DrawPath(corePen, path); }
//                        break;
//                }
//            }
//        }

//        private void DrawScrollbar(Graphics g)
//        {
//            if (_scrollThumbBounds == Rectangle.Empty) return;
//            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
//            using (var thumbBrush = new SolidBrush(Color.FromArgb(180, GetAccentColor())))
//            {
//                g.FillPath(thumbBrush, thumbPath);
//            }
//        }
//        #endregion

//        #region Color Palette Engine
//        private Color GetBackgroundColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium: return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26);
//                case DesignStyle.FluentGlass: return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32);
//                case DesignStyle.MaterialFlat: return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18);
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48);
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(12, 12, 14);
//                default: return Color.White;
//            }
//        }
//        private SolidBrush GetBackgroundBrush() => new SolidBrush(GetBackgroundColor());
//        private Color GetForegroundColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(230, 240, 255);
//                case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240);
//                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240);
//            }
//        }
//        private Color GetHeaderTextColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.CyberpunkIndustrial: return GetAccentColor();
//                default: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160);
//            }
//        }
//        private Color GetHeaderSeparatorColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
//        private Color GetAccentColor()
//        {
//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212);
//                case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255);
//                case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238);
//                case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51);
//                case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204);
//                default: return Color.Blue;
//            }
//        }
//        private Color GetNeumorphicLightColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
//        private Color GetNeumorphicDarkColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
//        #endregion

//        #region Geometry Helpers
//        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
//        {
//            GraphicsPath path = new GraphicsPath();
//            if (rect.Width <= 0 || rect.Height <= 0) return path;
//            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
//            if (r <= 0) { path.AddRectangle(rect); return path; }
//            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
//            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
//            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
//            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
//            path.CloseFigure();
//            return path;
//        }
//        #endregion

//        #region Advanced Data Export Engine
//        public void ShowExportDialog()
//        {
//            using (var sfd = new SaveFileDialog())
//            {
//                sfd.Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json|XML (*.xml)|*.xml|Excel (*.xlsx)|*.xlsx|PDF (*.pdf)|*.pdf";
//                if (sfd.ShowDialog() == DialogResult.OK)
//                {
//                    DataFormat format = (DataFormat)sfd.FilterIndex - 1;
//                    ExportData(sfd.FileName, format);
//                }
//            }
//        }

//        public void ExportData(string filePath, DataFormat format)
//        {
//            try
//            {
//                if (format == DataFormat.CSV) ExportCSV(filePath);
//                else if (format == DataFormat.JSON) ExportJSON(filePath);
//                else if (format == DataFormat.XML) ExportXML(filePath);
//                else if (format == DataFormat.XLSX) ExportXLSX(filePath);
//                else if (format == DataFormat.PDF) ExportPDF(filePath);

//                MessageBox.Show("Export successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }

//        private void ExportCSV(string filePath)
//        {
//            var sb = new StringBuilder();
//            sb.AppendLine(string.Join(",", _headers));
//            foreach (var row in _filteredRows) sb.AppendLine(string.Join(",", row));
//            File.WriteAllText(filePath, sb.ToString());
//        }

//        private void ExportJSON(string filePath)
//        {
//            var sb = new StringBuilder();
//            sb.Append("{\"headers\":[");
//            sb.Append(string.Join(",", _headers.ConvertAll(h => $"\"{EscapeJson(h)}\"")));
//            sb.Append("],\"rows\":[");
//            for (int i = 0; i < _filteredRows.Count; i++)
//            {
//                sb.Append("[" + string.Join(",", Array.ConvertAll(_filteredRows[i], c => $"\"{EscapeJson(c)}\"")) + "]");
//                if (i < _filteredRows.Count - 1) sb.Append(",");
//            }
//            sb.Append("]}");
//            File.WriteAllText(filePath, sb.ToString());
//        }

//        private void ExportXML(string filePath)
//        {
//            var doc = new XDocument(new XElement("GridData"));
//            var headersEl = new XElement("Headers");
//            foreach (var h in _headers) headersEl.Add(new XElement("Header", h));
//            doc.Root.Add(headersEl);
//            var rowsEl = new XElement("Rows");
//            foreach (var row in _filteredRows)
//            {
//                var rowEl = new XElement("Row");
//                foreach (var cell in row) rowEl.Add(new XElement("Cell", cell));
//                rowsEl.Add(rowEl);
//            }
//            doc.Root.Add(rowsEl);
//            doc.Save(filePath);
//        }

//        private void ExportXLSX(string filePath)
//        {
//            using (var package = System.IO.Packaging.Package.Open(filePath, FileMode.Create))
//            {
//                var workbookPart = package.CreatePart(new Uri("/xl/workbook.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml");
//                var sheetPart = package.CreatePart(new Uri("/xl/worksheets/sheet1.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");
//                var sharedStringsPart = package.CreatePart(new Uri("/xl/sharedStrings.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml");

//                var sb = new StringBuilder();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\"").Append(_headers.Count + _filteredRows.Count * _headers.Count).Append("\">");
//                foreach (var h in _headers) sb.Append("<si><t>").Append(EscapeXml(h)).Append("</t></si>");
//                foreach (var row in _filteredRows) foreach (var c in row) sb.Append("<si><t>").Append(EscapeXml(c)).Append("</t></si>");
//                sb.Append("</sst>");
//                using (var stream = sharedStringsPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                sb.Clear();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
//                sb.Append("<sheetData>");

//                sb.Append("<row r=\"1\">");
//                for (int i = 0; i < _headers.Count; i++)
//                {
//                    string cellRef = GetExcelCellRef(i, 1);
//                    sb.Append("<c r=\"").Append(cellRef).Append("\" t=\"sharedString\"><v>").Append(i).Append("</v></c>");
//                }
//                sb.Append("</row>");

//                for (int r = 0; r < _filteredRows.Count; r++)
//                {
//                    sb.Append("<row r=\"").Append(r + 2).Append("\">");
//                    for (int c = 0; c < _filteredRows[r].Length; c++)
//                    {
//                        string cellRef = GetExcelCellRef(c, r + 2);
//                        int sharedIndex = _headers.Count + (r * _headers.Count) + c;
//                        sb.Append("<c r=\"").Append(cellRef).Append("\" t=\"sharedString\"><v>").Append(sharedIndex).Append("</v></c>");
//                    }
//                    sb.Append("</row>");
//                }

//                sb.Append("</sheetData></worksheet>");
//                using (var stream = sheetPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                sb.Clear();
//                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
//                sb.Append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
//                sb.Append("<sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"/></sheets>");
//                sb.Append("</workbook>");
//                using (var stream = workbookPart.GetStream()) using (var writer = new StreamWriter(stream)) writer.Write(sb.ToString());

//                package.CreateRelationship(new Uri("/xl/worksheets/sheet1.xml", UriKind.Relative), System.IO.Packaging.TargetMode.Internal, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet", "rId1");
//                package.CreateRelationship(new Uri("/xl/sharedStrings.xml", UriKind.Relative), System.IO.Packaging.TargetMode.Internal, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings", "rId2");
//            }
//        }

//        private string GetExcelCellRef(int col, int row)
//        {
//            int dividend = col + 1;
//            string colRef = "";
//            while (dividend > 0)
//            {
//                int modulo = (dividend - 1) % 26;
//                colRef = Convert.ToChar(65 + modulo) + colRef;
//                dividend = (dividend - modulo) / 26;
//            }
//            return colRef + row;
//        }

//        private void ExportPDF(string filePath)
//        {
//            using (var stream = new FileStream(filePath, FileMode.Create))
//            using (var writer = new StreamWriter(stream))
//            {
//                writer.Write("%PDF-1.4\n");
//                writer.Write("1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n");
//                writer.Write("2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n");
//                writer.Write("3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n");

//                var content = new StringBuilder();
//                content.Append("BT /F1 12 Tf 50 750 Td 14 TL\n");
//                content.Append(string.Join("    ", _headers) + " Tj T*\n");
//                foreach (var row in _filteredRows)
//                {
//                    content.Append(string.Join("    ", row) + " Tj T*\n");
//                }
//                content.Append("ET\n");

//                string contentStr = content.ToString();
//                writer.Write($"4 0 obj<</Length {contentStr.Length}>>stream\n{contentStr}endstream endobj\n");
//                writer.Write("5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n");

//                writer.Write("xref\n0 6\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000266 00000 n \n0000000356 00000 n \n");
//                writer.Write("trailer<</Size 6/Root 1 0 R>>\nstartxref\n406\n%%EOF");
//            }
//        }

//        private string EscapeXml(string val) => val.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
//        private string EscapeJson(string val) => val.Replace("\\", "\\\\").Replace("\"", "\\\"");

//        public void ShowImportDialog()
//        {
//            using (var ofd = new OpenFileDialog())
//            {
//                ofd.Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json|XML (*.xml)|*.xml";
//                if (ofd.ShowDialog() == DialogResult.OK)
//                {
//                    DataFormat format = (DataFormat)ofd.FilterIndex - 1;
//                    ImportData(ofd.FileName, format);
//                }
//            }
//        }

//        public void ImportData(string filePath, DataFormat format)
//        {
//            try
//            {
//                if (format == DataFormat.CSV)
//                {
//                    var lines = File.ReadAllLines(filePath);
//                    if (lines.Length == 0) return;
//                    Headers = new List<string>(lines[0].Split(','));
//                    var newRows = new List<string[]>();
//                    for (int i = 1; i < lines.Length; i++) if (!string.IsNullOrWhiteSpace(lines[i])) newRows.Add(lines[i].Split(','));
//                    Rows = newRows;
//                }
//                MessageBox.Show("Data imported successfully!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Import failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }
//        #endregion

//        #region Mouse & State Handling
//        protected override void OnMouseMove(MouseEventArgs e)
//        {
//            base.OnMouseMove(e);
//            if (_isScrolling) { UpdateScrollPosition(e.Y); return; }

//            int newHoveredRow = GetRowAtPosition(e.Location);
//            if (newHoveredRow != _hoveredRowIndex)
//            {
//                _hoveredRowIndex = newHoveredRow;
//                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
//                Invalidate();
//            }
//        }

//        protected override void OnMouseDown(MouseEventArgs e)
//        {
//            base.OnMouseDown(e);
//            Focus();

//            if (e.Button == MouseButtons.Right && EnableDataContextMenu)
//            {
//                if (IsOnHeader(e.Location)) OpenFilterMenu(e.Location);
//                else _contextMenu.Show(this, e.Location);
//                return;
//            }

//            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
//            {
//                _isScrolling = true; Cursor = Cursors.SizeNS; _currentState = ControlState.Pressed; Invalidate(); return;
//            }

//            int clickedRow = GetRowAtPosition(e.Location);
//            if (clickedRow != -1)
//            {
//                _selectedRowIndex = clickedRow; _currentState = ControlState.Pressed; Invalidate();
//            }
//        }

//        private bool IsOnHeader(Point p)
//        {
//            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight);
//            return headerRect.Contains(p);
//        }

//        private void OpenFilterMenu(Point p)
//        {
//            _filterMenu.Items.Clear();
//            if (_headers.Count == 0) return;
//            int colIndex = (p.X - _contentBounds.X) / (int)(_contentBounds.Width / _headers.Count);
//            if (colIndex < 0 || colIndex >= _headers.Count) return;

//            string colName = _headers[colIndex];
//            _filterMenu.Items.Add($"Filter by: {colName}").Enabled = false;
//            _filterMenu.Items.Add(new ToolStripSeparator());

//            var distinctValues = _rows.Select(r => r.Length > colIndex ? r[colIndex] : "").Distinct().ToList();
//            var checkedListBox = new CheckedListBox { CheckOnClick = true, Height = 150, Width = 200 };
//            foreach (var val in distinctValues)
//            {
//                bool isChecked = !_activeFilters.ContainsKey(colName) || _activeFilters[colName].Contains(val);
//                checkedListBox.Items.Add(val, isChecked);
//            }

//            checkedListBox.ItemCheck += (s, e) =>
//            {
//                this.BeginInvoke((MethodInvoker)delegate
//                {
//                    var selected = new List<string>();
//                    foreach (var item in checkedListBox.CheckedItems) selected.Add(item.ToString());
//                    if (selected.Count == distinctValues.Count) _activeFilters.Remove(colName);
//                    else _activeFilters[colName] = selected;
//                    ApplyFiltersAndSearch();
//                });
//            };

//            var host = new ToolStripControlHost(checkedListBox) { AutoSize = false, Size = checkedListBox.Size };
//            _filterMenu.Items.Add(host);
//            _filterMenu.Show(this, p);
//        }

//        protected override void OnMouseUp(MouseEventArgs e)
//        {
//            base.OnMouseUp(e);
//            _isScrolling = false; Cursor = Cursors.Default;
//            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
//            Invalidate();
//        }

//        protected override void OnMouseLeave(EventArgs e)
//        {
//            base.OnMouseLeave(e);
//            _hoveredRowIndex = -1; _currentState = ControlState.Normal; Cursor = Cursors.Default; Invalidate();
//        }

//        protected override void OnMouseWheel(MouseEventArgs e)
//        {
//            base.OnMouseWheel(e);
//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;
//            if (totalContentHeight > visibleHeight)
//            {
//                _scrollOffset -= e.Delta;
//                _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, totalContentHeight - visibleHeight));
//                Invalidate();
//            }
//        }

//        protected override void OnDragEnter(DragEventArgs e) { if (e.Data.GetDataPresent(DataFormats.Text)) e.Effect = DragDropEffects.Move; }
//        protected override void OnDragOver(DragEventArgs e) { if (e.Data.GetDataPresent(DataFormats.Text)) e.Effect = DragDropEffects.Move; }
//        protected override void OnGiveFeedback(GiveFeedbackEventArgs gb) { gb.UseDefaultCursors = false; }

//        protected override void OnQueryContinueDrag(QueryContinueDragEventArgs qcdevent)
//        {
//            base.OnQueryContinueDrag(qcdevent);
//            if (qcdevent.Action == DragAction.Drop || qcdevent.Action == DragAction.Cancel)
//            {
//                Invalidate();
//            }
//        }

//        protected override void OnDragDrop(DragEventArgs e)
//        {
//            string colName = (string)e.Data.GetData(DataFormats.Text);
//            if (!_groupedColumns.Contains(colName))
//            {
//                _groupedColumns.Add(colName);
//                Invalidate();
//            }
//        }

//        private int GetRowAtPosition(Point p)
//        {
//            if (!_contentBounds.Contains(p)) return -1;
//            int relativeY = p.Y - (_contentBounds.Y + _headerHeight + _bandHeight) + _scrollOffset;
//            if (relativeY < 0) return -1;
//            int rowIndex = relativeY / _rowHeight;
//            if (rowIndex >= 0 && rowIndex < GetTotalRowCount()) return rowIndex;
//            return -1;
//        }

//        private void UpdateScrollPosition(int mouseY)
//        {
//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;
//            int maxScroll = totalContentHeight - visibleHeight;
//            if (maxScroll <= 0) return;

//            int thumbHeight = _scrollThumbBounds.Height;
//            int trackHeight = _scrollTrackBounds.Height - thumbHeight;
//            int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2);
//            relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight));

//            float scrollRatio = (float)relativeMouseY / Math.Max(1, trackHeight);
//            _scrollOffset = (int)(scrollRatio * maxScroll);
//            Invalidate();
//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                _headerFont?.Dispose();
//                _cellFont?.Dispose();
//                _contextMenu?.Dispose();
//                _filterMenu?.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//        #endregion
//    }
//}






//=======================VER 1.5 ===============================


//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.ComponentModel.DataAnnotations;
//using System.Data;
//using System.Diagnostics;
//using System.Drawing;
//using System.Drawing.Drawing2D;
//using System.Drawing.Text;
//using System.IO;
//using System.Linq;
//using System.Reflection;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;
//using System.Xml.Linq;

//namespace UltraModernUI.Controls
//{
//    [ToolboxItem(true)]
//    public class ModernDataGridView : Control
//    {
//        #region Enums & Data Classes
//        public enum ThemeMode { Light, Dark }
//        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
//        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
//        public enum DataFormat { CSV, JSON, XML, PDF }
//        public enum SummaryType { None, Sum, Avg, Count, Min, Max }

//        public class Band { public string Name { get; set; } public List<string> Columns { get; set; } = new List<string>(); }
//        public class FormatRule { public string ColumnName { get; set; } public string Operator { get; set; } public string Value { get; set; } public Color BackColor { get; set; } public Color ForeColor { get; set; } }
//        public class ColumnSummary { public string ColumnName { get; set; } public SummaryType SummaryType { get; set; } }
//        public class ColumnInfo { public string Name { get; set; } public float Width { get; set; } public bool Visible { get; set; } = true; public string Format { get; set; } = "{0}"; }

//        private struct UndoState { public int Row; public int Col; public string OldValue; public string NewValue; }
//        #endregion

//        #region Fields & Properties
//        private ThemeMode _themeMode = ThemeMode.Light;
//        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
//        private ControlState _currentState = ControlState.Normal;

//        private List<ColumnInfo> _columns = new List<ColumnInfo>();
//        private List<string[]> _rows = new List<string[]>();
//        private List<string[]> _filteredRows = new List<string[]>();
//        private HashSet<int> _dirtyRows = new HashSet<int>();
//        private Stack<UndoState> _undoStack = new Stack<UndoState>();
//        private Stack<UndoState> _redoStack = new Stack<UndoState>();

//        private int _hoveredRowIndex = -1;
//        private int _hoveredColIndex = -1;
//        private int _selectedRowIndex = -1;
//        private int _scrollOffset = 0;
//        private int _rowHeight = 42;
//        private int _headerHeight = 48;
//        private int _bandHeight = 0;
//        private int _groupPanelHeight = 0;
//        private int _footerHeight = 0;

//        private Rectangle _contentBounds;
//        private Rectangle _scrollTrackBounds;
//        private Rectangle _scrollThumbBounds;
//        private bool _isScrolling = false;
//        private int _resizingColIndex = -1;
//        private float _initialColWidth = 0;

//        private Font _headerFont;
//        private Font _cellFont;
//        private ContextMenuStrip _headerMenu;
//        private ContextMenuStrip _cellMenu;
//        private System.Windows.Forms.Timer _kineticTimer;
//        private float _kineticVelocity = 0;

//        private bool _virtualMode = false;
//        private int _virtualRowCount = 0;
//        private Dictionary<int, string[]> _virtualCache = new Dictionary<int, string[]>();
//        private HashSet<int> _pendingRequests = new HashSet<int>();

//        private string _searchQuery = "";
//        private List<string> _groupedColumns = new List<string>();
//        private List<Band> _bands = new List<Band>();
//        private List<FormatRule> _formatRules = new List<FormatRule>();
//        private List<ColumnSummary> _summaries = new List<ColumnSummary>();
//        private Dictionary<int, int> _rowHeightsCache = new Dictionary<int, int>();
//        private Dictionary<string, List<string>> _activeFilters = new Dictionary<string, List<string>>();

//        private object _dataSource;
//        private bool _isLoading = false;
//        private bool _debugMode = false;
//        private bool _enableGhostRow = true;

//        [Category("Data")]
//        [AttributeProvider(typeof(IListSource))]
//        public object DataSource { get { return _dataSource; } set { _dataSource = value; ProcessDataSource(); } }

//        [Category("Appearance")]
//        [DefaultValue(ThemeMode.Light)]
//        public ThemeMode Theme { get { return _themeMode; } set { _themeMode = value; Invalidate(); } }

//        [Category("Appearance")]
//        [DefaultValue(DesignStyle.DashboardPremium)]
//        public DesignStyle Style { get { return _controlStyle; } set { _controlStyle = value; Invalidate(); } }

//        [Browsable(false)]
//        public List<string[]> Rows { get { return _rows; } set { _rows = value ?? new List<string[]>(); _filteredRows = _rows; _selectedRowIndex = -1; _scrollOffset = 0; ApplyFiltersAndSearch(); } }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool AutoRowHeight { get; set; } = false;

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<Band> Bands { get { return _bands; } set { _bands = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<FormatRule> FormatRules { get { return _formatRules; } set { _formatRules = value; Invalidate(); } }

//        [Category("Data")]
//        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public List<ColumnSummary> Summaries { get { return _summaries; } set { _summaries = value; Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool VirtualMode { get { return _virtualMode; } set { _virtualMode = value; _virtualCache.Clear(); Invalidate(); } }

//        [Category("Data")]
//        [DefaultValue(0)]
//        public int VirtualRowCount { get { return _virtualRowCount; } set { _virtualRowCount = value; Invalidate(); } }

//        [Category("Appearance")]
//        [DefaultValue(42)]
//        public int RowHeight { get { return _rowHeight; } set { _rowHeight = Math.Max(1, value); Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(true)]
//        public bool EnableDataContextMenu { get; set; } = true;

//        [Category("Behavior")]
//        [DefaultValue(true)]
//        public bool EnableGhostRow { get { return _enableGhostRow; } set { _enableGhostRow = value; Invalidate(); } }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool DebugMode { get { return _debugMode; } set { _debugMode = value; } }

//        [Category("Behavior")]
//        [DefaultValue(false)]
//        public bool IsLoading { get { return _isLoading; } set { _isLoading = value; Invalidate(); } }

//        [Category("Data")]
//        public string SearchQuery { get { return _searchQuery; } set { _searchQuery = value; ApplyFiltersAndSearch(); } }

//        public event Func<int, string[]> RetrieveVirtualItem;
//        #endregion

//        #region Constructor & Initialization
//        public ModernDataGridView()
//        {
//            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);

//            UpdateFonts();
//            InitializeContextMenus();
//            InitializeKineticScrolling();

//            BackColor = Color.Transparent;
//            Size = new Size(800, 500);
//            AllowDrop = true;
//        }

//        private void UpdateFonts()
//        {
//            _headerFont?.Dispose();
//            _cellFont?.Dispose();

//            string fontName = "Segoe UI Variable Display";
//            try
//            {
//                using (var testFont = new Font(fontName, 9f)) { if (testFont.Name != fontName) fontName = "Segoe UI"; }
//                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
//                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
//            }
//            catch
//            {
//                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
//                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
//            }
//        }

//        private void InitializeContextMenus()
//        {
//            _headerMenu = new ContextMenuStrip();
//            _headerMenu.Items.Add("Sort Ascending", null, (s, e) => SortColumn(true));
//            _headerMenu.Items.Add("Sort Descending", null, (s, e) => SortColumn(false));
//            _headerMenu.Items.Add(new ToolStripSeparator());
//            _headerMenu.Items.Add("Hide Column", null, (s, e) => { if (_hoveredColIndex >= 0 && _hoveredColIndex < _columns.Count) _columns[_hoveredColIndex].Visible = false; Invalidate(); });
//            _headerMenu.Items.Add("Group By This Column", null, (s, e) => { if (_hoveredColIndex >= 0 && _hoveredColIndex < _columns.Count && !_groupedColumns.Contains(_columns[_hoveredColIndex].Name)) _groupedColumns.Add(_columns[_hoveredColIndex].Name); Invalidate(); });

//            _cellMenu = new ContextMenuStrip();
//            _cellMenu.Items.Add("Copy", null, (s, e) => CopyToClipboard());
//            _cellMenu.Items.Add("Paste", null, (s, e) => PasteFromClipboard());
//            _cellMenu.Items.Add(new ToolStripSeparator());
//            _cellMenu.Items.Add("Undo", null, (s, e) => Undo());
//            _cellMenu.Items.Add("Redo", null, (s, e) => Redo());
//            _cellMenu.Items.Add(new ToolStripSeparator());
//            _cellMenu.Items.Add("Filter By Selection", null, (s, e) => FilterBySelection());
//        }

//        private void InitializeKineticScrolling()
//        {
//            _kineticTimer = new System.Windows.Forms.Timer();
//            _kineticTimer.Interval = 16; // ~60fps
//            _kineticTimer.Tick += (s, e) =>
//            {
//                if (Math.Abs(_kineticVelocity) < 0.1f) { _kineticTimer.Stop(); return; }
//                _scrollOffset -= (int)_kineticVelocity;
//                _kineticVelocity *= 0.92f; // Friction
//                ClampScroll();
//                Invalidate();
//            };
//        }

//        private bool IsDesignerHosted
//        {
//            get
//            {
//                Control ctrl = this;
//                while (ctrl != null) { if (ctrl.Site != null && ctrl.Site.DesignMode) return true; ctrl = ctrl.Parent; }
//                return false;
//            }
//        }
//        #endregion

//        #region Diagnostic & Logging
//        private void Log(string message)
//        {
//            if (_debugMode) Debug.WriteLine($"[ModernDataGridView] {message}");
//        }
//        #endregion

//        #region Thread-Safe Data Processing & Reflection
//        private void ProcessDataSource()
//        {
//            if (IsDisposed || IsDesignerHosted) return;
//            if (InvokeRequired) { BeginInvoke((System.Windows.Forms.MethodInvoker)ProcessDataSource); return; }

//            try
//            {
//                if (_dataSource == null) { _columns.Clear(); Rows = new List<string[]>(); return; }

//                if (_dataSource is DataTable table)
//                {
//                    _columns.Clear();
//                    foreach (DataColumn col in table.Columns)
//                        _columns.Add(new ColumnInfo { Name = col.ColumnName, Width = 150, Visible = true, Format = "{0}" });

//                    var newRows = new List<string[]>();
//                    foreach (DataRow row in table.Rows)
//                    {
//                        var rowData = new string[table.Columns.Count];
//                        for (int i = 0; i < table.Columns.Count; i++)
//                            rowData[i] = row[i] == null || row[i] == DBNull.Value ? "" : string.Format(_columns[i].Format, row[i]);
//                        newRows.Add(rowData);
//                    }
//                    Rows = newRows;
//                    Log($"Bound DataTable with {table.Columns.Count} columns and {table.Rows.Count} rows.");
//                }
//                else if (_dataSource is IEnumerable list)
//                {
//                    object firstItem = null;
//                    foreach (var item in list) { firstItem = item; break; }
//                    if (firstItem == null) return;

//                    var props = firstItem.GetType().GetProperties();
//                    _columns.Clear();
//                    var newRows = new List<string[]>();

//                    foreach (var prop in props)
//                    {
//                        var browsableAttr = prop.GetCustomAttribute<BrowsableAttribute>();
//                        if (browsableAttr != null && !browsableAttr.Browsable) continue;

//                        var displayAttr = prop.GetCustomAttribute<DisplayAttribute>();
//                        var dataTypeAttr = prop.GetCustomAttribute<DataTypeAttribute>();

//                        string name = (displayAttr != null && !string.IsNullOrEmpty(displayAttr.Name)) ? displayAttr.Name : prop.Name;
//                        string format = "{0}";

//                        if (prop.PropertyType == typeof(DateTime) || (dataTypeAttr != null && dataTypeAttr.DataType == DataType.Date))
//                            format = "{0:yyyy-MM-dd}";
//                        else if (prop.PropertyType == typeof(decimal) || prop.PropertyType == typeof(double) || prop.PropertyType == typeof(int))
//                            format = "{0:N2}";

//                        _columns.Add(new ColumnInfo { Name = name, Width = 150, Visible = true, Format = format });
//                    }

//                    foreach (var item in list)
//                    {
//                        var rowData = new string[_columns.Count];
//                        int colIdx = 0;
//                        foreach (var prop in props)
//                        {
//                            var browsableAttr = prop.GetCustomAttribute<BrowsableAttribute>();
//                            if (browsableAttr != null && !browsableAttr.Browsable) continue;

//                            var val = prop.GetValue(item);
//                            rowData[colIdx] = val == null ? "" : string.Format(_columns[colIdx].Format, val);
//                            colIdx++;
//                        }
//                        newRows.Add(rowData);
//                    }
//                    Rows = newRows;
//                    Log($"Bound IEnumerable with {_columns.Count} columns.");
//                }
//            }
//            catch (Exception ex) { Log($"Binding failed: {ex.Message}"); }
//        }
//        #endregion

//        #region Filtering, Search, Sort & Virtual Data
//        private void ApplyFiltersAndSearch()
//        {
//            if (InvokeRequired) { BeginInvoke((System.Windows.Forms.MethodInvoker)ApplyFiltersAndSearch); return; }
//            if (_virtualMode) { Invalidate(); return; }
//            if (_rows == null) _rows = new List<string[]>();
//            var result = _rows;

//            if (!string.IsNullOrEmpty(_searchQuery))
//                result = result.Where(r => r != null && r.Any(c => c != null && c.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();

//            if (_activeFilters != null && _activeFilters.Count > 0)
//                foreach (var filter in _activeFilters) { int colIndex = _columns.FindIndex(c => c.Name == filter.Key); if (colIndex >= 0) result = result.Where(r => r != null && r.Length > colIndex && filter.Value.Contains(r[colIndex])).ToList(); }

//            _filteredRows = result.ToList();
//            _scrollOffset = 0;
//            Invalidate();
//        }

//        private void SortColumn(bool ascending)
//        {
//            if (_hoveredColIndex < 0 || _hoveredColIndex >= _columns.Count) return;
//            int colIdx = _hoveredColIndex;
//            if (ascending) _filteredRows = _filteredRows.OrderBy(r => r.Length > colIdx ? r[colIdx] : "").ToList();
//            else _filteredRows = _filteredRows.OrderByDescending(r => r.Length > colIdx ? r[colIdx] : "").ToList();
//            Invalidate();
//        }

//        private void FilterBySelection()
//        {
//            if (_selectedRowIndex < 0 || _selectedRowIndex >= _filteredRows.Count) return;
//            if (_hoveredColIndex < 0 || _hoveredColIndex >= _columns.Count) return;

//            string cellVal = _filteredRows[_selectedRowIndex][_hoveredColIndex];
//            string colName = _columns[_hoveredColIndex].Name;
//            _activeFilters[colName] = new List<string> { cellVal };
//            ApplyFiltersAndSearch();
//        }

//        private void EnsureVirtualRow(int rowIndex)
//        {
//            if (_virtualCache.ContainsKey(rowIndex) || _pendingRequests.Contains(rowIndex) || RetrieveVirtualItem == null) return;
//            _pendingRequests.Add(rowIndex);
//            Task.Run(() =>
//            {
//                var data = RetrieveVirtualItem(rowIndex);
//                if (data != null) lock (_virtualCache) { _virtualCache[rowIndex] = data; if (_virtualCache.Count > 1000) _virtualCache.Clear(); }
//                _pendingRequests.Remove(rowIndex);
//                this.BeginInvoke((System.Windows.Forms.MethodInvoker)delegate { Invalidate(); });
//            });
//        }

//        public string[] GetRowData(int rowIndex)
//        {
//            if (_virtualMode) { if (_virtualCache.TryGetValue(rowIndex, out var data)) return data; EnsureVirtualRow(rowIndex); return new string[_columns.Count]; }
//            return rowIndex >= 0 && rowIndex < _filteredRows.Count ? _filteredRows[rowIndex] : null;
//        }

//        public int GetTotalRowCount() { return _virtualMode ? _virtualRowCount : _filteredRows.Count + (_enableGhostRow ? 1 : 0); }
//        #endregion

//        #region Memory Safe Layout Calculation
//        private void CalculateLayout()
//        {
//            _bandHeight = _bands.Count > 0 ? 30 : 0;
//            _groupPanelHeight = _groupedColumns.Count > 0 ? 40 : 0;
//            _footerHeight = _summaries.Count > 0 ? 36 : 0;
//            _headerHeight = 48;

//            int safeWidth = Math.Max(0, Width - 24);
//            int safeHeight = Math.Max(0, Height - 24 - _groupPanelHeight - _footerHeight);
//            _contentBounds = new Rectangle(12, 12 + _groupPanelHeight, safeWidth, safeHeight);

//            float totalColWidth = _columns.Where(c => c.Visible).Sum(c => c.Width);
//            if (totalColWidth < _contentBounds.Width && _columns.Count > 0)
//            {
//                float diff = _contentBounds.Width - totalColWidth;
//                foreach (var col in _columns) if (col.Visible) col.Width += diff / Math.Max(1, _columns.Count(c => c.Visible));
//            }

//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;

//            if (totalContentHeight > visibleHeight && visibleHeight > 0)
//            {
//                int scrollWidth = 6;
//                _scrollTrackBounds = new Rectangle(_contentBounds.Right - scrollWidth - 2, _contentBounds.Y + _headerHeight + _bandHeight + 4, scrollWidth, Math.Max(0, visibleHeight - 8));
//                float scrollRatio = (float)visibleHeight / Math.Max(1, totalContentHeight);
//                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
//                int maxScroll = totalContentHeight - visibleHeight;
//                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / Math.Max(1, maxScroll)) * (_scrollTrackBounds.Height - thumbHeight));
//                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
//            }
//            else { _scrollTrackBounds = Rectangle.Empty; _scrollThumbBounds = Rectangle.Empty; _scrollOffset = 0; }
//        }
//        #endregion

//        #region Core Paint Engine
//        protected override void OnPaint(PaintEventArgs e)
//        {
//            if (Width <= 0 || Height <= 0) return;
//            Stopwatch sw = Stopwatch.StartNew();

//            if (IsDesignerHosted && _columns.Count == 0 && _rows.Count == 0)
//            {
//                _columns = new List<ColumnInfo> { new ColumnInfo { Name = "ID", Width = 100 }, new ColumnInfo { Name = "Status", Width = 150 }, new ColumnInfo { Name = "Metric", Width = 200 }, new ColumnInfo { Name = "Value", Width = 150 } };
//                _rows = new List<string[]> { new string[] { "001", "Active", "CPU Load", "2400" }, new string[] { "002", "Idle", "Memory", "4200" } };
//                _filteredRows = _rows;
//            }

//            Graphics g = e.Graphics;
//            g.SmoothingMode = SmoothingMode.AntiAlias;
//            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
//            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
//            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

//            CalculateLayout();

//            using (SolidBrush bgBrush = GetBackgroundBrush())
//            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8)) g.FillPath(bgBrush, bgPath);

//            if (_contentBounds.Width > 0 && _contentBounds.Height > 0)
//            {
//                using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
//                {
//                    g.SetClip(contentClipPath);
//                    if (_groupedColumns.Count > 0) DrawGroupingPanel(g);
//                    if (_bands.Count > 0) DrawBands(g);
//                    DrawHeader(g);
//                    if (_isLoading) DrawSkeletonRows(g); else DrawRows(g);
//                    g.ResetClip();
//                }
//            }

//            if (_summaries.Count > 0) DrawFooterSummaries(g);
//            DrawOuterBorder(g);
//            DrawScrollbar(g);

//            sw.Stop();
//            if (_debugMode && sw.ElapsedMilliseconds > 15) Log($"Render Pass took {sw.ElapsedMilliseconds}ms.");
//        }

//        private void DrawGroupingPanel(Graphics g)
//        {
//            Rectangle panelRect = new Rectangle(_contentBounds.X, _contentBounds.Y - _groupPanelHeight + 2, _contentBounds.Width, _groupPanelHeight - 4);
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var brush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
//            {
//                g.FillRectangle(brush, panelRect);
//                int x = panelRect.X + 10;
//                foreach (var col in _groupedColumns)
//                {
//                    var size = g.MeasureString(col, _cellFont);
//                    Rectangle tagRect = new Rectangle(x, panelRect.Y + 8, (int)size.Width + 20, 24);
//                    using (var tagPath = GetRoundedPath(tagRect, 4))
//                    using (var tagBrush = new SolidBrush(GetAccentColor()))
//                    using (var textBrush = new SolidBrush(Color.White))
//                    {
//                        g.FillPath(tagBrush, tagPath);
//                        g.DrawString(col, _cellFont, textBrush, new RectangleF(x + 10, panelRect.Y + 8, size.Width, 24), sf);
//                    }
//                    x += tagRect.Width + 8;
//                }
//                g.DrawLine(pen, panelRect.Left, panelRect.Bottom, panelRect.Right, panelRect.Bottom);
//            }
//        }

//        private void DrawBands(Graphics g)
//        {
//            int y = _contentBounds.Y;
//            int colX = _contentBounds.X;
//            using (var brush = new SolidBrush(GetHeaderTextColor()))
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Center })
//            {
//                foreach (var band in _bands)
//                {
//                    int spanCount = band.Columns.Count;
//                    if (spanCount == 0) continue;
//                    float width = 0;
//                    for (int i = 0; i < _columns.Count; i++)
//                    {
//                        if (band.Columns.Contains(_columns[i].Name)) width += _contentBounds.Width * (_columns[i].Width / Math.Max(1, _columns.Sum(c => c.Width)));
//                    }
//                    Rectangle bandRect = new Rectangle(colX, y, (int)width, _bandHeight);
//                    g.DrawString(band.Name, _headerFont, brush, bandRect, sf);
//                    g.DrawRectangle(pen, bandRect);
//                    colX += (int)width;
//                }
//            }
//        }

//        private void DrawSkeletonRows(Graphics g)
//        {
//            int y = _contentBounds.Y + _headerHeight + _bandHeight;
//            int visibleCount = (_contentBounds.Height - _headerHeight - _bandHeight) / _rowHeight;
//            int pulse = (int)(Math.Sin(Environment.TickCount / 200.0) * 20 + 30);

//            for (int i = 0; i < visibleCount; i++)
//            {
//                Rectangle rowRect = new Rectangle(_contentBounds.X, y, _contentBounds.Width, _rowHeight);
//                using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1)) g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);

//                int colX = rowRect.X;
//                foreach (var col in _columns)
//                {
//                    if (!col.Visible) continue;
//                    Rectangle skelRect = new Rectangle(colX + 12, y + (_rowHeight / 2) - 8, (int)col.Width - 24, 16);
//                    using (var skelBrush = new SolidBrush(Color.FromArgb(pulse, GetForegroundColor()))) g.FillPath(skelBrush, GetRoundedPath(skelRect, 4));
//                    colX += (int)col.Width;
//                }
//                y += _rowHeight;
//            }
//        }

//        private void DrawHeader(Graphics g)
//        {
//            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight);
//            int colX = headerRect.X;

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
//            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
//            {
//                for (int i = 0; i < _columns.Count; i++)
//                {
//                    if (!_columns[i].Visible) continue;
//                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, Math.Max(1, _columns[i].Width - 24), headerRect.Height);
//                    g.DrawString(_columns[i].Name, _headerFont, textBrush, cellRect, sf);
//                    Rectangle resizeRect = new Rectangle(colX + (int)_columns[i].Width - 4, headerRect.Y, 8, headerRect.Height);
//                    if (_resizingColIndex == i) g.FillRectangle(new SolidBrush(GetAccentColor()), resizeRect);
//                    colX += (int)_columns[i].Width;
//                }
//                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
//            }
//        }

//        private void DrawRows(Graphics g)
//        {
//            if (_rowHeight <= 0) return;
//            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight + _bandHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight - _bandHeight);
//            if (rowArea.Height <= 0) return;

//            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
//            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 2;
//            int totalRows = GetTotalRowCount();

//            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
//            {
//                for (int i = firstVisibleRow; i < Math.Min(totalRows, firstVisibleRow + visibleRowCount); i++)
//                {
//                    if (i < 0) continue;
//                    int y = rowArea.Y + (i * _rowHeight) - _scrollOffset;
//                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, _rowHeight);

//                    if (y + _rowHeight < rowArea.Y || y > rowArea.Y + rowArea.Height) continue;

//                    bool isGhostRow = (_enableGhostRow && i == totalRows - 1);
//                    bool isDirty = _dirtyRows.Contains(i);

//                    DrawRowBackground(g, rowRect, i, isGhostRow, isDirty);
//                    if (!isGhostRow) DrawRowContent(g, rowRect, i, sf);
//                    else DrawGhostRowContent(g, rowRect, sf);
//                }
//            }
//        }

//        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex, bool isGhost, bool isDirty)
//        {
//            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
//            bool isSelected = (rowIndex == _selectedRowIndex);

//            if (isDirty)
//            {
//                using (var dirtyBrush = new SolidBrush(Color.FromArgb(40, 255, 160, 0))) g.FillRectangle(dirtyBrush, rowRect);
//            }

//            using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1)) g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);

//            switch (_controlStyle)
//            {
//                case DesignStyle.DashboardPremium:
//                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
//                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
//                    {
//                        if (isGhost) { using (var ghostBrush = new SolidBrush(Color.FromArgb(5, GetForegroundColor()))) g.FillRectangle(ghostBrush, rowRect); }
//                        else if (isSelected) g.FillRectangle(selBrush, rowRect);
//                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);
//                    }
//                    break;
//                case DesignStyle.MaterialFlat:
//                    Color matBg = Color.Transparent;
//                    if (isSelected) matBg = Color.FromArgb(255, GetAccentColor());
//                    else if (isHovered) matBg = Color.FromArgb(50, GetForegroundColor());
//                    if (matBg != Color.Transparent) using (var matBrush = new SolidBrush(matBg)) g.FillRectangle(matBrush, rowRect);
//                    break;
//            }
//        }

//        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
//        {
//            var rowData = GetRowData(rowIndex);
//            if (rowData == null) return;
//            int colX = rowRect.X;

//            Color foreColor = GetForegroundColor();
//            foreach (var rule in _formatRules)
//            {
//                int colIdx = _columns.FindIndex(c => c.Name == rule.ColumnName);
//                if (colIdx >= 0 && rowData.Length > colIdx && EvaluateRule(rule.Operator, rowData[colIdx], rule.Value))
//                {
//                    if (rule.BackColor != Color.Empty) { using (var bgBrush = new SolidBrush(Color.FromArgb(150, rule.BackColor))) g.FillRectangle(bgBrush, rowRect); }
//                    if (rule.ForeColor != Color.Empty) foreColor = rule.ForeColor;
//                }
//            }

//            using (SolidBrush textBrush = new SolidBrush(foreColor))
//            {
//                for (int i = 0; i < _columns.Count; i++)
//                {
//                    if (!_columns[i].Visible) continue;
//                    float safeColWidth = Math.Max(1, _columns[i].Width - 24);
//                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, safeColWidth, rowRect.Height);
//                    string val = rowData.Length > i ? rowData[i] : "";

//                    if (!string.IsNullOrEmpty(_searchQuery) && val.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)
//                    {
//                        string lowerVal = val.ToLower();
//                        string lowerQuery = _searchQuery.ToLower();
//                        int idx = lowerVal.IndexOf(lowerQuery);
//                        using (Font highlightFont = new Font(_cellFont, FontStyle.Bold))
//                        using (SolidBrush highlightBrush = new SolidBrush(GetAccentColor()))
//                        {
//                            string before = val.Substring(0, idx);
//                            string match = val.Substring(idx, _searchQuery.Length);
//                            string after = val.Substring(idx + _searchQuery.Length);
//                            g.DrawString(before, _cellFont, textBrush, cellRect, sf);
//                            SizeF beforeSize = g.MeasureString(before, _cellFont);
//                            RectangleF matchRect = new RectangleF(cellRect.X + beforeSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - beforeSize.Width), cellRect.Height);
//                            g.DrawString(match, highlightFont, highlightBrush, matchRect, sf);
//                            SizeF matchSize = g.MeasureString(match, highlightFont);
//                            RectangleF afterRect = new RectangleF(matchRect.X + matchSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - (beforeSize.Width + matchSize.Width)), cellRect.Height);
//                            g.DrawString(after, _cellFont, textBrush, afterRect, sf);
//                        }
//                    }
//                    else g.DrawString(val, _cellFont, textBrush, cellRect, sf);
//                    colX += (int)_columns[i].Width;
//                }
//            }
//        }

//        private void DrawGhostRowContent(Graphics g, Rectangle rowRect, StringFormat sf)
//        {
//            int colX = rowRect.X;
//            using (SolidBrush textBrush = new SolidBrush(Color.FromArgb(100, GetForegroundColor())))
//            using (Font italicFont = new Font(_cellFont, FontStyle.Italic))
//            {
//                for (int i = 0; i < _columns.Count; i++)
//                {
//                    if (!_columns[i].Visible) continue;
//                    float safeColWidth = Math.Max(1, _columns[i].Width - 24);
//                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, safeColWidth, rowRect.Height);
//                    g.DrawString("Enter " + _columns[i].Name + "...", italicFont, textBrush, cellRect, sf);
//                    colX += (int)_columns[i].Width;
//                }
//            }
//        }

//        private bool EvaluateRule(string op, string cellVal, string targetVal)
//        {
//            if (string.IsNullOrEmpty(cellVal) || string.IsNullOrEmpty(targetVal)) return false;
//            if (double.TryParse(cellVal, out double c) && double.TryParse(targetVal, out double t))
//            {
//                switch (op) { case ">": return c > t; case "<": return c < t; case "==": return c == t; case "!=": return c != t; case ">=": return c >= t; case "<=": return c <= t; }
//            }
//            else { switch (op) { case "==": return cellVal == targetVal; case "!=": return cellVal != targetVal; } }
//            return false;
//        }

//        private void DrawFooterSummaries(Graphics g)
//        {
//            Rectangle footerRect = new Rectangle(_contentBounds.X, _contentBounds.Bottom + 4, _contentBounds.Width, _footerHeight);
//            int colX = footerRect.X;
//            using (var bgBrush = new SolidBrush(Color.FromArgb(_themeMode == ThemeMode.Light ? 240 : 30, GetBackgroundColor())))
//            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
//            using (var textBrush = new SolidBrush(GetForegroundColor()))
//            using (var boldFont = new Font(_cellFont, FontStyle.Bold))
//            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
//            {
//                g.FillPath(bgBrush, GetRoundedPath(footerRect, 4));
//                g.DrawLine(pen, footerRect.Left, footerRect.Top, footerRect.Right, footerRect.Top);
//                for (int i = 0; i < _columns.Count; i++)
//                {
//                    if (!_columns[i].Visible) continue;
//                    RectangleF cellRect = new RectangleF(colX + 12, footerRect.Y, Math.Max(1, _columns[i].Width - 24), footerRect.Height);
//                    var summary = _summaries.FirstOrDefault(s => s.ColumnName == _columns[i].Name);
//                    if (summary != null && summary.SummaryType != SummaryType.None)
//                    {
//                        string val = CalculateSummary(summary, i);
//                        g.DrawString(val, boldFont, textBrush, cellRect, sf);
//                    }
//                    colX += (int)_columns[i].Width;
//                }
//            }
//        }

//        private string CalculateSummary(ColumnSummary summary, int colIndex)
//        {
//            if (_virtualMode) return "N/A";
//            var values = _filteredRows.Select(r => r.Length > colIndex ? r[colIndex] : null).Where(v => v != null).ToList();
//            if (values.Count == 0) return "";
//            var nums = new List<double>(); foreach (var v in values) if (double.TryParse(v, out double d)) nums.Add(d);
//            if (summary.SummaryType == SummaryType.Count) return values.Count.ToString();
//            if (nums.Count > 0) { switch (summary.SummaryType) { case SummaryType.Sum: return nums.Sum().ToString("N2"); case SummaryType.Avg: return nums.Average().ToString("N2"); case SummaryType.Min: return nums.Min().ToString("N2"); case SummaryType.Max: return nums.Max().ToString("N2"); } }
//            return "";
//        }

//        private void DrawOuterBorder(Graphics g)
//        {
//            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
//            {
//                switch (_controlStyle)
//                {
//                    case DesignStyle.DashboardPremium: using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1)) g.DrawPath(borderPen, path); break;
//                    case DesignStyle.MaterialFlat: break;
//                    case DesignStyle.SoftNeumorphic: using (var lightPen = new Pen(GetNeumorphicLightColor(), 2)) using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2)) { g.DrawPath(lightPen, path); g.TranslateTransform(1, 1); g.DrawPath(darkPen, path); g.ResetTransform(); } break;
//                    case DesignStyle.CyberpunkIndustrial: using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4)) using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1)) { g.DrawPath(glowPen, path); g.DrawPath(corePen, path); } break;
//                }
//            }
//        }

//        private void DrawScrollbar(Graphics g)
//        {
//            if (_scrollThumbBounds == Rectangle.Empty) return;
//            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
//            using (var thumbBrush = new SolidBrush(Color.FromArgb(180, GetAccentColor()))) g.FillPath(thumbBrush, thumbPath);
//        }
//        #endregion

//        #region Color Palette Engine
//        private Color GetBackgroundColor() { switch (_controlStyle) { case DesignStyle.DashboardPremium: return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26); case DesignStyle.FluentGlass: return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32); case DesignStyle.MaterialFlat: return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18); case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48); case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(12, 12, 14); default: return Color.White; } }
//        private SolidBrush GetBackgroundBrush() => new SolidBrush(GetBackgroundColor());
//        private Color GetForegroundColor() { switch (_controlStyle) { case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(230, 240, 255); case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240); default: return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240); } }
//        private Color GetHeaderTextColor() { switch (_controlStyle) { case DesignStyle.CyberpunkIndustrial: return GetAccentColor(); default: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160); } }
//        private Color GetHeaderSeparatorColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
//        private Color GetAccentColor() { switch (_controlStyle) { case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212); case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255); case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238); case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51); case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204); default: return Color.Blue; } }
//        private Color GetNeumorphicLightColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
//        private Color GetNeumorphicDarkColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
//        #endregion

//        #region Geometry Helpers
//        private GraphicsPath GetRoundedPath(Rectangle rect, int radius) { GraphicsPath path = new GraphicsPath(); if (rect.Width <= 0 || rect.Height <= 0) return path; int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2)); if (r <= 0) { path.AddRectangle(rect); return path; } path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90); path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90); path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90); path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90); path.CloseFigure(); return path; }
//        #endregion

//        #region Advanced Data Export Engine
//        public void ShowExportDialog() { using (var sfd = new SaveFileDialog()) { sfd.Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json|XML (*.xml)|*.xml|PDF (*.pdf)|*.pdf"; if (sfd.ShowDialog() == DialogResult.OK) { DataFormat format; switch (sfd.FilterIndex) { case 2: format = DataFormat.JSON; break; case 3: format = DataFormat.XML; break; case 4: format = DataFormat.PDF; break; default: format = DataFormat.CSV; break; } ExportData(sfd.FileName, format); } } }
//        public void ExportData(string filePath, DataFormat format) { try { if (format == DataFormat.CSV) ExportCSV(filePath); else if (format == DataFormat.JSON) ExportJSON(filePath); else if (format == DataFormat.XML) ExportXML(filePath); else if (format == DataFormat.PDF) ExportPDF(filePath); MessageBox.Show("Export successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); } catch (Exception ex) { MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); } }
//        private void ExportCSV(string filePath) { var sb = new StringBuilder(); sb.AppendLine(string.Join(",", _columns.Select(c => c.Name))); foreach (var row in _filteredRows) sb.AppendLine(string.Join(",", row)); File.WriteAllText(filePath, sb.ToString()); }
//        private void ExportJSON(string filePath) { var sb = new StringBuilder(); sb.Append("{\"headers\":["); sb.Append(string.Join(",", _columns.Select(c => $"\"{c.Name}\""))); sb.Append("],\"rows\":["); for (int i = 0; i < _filteredRows.Count; i++) { sb.Append("[" + string.Join(",", _filteredRows[i].Select(c => $"\"{c.Replace("\\", "\\\\").Replace("\"", "\\\"")}\"")) + "]"); if (i < _filteredRows.Count - 1) sb.Append(","); } sb.Append("]}"); File.WriteAllText(filePath, sb.ToString()); }
//        private void ExportXML(string filePath) { var doc = new XDocument(new XElement("GridData")); var headersEl = new XElement("Headers"); foreach (var c in _columns) headersEl.Add(new XElement("Header", c.Name)); doc.Root.Add(headersEl); var rowsEl = new XElement("Rows"); foreach (var row in _filteredRows) { var rowEl = new XElement("Row"); foreach (var cell in row) rowEl.Add(new XElement("Cell", cell)); rowsEl.Add(rowEl); } doc.Root.Add(rowsEl); doc.Save(filePath); }
//        private void ExportPDF(string filePath) { using (var stream = new FileStream(filePath, FileMode.Create)) using (var writer = new StreamWriter(stream)) { writer.Write("%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n"); var content = new StringBuilder(); content.Append("BT /F1 12 Tf 50 750 Td 14 TL\n"); content.Append(string.Join("    ", _columns.Select(c => c.Name)) + " Tj T*\n"); foreach (var row in _filteredRows) content.Append(string.Join("    ", row) + " Tj T*\n"); content.Append("ET\n"); string contentStr = content.ToString(); writer.Write($"4 0 obj<</Length {contentStr.Length}>>stream\n{contentStr}endstream endobj\n5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\nxref\n0 6\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000266 00000 n \n0000000356 00000 n \ntrailer<</Size 6/Root 1 0 R>>\nstartxref\n406\n%%EOF"); } }
//        #endregion

//        #region Clipboard, Undo/Redo & Keyboard
//        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
//        {
//            if (keyData == (Keys.Control | Keys.C)) { CopyToClipboard(); return true; }
//            if (keyData == (Keys.Control | Keys.V)) { PasteFromClipboard(); return true; }
//            if (keyData == (Keys.Control | Keys.Z)) { Undo(); return true; }
//            if (keyData == (Keys.Control | Keys.Y)) { Redo(); return true; }
//            return base.ProcessCmdKey(ref msg, keyData);
//        }

//        private void CopyToClipboard()
//        {
//            if (_selectedRowIndex < 0 || _selectedRowIndex >= _filteredRows.Count) return;
//            var row = _filteredRows[_selectedRowIndex];
//            string data = string.Join("\t", row);
//            try { Clipboard.SetText(data); Log("Copied row to clipboard."); } catch { }
//        }

//        private void PasteFromClipboard()
//        {
//            if (_selectedRowIndex < 0 || !Clipboard.ContainsText()) return;
//            string[] lines = Clipboard.GetText().Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
//            for (int i = 0; i < lines.Length; i++)
//            {
//                int targetRow = _selectedRowIndex + i;
//                if (targetRow >= _filteredRows.Count) break;
//                string[] cells = lines[i].Split('\t');
//                for (int c = 0; c < cells.Length && c < _columns.Count; c++)
//                {
//                    string oldVal = _filteredRows[targetRow].Length > c ? _filteredRows[targetRow][c] : "";
//                    string newVal = cells[c];
//                    _filteredRows[targetRow][c] = newVal;
//                    _undoStack.Push(new UndoState { Row = targetRow, Col = c, OldValue = oldVal, NewValue = newVal });
//                    _redoStack.Clear();
//                    _dirtyRows.Add(targetRow);
//                }
//            }
//            Invalidate();
//            Log($"Pasted {lines.Length} rows.");
//        }

//        public void Undo()
//        {
//            if (_undoStack.Count == 0) return;
//            var state = _undoStack.Pop();
//            if (_filteredRows.Count > state.Row && _filteredRows[state.Row].Length > state.Col)
//            {
//                _filteredRows[state.Row][state.Col] = state.OldValue;
//                _redoStack.Push(state);
//                _dirtyRows.Add(state.Row);
//                Invalidate();
//                Log("Undo executed.");
//            }
//        }

//        public void Redo()
//        {
//            if (_redoStack.Count == 0) return;
//            var state = _redoStack.Pop();
//            if (_filteredRows.Count > state.Row && _filteredRows[state.Row].Length > state.Col)
//            {
//                _filteredRows[state.Row][state.Col] = state.NewValue;
//                _undoStack.Push(state);
//                _dirtyRows.Add(state.Row);
//                Invalidate();
//                Log("Redo executed.");
//            }
//        }
//        #endregion

//        #region Mouse, Kinetic Scroll & State Handling
//        protected override void OnMouseMove(MouseEventArgs e)
//        {
//            base.OnMouseMove(e);
//            if (_isScrolling) { UpdateScrollPosition(e.Y); return; }

//            if (_resizingColIndex >= 0 && e.Button == MouseButtons.Left)
//            {
//                float diff = e.X - (_contentBounds.X + _columns.Take(_resizingColIndex).Sum(c => c.Visible ? c.Width : 0)) - _initialColWidth;
//                _columns[_resizingColIndex].Width = Math.Max(20, _initialColWidth + diff);
//                Invalidate();
//                return;
//            }

//            int resizeIdx = GetResizeIndex(e.Location);
//            Cursor = resizeIdx >= 0 ? Cursors.SizeWE : Cursors.Default;

//            int newHoveredRow = GetRowAtPosition(e.Location);
//            int newHoveredCol = GetColIndexAtPosition(e.Location);
//            if (newHoveredRow != _hoveredRowIndex || newHoveredCol != _hoveredColIndex)
//            {
//                _hoveredRowIndex = newHoveredRow;
//                _hoveredColIndex = newHoveredCol;
//                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
//                Invalidate();
//            }
//        }

//        private int GetResizeIndex(Point p)
//        {
//            if (p.Y < _contentBounds.Y + _headerHeight + _bandHeight && p.Y > _contentBounds.Y + _bandHeight)
//            {
//                int colX = _contentBounds.X;
//                for (int i = 0; i < _columns.Count; i++)
//                {
//                    if (!_columns[i].Visible) continue;
//                    if (p.X >= colX + _columns[i].Width - 5 && p.X <= colX + _columns[i].Width + 5) return i;
//                    colX += (int)_columns[i].Width;
//                }
//            }
//            return -1;
//        }

//        protected override void OnMouseDown(MouseEventArgs e)
//        {
//            base.OnMouseDown(e);
//            Focus();

//            int resizeIdx = GetResizeIndex(e.Location);
//            if (resizeIdx >= 0)
//            {
//                _resizingColIndex = resizeIdx;
//                _initialColWidth = _columns[resizeIdx].Width;
//                return;
//            }

//            if (e.Button == MouseButtons.Right && EnableDataContextMenu)
//            {
//                if (IsOnHeader(e.Location)) { _hoveredColIndex = GetColIndexAtPosition(e.Location); _headerMenu.Show(this, e.Location); }
//                else { _selectedRowIndex = GetRowAtPosition(e.Location); _hoveredColIndex = GetColIndexAtPosition(e.Location); _cellMenu.Show(this, e.Location); }
//                return;
//            }

//            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
//            {
//                _isScrolling = true; Cursor = Cursors.SizeNS; _currentState = ControlState.Pressed; Invalidate(); return;
//            }

//            int clickedRow = GetRowAtPosition(e.Location);
//            if (clickedRow != -1)
//            {
//                if (_enableGhostRow && clickedRow == GetTotalRowCount() - 1)
//                {
//                    _filteredRows.Add(new string[_columns.Count]);
//                    _rows.Add(new string[_columns.Count]);
//                    _selectedRowIndex = clickedRow;
//                }
//                else _selectedRowIndex = clickedRow;
//                _currentState = ControlState.Pressed; Invalidate();
//            }
//        }

//        protected override void OnMouseUp(MouseEventArgs e)
//        {
//            base.OnMouseUp(e);
//            _isScrolling = false; _resizingColIndex = -1; Cursor = Cursors.Default;
//            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
//            Invalidate();
//        }

//        protected override void OnMouseLeave(EventArgs e)
//        {
//            base.OnMouseLeave(e);
//            _hoveredRowIndex = -1; _hoveredColIndex = -1; _currentState = ControlState.Normal; Cursor = Cursors.Default; Invalidate();
//        }

//        protected override void OnMouseWheel(MouseEventArgs e)
//        {
//            base.OnMouseWheel(e);
//            _kineticVelocity += e.Delta / 4f;
//            if (!_kineticTimer.Enabled) _kineticTimer.Start();
//        }

//        private void ClampScroll()
//        {
//            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
//            int totalContentHeight = GetTotalRowCount() * _rowHeight;
//            int maxScroll = Math.Max(0, totalContentHeight - visibleHeight);
//            _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, maxScroll));
//        }

//        private bool IsOnHeader(Point p) { Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight); return headerRect.Contains(p); }
//        private int GetColIndexAtPosition(Point p) { int colX = _contentBounds.X; for (int i = 0; i < _columns.Count; i++) { if (!_columns[i].Visible) continue; if (p.X >= colX && p.X < colX + _columns[i].Width) return i; colX += (int)_columns[i].Width; } return -1; }
//        private int GetRowAtPosition(Point p) { if (!_contentBounds.Contains(p)) return -1; int relativeY = p.Y - (_contentBounds.Y + _headerHeight + _bandHeight) + _scrollOffset; if (relativeY < 0) return -1; int rowIndex = relativeY / _rowHeight; if (rowIndex >= 0 && rowIndex < GetTotalRowCount()) return rowIndex; return -1; }
//        private void UpdateScrollPosition(int mouseY) { int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight; int totalContentHeight = GetTotalRowCount() * _rowHeight; int maxScroll = totalContentHeight - visibleHeight; if (maxScroll <= 0) return; int thumbHeight = _scrollThumbBounds.Height; int trackHeight = _scrollTrackBounds.Height - thumbHeight; int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2); relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight)); float scrollRatio = (float)relativeMouseY / Math.Max(1, trackHeight); _scrollOffset = (int)(scrollRatio * maxScroll); Invalidate(); }

//        protected override void Dispose(bool disposing) { if (disposing) { _headerFont?.Dispose(); _cellFont?.Dispose(); _headerMenu?.Dispose(); _cellMenu?.Dispose(); _kineticTimer?.Dispose(); } base.Dispose(disposing); }
//        #endregion
//    }
//}






//=========================================== ver 1.6 ==================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using MethodInvoker = System.Windows.Forms.MethodInvoker;

namespace UltraModernUI.Controls
{
    /// <summary>
    /// A fully custom, high-fidelity DataGridView replacement control with enterprise features.
    /// </summary>
    [ToolboxItem(true)]
    public class ModernDataGridView : Control
    {
        #region Enums & Data Classes
        public enum ThemeMode { Light, Dark }
        public enum DesignStyle { DashboardPremium, FluentGlass, MaterialFlat, SoftNeumorphic, CyberpunkIndustrial }
        public enum ControlState { Normal, Hover, Pressed, Focused, Disabled }
        public enum DataFormat { CSV, JSON, XML, PDF }
        public enum SummaryType { None, Sum, Avg, Count, Min, Max }
        public enum ColumnType { Text, DataBar, Sparkline }

        public class Band { public string Name { get; set; } public List<string> Columns { get; set; } = new List<string>(); }
        public class FormatRule { public string ColumnName { get; set; } public string Operator { get; set; } public string Value { get; set; } public Color BackColor { get; set; } public Color ForeColor { get; set; } }
        public class ColumnSummary { public string ColumnName { get; set; } public SummaryType SummaryType { get; set; } }
        public class ColumnInfo { public string Name { get; set; } public float Width { get; set; } public bool Visible { get; set; } = true; public string Format { get; set; } = "{0}"; public ColumnType ColType { get; set; } = ColumnType.Text; public int DisplayIndex { get; set; } = 0; public double MinValue { get; set; } = 0; public double MaxValue { get; set; } = 100; }

        private struct UndoState { public int Row; public int Col; public string OldValue; public string NewValue; }
        #endregion

        #region Fields & Properties
        private ThemeMode _themeMode = ThemeMode.Light;
        private DesignStyle _controlStyle = DesignStyle.DashboardPremium;
        private ControlState _currentState = ControlState.Normal;

        private List<ColumnInfo> _columns = new List<ColumnInfo>();

        /// <summary>
        /// Gets or sets the collection of columns in the grid.
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public List<ColumnInfo> Columns { get { return _columns; } set { _columns = value ?? new List<ColumnInfo>(); Invalidate(); } }

        private List<string[]> _rows = new List<string[]>();
        private List<string[]> _filteredRows = new List<string[]>();
        private HashSet<int> _dirtyRows = new HashSet<int>();
        private HashSet<int> _expandedRows = new HashSet<int>();
        private Stack<UndoState> _undoStack = new Stack<UndoState>();
        private Stack<UndoState> _redoStack = new Stack<UndoState>();

        private int _hoveredRowIndex = -1;
        private int _hoveredColIndex = -1;
        private int _selectedRowIndex = -1;
        private int _scrollOffset = 0;
        private int _hScrollOffset = 0;
        private int _rowHeight = 42;
        private int _headerHeight = 48;
        private int _bandHeight = 0;
        private int _groupPanelHeight = 0;
        private int _footerHeight = 0;

        private int _frozenColumnCount = 0;
        private int _frozenRowCount = 0;

        private Rectangle _contentBounds;
        private Rectangle _scrollTrackBounds;
        private Rectangle _scrollThumbBounds;
        private Rectangle _hScrollTrackBounds;
        private Rectangle _hScrollThumbBounds;
        private bool _isScrolling = false;
        private bool _isHScrolling = false;
        private int _resizingColIndex = -1;
        private float _initialColWidth = 0;

        private Font _headerFont;
        private Font _cellFont;
        private ContextMenuStrip _headerMenu;
        private ContextMenuStrip _cellMenu;
        private System.Windows.Forms.Timer _kineticTimer;
        private float _kineticVelocity = 0;

        private bool _virtualMode = false;
        private int _virtualRowCount = 0;
        private Dictionary<int, string[]> _virtualCache = new Dictionary<int, string[]>();
        private HashSet<int> _pendingRequests = new HashSet<int>();
        private Dictionary<Type, PropertyInfo[]> _reflectionCache = new Dictionary<Type, PropertyInfo[]>();

        private string _searchQuery = "";
        private List<string> _groupedColumns = new List<string>();
        private List<Band> _bands = new List<Band>();
        private List<FormatRule> _formatRules = new List<FormatRule>();
        private List<ColumnSummary> _summaries = new List<ColumnSummary>();
        private Dictionary<int, int> _rowHeightsCache = new Dictionary<int, int>();
        private Dictionary<string, List<string>> _activeFilters = new Dictionary<string, List<string>>();

        private object _dataSource;
        private bool _isLoading = false;
        private bool _debugMode = false;
        private bool _enableGhostRow = true;

        ///// <summary>
        ///// Gets or sets the data source. Supports DataTable and IList.
        ///// </summary>
        ////[RequiresUnreferencedCode("Data binding requires runtime reflection which may not be compatible with trimming.")]
        ////public object DataSource { get { return _dataSource; } set { _dataSource = value; ProcessDataSource(); } }
        //[Category("Data")]
        //[AttributeProvider(typeof(IListSource))]
        //public object DataSource
        //{
        //    [RequiresUnreferencedCode("Data binding requires runtime reflection which may not be compatible with trimming.")]
        //    get => _dataSource;

        //    [RequiresUnreferencedCode("Data binding requires runtime reflection which may not be compatible with trimming.")]
        //    set => _dataSource = value;
        //}


        /// <summary>
        /// Gets or sets the data source. Supports DataTable and IList.
        /// </summary>
        [Category("Data")]
        [AttributeProvider(typeof(IListSource))]
        public object DataSource
        {
            [RequiresUnreferencedCode("Data binding requires runtime reflection which may not be compatible with trimming.")]
            get { return _dataSource; }

            [RequiresUnreferencedCode("Data binding requires runtime reflection which may not be compatible with trimming.")]
            set
            {
                _dataSource = value;
                ProcessDataSource(); // <--- THIS IS REQUIRED TO LOAD THE DATA
            }
        }

        [Category("Appearance")]
        [DefaultValue(ThemeMode.Light)]
        public ThemeMode Theme { get { return _themeMode; } set { _themeMode = value; Invalidate(); } }

        [Category("Appearance")]
        [DefaultValue(DesignStyle.DashboardPremium)]
        public DesignStyle Style { get { return _controlStyle; } set { _controlStyle = value; Invalidate(); } }

        [Browsable(false)]
        public List<string[]> Rows { get { return _rows; } set { _rows = value ?? new List<string[]>(); _filteredRows = _rows; _selectedRowIndex = -1; _scrollOffset = 0; ApplyFiltersAndSearch(); } }

        [Category("Behavior")]
        [DefaultValue(false)]
        public bool AutoRowHeight { get; set; } = false;

        [Category("Data")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public List<Band> Bands { get { return _bands; } set { _bands = value; Invalidate(); } }

        [Category("Data")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public List<FormatRule> FormatRules { get { return _formatRules; } set { _formatRules = value; Invalidate(); } }

        [Category("Data")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public List<ColumnSummary> Summaries { get { return _summaries; } set { _summaries = value; Invalidate(); } }

        [Category("Behavior")]
        [DefaultValue(false)]
        public bool VirtualMode { get { return _virtualMode; } set { _virtualMode = value; _virtualCache.Clear(); Invalidate(); } }

        [Category("Data")]
        [DefaultValue(0)]
        public int VirtualRowCount { get { return _virtualRowCount; } set { _virtualRowCount = value; Invalidate(); } }

        [Category("Appearance")]
        [DefaultValue(42)]
        public int RowHeight { get { return _rowHeight; } set { _rowHeight = Math.Max(1, value); Invalidate(); } }

        [Category("Behavior")]
        [DefaultValue(true)]
        public bool EnableDataContextMenu { get; set; } = true;

        [Category("Behavior")]
        [DefaultValue(true)]
        public bool EnableGhostRow { get { return _enableGhostRow; } set { _enableGhostRow = value; Invalidate(); } }

        [Category("Behavior")]
        [DefaultValue(false)]
        public bool DebugMode { get { return _debugMode; } set { _debugMode = value; } }

        [Category("Behavior")]
        [DefaultValue(false)]
        public bool IsLoading { get { return _isLoading; } set { _isLoading = value; Invalidate(); } }

        /// <summary>
        /// Gets or sets the number of columns that are frozen on the left side.
        /// </summary>
        [Category("Behavior")]
        [DefaultValue(0)]
        public int FrozenColumnCount { get { return _frozenColumnCount; } set { _frozenColumnCount = Math.Max(0, value); Invalidate(); } }

        /// <summary>
        /// Gets or sets the number of rows that are frozen at the top.
        /// </summary>
        [Category("Behavior")]
        [DefaultValue(0)]
        public int FrozenRowCount { get { return _frozenRowCount; } set { _frozenRowCount = Math.Max(0, value); Invalidate(); } }

        [Category("Data")]
        public string SearchQuery { get { return _searchQuery; } set { _searchQuery = value; ApplyFiltersAndSearch(); } }

        public event Func<int, string[]> RetrieveVirtualItem;
        public event Func<int, int> GetRowDetailsHeight;
        public event Action<Graphics, Rectangle, int> DrawRowDetails;
        public event Func<int, int, double[]> GetSparklineData;

        #endregion

        #region Constructor & Initialization
        public ModernDataGridView()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);

            UpdateFonts();
            InitializeContextMenus();
            InitializeKineticScrolling();

            BackColor = Color.Transparent;
            Size = new Size(800, 500);
            AllowDrop = true;
        }

        private void UpdateFonts()
        {
            _headerFont?.Dispose();
            _cellFont?.Dispose();

            string fontName = "Segoe UI Variable Display";
            try
            {
                using (var testFont = new Font(fontName, 9f)) { if (testFont.Name != fontName) fontName = "Segoe UI"; }
                _headerFont = new Font(fontName, 10f, FontStyle.Bold);
                _cellFont = new Font(fontName, 9.5f, FontStyle.Regular);
            }
            catch
            {
                _headerFont = new Font("Segoe UI", 10f, FontStyle.Bold);
                _cellFont = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            }
        }

        private void InitializeContextMenus()
        {
            _headerMenu = new ContextMenuStrip();
            _headerMenu.Items.Add("Sort Ascending", null, (s, e) => SortColumn(true));
            _headerMenu.Items.Add("Sort Descending", null, (s, e) => SortColumn(false));
            _headerMenu.Items.Add(new ToolStripSeparator());
            _headerMenu.Items.Add("Hide Column", null, (s, e) => { if (_hoveredColIndex >= 0 && _hoveredColIndex < _columns.Count) _columns[_hoveredColIndex].Visible = false; Invalidate(); });
            _headerMenu.Items.Add("Group By This Column", null, (s, e) => { if (_hoveredColIndex >= 0 && _hoveredColIndex < _columns.Count && !_groupedColumns.Contains(_columns[_hoveredColIndex].Name)) _groupedColumns.Add(_columns[_hoveredColIndex].Name); Invalidate(); });

            _cellMenu = new ContextMenuStrip();
            _cellMenu.Items.Add("Copy", null, (s, e) => CopyToClipboard());
            _cellMenu.Items.Add("Paste", null, (s, e) => PasteFromClipboard());
            _cellMenu.Items.Add(new ToolStripSeparator());
            _cellMenu.Items.Add("Undo", null, (s, e) => Undo());
            _cellMenu.Items.Add("Redo", null, (s, e) => Redo());
            _cellMenu.Items.Add(new ToolStripSeparator());
            _cellMenu.Items.Add("Expand/Collapse Details", null, (s, e) => ToggleRowDetails(_selectedRowIndex));
            _cellMenu.Items.Add("Filter By Selection", null, (s, e) => FilterBySelection());
        }

        private void InitializeKineticScrolling()
        {
            _kineticTimer = new System.Windows.Forms.Timer();
            _kineticTimer.Interval = 16; // ~60fps
            _kineticTimer.Tick += (s, e) =>
            {
                if (Math.Abs(_kineticVelocity) < 0.1f) { _kineticTimer.Stop(); return; }
                _scrollOffset -= (int)_kineticVelocity;
                _kineticVelocity *= 0.92f; // Friction
                ClampScroll();
                Invalidate();
            };
        }

        private bool IsDesignerHosted
        {
            get
            {
                Control ctrl = this;
                while (ctrl != null) { if (ctrl.Site != null && ctrl.Site.DesignMode) return true; ctrl = ctrl.Parent; }
                return false;
            }
        }
        #endregion

        #region Diagnostic & Logging
        private void Log(string message)
        {
            if (_debugMode) Debug.WriteLine($"[ModernDataGridView] {message}");
        }
        #endregion

        #region Thread-Safe Data Processing & Reflection (AOT Friendly with Cache)
        [RequiresUnreferencedCode("Uses reflection to bind data.")]
        private void ProcessDataSource()
        {
            if (IsDisposed || IsDesignerHosted) return;
            if (InvokeRequired) { BeginInvoke((MethodInvoker)ProcessDataSource); return; }

            try
            {
                if (_dataSource == null) { _columns.Clear(); Rows = new List<string[]>(); return; }

                if (_dataSource is DataTable table)
                {
                    _columns.Clear();
                    foreach (DataColumn col in table.Columns)
                        _columns.Add(new ColumnInfo { Name = col.ColumnName, Width = 150, Visible = true, Format = "{0}" });

                    var newRows = new List<string[]>();
                    foreach (DataRow row in table.Rows)
                    {
                        var rowData = new string[table.Columns.Count];
                        for (int i = 0; i < table.Columns.Count; i++)
                            rowData[i] = row[i] == null || row[i] == DBNull.Value ? "" : string.Format(_columns[i].Format, row[i]);
                        newRows.Add(rowData);
                    }
                    Rows = newRows;
                    Log($"Bound DataTable with {table.Columns.Count} columns and {table.Rows.Count} rows.");
                }
                else if (_dataSource is IEnumerable list)
                {
                    object firstItem = null;
                    foreach (var item in list) { firstItem = item; break; }
                    if (firstItem == null) return;

                    var type = firstItem.GetType();
                    if (!_reflectionCache.TryGetValue(type, out var props))
                    {
                        props = type.GetProperties();
                        _reflectionCache[type] = props;
                    }

                    _columns.Clear();
                    var newRows = new List<string[]>();

                    foreach (var prop in props)
                    {
                        var browsableAttr = prop.GetCustomAttribute<BrowsableAttribute>();
                        if (browsableAttr != null && !browsableAttr.Browsable) continue;

                        var displayAttr = prop.GetCustomAttribute<DisplayAttribute>();
                        var dataTypeAttr = prop.GetCustomAttribute<DataTypeAttribute>();

                        string name = (displayAttr != null && !string.IsNullOrEmpty(displayAttr.Name)) ? displayAttr.Name : prop.Name;
                        string format = "{0}";

                        if (prop.PropertyType == typeof(DateTime) || (dataTypeAttr != null && dataTypeAttr.DataType == DataType.Date))
                            format = "{0:yyyy-MM-dd}";
                        else if (prop.PropertyType == typeof(decimal) || prop.PropertyType == typeof(double) || prop.PropertyType == typeof(int))
                            format = "{0:N2}";

                        _columns.Add(new ColumnInfo { Name = name, Width = 150, Visible = true, Format = format, DisplayIndex = _columns.Count });
                    }

                    foreach (var item in list)
                    {
                        var rowData = new string[_columns.Count];
                        int colIdx = 0;
                        foreach (var prop in props)
                        {
                            var browsableAttr = prop.GetCustomAttribute<BrowsableAttribute>();
                            if (browsableAttr != null && !browsableAttr.Browsable) continue;

                            var val = prop.GetValue(item);
                            rowData[colIdx] = val == null ? "" : string.Format(_columns[colIdx].Format, val);
                            colIdx++;
                        }
                        newRows.Add(rowData);
                    }
                    Rows = newRows;
                    Log($"Bound IEnumerable with {_columns.Count} columns.");
                }
            }
            catch (Exception ex) { Log($"Binding failed: {ex.Message}"); }
        }
        #endregion

        #region State Persistence (Save/Load Layout)
        public string SaveLayout()
        {
            var sb = new StringBuilder();
            sb.Append("{");
            sb.Append("\"columns\":[");
            for (int i = 0; i < _columns.Count; i++)
            {
                sb.Append($"{{\"name\":\"{EscapeJson(_columns[i].Name)}\",\"width\":{_columns[i].Width},\"visible\":{_columns[i].Visible.ToString().ToLower()},\"displayIndex\":{_columns[i].DisplayIndex}}}");
                if (i < _columns.Count - 1) sb.Append(",");
            }
            sb.Append("],");
            sb.Append($"\"frozenColumns\":{_frozenColumnCount},");
            sb.Append($"\"frozenRows\":{_frozenRowCount},");
            sb.Append($"\"rowHeight\":{_rowHeight}");
            sb.Append("}");
            return sb.ToString();
        }

        public void LoadLayout(string json)
        {
            if (string.IsNullOrEmpty(json)) return;

            try
            {
                // Zero-dependency Regex JSON parser for AOT/Trimming compatibility
                var colMatches = Regex.Matches(json, @"\{""name"":""(?<name>[^""]+)"",""width"":(?<width>[\d\.]+),""visible"":(?<vis>true|false),""displayIndex"":(?<idx>\d+)\}");
                foreach (Match m in colMatches)
                {
                    string name = m.Groups["name"].Value;
                    var col = _columns.FirstOrDefault(c => c.Name == name);
                    if (col != null)
                    {
                        col.Width = float.Parse(m.Groups["width"].Value);
                        col.Visible = bool.Parse(m.Groups["vis"].Value);
                        col.DisplayIndex = int.Parse(m.Groups["idx"].Value);
                    }
                }

                _frozenColumnCount = ExtractInt(json, "frozenColumns");
                _frozenRowCount = ExtractInt(json, "frozenRows");
                _rowHeight = ExtractInt(json, "rowHeight");

                // Re-order columns based on display index
                _columns = _columns.OrderBy(c => c.DisplayIndex).ToList();

                Invalidate();
                Log("Layout loaded successfully.");
            }
            catch (Exception ex)
            {
                Log($"Failed to load layout: {ex.Message}");
            }
        }

        private int ExtractInt(string json, string key)
        {
            var match = Regex.Match(json, $"\"{key}\":(?<val>\\d+)");
            return match.Success ? int.Parse(match.Groups["val"].Value) : 0;
        }

        private string EscapeJson(string val) => val.Replace("\\", "\\\\").Replace("\"", "\\\"");
        #endregion

        #region Filtering, Search, Sort & Virtual Data
        private void ApplyFiltersAndSearch()
        {
            if (InvokeRequired) { BeginInvoke((MethodInvoker)ApplyFiltersAndSearch); return; }
            if (_virtualMode) { Invalidate(); return; }
            if (_rows == null) _rows = new List<string[]>();
            var result = _rows;

            if (!string.IsNullOrEmpty(_searchQuery))
                result = result.Where(r => r != null && r.Any(c => c != null && c.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();

            if (_activeFilters != null && _activeFilters.Count > 0)
                foreach (var filter in _activeFilters) { int colIndex = _columns.FindIndex(c => c.Name == filter.Key); if (colIndex >= 0) result = result.Where(r => r != null && r.Length > colIndex && filter.Value.Contains(r[colIndex])).ToList(); }

            _filteredRows = result.ToList();
            _scrollOffset = 0;
            Invalidate();
        }

        private void SortColumn(bool ascending)
        {
            if (_hoveredColIndex < 0 || _hoveredColIndex >= _columns.Count) return;
            int colIdx = _hoveredColIndex;
            if (ascending) _filteredRows = _filteredRows.OrderBy(r => r.Length > colIdx ? r[colIdx] : "").ToList();
            else _filteredRows = _filteredRows.OrderByDescending(r => r.Length > colIdx ? r[colIdx] : "").ToList();
            Invalidate();
        }

        private void FilterBySelection()
        {
            if (_selectedRowIndex < 0 || _selectedRowIndex >= _filteredRows.Count) return;
            if (_hoveredColIndex < 0 || _hoveredColIndex >= _columns.Count) return;

            string cellVal = _filteredRows[_selectedRowIndex][_hoveredColIndex];
            string colName = _columns[_hoveredColIndex].Name;
            _activeFilters[colName] = new List<string> { cellVal };
            ApplyFiltersAndSearch();
        }

        private void EnsureVirtualRow(int rowIndex)
        {
            if (_virtualCache.ContainsKey(rowIndex) || _pendingRequests.Contains(rowIndex) || RetrieveVirtualItem == null) return;
            _pendingRequests.Add(rowIndex);
            Task.Run(() =>
            {
                var data = RetrieveVirtualItem(rowIndex);
                if (data != null) lock (_virtualCache) { _virtualCache[rowIndex] = data; if (_virtualCache.Count > 1000) _virtualCache.Clear(); }
                _pendingRequests.Remove(rowIndex);
                this.BeginInvoke((MethodInvoker)delegate { Invalidate(); });
            });
        }

        public string[] GetRowData(int rowIndex)
        {
            if (_virtualMode) { if (_virtualCache.TryGetValue(rowIndex, out var data)) return data; EnsureVirtualRow(rowIndex); return new string[_columns.Count]; }
            return rowIndex >= 0 && rowIndex < _filteredRows.Count ? _filteredRows[rowIndex] : null;
        }

        public int GetTotalRowCount() { return _virtualMode ? _virtualRowCount : _filteredRows.Count + (_enableGhostRow ? 1 : 0); }

        public void ToggleRowDetails(int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= _filteredRows.Count) return;
            if (_expandedRows.Contains(rowIndex)) _expandedRows.Remove(rowIndex);
            else _expandedRows.Add(rowIndex);
            Invalidate();
        }
        #endregion

        #region Memory Safe Layout Calculation
        private void CalculateLayout()
        {
            _bandHeight = _bands.Count > 0 ? 30 : 0;
            _groupPanelHeight = _groupedColumns.Count > 0 ? 40 : 0;
            _footerHeight = _summaries.Count > 0 ? 36 : 0;
            _headerHeight = 48;

            int safeWidth = Math.Max(0, Width - 24);
            int safeHeight = Math.Max(0, Height - 24 - _groupPanelHeight - _footerHeight);
            _contentBounds = new Rectangle(12, 12 + _groupPanelHeight, safeWidth, safeHeight);

            float totalColWidth = _columns.Where(c => c.Visible).Sum(c => c.Width);
            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
            int totalContentHeight = GetTotalRowCount() * _rowHeight;

            // Vertical Scrollbar
            if (totalContentHeight > visibleHeight && visibleHeight > 0)
            {
                int scrollWidth = 6;
                _scrollTrackBounds = new Rectangle(_contentBounds.Right - scrollWidth - 2, _contentBounds.Y + _headerHeight + _bandHeight + 4, scrollWidth, Math.Max(0, visibleHeight - 8));
                float scrollRatio = (float)visibleHeight / Math.Max(1, totalContentHeight);
                int thumbHeight = Math.Max(20, (int)(visibleHeight * scrollRatio));
                int maxScroll = totalContentHeight - visibleHeight;
                int thumbY = _scrollTrackBounds.Y + (int)(((float)_scrollOffset / Math.Max(1, maxScroll)) * (_scrollTrackBounds.Height - thumbHeight));
                _scrollThumbBounds = new Rectangle(_scrollTrackBounds.X, thumbY, scrollWidth, thumbHeight);
            }
            else { _scrollTrackBounds = Rectangle.Empty; _scrollThumbBounds = Rectangle.Empty; _scrollOffset = 0; }

            // Horizontal Scrollbar
            if (totalColWidth > _contentBounds.Width && _contentBounds.Width > 0)
            {
                int hScrollHeight = 6;
                _hScrollTrackBounds = new Rectangle(_contentBounds.X, _contentBounds.Bottom - hScrollHeight - 2, _contentBounds.Width - (_scrollThumbBounds != Rectangle.Empty ? _scrollThumbBounds.Width + 4 : 0), hScrollHeight);
                float hScrollRatio = (float)_contentBounds.Width / Math.Max(1, totalColWidth);
                int hThumbWidth = Math.Max(20, (int)(_contentBounds.Width * hScrollRatio));
                int hMaxScroll = (int)(totalColWidth - _contentBounds.Width);
                int hThumbX = _hScrollTrackBounds.X + (int)(((float)_hScrollOffset / Math.Max(1, hMaxScroll)) * (_hScrollTrackBounds.Width - hThumbWidth));
                _hScrollThumbBounds = new Rectangle(hThumbX, _hScrollTrackBounds.Y, hThumbWidth, hScrollHeight);
            }
            else { _hScrollTrackBounds = Rectangle.Empty; _hScrollThumbBounds = Rectangle.Empty; _hScrollOffset = 0; }
        }
        #endregion

        #region Core Paint Engine
        protected override void OnPaint(PaintEventArgs e)
        {
            if (Width <= 0 || Height <= 0) return;
            Stopwatch sw = Stopwatch.StartNew();

            if (IsDesignerHosted && _columns.Count == 0 && _rows.Count == 0)
            {
                _columns = new List<ColumnInfo> { new ColumnInfo { Name = "ID", Width = 100, DisplayIndex = 0 }, new ColumnInfo { Name = "Status", Width = 150, DisplayIndex = 1 }, new ColumnInfo { Name = "Metric", Width = 200, DisplayIndex = 2 }, new ColumnInfo { Name = "Value", Width = 150, DisplayIndex = 3 } };
                _rows = new List<string[]> { new string[] { "001", "Active", "CPU Load", "2400" }, new string[] { "002", "Idle", "Memory", "4200" } };
                _filteredRows = _rows;
            }

            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

            CalculateLayout();

            using (SolidBrush bgBrush = GetBackgroundBrush())
            using (GraphicsPath bgPath = GetRoundedPath(ClientRectangle, 8)) g.FillPath(bgBrush, bgPath);

            if (_contentBounds.Width > 0 && _contentBounds.Height > 0)
            {
                using (GraphicsPath contentClipPath = GetRoundedPath(_contentBounds, 6))
                {
                    g.SetClip(contentClipPath);
                    if (_groupedColumns.Count > 0) DrawGroupingPanel(g);
                    if (_bands.Count > 0) DrawBands(g);
                    DrawHeader(g);
                    if (_isLoading) DrawSkeletonRows(g); else DrawRows(g);
                    g.ResetClip();
                }
            }

            if (_summaries.Count > 0) DrawFooterSummaries(g);
            DrawOuterBorder(g);
            DrawScrollbar(g);
            DrawHScrollbar(g);

            sw.Stop();
            if (_debugMode && sw.ElapsedMilliseconds > 15) Log($"Render Pass took {sw.ElapsedMilliseconds}ms.");
        }

        private void DrawGroupingPanel(Graphics g)
        {
            Rectangle panelRect = new Rectangle(_contentBounds.X, _contentBounds.Y - _groupPanelHeight + 2, _contentBounds.Width, _groupPanelHeight - 4);
            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
            using (var brush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
            {
                g.FillRectangle(brush, panelRect);
                int x = panelRect.X + 10;
                foreach (var col in _groupedColumns)
                {
                    var size = g.MeasureString(col, _cellFont);
                    Rectangle tagRect = new Rectangle(x, panelRect.Y + 8, (int)size.Width + 20, 24);
                    using (var tagPath = GetRoundedPath(tagRect, 4))
                    using (var tagBrush = new SolidBrush(GetAccentColor()))
                    using (var textBrush = new SolidBrush(Color.White))
                    {
                        g.FillPath(tagBrush, tagPath);
                        g.DrawString(col, _cellFont, textBrush, new RectangleF(x + 10, panelRect.Y + 8, size.Width, 24), sf);
                    }
                    x += tagRect.Width + 8;
                }
                g.DrawLine(pen, panelRect.Left, panelRect.Bottom, panelRect.Right, panelRect.Bottom);
            }
        }

        private void DrawBands(Graphics g)
        {
            int y = _contentBounds.Y;
            int colX = _contentBounds.X - _hScrollOffset;
            using (var brush = new SolidBrush(GetHeaderTextColor()))
            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Center })
            {
                foreach (var band in _bands)
                {
                    int spanCount = band.Columns.Count;
                    if (spanCount == 0) continue;
                    float width = 0;
                    for (int i = 0; i < _columns.Count; i++)
                    {
                        if (band.Columns.Contains(_columns[i].Name)) width += _columns[i].Width;
                    }
                    Rectangle bandRect = new Rectangle(colX, y, (int)width, _bandHeight);
                    if (bandRect.Right > _contentBounds.X && bandRect.Left < _contentBounds.Right)
                    {
                        g.DrawString(band.Name, _headerFont, brush, bandRect, sf);
                        g.DrawRectangle(pen, bandRect);
                    }
                    colX += (int)width;
                }
            }
        }

        private void DrawSkeletonRows(Graphics g)
        {
            int y = _contentBounds.Y + _headerHeight + _bandHeight;
            int visibleCount = (_contentBounds.Height - _headerHeight - _bandHeight) / _rowHeight;
            int pulse = (int)(Math.Sin(Environment.TickCount / 200.0) * 20 + 30);

            for (int i = 0; i < visibleCount; i++)
            {
                Rectangle rowRect = new Rectangle(_contentBounds.X, y, _contentBounds.Width, _rowHeight);
                using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1)) g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);

                int colX = rowRect.X - _hScrollOffset;
                foreach (var col in _columns)
                {
                    if (!col.Visible) continue;
                    Rectangle skelRect = new Rectangle(colX + 12, y + (_rowHeight / 2) - 8, (int)col.Width - 24, 16);
                    if (skelRect.Right > _contentBounds.X && skelRect.Left < _contentBounds.Right)
                    {
                        using (var skelBrush = new SolidBrush(Color.FromArgb(pulse, GetForegroundColor()))) g.FillPath(skelBrush, GetRoundedPath(skelRect, 4));
                    }
                    colX += (int)col.Width;
                }
                y += _rowHeight;
            }
        }

        private void DrawHeader(Graphics g)
        {
            Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight);
            int colX = headerRect.X - _hScrollOffset;

            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
            using (SolidBrush textBrush = new SolidBrush(GetHeaderTextColor()))
            using (Pen bottomLinePen = new Pen(GetHeaderSeparatorColor(), 1))
            {
                for (int i = 0; i < _columns.Count; i++)
                {
                    if (!_columns[i].Visible) continue;
                    RectangleF cellRect = new RectangleF(colX + 12, headerRect.Y, Math.Max(1, _columns[i].Width - 24), headerRect.Height);

                    // Only draw if in bounds (Horizontal Scroll)
                    if (cellRect.Right > headerRect.Left && cellRect.Left < headerRect.Right)
                    {
                        g.DrawString(_columns[i].Name, _headerFont, textBrush, cellRect, sf);
                        if (_resizingColIndex == i) g.FillRectangle(new SolidBrush(GetAccentColor()), colX + _columns[i].Width - 4, headerRect.Y, 8, headerRect.Height);
                    }
                    colX += (int)_columns[i].Width;
                }
                g.DrawLine(bottomLinePen, headerRect.Left, headerRect.Bottom - 1, headerRect.Right, headerRect.Bottom - 1);
            }
        }

        private void DrawRows(Graphics g)
        {
            if (_rowHeight <= 0) return;
            Rectangle rowArea = new Rectangle(_contentBounds.X, _contentBounds.Y + _headerHeight + _bandHeight, _contentBounds.Width, _contentBounds.Height - _headerHeight - _bandHeight);
            if (rowArea.Height <= 0) return;

            int firstVisibleRow = (int)Math.Floor((double)_scrollOffset / _rowHeight);
            int visibleRowCount = (int)Math.Ceiling((double)rowArea.Height / _rowHeight) + 2;
            int totalRows = GetTotalRowCount();

            using (StringFormat sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near, Trimming = StringTrimming.EllipsisCharacter })
            {
                for (int i = firstVisibleRow; i < Math.Min(totalRows, firstVisibleRow + visibleRowCount); i++)
                {
                    if (i < 0) continue;
                    int y = rowArea.Y + (i * _rowHeight) - _scrollOffset;

                    // Master-Detail Expansion Height
                    int extraHeight = 0;
                    if (_expandedRows.Contains(i) && GetRowDetailsHeight != null)
                    {
                        extraHeight = GetRowDetailsHeight(i);
                    }

                    Rectangle rowRect = new Rectangle(rowArea.X, y, rowArea.Width, _rowHeight + extraHeight);

                    if (y + rowRect.Height < rowArea.Y || y > rowArea.Y + rowArea.Height) continue;

                    bool isGhostRow = (_enableGhostRow && i == totalRows - 1);
                    bool isDirty = _dirtyRows.Contains(i);

                    DrawRowBackground(g, rowRect, i, isGhostRow, isDirty);
                    if (!isGhostRow) DrawRowContent(g, rowRect, i, sf);
                    else DrawGhostRowContent(g, rowRect, sf);

                    // Draw details panel
                    if (extraHeight > 0 && DrawRowDetails != null)
                    {
                        Rectangle detailsRect = new Rectangle(rowArea.X + 12, y + _rowHeight, rowArea.Width - 24, extraHeight);
                        DrawRowDetails(g, detailsRect, i);
                    }
                }
            }

            // High-Contrast Focus Indicator (Accessibility)
            if (_selectedRowIndex >= 0 && _selectedRowIndex < totalRows)
            {
                int y = rowArea.Y + (_selectedRowIndex * _rowHeight) - _scrollOffset;
                int extraHeight = _expandedRows.Contains(_selectedRowIndex) && GetRowDetailsHeight != null ? GetRowDetailsHeight(_selectedRowIndex) : 0;
                Rectangle focusRect = new Rectangle(rowArea.X, y, rowArea.Width - 4, _rowHeight + extraHeight);

                // Ensure it doesn't draw over frozen columns
                if (_frozenColumnCount > 0 && _columns.Count > 0)
                {
                    float frozenWidth = _columns.Take(_frozenColumnCount).Where(c => c.Visible).Sum(c => c.Width);
                    focusRect.X += (int)frozenWidth;
                    focusRect.Width -= (int)frozenWidth;
                }

                ControlPaint.DrawFocusRectangle(g, focusRect, GetAccentColor(), GetBackgroundColor());
            }
        }

        private void DrawRowBackground(Graphics g, Rectangle rowRect, int rowIndex, bool isGhost, bool isDirty)
        {
            bool isHovered = (rowIndex == _hoveredRowIndex && _currentState != ControlState.Pressed);
            bool isSelected = (rowIndex == _selectedRowIndex);

            if (isDirty)
            {
                using (var dirtyBrush = new SolidBrush(Color.FromArgb(40, 255, 160, 0))) g.FillRectangle(dirtyBrush, rowRect);
            }

            using (var sepPen = new Pen(Color.FromArgb(15, GetForegroundColor()), 1)) g.DrawLine(sepPen, rowRect.Left, rowRect.Bottom - 1, rowRect.Right, rowRect.Bottom - 1);

            switch (_controlStyle)
            {
                case DesignStyle.DashboardPremium:
                    using (var selBrush = new SolidBrush(Color.FromArgb(20, GetAccentColor())))
                    using (var hovBrush = new SolidBrush(Color.FromArgb(10, GetAccentColor())))
                    {
                        if (isGhost) { using (var ghostBrush = new SolidBrush(Color.FromArgb(5, GetForegroundColor()))) g.FillRectangle(ghostBrush, rowRect); }
                        else if (isSelected) g.FillRectangle(selBrush, rowRect);
                        else if (isHovered) g.FillRectangle(hovBrush, rowRect);
                    }
                    break;
                case DesignStyle.MaterialFlat:
                    Color matBg = Color.Transparent;
                    if (isSelected) matBg = Color.FromArgb(255, GetAccentColor());
                    else if (isHovered) matBg = Color.FromArgb(50, GetForegroundColor());
                    if (matBg != Color.Transparent) using (var matBrush = new SolidBrush(matBg)) g.FillRectangle(matBrush, rowRect);
                    break;
            }
        }

        private void DrawRowContent_old(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
        {
            var rowData = GetRowData(rowIndex);
            if (rowData == null) return;
            int colX = rowRect.X - _hScrollOffset;

            Color foreColor = GetForegroundColor();
            foreach (var rule in _formatRules)
            {
                int colIdx = _columns.FindIndex(c => c.Name == rule.ColumnName);
                if (colIdx >= 0 && rowData.Length > colIdx && EvaluateRule(rule.Operator, rowData[colIdx], rule.Value))
                {
                    if (rule.BackColor != Color.Empty) { using (var bgBrush = new SolidBrush(Color.FromArgb(150, rule.BackColor))) g.FillRectangle(bgBrush, rowRect); }
                    if (rule.ForeColor != Color.Empty) foreColor = rule.ForeColor;
                }
            }

            using (SolidBrush textBrush = new SolidBrush(foreColor))
            {
                for (int i = 0; i < _columns.Count; i++)
                {
                    if (!_columns[i].Visible) continue;
                    float safeColWidth = Math.Max(1, _columns[i].Width - 24);
                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, safeColWidth, rowRect.Height);

                    // Only draw if in bounds (Horizontal scroll)
                    if (cellRect.Right > rowRect.Left && cellRect.Left < rowRect.Right)
                    {
                        string val = rowData.Length > i ? rowData[i] : "";

                        // Draw DataBars or Sparklines
                        if (_columns[i].ColType == ColumnType.DataBar && double.TryParse(val, out double barVal))
                        {
                            double pct = (barVal - _columns[i].MinValue) / Math.Max(1, _columns[i].MaxValue - _columns[i].MinValue);
                            pct = Math.Max(0, Math.Min(1, pct));
                            int barWidth = (int)(safeColWidth * pct);
                            using (var dataBarBrush = new LinearGradientBrush(cellRect, Color.FromArgb(100, GetAccentColor()), Color.FromArgb(255, GetAccentColor()), LinearGradientMode.Horizontal))
                            {
                                g.FillRectangle(dataBarBrush, new RectangleF(cellRect.X, cellRect.Y + 4, barWidth, cellRect.Height - 8));
                            }
                        }
                        else if (_columns[i].ColType == ColumnType.Sparkline && GetSparklineData != null)
                        {
                            double[] sparkData = GetSparklineData(rowIndex, i);
                            if (sparkData != null && sparkData.Length > 1)
                            {
                                double min = sparkData.Min();
                                double max = sparkData.Max();
                                float stepX = safeColWidth / (sparkData.Length - 1);
                                using (var sparkPen = new Pen(GetAccentColor(), 1.5f))
                                {
                                    PointF[] points = new PointF[sparkData.Length];
                                    for (int p = 0; p < sparkData.Length; p++)
                                    {
                                        float px = cellRect.X + (p * stepX);
                                        float py = cellRect.Y + cellRect.Height - (float)((sparkData[p] - min) / Math.Max(0.1, max - min)) * cellRect.Height;
                                        points[p] = new PointF(px, py);
                                    }
                                    g.DrawLines(sparkPen, points);
                                }
                            }
                        }

                        if (!string.IsNullOrEmpty(_searchQuery) && val.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            string lowerVal = val.ToLower();
                            string lowerQuery = _searchQuery.ToLower();
                            int idx = lowerVal.IndexOf(lowerQuery);
                            using (Font highlightFont = new Font(_cellFont, FontStyle.Bold))
                            using (SolidBrush highlightBrush = new SolidBrush(GetAccentColor()))
                            {
                                string before = val.Substring(0, idx);
                                string match = val.Substring(idx, _searchQuery.Length);
                                string after = val.Substring(idx + _searchQuery.Length);
                                g.DrawString(before, _cellFont, textBrush, cellRect, sf);
                                SizeF beforeSize = g.MeasureString(before, _cellFont);
                                RectangleF matchRect = new RectangleF(cellRect.X + beforeSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - beforeSize.Width), cellRect.Height);
                                g.DrawString(match, highlightFont, highlightBrush, matchRect, sf);
                                SizeF matchSize = g.MeasureString(match, highlightFont);
                                RectangleF afterRect = new RectangleF(matchRect.X + matchSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - (beforeSize.Width + matchSize.Width)), cellRect.Height);
                                g.DrawString(after, _cellFont, textBrush, afterRect, sf);
                            }
                        }
                        else g.DrawString(val, _cellFont, textBrush, cellRect, sf);
                    }
                    colX += (int)_columns[i].Width;
                }
            }

            // Draw Frozen Columns overlay
            if (_frozenColumnCount > 0 && _hScrollOffset > 0)
            {
                float frozenWidth = _columns.Take(_frozenColumnCount).Where(c => c.Visible).Sum(c => c.Width);
                Rectangle frozenRect = new Rectangle(rowRect.X, rowRect.Y, (int)frozenWidth, rowRect.Height);
                using (var frozenBg = new SolidBrush(GetBackgroundColor()))
                using (var frozenLine = new Pen(GetHeaderSeparatorColor(), 1))
                {
                    g.FillRectangle(frozenBg, frozenRect);
                    g.DrawLine(frozenLine, frozenRect.Right, frozenRect.Top, frozenRect.Right, frozenRect.Bottom);

                    // Redraw frozen text
                    int fColX = rowRect.X;
                    using (SolidBrush textBrush = new SolidBrush(foreColor))
                    {
                        for (int i = 0; i < _frozenColumnCount; i++)
                        {
                            if (!_columns[i].Visible) continue;
                            float safeColWidth = Math.Max(1, _columns[i].Width - 24);
                            RectangleF cellRect = new RectangleF(fColX + 12, rowRect.Y, safeColWidth, rowRect.Height);
                            string val = rowData.Length > i ? rowData[i] : "";
                            g.DrawString(val, _cellFont, textBrush, cellRect, sf);
                            fColX += (int)_columns[i].Width;
                        }
                    }
                }
            }
        }

        private void DrawRowContent(Graphics g, Rectangle rowRect, int rowIndex, StringFormat sf)
        {
            var rowData = GetRowData(rowIndex);
            if (rowData == null) return;
            int colX = rowRect.X - _hScrollOffset;

            Color foreColor = GetForegroundColor();
            foreach (var rule in _formatRules)
            {
                int colIdx = _columns.FindIndex(c => c.Name == rule.ColumnName);
                if (colIdx >= 0 && rowData.Length > colIdx && EvaluateRule(rule.Operator, rowData[colIdx], rule.Value))
                {
                    if (rule.BackColor != Color.Empty) { using (var bgBrush = new SolidBrush(Color.FromArgb(150, rule.BackColor))) g.FillRectangle(bgBrush, rowRect); }
                    if (rule.ForeColor != Color.Empty) foreColor = rule.ForeColor;
                }
            }

            using (SolidBrush textBrush = new SolidBrush(foreColor))
            {
                for (int i = 0; i < _columns.Count; i++)
                {
                    if (!_columns[i].Visible) continue;
                    float safeColWidth = Math.Max(1, _columns[i].Width - 24);
                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, safeColWidth, rowRect.Height);

                    // Only draw if in bounds (Horizontal scroll)
                    if (cellRect.Right > rowRect.Left && cellRect.Left < rowRect.Right)
                    {
                        string val = rowData.Length > i ? rowData[i] : "";

                        if (_columns[i].ColType == ColumnType.DataBar && double.TryParse(val, out double barVal))
                        {
                            // Draw DataBar
                            double pct = (barVal - _columns[i].MinValue) / Math.Max(1, _columns[i].MaxValue - _columns[i].MinValue);
                            pct = Math.Max(0, Math.Min(1, pct));
                            int barWidth = (int)(safeColWidth * pct);
                            using (var dataBarBrush = new LinearGradientBrush(cellRect, Color.FromArgb(100, GetAccentColor()), Color.FromArgb(255, GetAccentColor()), LinearGradientMode.Horizontal))
                            {
                                g.FillRectangle(dataBarBrush, new RectangleF(cellRect.X, cellRect.Y + 4, barWidth, cellRect.Height - 8));
                            }
                            // Draw text over databar
                            g.DrawString(val, _cellFont, textBrush, cellRect, sf);
                        }
                        else if (_columns[i].ColType == ColumnType.Sparkline && GetSparklineData != null)
                        {
                            // Draw Sparkline (DO NOT draw text)
                            double[] sparkData = GetSparklineData(rowIndex, i);
                            if (sparkData != null && sparkData.Length > 1)
                            {
                                double min = sparkData.Min();
                                double max = sparkData.Max();
                                float stepX = safeColWidth / (sparkData.Length - 1);
                                using (var sparkPen = new Pen(GetAccentColor(), 1.5f))
                                {
                                    PointF[] points = new PointF[sparkData.Length];
                                    for (int p = 0; p < sparkData.Length; p++)
                                    {
                                        float px = cellRect.X + (p * stepX);
                                        float py = cellRect.Y + cellRect.Height - (float)((sparkData[p] - min) / Math.Max(0.1, max - min)) * cellRect.Height;
                                        points[p] = new PointF(px, py);
                                    }
                                    g.DrawLines(sparkPen, points);
                                }
                            }
                        }
                        else
                        {
                            // Standard Text Cell
                            if (!string.IsNullOrEmpty(_searchQuery) && val.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                string lowerVal = val.ToLower();
                                string lowerQuery = _searchQuery.ToLower();
                                int idx = lowerVal.IndexOf(lowerQuery);
                                using (Font highlightFont = new Font(_cellFont, FontStyle.Bold))
                                using (SolidBrush highlightBrush = new SolidBrush(GetAccentColor()))
                                {
                                    string before = val.Substring(0, idx);
                                    string match = val.Substring(idx, _searchQuery.Length);
                                    string after = val.Substring(idx + _searchQuery.Length);
                                    g.DrawString(before, _cellFont, textBrush, cellRect, sf);
                                    SizeF beforeSize = g.MeasureString(before, _cellFont);
                                    RectangleF matchRect = new RectangleF(cellRect.X + beforeSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - beforeSize.Width), cellRect.Height);
                                    g.DrawString(match, highlightFont, highlightBrush, matchRect, sf);
                                    SizeF matchSize = g.MeasureString(match, highlightFont);
                                    RectangleF afterRect = new RectangleF(matchRect.X + matchSize.Width, cellRect.Y, Math.Max(1, cellRect.Width - (beforeSize.Width + matchSize.Width)), cellRect.Height);
                                    g.DrawString(after, _cellFont, textBrush, afterRect, sf);
                                }
                            }
                            else g.DrawString(val, _cellFont, textBrush, cellRect, sf);
                        }
                    }
                    colX += (int)_columns[i].Width;
                }
            }

            // Draw Frozen Columns overlay
            if (_frozenColumnCount > 0 && _hScrollOffset > 0)
            {
                float frozenWidth = _columns.Take(_frozenColumnCount).Where(c => c.Visible).Sum(c => c.Width);
                Rectangle frozenRect = new Rectangle(rowRect.X, rowRect.Y, (int)frozenWidth, rowRect.Height);
                using (var frozenBg = new SolidBrush(GetBackgroundColor()))
                using (var frozenLine = new Pen(GetHeaderSeparatorColor(), 1))
                {
                    g.FillRectangle(frozenBg, frozenRect);
                    g.DrawLine(frozenLine, frozenRect.Right, frozenRect.Top, frozenRect.Right, frozenRect.Bottom);

                    // Redraw frozen text
                    int fColX = rowRect.X;
                    using (SolidBrush textBrush = new SolidBrush(foreColor))
                    {
                        for (int i = 0; i < _frozenColumnCount; i++)
                        {
                            if (!_columns[i].Visible) continue;
                            float safeColWidth = Math.Max(1, _columns[i].Width - 24);
                            RectangleF cellRect = new RectangleF(fColX + 12, rowRect.Y, safeColWidth, rowRect.Height);
                            string val = rowData.Length > i ? rowData[i] : "";

                            if (_columns[i].ColType == ColumnType.DataBar && double.TryParse(val, out double barVal))
                            {
                                double pct = (barVal - _columns[i].MinValue) / Math.Max(1, _columns[i].MaxValue - _columns[i].MinValue);
                                pct = Math.Max(0, Math.Min(1, pct));
                                int barWidth = (int)(safeColWidth * pct);
                                using (var dataBarBrush = new LinearGradientBrush(cellRect, Color.FromArgb(100, GetAccentColor()), Color.FromArgb(255, GetAccentColor()), LinearGradientMode.Horizontal))
                                {
                                    g.FillRectangle(dataBarBrush, new RectangleF(cellRect.X, cellRect.Y + 4, barWidth, cellRect.Height - 8));
                                }
                                g.DrawString(val, _cellFont, textBrush, cellRect, sf);
                            }
                            else if (_columns[i].ColType == ColumnType.Sparkline && GetSparklineData != null)
                            {
                                double[] sparkData = GetSparklineData(rowIndex, i);
                                if (sparkData != null && sparkData.Length > 1)
                                {
                                    double min = sparkData.Min();
                                    double max = sparkData.Max();
                                    float stepX = safeColWidth / (sparkData.Length - 1);
                                    using (var sparkPen = new Pen(GetAccentColor(), 1.5f))
                                    {
                                        PointF[] points = new PointF[sparkData.Length];
                                        for (int p = 0; p < sparkData.Length; p++)
                                        {
                                            float px = cellRect.X + (p * stepX);
                                            float py = cellRect.Y + cellRect.Height - (float)((sparkData[p] - min) / Math.Max(0.1, max - min)) * cellRect.Height;
                                            points[p] = new PointF(px, py);
                                        }
                                        g.DrawLines(sparkPen, points);
                                    }
                                }
                            }
                            else
                            {
                                g.DrawString(val, _cellFont, textBrush, cellRect, sf);
                            }
                            fColX += (int)_columns[i].Width;
                        }
                    }
                }
            }
        }

        private void DrawGhostRowContent(Graphics g, Rectangle rowRect, StringFormat sf)
        {
            int colX = rowRect.X - _hScrollOffset;
            using (SolidBrush textBrush = new SolidBrush(Color.FromArgb(100, GetForegroundColor())))
            using (Font italicFont = new Font(_cellFont, FontStyle.Italic))
            {
                for (int i = 0; i < _columns.Count; i++)
                {
                    if (!_columns[i].Visible) continue;
                    float safeColWidth = Math.Max(1, _columns[i].Width - 24);
                    RectangleF cellRect = new RectangleF(colX + 12, rowRect.Y, safeColWidth, rowRect.Height);
                    if (cellRect.Right > rowRect.Left && cellRect.Left < rowRect.Right)
                    {
                        g.DrawString("Enter " + _columns[i].Name + "...", italicFont, textBrush, cellRect, sf);
                    }
                    colX += (int)_columns[i].Width;
                }
            }
        }

        private bool EvaluateRule(string op, string cellVal, string targetVal)
        {
            if (string.IsNullOrEmpty(cellVal) || string.IsNullOrEmpty(targetVal)) return false;
            if (double.TryParse(cellVal, out double c) && double.TryParse(targetVal, out double t))
            {
                switch (op) { case ">": return c > t; case "<": return c < t; case "==": return c == t; case "!=": return c != t; case ">=": return c >= t; case "<=": return c <= t; }
            }
            else { switch (op) { case "==": return cellVal == targetVal; case "!=": return cellVal != targetVal; } }
            return false;
        }

        private void DrawFooterSummaries(Graphics g)
        {
            Rectangle footerRect = new Rectangle(_contentBounds.X, _contentBounds.Bottom + 4, _contentBounds.Width, _footerHeight);
            int colX = footerRect.X - _hScrollOffset;
            using (var bgBrush = new SolidBrush(Color.FromArgb(_themeMode == ThemeMode.Light ? 240 : 30, GetBackgroundColor())))
            using (var pen = new Pen(GetHeaderSeparatorColor(), 1))
            using (var textBrush = new SolidBrush(GetForegroundColor()))
            using (var boldFont = new Font(_cellFont, FontStyle.Bold))
            using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
            {
                g.FillPath(bgBrush, GetRoundedPath(footerRect, 4));
                g.DrawLine(pen, footerRect.Left, footerRect.Top, footerRect.Right, footerRect.Top);
                for (int i = 0; i < _columns.Count; i++)
                {
                    if (!_columns[i].Visible) continue;
                    RectangleF cellRect = new RectangleF(colX + 12, footerRect.Y, Math.Max(1, _columns[i].Width - 24), footerRect.Height);
                    if (cellRect.Right > footerRect.Left && cellRect.Left < footerRect.Right)
                    {
                        var summary = _summaries.FirstOrDefault(s => s.ColumnName == _columns[i].Name);
                        if (summary != null && summary.SummaryType != SummaryType.None)
                        {
                            string val = CalculateSummary(summary, i);
                            g.DrawString(val, boldFont, textBrush, cellRect, sf);
                        }
                    }
                    colX += (int)_columns[i].Width;
                }
            }
        }

        private string CalculateSummary(ColumnSummary summary, int colIndex)
        {
            if (_virtualMode) return "N/A";
            var values = _filteredRows.Select(r => r.Length > colIndex ? r[colIndex] : null).Where(v => v != null).ToList();
            if (values.Count == 0) return "";
            var nums = new List<double>(); foreach (var v in values) if (double.TryParse(v, out double d)) nums.Add(d);
            if (summary.SummaryType == SummaryType.Count) return values.Count.ToString();
            if (nums.Count > 0) { switch (summary.SummaryType) { case SummaryType.Sum: return nums.Sum().ToString("N2"); case SummaryType.Avg: return nums.Average().ToString("N2"); case SummaryType.Min: return nums.Min().ToString("N2"); case SummaryType.Max: return nums.Max().ToString("N2"); } }
            return "";
        }

        private void DrawOuterBorder(Graphics g)
        {
            using (GraphicsPath path = GetRoundedPath(ClientRectangle, 8))
            {
                switch (_controlStyle)
                {
                    case DesignStyle.DashboardPremium: using (var borderPen = new Pen(Color.FromArgb(_themeMode == ThemeMode.Light ? 20 : 40, GetForegroundColor()), 1)) g.DrawPath(borderPen, path); break;
                    case DesignStyle.MaterialFlat: break;
                    case DesignStyle.SoftNeumorphic: using (var lightPen = new Pen(GetNeumorphicLightColor(), 2)) using (var darkPen = new Pen(GetNeumorphicDarkColor(), 2)) { g.DrawPath(lightPen, path); g.TranslateTransform(1, 1); g.DrawPath(darkPen, path); g.ResetTransform(); } break;
                    case DesignStyle.CyberpunkIndustrial: using (var glowPen = new Pen(Color.FromArgb(40, GetAccentColor()), 4)) using (var corePen = new Pen(Color.FromArgb(255, GetAccentColor()), 1)) { g.DrawPath(glowPen, path); g.DrawPath(corePen, path); } break;
                }
            }
        }

        private void DrawScrollbar(Graphics g)
        {
            if (_scrollThumbBounds == Rectangle.Empty) return;
            using (GraphicsPath thumbPath = GetRoundedPath(_scrollThumbBounds, 3))
            using (var thumbBrush = new SolidBrush(Color.FromArgb(180, GetAccentColor()))) g.FillPath(thumbBrush, thumbPath);
        }

        private void DrawHScrollbar(Graphics g)
        {
            if (_hScrollThumbBounds == Rectangle.Empty) return;
            using (GraphicsPath thumbPath = GetRoundedPath(_hScrollThumbBounds, 3))
            using (var thumbBrush = new SolidBrush(Color.FromArgb(180, GetAccentColor()))) g.FillPath(thumbBrush, thumbPath);
        }
        #endregion

        #region Color Palette Engine
        private Color GetBackgroundColor() { switch (_controlStyle) { case DesignStyle.DashboardPremium: return _themeMode == ThemeMode.Light ? Color.FromArgb(248, 250, 252) : Color.FromArgb(22, 22, 26); case DesignStyle.FluentGlass: return _themeMode == ThemeMode.Light ? Color.FromArgb(243, 244, 246) : Color.FromArgb(28, 28, 32); case DesignStyle.MaterialFlat: return _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(18, 18, 18); case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(224, 229, 236) : Color.FromArgb(32, 38, 48); case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(12, 12, 14); default: return Color.White; } }
        private SolidBrush GetBackgroundBrush() => new SolidBrush(GetBackgroundColor());
        private Color GetForegroundColor() { switch (_controlStyle) { case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(230, 240, 255); case DesignStyle.SoftNeumorphic: return _themeMode == ThemeMode.Light ? Color.FromArgb(50, 60, 70) : Color.FromArgb(220, 230, 240); default: return _themeMode == ThemeMode.Light ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240); } }
        private Color GetHeaderTextColor() { switch (_controlStyle) { case DesignStyle.CyberpunkIndustrial: return GetAccentColor(); default: return _themeMode == ThemeMode.Light ? Color.FromArgb(100, 110, 120) : Color.FromArgb(160, 160, 160); } }
        private Color GetHeaderSeparatorColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(220, 220, 220) : Color.FromArgb(40, 40, 40);
        private Color GetAccentColor() { switch (_controlStyle) { case DesignStyle.DashboardPremium: return Color.FromArgb(0, 120, 212); case DesignStyle.FluentGlass: return Color.FromArgb(0, 180, 255); case DesignStyle.MaterialFlat: return Color.FromArgb(98, 0, 238); case DesignStyle.SoftNeumorphic: return Color.FromArgb(255, 87, 51); case DesignStyle.CyberpunkIndustrial: return Color.FromArgb(0, 255, 204); default: return Color.Blue; } }
        private Color GetNeumorphicLightColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(255, 255, 255) : Color.FromArgb(48, 54, 64);
        private Color GetNeumorphicDarkColor() => _themeMode == ThemeMode.Light ? Color.FromArgb(163, 177, 198) : Color.FromArgb(12, 18, 24);
        #endregion

        #region Geometry Helpers
        private GraphicsPath GetRoundedPath(Rectangle rect, int radius) { GraphicsPath path = new GraphicsPath(); if (rect.Width <= 0 || rect.Height <= 0) return path; int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2)); if (r <= 0) { path.AddRectangle(rect); return path; } path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90); path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90); path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90); path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90); path.CloseFigure(); return path; }
        #endregion

        #region Advanced Data Export Engine
        public void ShowExportDialog() { using (var sfd = new SaveFileDialog()) { sfd.Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json|XML (*.xml)|*.xml|PDF (*.pdf)|*.pdf"; if (sfd.ShowDialog() == DialogResult.OK) { DataFormat format; switch (sfd.FilterIndex) { case 2: format = DataFormat.JSON; break; case 3: format = DataFormat.XML; break; case 4: format = DataFormat.PDF; break; default: format = DataFormat.CSV; break; } ExportData(sfd.FileName, format); } } }
        public void ExportData(string filePath, DataFormat format) { try { if (format == DataFormat.CSV) ExportCSV(filePath); else if (format == DataFormat.JSON) ExportJSON(filePath); else if (format == DataFormat.XML) ExportXML(filePath); else if (format == DataFormat.PDF) ExportPDF(filePath); MessageBox.Show("Export successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); } catch (Exception ex) { MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); } }
        private void ExportCSV(string filePath) { var sb = new StringBuilder(); sb.AppendLine(string.Join(",", _columns.Select(c => c.Name))); foreach (var row in _filteredRows) sb.AppendLine(string.Join(",", row)); File.WriteAllText(filePath, sb.ToString()); }
        private void ExportJSON(string filePath) { var sb = new StringBuilder(); sb.Append("{\"headers\":["); sb.Append(string.Join(",", _columns.Select(c => $"\"{c.Name}\""))); sb.Append("],\"rows\":["); for (int i = 0; i < _filteredRows.Count; i++) { sb.Append("[" + string.Join(",", _filteredRows[i].Select(c => $"\"{c.Replace("\\", "\\\\").Replace("\"", "\\\"")}\"")) + "]"); if (i < _filteredRows.Count - 1) sb.Append(","); } sb.Append("]}"); File.WriteAllText(filePath, sb.ToString()); }
        private void ExportXML(string filePath) { var doc = new XDocument(new XElement("GridData")); var headersEl = new XElement("Headers"); foreach (var c in _columns) headersEl.Add(new XElement("Header", c.Name)); doc.Root.Add(headersEl); var rowsEl = new XElement("Rows"); foreach (var row in _filteredRows) { var rowEl = new XElement("Row"); foreach (var cell in row) rowEl.Add(new XElement("Cell", cell)); rowsEl.Add(rowEl); } doc.Root.Add(rowsEl); doc.Save(filePath); }
        private void ExportPDF(string filePath) { using (var stream = new FileStream(filePath, FileMode.Create)) using (var writer = new StreamWriter(stream)) { writer.Write("%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n"); var content = new StringBuilder(); content.Append("BT /F1 12 Tf 50 750 Td 14 TL\n"); content.Append(string.Join("    ", _columns.Select(c => c.Name)) + " Tj T*\n"); foreach (var row in _filteredRows) content.Append(string.Join("    ", row) + " Tj T*\n"); content.Append("ET\n"); string contentStr = content.ToString(); writer.Write($"4 0 obj<</Length {contentStr.Length}>>stream\n{contentStr}endstream endobj\n5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\nxref\n0 6\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000266 00000 n \n0000000356 00000 n \ntrailer<</Size 6/Root 1 0 R>>\nstartxref\n406\n%%EOF"); } }
        #endregion

        #region Clipboard, Undo/Redo & Accessibility Keyboard
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.C)) { CopyToClipboard(); return true; }
            if (keyData == (Keys.Control | Keys.V)) { PasteFromClipboard(); return true; }
            if (keyData == (Keys.Control | Keys.Z)) { Undo(); return true; }
            if (keyData == (Keys.Control | Keys.Y)) { Redo(); return true; }
            if (keyData == (Keys.Control | Keys.S)) { string layout = SaveLayout(); File.WriteAllText("layout.json", layout); return true; }

            // Keyboard Navigation (Accessibility)
            if (keyData == Keys.Down) { _selectedRowIndex = Math.Min(GetTotalRowCount() - 1, _selectedRowIndex + 1); ScrollToRow(_selectedRowIndex); Invalidate(); return true; }
            if (keyData == Keys.Up) { _selectedRowIndex = Math.Max(0, _selectedRowIndex - 1); ScrollToRow(_selectedRowIndex); Invalidate(); return true; }
            if (keyData == Keys.Right) { _hScrollOffset += 50; ClampHScroll(); Invalidate(); return true; }
            if (keyData == Keys.Left) { _hScrollOffset -= 50; ClampHScroll(); Invalidate(); return true; }
            if (keyData == Keys.Enter) { ToggleRowDetails(_selectedRowIndex); return true; }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void ScrollToRow(int rowIndex)
        {
            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
            if (rowIndex * _rowHeight < _scrollOffset) _scrollOffset = rowIndex * _rowHeight;
            else if ((rowIndex + 1) * _rowHeight > _scrollOffset + visibleHeight) _scrollOffset = (rowIndex + 1) * _rowHeight - visibleHeight;
            ClampScroll();
        }

        private void CopyToClipboard()
        {
            if (_selectedRowIndex < 0 || _selectedRowIndex >= _filteredRows.Count) return;
            var row = _filteredRows[_selectedRowIndex];
            string data = string.Join("\t", row);
            try { Clipboard.SetText(data); Log("Copied row to clipboard."); } catch { }
        }

        private void PasteFromClipboard()
        {
            if (_selectedRowIndex < 0 || !Clipboard.ContainsText()) return;
            string[] lines = Clipboard.GetText().Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < lines.Length; i++)
            {
                int targetRow = _selectedRowIndex + i;
                if (targetRow >= _filteredRows.Count) break;
                string[] cells = lines[i].Split('\t');
                for (int c = 0; c < cells.Length && c < _columns.Count; c++)
                {
                    string oldVal = _filteredRows[targetRow].Length > c ? _filteredRows[targetRow][c] : "";
                    string newVal = cells[c];
                    _filteredRows[targetRow][c] = newVal;
                    _undoStack.Push(new UndoState { Row = targetRow, Col = c, OldValue = oldVal, NewValue = newVal });
                    _redoStack.Clear();
                    _dirtyRows.Add(targetRow);
                }
            }
            Invalidate();
            Log($"Pasted {lines.Length} rows.");
        }

        public void Undo()
        {
            if (_undoStack.Count == 0) return;
            var state = _undoStack.Pop();
            if (_filteredRows.Count > state.Row && _filteredRows[state.Row].Length > state.Col)
            {
                _filteredRows[state.Row][state.Col] = state.OldValue;
                _redoStack.Push(state);
                _dirtyRows.Add(state.Row);
                Invalidate();
                Log("Undo executed.");
            }
        }

        public void Redo()
        {
            if (_redoStack.Count == 0) return;
            var state = _redoStack.Pop();
            if (_filteredRows.Count > state.Row && _filteredRows[state.Row].Length > state.Col)
            {
                _filteredRows[state.Row][state.Col] = state.NewValue;
                _undoStack.Push(state);
                _dirtyRows.Add(state.Row);
                Invalidate();
                Log("Redo executed.");
            }
        }
        #endregion

        #region Mouse, Kinetic Scroll & State Handling
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (_isScrolling) { UpdateScrollPosition(e.Y); return; }
            if (_isHScrolling) { UpdateHScrollPosition(e.X); return; }

            if (_resizingColIndex >= 0 && e.Button == MouseButtons.Left)
            {
                float diff = e.X - (_contentBounds.X + _columns.Take(_resizingColIndex).Sum(c => c.Visible ? c.Width : 0)) - _initialColWidth;
                _columns[_resizingColIndex].Width = Math.Max(20, _initialColWidth + diff);
                Invalidate();
                return;
            }

            int resizeIdx = GetResizeIndex(e.Location);
            Cursor = resizeIdx >= 0 ? Cursors.SizeWE : Cursors.Default;

            int newHoveredRow = GetRowAtPosition(e.Location);
            int newHoveredCol = GetColIndexAtPosition(e.Location);
            if (newHoveredRow != _hoveredRowIndex || newHoveredCol != _hoveredColIndex)
            {
                _hoveredRowIndex = newHoveredRow;
                _hoveredColIndex = newHoveredCol;
                _currentState = newHoveredRow != -1 ? ControlState.Hover : ControlState.Normal;
                Invalidate();
            }
        }

        private int GetResizeIndex(Point p)
        {
            if (p.Y < _contentBounds.Y + _headerHeight + _bandHeight && p.Y > _contentBounds.Y + _bandHeight)
            {
                int colX = _contentBounds.X - _hScrollOffset;
                for (int i = 0; i < _columns.Count; i++)
                {
                    if (!_columns[i].Visible) continue;
                    if (p.X >= colX + _columns[i].Width - 5 && p.X <= colX + _columns[i].Width + 5) return i;
                    colX += (int)_columns[i].Width;
                }
            }
            return -1;
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Focus();

            int resizeIdx = GetResizeIndex(e.Location);
            if (resizeIdx >= 0)
            {
                _resizingColIndex = resizeIdx;
                _initialColWidth = _columns[resizeIdx].Width;
                return;
            }

            if (e.Button == MouseButtons.Right && EnableDataContextMenu)
            {
                if (IsOnHeader(e.Location)) { _hoveredColIndex = GetColIndexAtPosition(e.Location); _headerMenu.Show(this, e.Location); }
                else { _selectedRowIndex = GetRowAtPosition(e.Location); _hoveredColIndex = GetColIndexAtPosition(e.Location); _cellMenu.Show(this, e.Location); }
                return;
            }

            if (_scrollThumbBounds.Contains(e.Location) && _scrollThumbBounds != Rectangle.Empty)
            {
                _isScrolling = true; Cursor = Cursors.SizeNS; _currentState = ControlState.Pressed; Invalidate(); return;
            }

            if (_hScrollThumbBounds.Contains(e.Location) && _hScrollThumbBounds != Rectangle.Empty)
            {
                _isHScrolling = true; Cursor = Cursors.SizeWE; _currentState = ControlState.Pressed; Invalidate(); return;
            }

            int clickedRow = GetRowAtPosition(e.Location);
            if (clickedRow != -1)
            {
                if (_enableGhostRow && clickedRow == GetTotalRowCount() - 1)
                {
                    _filteredRows.Add(new string[_columns.Count]);
                    _rows.Add(new string[_columns.Count]);
                    _selectedRowIndex = clickedRow;
                }
                else _selectedRowIndex = clickedRow;
                _currentState = ControlState.Pressed; Invalidate();
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            _isScrolling = false; _isHScrolling = false; _resizingColIndex = -1; Cursor = Cursors.Default;
            _currentState = _hoveredRowIndex != -1 ? ControlState.Hover : ControlState.Normal;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _hoveredRowIndex = -1; _hoveredColIndex = -1; _currentState = ControlState.Normal; Cursor = Cursors.Default; Invalidate();
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);
            if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
            {
                _hScrollOffset += (e.Delta > 0 ? 50 : -50);
                ClampHScroll();
            }
            else
            {
                _kineticVelocity += e.Delta / 4f;
                if (!_kineticTimer.Enabled) _kineticTimer.Start();
            }
        }

        private void ClampScroll()
        {
            int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight;
            int totalContentHeight = GetTotalRowCount() * _rowHeight;
            int maxScroll = Math.Max(0, totalContentHeight - visibleHeight);
            _scrollOffset = Math.Max(0, Math.Min(_scrollOffset, maxScroll));
        }

        private void ClampHScroll()
        {
            float totalColWidth = _columns.Where(c => c.Visible).Sum(c => c.Width);
            int maxScroll = Math.Max(0, (int)(totalColWidth - _contentBounds.Width));
            _hScrollOffset = Math.Max(0, Math.Min(_hScrollOffset, maxScroll));
            Invalidate();
        }

        private bool IsOnHeader(Point p) { Rectangle headerRect = new Rectangle(_contentBounds.X, _contentBounds.Y + _bandHeight, _contentBounds.Width, _headerHeight); return headerRect.Contains(p); }
        private int GetColIndexAtPosition(Point p) { int colX = _contentBounds.X - _hScrollOffset; for (int i = 0; i < _columns.Count; i++) { if (!_columns[i].Visible) continue; if (p.X >= colX && p.X < colX + _columns[i].Width) return i; colX += (int)_columns[i].Width; } return -1; }
        private int GetRowAtPosition(Point p) { if (!_contentBounds.Contains(p)) return -1; int relativeY = p.Y - (_contentBounds.Y + _headerHeight + _bandHeight) + _scrollOffset; if (relativeY < 0) return -1; int rowIndex = relativeY / _rowHeight; if (rowIndex >= 0 && rowIndex < GetTotalRowCount()) return rowIndex; return -1; }
        private void UpdateScrollPosition(int mouseY) { int visibleHeight = _contentBounds.Height - _headerHeight - _bandHeight; int totalContentHeight = GetTotalRowCount() * _rowHeight; int maxScroll = totalContentHeight - visibleHeight; if (maxScroll <= 0) return; int thumbHeight = _scrollThumbBounds.Height; int trackHeight = _scrollTrackBounds.Height - thumbHeight; int relativeMouseY = mouseY - _scrollTrackBounds.Y - (thumbHeight / 2); relativeMouseY = Math.Max(0, Math.Min(relativeMouseY, trackHeight)); float scrollRatio = (float)relativeMouseY / Math.Max(1, trackHeight); _scrollOffset = (int)(scrollRatio * maxScroll); Invalidate(); }
        private void UpdateHScrollPosition(int mouseX) { float totalColWidth = _columns.Where(c => c.Visible).Sum(c => c.Width); int maxScroll = (int)(totalColWidth - _contentBounds.Width); if (maxScroll <= 0) return; int thumbWidth = _hScrollThumbBounds.Width; int trackWidth = _hScrollTrackBounds.Width - thumbWidth; int relativeMouseX = mouseX - _hScrollTrackBounds.X - (thumbWidth / 2); relativeMouseX = Math.Max(0, Math.Min(relativeMouseX, trackWidth)); float scrollRatio = (float)relativeMouseX / Math.Max(1, trackWidth); _hScrollOffset = (int)(scrollRatio * maxScroll); Invalidate(); }

        protected override void Dispose(bool disposing) { if (disposing) { _headerFont?.Dispose(); _cellFont?.Dispose(); _headerMenu?.Dispose(); _cellMenu?.Dispose(); _kineticTimer?.Dispose(); } base.Dispose(disposing); }
        #endregion
    }
}