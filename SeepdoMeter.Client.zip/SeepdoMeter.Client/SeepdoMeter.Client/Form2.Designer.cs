﻿namespace SeepdoMeter.Client
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            modernDataGridView1 = new UltraModernUI.Controls.ModernDataGridView();
            SuspendLayout();
            // 
            // modernDataGridView1
            // 
            modernDataGridView1.AllowDrop = true;
            modernDataGridView1.BackColor = Color.Transparent;
            modernDataGridView1.DataSource = null;
            modernDataGridView1.Location = new Point(118, 37);
            modernDataGridView1.Name = "modernDataGridView1";
            modernDataGridView1.Rows = (List<string[]>)resources.GetObject("modernDataGridView1.Rows");
            modernDataGridView1.SearchQuery = "";
            modernDataGridView1.Size = new Size(807, 253);
            modernDataGridView1.TabIndex = 0;
            modernDataGridView1.Text = "modernDataGridView1";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(946, 471);
            Controls.Add(modernDataGridView1);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
        }

        #endregion

        private UltraModernUI.Controls.ModernDataGridView modernDataGridView1;
    }
}