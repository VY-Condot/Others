﻿////using System;
////using System.Collections.Generic;
////using System.ComponentModel;
////using System.ComponentModel.DataAnnotations;
////using System.Data;
////using System.Drawing;
////using System.Threading.Tasks;
////using System.Windows.Forms;
////using UltraModernUI.Controls; // Make sure this matches your namespace

////namespace SeepdoMeter.Client
////{
////    // This class demonstrates Intelligent Auto-Column Generation via Data Annotations
////    public class SalesRecord
////    {
////        [Browsable(false)] // This column will NOT show up in the grid
////        public int InternalId { get; set; }

////        [Display(Name = "Invoice #")]
////        public string InvoiceNumber { get; set; }

////        [Display(Name = "Customer Name")]
////        public string Customer { get; set; }

////        [Display(Name = "Amount Due")]
////        [DataType(DataType.Currency)]
////        public decimal Amount { get; set; }

////        [Display(Name = "Order Date")]
////        [DataType(DataType.Date)]
////        public DateTime OrderDate { get; set; }

////        [Display(Name = "Status")]
////        public string Status { get; set; }
////    }

////    public partial class Form1 : Form
////    {
////        private ModernDataGridView grid;
////        private Button btnLoadData;
////        private Button btnToggleTheme;
////        private Button btnExport;
////        private Button btnThreadTest;
////        private Label lblInstructions;

////        public Form1()
////        {
////            InitializeComponent();
////            SetupForm();
////        }

////        private void SetupForm()
////        {
////            this.Text = "ModernDataGridView - Ultimate Feature Tester";
////            this.Size = new Size(1000, 700);
////            this.StartPosition = FormStartPosition.CenterScreen;
////            this.BackColor = Color.FromArgb(30, 30, 30);

////            // Top Control Panel
////            Panel topPanel = new Panel { Dock = DockStyle.Top, Height = 80, BackColor = Color.FromArgb(40, 40, 40) };

////            lblInstructions = new Label
////            {
////                Text = "1. Click 'Load Data' to simulate a 2s network delay (Skeleton Screen).\n2. Try Ctrl+C / Ctrl+V from Excel. Try Ctrl+Z (Undo). 3. Right-click headers & cells. 4. Drag column edges to resize.",
////                ForeColor = Color.LightGray,
////                AutoSize = false,
////                Size = new Size(400, 50),
////                Location = new Point(10, 10)
////            };

////            btnLoadData = new Button { Text = "Load Data (Async)", Location = new Point(420, 10), Size = new Size(120, 32) };
////            btnToggleTheme = new Button { Text = "Toggle Theme", Location = new Point(550, 10), Size = new Size(120, 32) };
////            btnExport = new Button { Text = "Export Data", Location = new Point(680, 10), Size = new Size(120, 32) };
////            btnThreadTest = new Button { Text = "Thread Update Test", Location = new Point(810, 10), Size = new Size(140, 32) };

////            btnLoadData.Click += (s, e) => LoadDataAsync();
////            btnToggleTheme.Click += (s, e) => grid.Theme = grid.Theme == ModernDataGridView.ThemeMode.Light ? ModernDataGridView.ThemeMode.Dark : ModernDataGridView.ThemeMode.Light;
////            btnExport.Click += (s, e) => grid.ShowExportDialog();
////            btnThreadTest.Click += (s, e) => TestThreadSafety();

////            topPanel.Controls.AddRange(new Control[] { lblInstructions, btnLoadData, btnToggleTheme, btnExport, btnThreadTest });

////            // Initialize the Grid
////            grid = new ModernDataGridView
////            {
////                Dock = DockStyle.Fill,
////                Theme = ModernDataGridView.ThemeMode.Light,
////                Style = ModernDataGridView.DesignStyle.DashboardPremium,
////                DebugMode = true, // Outputs internal logs to Visual Studio "Output" window
////                EnableGhostRow = true,
////                IsLoading = false
////            };

////            // Apply Conditional Formatting Rule (Amount Due > 5000 turns Green)
////            grid.FormatRules.Add(new ModernDataGridView.FormatRule
////            {
////                ColumnName = "Amount Due",
////                Operator = ">",
////                Value = "5000",
////                BackColor = Color.LightGreen,
////                ForeColor = Color.DarkGreen
////            });

////            // Apply Footer Summary (Sum the Amount Due column)
////            grid.Summaries.Add(new ModernDataGridView.ColumnSummary
////            {
////                ColumnName = "Amount Due",
////                SummaryType = ModernDataGridView.SummaryType.Sum
////            });

////            this.Controls.Add(topPanel);
////            this.Controls.Add(grid);
////        }

////        private async void LoadDataAsync()
////        {
////            btnLoadData.Enabled = false;
////            grid.IsLoading = true; // Triggers the animated Skeleton Screen

////            await Task.Delay(2000); // Simulate a slow network/database query

////            // Generate 5,000 rows of dummy data
////            var data = new List<SalesRecord>();
////            var rand = new Random();
////            for (int i = 1; i <= 5000; i++)
////            {
////                data.Add(new SalesRecord
////                {
////                    InternalId = i,
////                    InvoiceNumber = "INV-" + i.ToString("D5"),
////                    Customer = "Customer " + rand.Next(1, 100),
////                    Amount = rand.Next(100, 9999),
////                    OrderDate = DateTime.Now.AddDays(-rand.Next(1, 365)),
////                    Status = rand.Next(1, 3) == 1 ? "Active" : "Pending"
////                });
////            }

////            // Bind the data. The grid will automatically read the [Display] and [Browsable] attributes
////            grid.DataSource = data;
////            grid.IsLoading = false; // Hide skeleton, show data
////            btnLoadData.Enabled = true;
////        }

////        private void TestThreadSafety()
////        {
////            // This proves the Thread-Safe Guardrails. Normally this crashes WinForms.
////            // But our grid automatically marshals it to the UI thread via BeginInvoke.
////            Task.Run(() =>
////            {
////                var threadData = new List<string[]>
////                {
////                    new string[] { "999", "Thread-Safe Insert!", "0", "0" }
////                };
////                grid.Rows = threadData;
////            });
////        }
////    }
////}



















//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.ComponentModel.DataAnnotations;
//using System.Drawing;
//using System.IO;
//using System.Windows.Forms;
//using UltraModernUI.Controls;

//namespace SeepdoMeter.Client
//{
//    public class SalesRecord
//    {
//        [Browsable(false)]
//        public int InternalId { get; set; }

//        [Display(Name = "Invoice #")]
//        public string InvoiceNumber { get; set; }

//        [Display(Name = "Customer")]
//        public string Customer { get; set; }

//        [Display(Name = "Amount")]
//        [DataType(DataType.Currency)]
//        public decimal Amount { get; set; }

//        [Display(Name = "Target")]
//        public decimal Target { get; set; }

//        [Display(Name = "Q1 Trend")]
//        public double[] Q1Trend { get; set; }

//        [Display(Name = "Order Date")]
//        [DataType(DataType.Date)]
//        public DateTime OrderDate { get; set; }
//    }

//    public partial class Form1 : Form
//    {
//        private ModernDataGridView grid;
//        private Button btnLoadData;
//        private Button btnFreezePanes;
//        private Button btnSaveLayout;
//        private Button btnLoadLayout;

//        public Form1()
//        {
//            InitializeComponent();
//            SetupForm();
//        }

//        private void SetupForm()
//        {
//            this.Text = "ModernDataGridView - Enterprise Feature Tester";
//            this.Size = new Size(1200, 800);
//            this.StartPosition = FormStartPosition.CenterScreen;
//            this.BackColor = Color.FromArgb(30, 30, 30);

//            Panel topPanel = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(40, 40, 40) };

//            btnLoadData = new Button { Text = "Load Data", Location = new Point(10, 15), Size = new Size(100, 32) };
//            btnFreezePanes = new Button { Text = "Freeze Col 1", Location = new Point(120, 15), Size = new Size(100, 32) };
//            btnSaveLayout = new Button { Text = "Save Layout", Location = new Point(230, 15), Size = new Size(100, 32) };
//            btnLoadLayout = new Button { Text = "Load Layout", Location = new Point(340, 15), Size = new Size(100, 32) };

//            btnLoadData.Click += (s, e) => LoadData();
//            btnFreezePanes.Click += (s, e) => grid.FrozenColumnCount = grid.FrozenColumnCount == 0 ? 1 : 0;
//            btnSaveLayout.Click += (s, e) => File.WriteAllText("grid_layout.json", grid.SaveLayout());
//            btnLoadLayout.Click += (s, e) => { if (File.Exists("grid_layout.json")) grid.LoadLayout(File.ReadAllText("grid_layout.json")); };

//            topPanel.Controls.AddRange(new Control[] { btnLoadData, btnFreezePanes, btnSaveLayout, btnLoadLayout });

//            grid = new ModernDataGridView
//            {
//                Dock = DockStyle.Fill,
//                Theme = ModernDataGridView.ThemeMode.Light,
//                Style = ModernDataGridView.DesignStyle.DashboardPremium,
//                DebugMode = true,
//                EnableGhostRow = true
//            };

//            // Provide the event for Master-Detail Expansion Height
//            grid.GetRowDetailsHeight += (rowIndex) => 100; // 100px extra space for expanded rows

//            // Provide the event to draw the Master-Detail content
//            grid.DrawRowDetails += (g, rect, rowIndex) =>
//            {
//                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
//                using (var bgBrush = new SolidBrush(Color.FromArgb(240, 240, 240)))
//                using (var pen = new Pen(Color.Gray, 1))
//                {
//                    g.FillPath(bgBrush, GetRoundedRect(rect, 8));
//                    g.DrawPath(pen, GetRoundedRect(rect, 8));
//                }
//                string text = $"Detailed information for row {rowIndex}. (Imagine a sub-grid or charts here).";
//                using (var font = new Font("Segoe UI", 9f))
//                using (var textBrush = new SolidBrush(Color.DarkGray))
//                {
//                    g.DrawString(text, font, textBrush, new RectangleF(rect.X + 20, rect.Y + 20, rect.Width - 40, rect.Height - 40));
//                }
//            };

//            // Provide the event to fetch Sparkline data for the "Q1 Trend" column
//            grid.GetSparklineData += (rowIndex, colIndex) =>
//            {
//                if (grid.Rows.Count > rowIndex && rowIndex >= 0)
//                {
//                    // In a real app, you'd parse this from your data source. We're returning random mock data.
//                    return new double[] { 10, 20, 15, 30, 25, 40, 35, 50 };
//                }
//                return null;
//            };

//            this.Controls.Add(topPanel);
//            this.Controls.Add(grid);
//        }

//        private void LoadData()
//        {
//            var data = new List<SalesRecord>();
//            var rand = new Random();
//            for (int i = 1; i <= 50; i++)
//            {
//                data.Add(new SalesRecord
//                {
//                    InternalId = i,
//                    InvoiceNumber = "INV-" + i.ToString("D4"),
//                    Customer = "Customer " + rand.Next(1, 50),
//                    Amount = rand.Next(100, 9000),
//                    Target = 5000,
//                    Q1Trend = new double[] { rand.Next(10, 50), rand.Next(10, 50), rand.Next(10, 50), rand.Next(10, 50) },
//                    OrderDate = DateTime.Now.AddDays(-rand.Next(1, 100))
//                });
//            }

//            grid.DataSource = data;

//            // After binding, configure the specific column types!
//            // Find the "Amount" column and turn it into a DataBar
//            if (grid.Columns.Count > 3)
//            {
//                grid.Columns[2].ColType = ModernDataGridView.ColumnType.DataBar; // Amount
//                grid.Columns[2].MinValue = 0;
//                grid.Columns[2].MaxValue = 9000;

//                // Find the "Q1 Trend" column and turn it into a Sparkline
//                grid.Columns[4].ColType = ModernDataGridView.ColumnType.Sparkline;

//                // Hide the Q1Trend array string representation so it doesn't print "System.Double[]"
//                // The grid will just draw the sparkline instead.
//            }
//        }

//        private System.Drawing.Drawing2D.GraphicsPath GetRoundedRect(Rectangle rect, int radius)
//        {
//            var path = new System.Drawing.Drawing2D.GraphicsPath();
//            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
//            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
//            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
//            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
//            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
//            path.CloseFigure();
//            return path;
//        }
//    }
//}







using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;
using UltraModernUI.Controls;

namespace SeepdoMeter.Client
{
    public class SalesRecord
    {
        [Browsable(false)]
        public int InternalId { get; set; }

        [Display(Name = "Invoice #")]
        public string InvoiceNumber { get; set; }

        [Display(Name = "Customer")]
        public string Customer { get; set; }

        [Display(Name = "Amount")]
        [DataType(DataType.Currency)]
        public decimal Amount { get; set; }

        [Display(Name = "Target")]
        public decimal Target { get; set; }

        [Display(Name = "Q1 Trend")]
        public double[] Q1Trend { get; set; }

        [Display(Name = "Order Date")]
        [DataType(DataType.Date)]
        public DateTime OrderDate { get; set; }
    }

    public partial class Form1 : Form
    {
        private ModernDataGridView grid;
        private Button btnLoadData;
        private Button btnFreezePanes;
        private Button btnSaveLayout;
        private Button btnLoadLayout;

        public Form1()
        {
            InitializeComponent();
            SetupForm();
        }

        private void SetupForm()
        {
            this.Text = "ModernDataGridView - Ultimate Enterprise Tester";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(30, 30, 30);

            Panel topPanel = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(40, 40, 40) };

            btnLoadData = new Button { Text = "Load Data", Location = new Point(10, 15), Size = new Size(100, 32) };
            btnFreezePanes = new Button { Text = "Freeze Col 1", Location = new Point(120, 15), Size = new Size(100, 32) };
            btnSaveLayout = new Button { Text = "Save Layout", Location = new Point(230, 15), Size = new Size(100, 32) };
            btnLoadLayout = new Button { Text = "Load Layout", Location = new Point(340, 15), Size = new Size(100, 32) };

            btnLoadData.Click += (s, e) => LoadData();
            btnFreezePanes.Click += (s, e) => grid.FrozenColumnCount = grid.FrozenColumnCount == 0 ? 1 : 0;
            btnSaveLayout.Click += (s, e) => File.WriteAllText("grid_layout.json", grid.SaveLayout());
            btnLoadLayout.Click += (s, e) => { if (File.Exists("grid_layout.json")) grid.LoadLayout(File.ReadAllText("grid_layout.json")); };

            topPanel.Controls.AddRange(new Control[] { btnLoadData, btnFreezePanes, btnSaveLayout, btnLoadLayout });

            grid = new ModernDataGridView
            {
                Dock = DockStyle.Fill,
                Theme = ModernDataGridView.ThemeMode.Light,
                Style = ModernDataGridView.DesignStyle.DashboardPremium,
                DebugMode = true,
                EnableGhostRow = true
            };

            // 1. Master-Detail Expansion Height (100px for the sub-grid)
            grid.GetRowDetailsHeight += (rowIndex) => 120;

            // 2. Draw the beautiful sub-grid inside the expanded row
            grid.DrawRowDetails += (g, rect, rowIndex) =>
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;

                // Draw background container for details
                using (var bgPath = GetRoundedRect(rect, 8))
                using (var bgBrush = new SolidBrush(Color.FromArgb(245, 247, 250)))
                using (var borderPen = new Pen(Color.FromArgb(220, 220, 220), 1))
                {
                    g.FillPath(bgBrush, bgPath);
                    g.DrawPath(borderPen, bgPath);
                }

                // Draw Sub-Grid Header
                string[] subHeaders = { "Item SKU", "Description", "Qty", "Price" };
                float[] subWidths = { 100, 200, 50, 80 };
                float subX = rect.X + 20;
                float subY = rect.Y + 15;

                using (var headerBrush = new SolidBrush(Color.FromArgb(230, 232, 236)))
                using (var textBrush = new SolidBrush(Color.FromArgb(80, 80, 80)))
                using (var font = new Font("Segoe UI", 8f, FontStyle.Bold))
                using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
                {
                    RectangleF headerRect = new RectangleF(subX, subY, subWidths.Sum(), 25);
                    g.FillRectangle(headerBrush, headerRect);

                    float curX = subX + 10;
                    for (int i = 0; i < subHeaders.Length; i++)
                    {
                        g.DrawString(subHeaders[i], font, textBrush, new RectangleF(curX, subY, subWidths[i] - 10, 25), sf);
                        curX += subWidths[i];
                    }
                }

                // Draw Sub-Grid Rows (Mock data based on rowIndex)
                Random rand = new Random(rowIndex);
                int subRowCount = 3;
                using (var font = new Font("Segoe UI", 8f))
                using (var textBrush = new SolidBrush(Color.FromArgb(50, 50, 50)))
                using (var sepPen = new Pen(Color.FromArgb(230, 230, 230), 1))
                using (var sf = new StringFormat { LineAlignment = StringAlignment.Center, Alignment = StringAlignment.Near })
                {
                    for (int r = 0; r < subRowCount; r++)
                    {
                        float rowY = subY + 25 + (r * 25);
                        string[] rowData = { $"SKU-{rand.Next(1000, 9999)}", $"Product Desc {rand.Next(1, 50)}", rand.Next(1, 10).ToString(), $"${rand.Next(50, 500)}.00" };

                        float curX = subX + 10;
                        for (int c = 0; c < rowData.Length; c++)
                        {
                            g.DrawString(rowData[c], font, textBrush, new RectangleF(curX, rowY, subWidths[c] - 10, 25), sf);
                            curX += subWidths[c];
                        }
                        g.DrawLine(sepPen, subX, rowY + 25, subX + subWidths.Sum(), rowY + 25);
                    }
                }
            };

            // 3. Provide Sparkline data to avoid "System.Double[]" text
            grid.GetSparklineData += (rowIndex, colIndex) =>
            {
                // Return a fluctuating mock array
                return new double[] { 10 + (rowIndex % 5), 20 + (rowIndex % 3), 15 + (rowIndex % 7), 30 + (rowIndex % 2), 25, 40, 35, 50 };
            };

            this.Controls.Add(topPanel);
            this.Controls.Add(grid);
        }

        private void LoadData()
        {
            var data = new List<SalesRecord>();
            var rand = new Random();
            for (int i = 1; i <= 50; i++)
            {
                data.Add(new SalesRecord
                {
                    InternalId = i,
                    InvoiceNumber = "INV-" + i.ToString("D4"),
                    Customer = "Customer " + rand.Next(1, 50),
                    Amount = rand.Next(100, 9000),
                    Target = 5000,
                    Q1Trend = new double[] { rand.Next(10, 50), rand.Next(10, 50), rand.Next(10, 50), rand.Next(10, 50) },
                    OrderDate = DateTime.Now.AddDays(-rand.Next(1, 100))
                });
            }

            grid.DataSource = data;

            // Configure column types after binding
            if (grid.Columns.Count > 4)
            {
                grid.Columns[2].ColType = ModernDataGridView.ColumnType.DataBar; // Amount
                grid.Columns[2].MinValue = 0;
                grid.Columns[2].MaxValue = 9000;

                grid.Columns[4].ColType = ModernDataGridView.ColumnType.Sparkline; // Q1 Trend
            }
        }

        private GraphicsPath GetRoundedRect(Rectangle rect, int radius)
        {
            var path = new GraphicsPath();
            int r = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
            path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
            path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
            path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
            path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}