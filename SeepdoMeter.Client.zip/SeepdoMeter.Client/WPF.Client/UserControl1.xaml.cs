﻿////using System;
////using System.ComponentModel;
////using System.Diagnostics;
////using System.Windows;
////using System.Windows.Media;

////namespace SpeedoMeter
////{
////    public enum NeedleStyle
////    {
////        ModernIndicator, ModernThin, ModernBlocky, ModernSleek, ModernCutout,
////        ModernDualLine, ClassicTapered, ClassicWide, Arrowhead, Broadhead,
////        CrossbowBolt, VintageThinWithTail, VintageArtDeco, VintageCrescentTail,
////        VintageAviator, OrnateDiamond, OrnateSpearTip, OrnateFleurDeLis,
////        OrnateSword, CompassNorth, AnchorTail, Harpoon, SciFiArrow,
////        SciFiDataSpike, EnergyBlade, SimplePin, KiteTail
////    }

////#if RELEASE
////    [DebuggerStepThrough]
////#endif
////    public partial class SpeedometerControl : FrameworkElement
////    {
////        // Dynamic scale factor to make everything proportional at any size
////        private double _scale = 1.0;

////        #region --- Backing Fields ---
////        private double _value = 0d;
////        private double _minValue = 0d;
////        private double _maxValue = 450d;
////        private string _unitLabel = "M/min";
////        private double _scaleStartAngle = 135d;
////        private double _scaleSweepAngle = 270d;
////        private int _gaugePadding = 10;
////        private double _dialPadding = 1d;
////        private double _tickZonePadding = 5d;
////        private double _tickLabelSpacing = 7d;
////        private Point _valuePosition = new Point(0.5, 0.85);
////        private double _bezelWidthMultiplier = 0.08d;
////        private Color _dialColor1 = Colors.White;
////        private Color _dialColor2 = Color.FromRgb(224, 224, 224);
////        private Color _bezelColor1 = Colors.White;
////        private Color _bezelColor2 = Colors.White;
////        private Color _bezelHighlightColor = Colors.White;
////        private Color _bezelShadowColor = Colors.White;
////        private double _zoneGreenEndValue = 100d;
////        private double _zoneRedStartValue = 250d;
////        private Color _zoneGreenColor = Color.FromRgb(0, 200, 83);
////        private Color _zoneYellowColor = Color.FromRgb(255, 193, 7);
////        private Color _zoneRedColor = Color.FromRgb(244, 67, 54);
////        private double _zoneThicknessMultiplier = 0.02d;
////        private double _zoneMinThickness = 2d;
////        private int _majorTickStep = 50;
////        private int _desiredTickLabelCount = 8;
////        private int _minorTicksPerMajor = 5;
////        private double _majorTickLengthMultiplier = 0.09d;
////        private double _minorTickLengthMultiplier = 0.05d;
////        private double _majorTickWidth = 5d;
////        private double _minorTickWidth = 2d;
////        private string _tickLabelFontFamily = "Segoe UI";
////        private double _tickLabelFontSizeMultiplier = 0.05d;
////        private double _tickLabelMinFontSize = 10d;
////        private Color _tickLabelColor = Color.FromArgb(220, 60, 60, 60);
////        private Color _majorTickColor = Color.FromArgb(220, 60, 60, 60);
////        private Color _minorTickColor = Color.FromArgb(160, 60, 60, 60);
////        private string _valueFontFamily = "Segoe UI";
////        private double _valueFontSizeMultiplier = 0.1d;
////        private double _unitFontSizeScale = 0.4d;
////        private double _valueUnitVerticalSpacing = 4d; // Fixed positive value for proper scaling
////        private double _valueMinFontSize = 18d;
////        private double _unitMinFontSize = 10d;
////        private Color _valueTextColor = Color.FromArgb(220, 40, 40, 40);
////        private Color _unitTextColor = Color.FromArgb(180, 80, 80, 80);
////        private NeedleStyle _needleStyle = NeedleStyle.ModernThin;
////        private int _needleTransparency = 180;
////        private double _needleTipMultiplier = 0.75d;
////        private double _needleTailMultiplier = 0.20d;
////        private double _needleTailSplitDistanceMultiplier = 0.24d;
////        private double _needleShoulderDistanceMultiplier = 0.08d;
////        private double _needleShoulderWidthMultiplier = 0.055d;
////        private double _needleTailWidthMultiplier = 0.03d;
////        private double _needleHighlightWidth = 2.0d;
////        private double _needleShadowOffsetMultiplier = 0.02d;
////        private Color _needleColor1 = Colors.Red;
////        private Color _needleColor2 = Colors.Red;
////        private Color _needleHighlightColor1 = Color.FromArgb(200, 255, 255, 255);
////        private Color _needleHighlightColor2 = Color.FromArgb(0, 255, 255, 255);
////        private Color _needleShadowColor = Color.FromArgb(72, 0, 0, 0);
////        private double _blockyNeedleWidthMultiplier = 0.1d;
////        private double _classicNeedleBaseWidthMultiplier = 0.15d;
////        private double _ornateDiamondSizeMultiplier = 0.1d;
////        private double _ornateCircleTailRadiusMultiplier = 0.08d;
////        private double _arrowheadSizeMultiplier = 0.1d;
////        private double _dualLineGapMultiplier = 0.02d;
////        private double _kiteTailSizeMultiplier = 0.1d;
////        private double _indicatorTipWidthMultiplier = 0.05d;
////        private double _indicatorTipLengthMultiplier = 0.1d;
////        private Color _indicatorHubColor = Color.FromRgb(40, 40, 40);
////        private Color _indicatorHubHighlightColor = Color.FromRgb(100, 100, 100);
////        private double _hubSizeMultiplier = 0.12d;
////        private double _hubMinSize = 12d;
////        private Color _hubColor1 = Color.FromRgb(224, 224, 224);
////        private Color _hubColor2 = Colors.Transparent;
////        private Color _hubShadowColor = Color.FromArgb(50, 0, 0, 0);
////        private Color _hubHighlightColor = Color.FromArgb(150, 255, 255, 255);
////        private Color _outerBorderColor = Color.FromArgb(120, 80, 80, 80);
////        private double _outerBorderWidth = 1.5d;
////        private Color _outerShadowColor = Color.FromArgb(50, 0, 0, 0);
////        private Color _innerShadowColor = Color.FromArgb(100, 0, 0, 0);
////        private Color _textShadowColor = Color.FromArgb(30, 0, 0, 0);
////        private Color _glassEffectCenterColor = Colors.Transparent;
////        private Color _glassEffectOuterColor = Color.FromArgb(0, 255, 255, 255);
////        private Rect _glassEffectRect = new Rect(0.1, 0.05, 0.8, 0.4);
////        #endregion

////        public Color BackColor { get; set; } = Colors.White;

////        #region --- Properties (Omitted for brevity, identical to previous) ---
////        [Category("1. Gauge Core")]
////        public double Value { get => _value; set { _value = Clamp(value, _minValue, _maxValue); InvalidateVisual(); } }
////        public double MinValue { get => _minValue; set { _minValue = value; if (_maxValue < _minValue) _maxValue = _minValue; _value = Clamp(_value, _minValue, _maxValue); InvalidateVisual(); } }
////        public double MaxValue { get => _maxValue; set { _maxValue = Math.Max(value, _minValue); _value = Clamp(_value, _minValue, _maxValue); InvalidateVisual(); } }
////        public string UnitLabel { get => _unitLabel; set { _unitLabel = value ?? ""; InvalidateVisual(); } }

////        public double ScaleStartAngle { get => _scaleStartAngle; set { _scaleStartAngle = value; InvalidateVisual(); } }
////        public double ScaleSweepAngle { get => _scaleSweepAngle; set { _scaleSweepAngle = value; InvalidateVisual(); } }
////        public int GaugePadding { get => _gaugePadding; set { _gaugePadding = value; InvalidateVisual(); } }
////        public double DialPadding { get => _dialPadding; set { _dialPadding = value; InvalidateVisual(); } }
////        public double TickZonePadding { get => _tickZonePadding; set { _tickZonePadding = value; InvalidateVisual(); } }
////        public double TickLabelSpacing { get => _tickLabelSpacing; set { _tickLabelSpacing = value; InvalidateVisual(); } }
////        public Point ValuePosition { get => _valuePosition; set { _valuePosition = value; InvalidateVisual(); } }
////        public double BezelWidthMultiplier { get => _bezelWidthMultiplier; set { _bezelWidthMultiplier = value; InvalidateVisual(); } }

////        public Color DialColor1 { get => _dialColor1; set { _dialColor1 = value; InvalidateVisual(); } }
////        public Color DialColor2 { get => _dialColor2; set { _dialColor2 = value; InvalidateVisual(); } }
////        public Color BezelColor1 { get => _bezelColor1; set { _bezelColor1 = value; InvalidateVisual(); } }
////        public Color BezelColor2 { get => _bezelColor2; set { _bezelColor2 = value; InvalidateVisual(); } }
////        public Color BezelHighlightColor { get => _bezelHighlightColor; set { _bezelHighlightColor = value; InvalidateVisual(); } }
////        public Color BezelShadowColor { get => _bezelShadowColor; set { _bezelShadowColor = value; InvalidateVisual(); } }

////        public double ZoneGreenEndValue { get => _zoneGreenEndValue; set { _zoneGreenEndValue = value; InvalidateVisual(); } }
////        public double ZoneRedStartValue { get => _zoneRedStartValue; set { _zoneRedStartValue = value; InvalidateVisual(); } }
////        public Color ZoneGreenColor { get => _zoneGreenColor; set { _zoneGreenColor = value; InvalidateVisual(); } }
////        public Color ZoneYellowColor { get => _zoneYellowColor; set { _zoneYellowColor = value; InvalidateVisual(); } }
////        public Color ZoneRedColor { get => _zoneRedColor; set { _zoneRedColor = value; InvalidateVisual(); } }
////        public double ZoneThicknessMultiplier { get => _zoneThicknessMultiplier; set { _zoneThicknessMultiplier = value; InvalidateVisual(); } }
////        public double ZoneMinThickness { get => _zoneMinThickness; set { _zoneMinThickness = value; InvalidateVisual(); } }

////        public int MajorTickStep { get => _majorTickStep; set { _majorTickStep = value; InvalidateVisual(); } }
////        public int DesiredTickLabelCount { get => _desiredTickLabelCount; set { _desiredTickLabelCount = value; InvalidateVisual(); } }
////        public int MinorTicksPerMajor { get => _minorTicksPerMajor; set { _minorTicksPerMajor = value; InvalidateVisual(); } }
////        public double MajorTickLengthMultiplier { get => _majorTickLengthMultiplier; set { _majorTickLengthMultiplier = value; InvalidateVisual(); } }
////        public double MinorTickLengthMultiplier { get => _minorTickLengthMultiplier; set { _minorTickLengthMultiplier = value; InvalidateVisual(); } }
////        public double MajorTickWidth { get => _majorTickWidth; set { _majorTickWidth = value; InvalidateVisual(); } }
////        public double MinorTickWidth { get => _minorTickWidth; set { _minorTickWidth = value; InvalidateVisual(); } }
////        public string TickLabelFontFamily { get => _tickLabelFontFamily; set { _tickLabelFontFamily = value; InvalidateVisual(); } }
////        public double TickLabelFontSizeMultiplier { get => _tickLabelFontSizeMultiplier; set { _tickLabelFontSizeMultiplier = value; InvalidateVisual(); } }
////        public double TickLabelMinFontSize { get => _tickLabelMinFontSize; set { _tickLabelMinFontSize = value; InvalidateVisual(); } }
////        public Color TickLabelColor { get => _tickLabelColor; set { _tickLabelColor = value; InvalidateVisual(); } }
////        public Color MajorTickColor { get => _majorTickColor; set { _majorTickColor = value; InvalidateVisual(); } }
////        public Color MinorTickColor { get => _minorTickColor; set { _minorTickColor = value; InvalidateVisual(); } }

////        public string ValueFontFamily { get => _valueFontFamily; set { _valueFontFamily = value; InvalidateVisual(); } }
////        public double ValueFontSizeMultiplier { get => _valueFontSizeMultiplier; set { _valueFontSizeMultiplier = value; InvalidateVisual(); } }
////        public double UnitFontSizeScale { get => _unitFontSizeScale; set { _unitFontSizeScale = value; InvalidateVisual(); } }
////        public double ValueUnitVerticalSpacing { get => _valueUnitVerticalSpacing; set { _valueUnitVerticalSpacing = value; InvalidateVisual(); } }
////        public double ValueMinFontSize { get => _valueMinFontSize; set { _valueMinFontSize = value; InvalidateVisual(); } }
////        public double UnitMinFontSize { get => _unitMinFontSize; set { _unitMinFontSize = value; InvalidateVisual(); } }
////        public Color ValueTextColor { get => _valueTextColor; set { _valueTextColor = value; InvalidateVisual(); } }
////        public Color UnitTextColor { get => _unitTextColor; set { _unitTextColor = value; InvalidateVisual(); } }

////        public NeedleStyle NeedleStyle { get => _needleStyle; set { _needleStyle = value; InvalidateVisual(); } }
////        public int NeedleTransparency { get => _needleTransparency; set { _needleTransparency = value; InvalidateVisual(); } }
////        public double NeedleTipMultiplier { get => _needleTipMultiplier; set { _needleTipMultiplier = value; InvalidateVisual(); } }
////        public double NeedleTailMultiplier { get => _needleTailMultiplier; set { _needleTailMultiplier = value; InvalidateVisual(); } }
////        public double NeedleTailSplitDistanceMultiplier { get => _needleTailSplitDistanceMultiplier; set { _needleTailSplitDistanceMultiplier = value; InvalidateVisual(); } }
////        public double NeedleShoulderDistanceMultiplier { get => _needleShoulderDistanceMultiplier; set { _needleShoulderDistanceMultiplier = value; InvalidateVisual(); } }
////        public double NeedleShoulderWidthMultiplier { get => _needleShoulderWidthMultiplier; set { _needleShoulderWidthMultiplier = value; InvalidateVisual(); } }
////        public double NeedleTailWidthMultiplier { get => _needleTailWidthMultiplier; set { _needleTailWidthMultiplier = value; InvalidateVisual(); } }
////        public double NeedleHighlightWidth { get => _needleHighlightWidth; set { _needleHighlightWidth = value; InvalidateVisual(); } }
////        public double NeedleShadowOffsetMultiplier { get => _needleShadowOffsetMultiplier; set { _needleShadowOffsetMultiplier = value; InvalidateVisual(); } }
////        public Color NeedleColor1 { get => _needleColor1; set { _needleColor1 = value; InvalidateVisual(); } }
////        public Color NeedleColor2 { get => _needleColor2; set { _needleColor2 = value; InvalidateVisual(); } }
////        public Color NeedleHighlightColor1 { get => _needleHighlightColor1; set { _needleHighlightColor1 = value; InvalidateVisual(); } }
////        public Color NeedleHighlightColor2 { get => _needleHighlightColor2; set { _needleHighlightColor2 = value; InvalidateVisual(); } }
////        public Color NeedleShadowColor { get => _needleShadowColor; set { _needleShadowColor = value; InvalidateVisual(); } }

////        public double BlockyNeedleWidthMultiplier { get => _blockyNeedleWidthMultiplier; set { _blockyNeedleWidthMultiplier = value; InvalidateVisual(); } }
////        public double ClassicNeedleBaseWidthMultiplier { get => _classicNeedleBaseWidthMultiplier; set { _classicNeedleBaseWidthMultiplier = value; InvalidateVisual(); } }
////        public double OrnateDiamondSizeMultiplier { get => _ornateDiamondSizeMultiplier; set { _ornateDiamondSizeMultiplier = value; InvalidateVisual(); } }
////        public double OrnateCircleTailRadiusMultiplier { get => _ornateCircleTailRadiusMultiplier; set { _ornateCircleTailRadiusMultiplier = value; InvalidateVisual(); } }
////        public double ArrowheadSizeMultiplier { get => _arrowheadSizeMultiplier; set { _arrowheadSizeMultiplier = value; InvalidateVisual(); } }
////        public double DualLineGapMultiplier { get => _dualLineGapMultiplier; set { _dualLineGapMultiplier = value; InvalidateVisual(); } }
////        public double KiteTailSizeMultiplier { get => _kiteTailSizeMultiplier; set { _kiteTailSizeMultiplier = value; InvalidateVisual(); } }
////        public double IndicatorTipWidthMultiplier { get => _indicatorTipWidthMultiplier; set { _indicatorTipWidthMultiplier = value; InvalidateVisual(); } }
////        public double IndicatorTipLengthMultiplier { get => _indicatorTipLengthMultiplier; set { _indicatorTipLengthMultiplier = value; InvalidateVisual(); } }
////        public Color IndicatorHubColor { get => _indicatorHubColor; set { _indicatorHubColor = value; InvalidateVisual(); } }
////        public Color IndicatorHubHighlightColor { get => _indicatorHubHighlightColor; set { _indicatorHubHighlightColor = value; InvalidateVisual(); } }

////        public double HubSizeMultiplier { get => _hubSizeMultiplier; set { _hubSizeMultiplier = value; InvalidateVisual(); } }
////        public double HubMinSize { get => _hubMinSize; set { _hubMinSize = value; InvalidateVisual(); } }
////        public Color HubColor1 { get => _hubColor1; set { _hubColor1 = value; InvalidateVisual(); } }
////        public Color HubColor2 { get => _hubColor2; set { _hubColor2 = value; InvalidateVisual(); } }
////        public Color HubShadowColor { get => _hubShadowColor; set { _hubShadowColor = value; InvalidateVisual(); } }
////        public Color HubHighlightColor { get => _hubHighlightColor; set { _hubHighlightColor = value; InvalidateVisual(); } }

////        public Color OuterBorderColor { get => _outerBorderColor; set { _outerBorderColor = value; InvalidateVisual(); } }
////        public double OuterBorderWidth { get => _outerBorderWidth; set { _outerBorderWidth = value; InvalidateVisual(); } }
////        public Color OuterShadowColor { get => _outerShadowColor; set { _outerShadowColor = value; InvalidateVisual(); } }
////        public Color InnerShadowColor { get => _innerShadowColor; set { _innerShadowColor = value; InvalidateVisual(); } }
////        public Color TextShadowColor { get => _textShadowColor; set { _textShadowColor = value; InvalidateVisual(); } }
////        public Color GlassEffectCenterColor { get => _glassEffectCenterColor; set { _glassEffectCenterColor = value; InvalidateVisual(); } }
////        public Color GlassEffectOuterColor { get => _glassEffectOuterColor; set { _glassEffectOuterColor = value; InvalidateVisual(); } }
////        public Rect GlassEffectRect { get => _glassEffectRect; set { _glassEffectRect = value; InvalidateVisual(); } }
////        #endregion

////        public SpeedometerControl()
////        {
////            Width = 340;
////            Height = 340;
////        }

////        #region --- WPF Drawing Helpers ---
////        private static Color WithAlpha(Color c, int a) => Color.FromArgb((byte)a, c.R, c.G, c.B);

////        private StreamGeometry PolygonGeometry(Point[] pts, bool filled, bool closed)
////        {
////            var sg = new StreamGeometry();
////            using (var ctx = sg.Open())
////            {
////                ctx.BeginFigure(pts[0], filled, closed);
////                for (int i = 1; i < pts.Length; i++) ctx.LineTo(pts[i], true, false);
////            }
////            return sg;
////        }

////        private StreamGeometry LineGeometry(Point p1, Point p2)
////        {
////            var sg = new StreamGeometry();
////            using (var ctx = sg.Open()) { ctx.BeginFigure(p1, false, false); ctx.LineTo(p2, true, false); }
////            return sg;
////        }

////        private StreamGeometry MultiLineGeometry(Point p1, Point p2, Point p3, Point p4)
////        {
////            var sg = new StreamGeometry();
////            using (var ctx = sg.Open())
////            {
////                ctx.BeginFigure(p1, false, false);
////                ctx.LineTo(p2, true, false);
////                ctx.LineTo(p3, true, false);
////                ctx.LineTo(p4, true, false);
////            }
////            return sg;
////        }

////        private StreamGeometry CurveGeometry(Point[] pts)
////        {
////            var sg = new StreamGeometry();
////            using (var ctx = sg.Open())
////            {
////                ctx.BeginFigure(pts[0], false, false);
////                for (int i = 0; i < pts.Length - 1; i++)
////                {
////                    Point p0 = pts[Math.Max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.Min(pts.Length - 1, i + 2)];
////                    double t = 0.5 / 3.0;
////                    ctx.BezierTo(
////                        new Point(p1.X + (p2.X - p0.X) * t, p1.Y + (p2.Y - p0.Y) * t),
////                        new Point(p2.X - (p3.X - p1.X) * t, p2.Y - (p3.Y - p1.Y) * t),
////                        p2, true, false);
////                }
////            }
////            return sg;
////        }

////        private LinearGradientBrush CreateLinearGradient(Rect rect, Color c1, Color c2, double angle)
////        {
////            double rad = angle * Math.PI / 180.0;
////            double dx = Math.Cos(rad), dy = Math.Sin(rad);
////            double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2;
////            double halfLen = Math.Abs(dx) * (rect.Width / 2) + Math.Abs(dy) * (rect.Height / 2);
////            var b = new LinearGradientBrush();
////            b.StartPoint = new Point(cx - dx * halfLen, cy - dy * halfLen);
////            b.EndPoint = new Point(cx + dx * halfLen, cy + dy * halfLen);
////            b.MappingMode = BrushMappingMode.Absolute;
////            b.GradientStops.Add(new GradientStop(c1, 0));
////            b.GradientStops.Add(new GradientStop(c2, 1));
////            return b;
////        }

////        private RadialGradientBrush CreateRadialGradient(Rect rect, Color centerColor, Color surroundColor, double focusScale)
////        {
////            double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2;
////            double r = Math.Min(rect.Width, rect.Height) / 2;
////            var b = new RadialGradientBrush();
////            b.Center = new Point(cx, cy);
////            b.GradientOrigin = new Point(cx, cy);
////            b.RadiusX = r; b.RadiusY = r;
////            b.MappingMode = BrushMappingMode.Absolute;
////            b.GradientStops.Add(new GradientStop(centerColor, 0.0));
////            if (focusScale > 0 && focusScale < 1)
////                b.GradientStops.Add(new GradientStop(centerColor, focusScale));
////            b.GradientStops.Add(new GradientStop(surroundColor, 1.0));
////            return b;
////        }

////        private FormattedText FormatText(string text, string fontFamily, double size, bool bold, Color color)
////        {
////            var tf = new Typeface(new FontFamily(fontFamily), FontStyles.Normal,
////                bold ? FontWeights.Bold : FontWeights.Normal, FontStretches.Normal);
////            return new FormattedText(text, System.Globalization.CultureInfo.InvariantCulture,
////                FlowDirection.LeftToRight, tf, size, new SolidColorBrush(color), 1.0);
////        }

////        private void DrawArc(DrawingContext g, Pen pen, Rect rect, double startAngle, double sweepAngle)
////        {
////            if (Math.Abs(sweepAngle) < 0.001) return;
////            double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2;
////            double rx = rect.Width / 2, ry = rect.Height / 2;
////            double sRad = startAngle * Math.PI / 180.0;
////            double eRad = (startAngle + sweepAngle) * Math.PI / 180.0;
////            Point sp = new Point(cx + rx * Math.Cos(sRad), cy + ry * Math.Sin(sRad));
////            Point ep = new Point(cx + rx * Math.Cos(eRad), cy + ry * Math.Sin(eRad));
////            var sg = new StreamGeometry();
////            using (var ctx = sg.Open())
////            {
////                ctx.BeginFigure(sp, false, false);
////                ctx.ArcTo(ep, new Size(rx, ry), 0, Math.Abs(sweepAngle) > 180,
////                    sweepAngle > 0 ? SweepDirection.Clockwise : SweepDirection.Counterclockwise, true, false);
////            }
////            g.DrawGeometry(null, pen, sg);
////        }

////        private static Rect Inflate(Rect r, double dx, double dy) => new Rect(r.X - dx, r.Y - dy, r.Width + 2 * dx, r.Height + 2 * dy);
////        #endregion

////        #region --- Drawing Methods ---
////        protected override void OnRender(DrawingContext g)
////        {
////            base.OnRender(g);
////            g.DrawRectangle(new SolidColorBrush(BackColor), null, new Rect(0, 0, ActualWidth, ActualHeight));

////            var bounds = new Rect(0, 0, ActualWidth, ActualHeight);
////            double baseSize = Math.Min(bounds.Width, bounds.Height);

////            // Calculate dynamic scale factor based on the design size of 340
////            _scale = baseSize / 340.0;
////            if (_scale <= 0) return;

////            double size = baseSize - GaugePadding * 2 * _scale;
////            if (size <= 8 * _scale) return;

////            double left = bounds.Left + (bounds.Width - size) / 2;
////            double top = bounds.Top + (bounds.Height - size) / 2;
////            var dialRect = new Rect(left, top, size, size);

////            DrawOuterShadow(g, dialRect);
////            DrawFace(g, dialRect);
////            DrawBezel(g, dialRect);
////            DrawInnerBezelShadow(g, dialRect);
////            DrawZones(g, dialRect);
////            DrawTicks(g, dialRect);
////            DrawNeedle(g, dialRect);
////            DrawValueLabel(g, dialRect);
////            DrawThinBorder(g, dialRect);
////            DrawGlassEffect(g, dialRect);
////        }

////        private void DrawOuterShadow(DrawingContext g, Rect rect)
////        {
////            var shadowRect = Inflate(rect, rect.Width * 0.03, rect.Height * 0.03);
////            var eg = new EllipseGeometry(shadowRect);
////            var brush = CreateRadialGradient(shadowRect, OuterShadowColor, WithAlpha(OuterShadowColor, 0), 0.85);
////            g.DrawGeometry(brush, null, eg);
////        }

////        private void DrawFace(DrawingContext g, Rect rect)
////        {
////            var eg = new EllipseGeometry(rect);
////            var brush = CreateRadialGradient(rect, DialColor1, DialColor2, 0.7);
////            g.DrawGeometry(brush, null, eg);
////        }

////        private void DrawBezel(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            double w = Math.Max(4 * _scale, r * BezelWidthMultiplier);
////            var rr = Inflate(rect, -w / 2, -w / 2);
////            var eg = new EllipseGeometry(rr);

////            g.DrawGeometry(CreateLinearGradient(rect, _bezelColor1, _bezelColor2, 45), null, eg);
////            g.DrawGeometry(CreateLinearGradient(rect, _bezelHighlightColor, Colors.Transparent, 225), null, eg);
////            g.DrawGeometry(CreateLinearGradient(rect, Colors.Transparent, _bezelShadowColor, 45), null, eg);
////        }

////        private void DrawInnerBezelShadow(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            double w = Math.Max(4 * _scale, r * BezelWidthMultiplier);
////            var sr = Inflate(rect, -w * 0.9, -w * 0.9);

////            var outerEG = new EllipseGeometry(rect);
////            var innerEG = new EllipseGeometry(sr);
////            var combined = new CombinedGeometry(GeometryCombineMode.Exclude, outerEG, innerEG);
////            var brush = CreateRadialGradient(rect, InnerShadowColor, WithAlpha(InnerShadowColor, 0), 0);
////            g.DrawGeometry(brush, null, combined);
////        }

////        private void DrawGlassEffect(DrawingContext g, Rect rect)
////        {
////            var eff = GlassEffectRect;
////            var hr = new Rect(rect.Left + rect.Width * eff.X, rect.Top + rect.Height * eff.Y,
////                              rect.Width * eff.Width, rect.Height * eff.Height);
////            var eg = new EllipseGeometry(hr);
////            var brush = CreateRadialGradient(hr, GlassEffectCenterColor, GlassEffectOuterColor, 0.5);
////            g.DrawGeometry(brush, null, eg);
////        }

////        private void DrawZones(DrawingContext g, Rect rect)
////        {
////            double gs = SpanForRange(MinValue, ZoneGreenEndValue);
////            double ys = SpanForRange(ZoneGreenEndValue, ZoneRedStartValue);
////            double rs = SpanForRange(ZoneRedStartValue, MaxValue);
////            double r = rect.Width * 0.5;
////            double bw = r * BezelWidthMultiplier;
////            double zt = Math.Max(ZoneMinThickness * _scale, r * ZoneThicknessMultiplier);
////            double ti = bw + DialPadding * _scale + (zt / 2);
////            var zr = Inflate(rect, -ti, -ti);

////            var pG = new Pen(new SolidColorBrush(ZoneGreenColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
////            var pY = new Pen(new SolidColorBrush(ZoneYellowColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
////            var pR = new Pen(new SolidColorBrush(ZoneRedColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };

////            if (gs > 0) DrawArc(g, pG, zr, ScaleStartAngle, gs);
////            if (ys > 0) DrawArc(g, pY, zr, ScaleStartAngle + gs, ys);
////            if (rs > 0) DrawArc(g, pR, zr, ScaleStartAngle + gs + ys, rs);
////        }

////        private void DrawTicks(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double vr = Math.Max(1, MaxValue - MinValue);
////            int M = (MajorTickStep > 0) ? MajorTickStep : NiceNumber((float)(vr / Math.Max(1, DesiredTickLabelCount)));
////            int m = Math.Max(1, M / Math.Max(1, MinorTicksPerMajor));
////            double bw = r * BezelWidthMultiplier;
////            double zt = Math.Max(ZoneMinThickness * _scale, r * ZoneThicknessMultiplier);
////            double ot = bw + DialPadding * _scale + zt + TickZonePadding * _scale;
////            double Mtl = r * MajorTickLengthMultiplier;
////            double mtl = r * MinorTickLengthMultiplier;
////            double Mit = ot + Mtl;
////            double mit = ot + mtl;
////            double fs = Math.Max(TickLabelMinFontSize * _scale, r * TickLabelFontSizeMultiplier);

////            var Mp = new Pen(new SolidColorBrush(MajorTickColor), MajorTickWidth * _scale);
////            var mp = new Pen(new SolidColorBrush(MinorTickColor), MinorTickWidth * _scale);

////            for (int v = (int)(Math.Ceiling(MinValue / m) * m); v <= (int)(Math.Floor(MaxValue / m) * m); v += m)
////            {
////                bool iM = (v % M == 0);
////                g.DrawLine(iM ? Mp : mp, PointOnCircle(c, r - ot, v), PointOnCircle(c, r - (iM ? Mit : mit), v));
////            }

////            for (int v = (int)(Math.Ceiling(MinValue / M) * M); v <= MaxValue; v += M)
////                DrawLabelAtValue(g, c, r, v, Mit, fs);

////            DrawLabelAtValue(g, c, r, (int)MinValue, Mit, fs);
////            DrawLabelAtValue(g, c, r, (int)MaxValue, Mit, fs);
////        }

////        private void DrawLabelAtValue(DrawingContext g, Point c, double r, int v, double t, double fs)
////        {
////            string l = v.ToString();
////            var ft = FormatText(l, TickLabelFontFamily, fs, true, Colors.Black);
////            var s = new Size(ft.Width, ft.Height);
////            double lci = t + TickLabelSpacing * _scale + (s.Height / 2);
////            var p = PointOnCircle(c, r - lci, v);

////            g.DrawText(FormatText(l, TickLabelFontFamily, fs, true, TextShadowColor), new Point(p.X - s.Width / 2 + 1 * _scale, p.Y - s.Height / 2 + 1 * _scale));
////            g.DrawText(FormatText(l, TickLabelFontFamily, fs, true, TickLabelColor), new Point(p.X - s.Width / 2, p.Y - s.Height / 2));
////        }

////        private void DrawValueLabel(DrawingContext g, Rect rect)
////        {
////            string vt = ((int)_value).ToString();
////            string ut = _unitLabel;
////            double r = rect.Width * 0.5;
////            var bc = new Point(rect.Left + rect.Width * ValuePosition.X, rect.Top + rect.Height * ValuePosition.Y);
////            double fsv = Math.Max(ValueMinFontSize * _scale, r * ValueFontSizeMultiplier);
////            double fsu = Math.Max(UnitMinFontSize * _scale, fsv * UnitFontSizeScale);

////            var vft = FormatText(vt, ValueFontFamily, fsv, true, Colors.Black);
////            var uft = FormatText(ut, ValueFontFamily, fsu, false, Colors.Black);
////            var vs = new Size(vft.Width, vft.Height);
////            var us = new Size(uft.Width, uft.Height);
////            double tbh = vs.Height + us.Height + ValueUnitVerticalSpacing * _scale;
////            double vty = bc.Y - tbh / 2;
////            double uty = vty + vs.Height + ValueUnitVerticalSpacing * _scale;

////            g.DrawText(FormatText(vt, ValueFontFamily, fsv, true, ValueTextColor), new Point(bc.X - vs.Width / 2, vty));
////            g.DrawText(FormatText(ut, ValueFontFamily, fsu, false, UnitTextColor), new Point(bc.X - us.Width / 2, uty));
////        }

////        private void DrawThinBorder(DrawingContext g, Rect rect)
////        {
////            var pen = new Pen(new SolidColorBrush(OuterBorderColor), OuterBorderWidth * _scale);
////            var center = new Point(rect.X + rect.Width / 2, rect.Y + rect.Height / 2);
////            g.DrawEllipse(null, pen, center, rect.Width / 2, rect.Height / 2);
////        }
////        #endregion

////        #region --- Needle Drawing Logic ---
////        private void DrawNeedle(DrawingContext g, Rect rect)
////        {
////            switch (NeedleStyle)
////            {
////                case NeedleStyle.ModernIndicator: DrawNeedle_ModernIndicator(g, rect); break;
////                case NeedleStyle.ClassicTapered: DrawNeedle_ClassicTapered(g, rect); break;
////                case NeedleStyle.ClassicWide: DrawNeedle_ClassicWide(g, rect); break;
////                case NeedleStyle.OrnateDiamond: DrawNeedle_OrnateDiamond(g, rect); break;
////                case NeedleStyle.ModernSleek: DrawNeedle_ModernSleek(g, rect); break;
////                case NeedleStyle.ModernCutout: DrawNeedle_ModernCutout(g, rect); break;
////                case NeedleStyle.ModernDualLine: DrawNeedle_ModernDualLine(g, rect); break;
////                case NeedleStyle.Arrowhead: DrawNeedle_Arrowhead(g, rect); break;
////                case NeedleStyle.Broadhead: DrawNeedle_Broadhead(g, rect); break;
////                case NeedleStyle.CrossbowBolt: DrawNeedle_CrossbowBolt(g, rect); break;
////                case NeedleStyle.VintageThinWithTail: DrawNeedle_VintageThinWithTail(g, rect); break;
////                case NeedleStyle.VintageArtDeco: DrawNeedle_VintageArtDeco(g, rect); break;
////                case NeedleStyle.VintageCrescentTail: DrawNeedle_VintageCrescentTail(g, rect); break;
////                case NeedleStyle.VintageAviator: DrawNeedle_VintageAviator(g, rect); break;
////                case NeedleStyle.OrnateSpearTip: DrawNeedle_OrnateSpearTip(g, rect); break;
////                case NeedleStyle.OrnateFleurDeLis: DrawNeedle_OrnateFleurDeLis(g, rect); break;
////                case NeedleStyle.OrnateSword: DrawNeedle_OrnateSword(g, rect); break;
////                case NeedleStyle.CompassNorth: DrawNeedle_CompassNorth(g, rect); break;
////                case NeedleStyle.AnchorTail: DrawNeedle_AnchorTail(g, rect); break;
////                case NeedleStyle.Harpoon: DrawNeedle_Harpoon(g, rect); break;
////                case NeedleStyle.SciFiArrow: DrawNeedle_SciFiArrow(g, rect); break;
////                case NeedleStyle.SciFiDataSpike: DrawNeedle_SciFiDataSpike(g, rect); break;
////                case NeedleStyle.EnergyBlade: DrawNeedle_EnergyBlade(g, rect); break;
////                case NeedleStyle.SimplePin: DrawNeedle_SimplePin(g, rect); break;
////                case NeedleStyle.ModernThin:
////                default: DrawNeedle_ModernThin(g, rect); break;
////            }
////        }

////        private void DrawNeedleShadowAndFill(DrawingContext g, Geometry path, double angle, double radius)
////        {
////            double offset = radius * NeedleShadowOffsetMultiplier;
////            g.PushTransform(new TranslateTransform(offset, offset));
////            g.DrawGeometry(new SolidColorBrush(NeedleShadowColor), null, path);
////            g.Pop();

////            var bounds = path.Bounds;
////            var brush = CreateLinearGradient(bounds, WithAlpha(NeedleColor1, NeedleTransparency), WithAlpha(NeedleColor2, NeedleTransparency), angle + 90);
////            g.DrawGeometry(brush, null, path);
////        }

////        private void DrawNeedleShadowAndFill(DrawingContext g, Pen pen, Geometry path, double angle, double radius)
////        {
////            double offset = radius * NeedleShadowOffsetMultiplier;
////            g.PushTransform(new TranslateTransform(offset, offset));
////            g.DrawGeometry(null, new Pen(new SolidColorBrush(NeedleShadowColor), pen.Thickness), path);
////            g.Pop();
////            g.DrawGeometry(null, pen, path);
////        }

////        private void DrawNeedleHub(DrawingContext g, Point center, double radius)
////        {
////            double hr = Math.Max(HubMinSize * _scale, radius * HubSizeMultiplier);
////            var hrect = new Rect(center.X - hr, center.Y - hr, hr * 2, hr * 2);
////            var eg = new EllipseGeometry(hrect);

////            g.DrawGeometry(CreateLinearGradient(hrect, HubColor1, HubColor2, 45), null, eg);

////            var innerRect = Inflate(hrect, -2 * _scale, -2 * _scale);
////            g.DrawEllipse(null, new Pen(new SolidColorBrush(HubHighlightColor), 1 * _scale),
////                new Point(innerRect.X + innerRect.Width / 2, innerRect.Y + innerRect.Height / 2),
////                innerRect.Width / 2, innerRect.Height / 2);

////            g.DrawEllipse(null, new Pen(new SolidColorBrush(HubShadowColor), 2 * _scale),
////                new Point(hrect.X + hrect.Width / 2, hrect.Y + hrect.Height / 2),
////                hrect.Width / 2, hrect.Height / 2);
////        }

////        private void DrawNeedleHub_IndicatorStyle(DrawingContext g, Point center, double radius)
////        {
////            double hr = Math.Max(HubMinSize * _scale, radius * HubSizeMultiplier);
////            var hrect = new Rect(center.X - hr, center.Y - hr, hr * 2, hr * 2);
////            var eg = new EllipseGeometry(hrect);
////            g.DrawGeometry(new SolidColorBrush(IndicatorHubColor), null, eg);

////            var irect = Inflate(hrect, -hr * 0.1, -hr * 0.1);
////            var ieg = new EllipseGeometry(irect);
////            var brush = CreateRadialGradient(irect, IndicatorHubHighlightColor, Colors.Transparent, 0);
////            g.DrawGeometry(brush, null, ieg);
////        }

////        private void DrawNeedle_ModernIndicator(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

////            var linePen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale);
////            g.DrawLine(linePen, c, t);

////            double tl = r * IndicatorTipLengthMultiplier;
////            double tw = r * IndicatorTipWidthMultiplier;
////            var perp = GetPerpendicularVector(a);
////            var tb = PointOnCircle(c, r * NeedleTipMultiplier - tl, Value);
////            var p1 = new Point(t.X - perp.X * tw / 2, t.Y - perp.Y * tw / 2);
////            var p2 = new Point(t.X + perp.X * tw / 2, t.Y + perp.Y * tw / 2);
////            var p3 = new Point(tb.X + perp.X * tw / 2, tb.Y + perp.Y * tw / 2);
////            var p4 = new Point(tb.X - perp.X * tw / 2, tb.Y - perp.Y * tw / 2);

////            var path = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
////            g.DrawGeometry(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), null, path);

////            DrawNeedleHub_IndicatorStyle(g, c, r);
////        }

////        private void DrawNeedle_ModernThin(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var d = GetDirectionVector(a);
////            var p = new Point(-d.Y, d.X);
////            var t = new Point(c.X + d.X * (r * NeedleTipMultiplier), c.Y + d.Y * (r * NeedleTipMultiplier));
////            var sl = new Point(c.X + d.X * (r * NeedleShoulderDistanceMultiplier) - p.X * (r * NeedleShoulderWidthMultiplier), c.Y + d.Y * (r * NeedleShoulderDistanceMultiplier) - p.Y * (r * NeedleShoulderWidthMultiplier));
////            var sr = new Point(c.X + d.X * (r * NeedleShoulderDistanceMultiplier) + p.X * (r * NeedleShoulderWidthMultiplier), c.Y + d.Y * (r * NeedleShoulderDistanceMultiplier) + p.Y * (r * NeedleShoulderWidthMultiplier));
////            var tl = new Point(c.X - d.X * (r * NeedleTailSplitDistanceMultiplier) - p.X * (r * NeedleTailWidthMultiplier), c.Y - d.Y * (r * NeedleTailSplitDistanceMultiplier) - p.Y * (r * NeedleTailWidthMultiplier));
////            var tr = new Point(c.X - d.X * (r * NeedleTailSplitDistanceMultiplier) + p.X * (r * NeedleTailWidthMultiplier), c.Y - d.Y * (r * NeedleTailSplitDistanceMultiplier) + p.Y * (r * NeedleTailWidthMultiplier));
////            var tc = new Point(c.X - d.X * (r * NeedleTailMultiplier), c.Y - d.Y * (r * NeedleTailMultiplier));

////            var path = PolygonGeometry(new[] { t, sr, tr, tc, tl, sl }, true, true);
////            DrawNeedleShadowAndFill(g, path, a, r);

////            var hp = PolygonGeometry(new[] { sl, t, sr }, false, false);
////            var lgb = CreateLinearGradient(path.Bounds, NeedleHighlightColor1, NeedleHighlightColor2, a);
////            g.DrawGeometry(null, new Pen(lgb, NeedleHighlightWidth * _scale), hp);

////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_SimplePin(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

////            var path = LineGeometry(c, t);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), path, a, r);

////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_ClassicTapered(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double bw = r * ClassicNeedleBaseWidthMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
////            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

////            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
////            DrawNeedleShadowAndFill(g, path, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_ClassicWide(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var d = GetDirectionVector(a);
////            var p = new Point(-d.Y, d.X);
////            double bw = r * ClassicNeedleBaseWidthMultiplier;
////            double tw = bw * 0.2;
////            var tl = new Point(c.X + d.X * (r * NeedleTipMultiplier) - p.X * tw / 2, c.Y + d.Y * (r * NeedleTipMultiplier) - p.Y * tw / 2);
////            var tr = new Point(c.X + d.X * (r * NeedleTipMultiplier) + p.X * tw / 2, c.Y + d.Y * (r * NeedleTipMultiplier) + p.Y * tw / 2);
////            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
////            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

////            var path = PolygonGeometry(new[] { tr, br, bl, tl }, true, true);
////            DrawNeedleShadowAndFill(g, path, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_OrnateDiamond(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double ds = r * OrnateDiamondSizeMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var mp = PointOnCircle(c, r * NeedleTipMultiplier - ds, Value);
////            var sl = new Point(mp.X - p.X * ds / 2, mp.Y - p.Y * ds / 2);
////            var sr = new Point(mp.X + p.X * ds / 2, mp.Y + p.Y * ds / 2);
////            var bp = PointOnCircle(c, r * NeedleTipMultiplier - ds * 2, Value);

////            var linePath = LineGeometry(c, bp);
////            var polyPath = PolygonGeometry(new[] { t, sr, bp, sl }, true, true);
////            var combined = new GeometryGroup();
////            combined.Children.Add(linePath);
////            combined.Children.Add(polyPath);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), combined, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_OrnateCircleTail(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double bw = r * ClassicNeedleBaseWidthMultiplier * 0.5;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
////            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

////            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
////            DrawNeedleShadowAndFill(g, path, a, r);

////            double tr = r * OrnateCircleTailRadiusMultiplier;
////            var tp = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
////            var trect = new Rect(tp.X - tr, tp.Y - tr, tr * 2, tr * 2);
////            g.DrawEllipse(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), null,
////                new Point(tp.X, tp.Y), tr, tr);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_ModernTriangle(DrawingContext g, Rect rect) => DrawNeedle_ClassicTapered(g, rect);

////        private void DrawNeedle_ModernDualLine(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double gap = r * DualLineGapMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var p1s = new Point(c.X - p.X * gap, c.Y - p.Y * gap);
////            var p1e = new Point(t.X - p.X * gap, t.Y - p.Y * gap);
////            var p2s = new Point(c.X + p.X * gap, c.Y + p.Y * gap);
////            var p2e = new Point(t.X + p.X * gap, t.Y + p.Y * gap);

////            var pen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale);
////            g.DrawLine(pen, p1s, p1e);
////            g.DrawLine(pen, p2s, p2e);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_ModernCutout(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double bw = r * BlockyNeedleWidthMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var p1 = new Point(t.X - p.X * bw / 4, t.Y - p.Y * bw / 4);
////            var p2 = new Point(t.X + p.X * bw / 4, t.Y + p.Y * bw / 4);
////            var p3 = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);
////            var p4 = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
////            var cp1 = PointOnCircle(c, r * 0.5, Value);
////            var cp2 = PointOnCircle(c, r * 0.3, Value);
////            var cp3 = new Point(cp2.X + p.X * bw / 4, cp2.Y + p.Y * bw / 4);
////            var cp4 = new Point(cp2.X - p.X * bw / 4, cp2.Y - p.Y * bw / 4);

////            var outerPath = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
////            var innerPath = PolygonGeometry(new[] { cp1, cp3, cp4 }, true, true);
////            var combined = new CombinedGeometry(GeometryCombineMode.Exclude, outerPath, innerPath);
////            DrawNeedleShadowAndFill(g, combined, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_VintageThinWithTail(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var tip = PointOnCircle(c, r * NeedleTipMultiplier, Value);

////            var linePath = LineGeometry(c, tip);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), linePath, a, r);

////            var perp = GetPerpendicularVector(a);
////            double ts = r * KiteTailSizeMultiplier;
////            var te = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
////            var p1 = new Point(te.X - perp.X * ts / 2, te.Y - perp.Y * ts / 2);
////            var p2 = new Point(te.X + perp.X * ts / 2, te.Y + perp.Y * ts / 2);

////            var tailPath = PolygonGeometry(new[] { c, p2, p1 }, true, true);
////            DrawNeedleShadowAndFill(g, tailPath, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_VintageArtDeco(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double bw = r * ClassicNeedleBaseWidthMultiplier;

////            var p1 = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var p2 = PointOnCircle(c, r * 0.6, Value);
////            var p3 = new Point(p2.X + p.X * bw * 0.2, p2.Y + p.Y * bw * 0.2);
////            var p4 = new Point(p2.X - p.X * bw * 0.2, p2.Y - p.Y * bw * 0.2);
////            var p5 = PointOnCircle(c, r * 0.5, Value);
////            var p6 = new Point(p5.X + p.X * bw * 0.4, p5.Y + p.Y * bw * 0.4);
////            var p7 = new Point(p5.X - p.X * bw * 0.4, p5.Y - p.Y * bw * 0.4);
////            var p8 = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);
////            var p9 = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);

////            var path = PolygonGeometry(new[] { p1, p3, p6, p8, p9, p7, p4 }, true, true);
////            DrawNeedleShadowAndFill(g, path, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_VintageCrescentTail(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            DrawNeedle_ClassicTapered(g, rect);
////            double tr = r * OrnateCircleTailRadiusMultiplier * 1.5;
////            var tp = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
////            g.DrawEllipse(new SolidColorBrush(BackColor), null, new Point(tp.X, tp.Y), tr, tr);
////        }

////        private void DrawNeedle_OrnateSpearTip(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            double ss = r * ArrowheadSizeMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var boh = PointOnCircle(c, r * NeedleTipMultiplier - ss, Value);
////            var b1 = PointOnCircle(boh, ss * 0.8, Value, 150);
////            var b2 = PointOnCircle(boh, ss * 0.8, Value, -150);

////            var linePath = LineGeometry(c, boh);
////            var polyPath = PolygonGeometry(new[] { t, b2, boh, b1 }, true, true);
////            var combined = new GeometryGroup();
////            combined.Children.Add(linePath);
////            combined.Children.Add(polyPath);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), combined, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_OrnateFleurDeLis(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

////            var linePath = LineGeometry(c, t);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), linePath, a, r);

////            double ts = r * KiteTailSizeMultiplier * 1.5;
////            var tb = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
////            var p1 = PointOnCircle(tb, ts * 0.5, Value, 180);
////            var p2 = PointOnCircle(tb, ts, Value, 180 + 90);
////            var p3 = PointOnCircle(tb, ts, Value, 180 - 90);

////            var curvePath = CurveGeometry(new[] { p2, p1, p3 });
////            g.DrawGeometry(null, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), curvePath);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_OrnateSword(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double bw = r * ClassicNeedleBaseWidthMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var m1 = PointOnCircle(c, r * 0.6, Value);
////            var m2 = PointOnCircle(c, r * 0.5, Value);
////            var h1 = new Point(m2.X + p.X * bw / 2, m2.Y + p.Y * bw / 2);
////            var h2 = new Point(m2.X - p.X * bw / 2, m2.Y - p.Y * bw / 2);

////            var path = MultiLineGeometry(t, m1, h1, h2);
////            var path2 = LineGeometry(m2, c);
////            var combined = new GeometryGroup();
////            combined.Children.Add(path);
////            combined.Children.Add(path2);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), combined, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_SciFiArrow(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            double hs = r * ArrowheadSizeMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var p2 = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value, -2);
////            var p3 = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value, 2);
////            var p4 = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);

////            var path = PolygonGeometry(new[] { t, p3, p4, p2 }, true, true);
////            DrawNeedleShadowAndFill(g, path, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_SciFiDataSpike(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var p1 = PointOnCircle(c, r * 0.6, Value, 2);
////            var p2 = PointOnCircle(c, r * 0.6, Value, -2);
////            var p3 = PointOnCircle(c, r * 0.3, Value, 4);
////            var p4 = PointOnCircle(c, r * 0.3, Value, -4);

////            var path = PolygonGeometry(new[] { t, p1, p3, c, p4, p2 }, true, true);
////            DrawNeedleShadowAndFill(g, path, MapValueToAngle(Value), r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_EnergyBlade(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double bw = r * BlockyNeedleWidthMultiplier * 0.5;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
////            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

////            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
////            var bounds = path.Bounds;
////            var brush = new RadialGradientBrush();
////            brush.Center = new Point(bounds.X + bounds.Width / 2, bounds.Y + bounds.Height / 2);
////            brush.GradientOrigin = brush.Center;
////            brush.RadiusX = Math.Max(bounds.Width, bounds.Height) / 2;
////            brush.RadiusY = brush.RadiusX;
////            brush.MappingMode = BrushMappingMode.Absolute;
////            brush.GradientStops.Add(new GradientStop(Colors.White, 0));
////            brush.GradientStops.Add(new GradientStop(WithAlpha(NeedleColor1, NeedleTransparency), 1));
////            g.DrawGeometry(brush, null, path);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_ModernSleek(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var s1 = new Point(c.X + p.X * r * 0.05, c.Y + p.Y * r * 0.05);
////            var s2 = new Point(c.X - p.X * r * 0.05, c.Y - p.Y * r * 0.05);
////            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);

////            var path = CurveGeometry(new[] { tail, s2, t, s1, tail });
////            DrawNeedleShadowAndFill(g, path, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_Arrowhead(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            double hs = r * ArrowheadSizeMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var boh = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
////            var p = GetPerpendicularVector(a);
////            var p1 = new Point(boh.X - p.X * hs / 2, boh.Y - p.Y * hs / 2);
////            var p2 = new Point(boh.X + p.X * hs / 2, boh.Y + p.Y * hs / 2);

////            var linePath = LineGeometry(c, boh);
////            var polyPath = PolygonGeometry(new[] { t, p2, p1 }, true, true);
////            var combined = new GeometryGroup();
////            combined.Children.Add(linePath);
////            combined.Children.Add(polyPath);
////            DrawNeedleShadowAndFill(g, combined, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_Broadhead(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            double hs = r * ArrowheadSizeMultiplier * 1.5;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var n = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
////            var p = GetPerpendicularVector(a);
////            var b1 = new Point(n.X + p.X * hs * 0.4, n.Y + p.Y * hs * 0.4);
////            var b2 = new Point(n.X - p.X * hs * 0.4, n.Y - p.Y * hs * 0.4);
////            var back = PointOnCircle(c, r * NeedleTipMultiplier - hs * 1.2, Value);

////            var linePath = LineGeometry(c, back);
////            var polyPath = PolygonGeometry(new[] { t, b1, back, b2 }, true, true);
////            var combined = new GeometryGroup();
////            combined.Children.Add(linePath);
////            combined.Children.Add(polyPath);
////            DrawNeedleShadowAndFill(g, combined, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_CrossbowBolt(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            double hs = r * ArrowheadSizeMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var boh = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
////            var p = GetPerpendicularVector(a);
////            var p1 = new Point(boh.X - p.X * hs / 3, boh.Y - p.Y * hs / 3);
////            var p2 = new Point(boh.X + p.X * hs / 3, boh.Y + p.Y * hs / 3);
////            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
////            var f1 = new Point(tail.X - p.X * hs / 2, tail.Y - p.Y * hs / 2);
////            var f2 = new Point(tail.X + p.X * hs / 2, tail.Y + p.Y * hs / 2);

////            var path = PolygonGeometry(new[] { t, p2, f2, f1, p1 }, true, true);
////            DrawNeedleShadowAndFill(g, path, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_VintageAviator(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
////            var p = GetPerpendicularVector(a);
////            double w = r * 0.05;
////            var p1 = new Point(t.X - p.X * w, t.Y - p.Y * w);
////            var p2 = new Point(t.X + p.X * w, t.Y + p.Y * w);
////            var p3 = new Point(tail.X + p.X * w * 2, tail.Y + p.Y * w * 2);
////            var p4 = new Point(tail.X - p.X * w * 2, tail.Y - p.Y * w * 2);

////            var path = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
////            DrawNeedleShadowAndFill(g, path, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_Harpoon(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            double hs = r * ArrowheadSizeMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var n = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
////            var b1 = PointOnCircle(n, hs * 0.5, Value, 150);
////            var b2 = PointOnCircle(n, hs * 0.5, Value, -150);

////            var mainLine = LineGeometry(c, t);
////            var barb1 = LineGeometry(b1, n);
////            var barb2 = LineGeometry(n, b2);
////            var combined = new GeometryGroup();
////            combined.Children.Add(mainLine);
////            combined.Children.Add(barb1);
////            combined.Children.Add(barb2);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), combined, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_CompassNorth(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double s = r * ClassicNeedleBaseWidthMultiplier / 2;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
////            var p1 = new Point(c.X - p.X * s, c.Y - p.Y * s);
////            var p2 = new Point(c.X + p.X * s, c.Y + p.Y * s);

////            var halfPath = PolygonGeometry(new[] { t, p2, c, p1 }, true, true);
////            g.DrawGeometry(new SolidColorBrush(WithAlpha(NeedleColor2, NeedleTransparency)), null, halfPath);

////            var fullPath = PolygonGeometry(new[] { t, p2, tail, p1 }, true, false);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), fullPath, a, r);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_AnchorTail(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            DrawNeedle_SimplePin(g, rect);
////            double ts = r * KiteTailSizeMultiplier * 1.5;
////            var tb = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
////            var te = PointOnCircle(tb, ts * 0.5, Value, 180);
////            var p1 = PointOnCircle(te, ts, Value, 180 + 90);
////            var p2 = PointOnCircle(te, ts, Value, 180 - 90);

////            var path = MultiLineGeometry(tb, te, p1, p2);
////            var pen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 4 * _scale)
////            { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
////            g.DrawGeometry(null, pen, path);
////            DrawNeedleHub(g, c, r);
////        }

////        private void DrawNeedle_SciFiHollow(DrawingContext g, Rect rect)
////        {
////            double r = rect.Width * 0.5;
////            var c = new Point(rect.Left + r, rect.Top + r);
////            double a = MapValueToAngle(Value);
////            var p = GetPerpendicularVector(a);
////            double bw = r * BlockyNeedleWidthMultiplier;
////            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
////            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
////            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

////            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
////            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), path, a, r);
////            DrawNeedleHub(g, c, r);
////        }
////        #endregion

////        #region --- Helper Methods ---
////        private double MapValueToAngle(double v)
////        {
////            double r = MaxValue - MinValue;
////            return r <= 0 ? ScaleStartAngle : ScaleStartAngle + (Clamp(v, MinValue, MaxValue) - MinValue) / r * ScaleSweepAngle;
////        }

////        private Point PointOnCircle(Point c, double r, double v)
////        {
////            double a = MapValueToAngle(v);
////            double rad = DegToRad(a);
////            return new Point(c.X + Math.Cos(rad) * r, c.Y + Math.Sin(rad) * r);
////        }

////        private Point PointOnCircle(Point c, double r, double v, double angleOffset)
////        {
////            double a = MapValueToAngle(v) + angleOffset;
////            double rad = DegToRad(a);
////            return new Point(c.X + Math.Cos(rad) * r, c.Y + Math.Sin(rad) * r);
////        }

////        private static double Clamp(double v, double min, double max) => Math.Max(min, Math.Min(max, v));

////        private double SpanForRange(double from, double to)
////        {
////            double t = MaxValue - MinValue;
////            return t <= 0 ? 0 : (Clamp(to, MinValue, MaxValue) - Clamp(from, MinValue, MaxValue)) / t * ScaleSweepAngle;
////        }

////        private static double DegToRad(double deg) => (Math.PI / 180.0) * deg;

////        private static int NiceNumber(float raw)
////        {
////            if (raw <= 0) return 1;
////            double exp = Math.Floor(Math.Log10(raw));
////            double p = Math.Pow(10.0, exp);
////            double n = raw / p, nf;
////            if (n <= 1.0) nf = 1.0;
////            else if (n <= 2.0) nf = 2.0;
////            else if (n <= 5.0) nf = 5.0;
////            else nf = 10.0;
////            return Math.Max(1, (int)(nf * p));
////        }

////        private Point GetDirectionVector(double a)
////        {
////            double rad = DegToRad(a);
////            return new Point(Math.Cos(rad), Math.Sin(rad));
////        }

////        private Point GetPerpendicularVector(double a)
////        {
////            double rad = DegToRad(a);
////            return new Point(-Math.Sin(rad), Math.Cos(rad));
////        }
////        #endregion
////    }
////}















//using System;
//using System.ComponentModel;
//using System.Diagnostics;
//using System.Windows;
//using System.Windows.Media;

//namespace SpeedoMeter
//{
//    public enum NeedleStyle
//    {
//        ModernIndicator, ModernThin, ModernBlocky, ModernSleek, ModernCutout,
//        ModernDualLine, ClassicTapered, ClassicWide, Arrowhead, Broadhead,
//        CrossbowBolt, VintageThinWithTail, VintageArtDeco, VintageCrescentTail,
//        VintageAviator, OrnateDiamond, OrnateSpearTip, OrnateFleurDeLis,
//        OrnateSword, CompassNorth, AnchorTail, Harpoon, SciFiArrow,
//        SciFiDataSpike, EnergyBlade, SimplePin, KiteTail
//    }

//#if RELEASE
//    [DebuggerStepThrough]
//#endif
//    public partial class SpeedometerControl : FrameworkElement
//    {
//        private double _scale = 1.0;

//        #region --- Backing Fields (Restored exactly to original) ---
//        private double _value = 0d;
//        private double _minValue = 0d;
//        private double _maxValue = 450d;
//        private string _unitLabel = "M/min";
//        private double _scaleStartAngle = 135d;
//        private double _scaleSweepAngle = 270d;
//        private int _gaugePadding = 10;
//        private double _dialPadding = 1d;
//        private double _tickZonePadding = 5d;
//        private double _tickLabelSpacing = 7d;
//        private Point _valuePosition = new Point(0.5, 0.85);
//        private double _bezelWidthMultiplier = 0.08d;
//        private Color _dialColor1 = Colors.White;
//        private Color _dialColor2 = Color.FromRgb(224, 224, 224);
//        private Color _bezelColor1 = Colors.White;
//        private Color _bezelColor2 = Colors.White;
//        private Color _bezelHighlightColor = Colors.White;
//        private Color _bezelShadowColor = Colors.White;
//        private double _zoneGreenEndValue = 100d;
//        private double _zoneRedStartValue = 250d;
//        private Color _zoneGreenColor = Color.FromRgb(0, 200, 83);
//        private Color _zoneYellowColor = Color.FromRgb(255, 193, 7);
//        private Color _zoneRedColor = Color.FromRgb(244, 67, 54);
//        private double _zoneThicknessMultiplier = 0.02d;
//        private double _zoneMinThickness = 2d;
//        private int _majorTickStep = 50;
//        private int _desiredTickLabelCount = 8;
//        private int _minorTicksPerMajor = 5;
//        private double _majorTickLengthMultiplier = 0.09d;
//        private double _minorTickLengthMultiplier = 0.05d;
//        private double _majorTickWidth = 5d;
//        private double _minorTickWidth = 2d;
//        private string _tickLabelFontFamily = "Segoe UI";
//        private double _tickLabelFontSizeMultiplier = 0.05d;
//        private double _tickLabelMinFontSize = 10d;
//        private Color _tickLabelColor = Color.FromArgb(220, 60, 60, 60);
//        private Color _majorTickColor = Color.FromArgb(220, 60, 60, 60);
//        private Color _minorTickColor = Color.FromArgb(160, 60, 60, 60);
//        private string _valueFontFamily = "Segoe UI";
//        private double _valueFontSizeMultiplier = 0.1d;
//        private double _unitFontSizeScale = 0.4d;
//        private double _valueUnitVerticalSpacing = -12d;
//        private double _valueMinFontSize = 18d;
//        private double _unitMinFontSize = 10d;
//        private Color _valueTextColor = Color.FromArgb(220, 40, 40, 40);
//        private Color _unitTextColor = Color.FromArgb(180, 80, 80, 80);
//        private NeedleStyle _needleStyle = NeedleStyle.ModernThin;
//        private int _needleTransparency = 180;
//        private double _needleTipMultiplier = 0.75d;
//        private double _needleTailMultiplier = 0.20d;
//        private double _needleTailSplitDistanceMultiplier = 0.24d;
//        private double _needleShoulderDistanceMultiplier = 0.08d;
//        private double _needleShoulderWidthMultiplier = 0.055d;
//        private double _needleTailWidthMultiplier = 0.03d;
//        private double _needleHighlightWidth = 2.0d;
//        private double _needleShadowOffsetMultiplier = 0.02d;
//        private Color _needleColor1 = Colors.Red;
//        private Color _needleColor2 = Colors.Red;
//        private Color _needleHighlightColor1 = Color.FromArgb(200, 255, 255, 255);
//        private Color _needleHighlightColor2 = Color.FromArgb(0, 255, 255, 255);
//        private Color _needleShadowColor = Color.FromArgb(72, 0, 0, 0);
//        private double _blockyNeedleWidthMultiplier = 0.1d;
//        private double _classicNeedleBaseWidthMultiplier = 0.15d;
//        private double _ornateDiamondSizeMultiplier = 0.1d;
//        private double _ornateCircleTailRadiusMultiplier = 0.08d;
//        private double _arrowheadSizeMultiplier = 0.1d;
//        private double _dualLineGapMultiplier = 0.02d;
//        private double _kiteTailSizeMultiplier = 0.1d;
//        private double _indicatorTipWidthMultiplier = 0.05d;
//        private double _indicatorTipLengthMultiplier = 0.1d;
//        private Color _indicatorHubColor = Color.FromRgb(40, 40, 40);
//        private Color _indicatorHubHighlightColor = Color.FromRgb(100, 100, 100);
//        private double _hubSizeMultiplier = 0.12d;
//        private double _hubMinSize = 12d;
//        private Color _hubColor1 = Color.FromRgb(224, 224, 224);
//        private Color _hubColor2 = Colors.Transparent;
//        private Color _hubShadowColor = Color.FromArgb(50, 0, 0, 0);
//        private Color _hubHighlightColor = Color.FromArgb(150, 255, 255, 255);
//        private Color _outerBorderColor = Color.FromArgb(120, 80, 80, 80);
//        private double _outerBorderWidth = 1.5d;
//        private Color _outerShadowColor = Color.FromArgb(50, 0, 0, 0);
//        private Color _innerShadowColor = Color.FromArgb(100, 0, 0, 0);
//        private Color _textShadowColor = Color.FromArgb(30, 0, 0, 0);
//        private Color _glassEffectCenterColor = Colors.Transparent;
//        private Color _glassEffectOuterColor = Color.FromArgb(0, 255, 255, 255);
//        private Rect _glassEffectRect = new Rect(0.1, 0.05, 0.8, 0.4);
//        #endregion

//        public Color BackColor { get; set; } = Colors.White;

//        #region --- Properties (Omitted for brevity, identical to original) ---
//        [Category("1. Gauge Core")] public double Value { get => _value; set { _value = Clamp(value, _minValue, _maxValue); InvalidateVisual(); } }
//        public double MinValue { get => _minValue; set { _minValue = value; if (_maxValue < _minValue) _maxValue = _minValue; _value = Clamp(_value, _minValue, _maxValue); InvalidateVisual(); } }
//        public double MaxValue { get => _maxValue; set { _maxValue = Math.Max(value, _minValue); _value = Clamp(_value, _minValue, _maxValue); InvalidateVisual(); } }
//        public string UnitLabel { get => _unitLabel; set { _unitLabel = value ?? ""; InvalidateVisual(); } }
//        public double ScaleStartAngle { get => _scaleStartAngle; set { _scaleStartAngle = value; InvalidateVisual(); } }
//        public double ScaleSweepAngle { get => _scaleSweepAngle; set { _scaleSweepAngle = value; InvalidateVisual(); } }
//        public int GaugePadding { get => _gaugePadding; set { _gaugePadding = value; InvalidateVisual(); } }
//        public double DialPadding { get => _dialPadding; set { _dialPadding = value; InvalidateVisual(); } }
//        public double TickZonePadding { get => _tickZonePadding; set { _tickZonePadding = value; InvalidateVisual(); } }
//        public double TickLabelSpacing { get => _tickLabelSpacing; set { _tickLabelSpacing = value; InvalidateVisual(); } }
//        public Point ValuePosition { get => _valuePosition; set { _valuePosition = value; InvalidateVisual(); } }
//        public double BezelWidthMultiplier { get => _bezelWidthMultiplier; set { _bezelWidthMultiplier = value; InvalidateVisual(); } }
//        public Color DialColor1 { get => _dialColor1; set { _dialColor1 = value; InvalidateVisual(); } }
//        public Color DialColor2 { get => _dialColor2; set { _dialColor2 = value; InvalidateVisual(); } }
//        public Color BezelColor1 { get => _bezelColor1; set { _bezelColor1 = value; InvalidateVisual(); } }
//        public Color BezelColor2 { get => _bezelColor2; set { _bezelColor2 = value; InvalidateVisual(); } }
//        public Color BezelHighlightColor { get => _bezelHighlightColor; set { _bezelHighlightColor = value; InvalidateVisual(); } }
//        public Color BezelShadowColor { get => _bezelShadowColor; set { _bezelShadowColor = value; InvalidateVisual(); } }
//        public double ZoneGreenEndValue { get => _zoneGreenEndValue; set { _zoneGreenEndValue = value; InvalidateVisual(); } }
//        public double ZoneRedStartValue { get => _zoneRedStartValue; set { _zoneRedStartValue = value; InvalidateVisual(); } }
//        public Color ZoneGreenColor { get => _zoneGreenColor; set { _zoneGreenColor = value; InvalidateVisual(); } }
//        public Color ZoneYellowColor { get => _zoneYellowColor; set { _zoneYellowColor = value; InvalidateVisual(); } }
//        public Color ZoneRedColor { get => _zoneRedColor; set { _zoneRedColor = value; InvalidateVisual(); } }
//        public double ZoneThicknessMultiplier { get => _zoneThicknessMultiplier; set { _zoneThicknessMultiplier = value; InvalidateVisual(); } }
//        public double ZoneMinThickness { get => _zoneMinThickness; set { _zoneMinThickness = value; InvalidateVisual(); } }
//        public int MajorTickStep { get => _majorTickStep; set { _majorTickStep = value; InvalidateVisual(); } }
//        public int DesiredTickLabelCount { get => _desiredTickLabelCount; set { _desiredTickLabelCount = value; InvalidateVisual(); } }
//        public int MinorTicksPerMajor { get => _minorTicksPerMajor; set { _minorTicksPerMajor = value; InvalidateVisual(); } }
//        public double MajorTickLengthMultiplier { get => _majorTickLengthMultiplier; set { _majorTickLengthMultiplier = value; InvalidateVisual(); } }
//        public double MinorTickLengthMultiplier { get => _minorTickLengthMultiplier; set { _minorTickLengthMultiplier = value; InvalidateVisual(); } }
//        public double MajorTickWidth { get => _majorTickWidth; set { _majorTickWidth = value; InvalidateVisual(); } }
//        public double MinorTickWidth { get => _minorTickWidth; set { _minorTickWidth = value; InvalidateVisual(); } }
//        public string TickLabelFontFamily { get => _tickLabelFontFamily; set { _tickLabelFontFamily = value; InvalidateVisual(); } }
//        public double TickLabelFontSizeMultiplier { get => _tickLabelFontSizeMultiplier; set { _tickLabelFontSizeMultiplier = value; InvalidateVisual(); } }
//        public double TickLabelMinFontSize { get => _tickLabelMinFontSize; set { _tickLabelMinFontSize = value; InvalidateVisual(); } }
//        public Color TickLabelColor { get => _tickLabelColor; set { _tickLabelColor = value; InvalidateVisual(); } }
//        public Color MajorTickColor { get => _majorTickColor; set { _majorTickColor = value; InvalidateVisual(); } }
//        public Color MinorTickColor { get => _minorTickColor; set { _minorTickColor = value; InvalidateVisual(); } }
//        public string ValueFontFamily { get => _valueFontFamily; set { _valueFontFamily = value; InvalidateVisual(); } }
//        public double ValueFontSizeMultiplier { get => _valueFontSizeMultiplier; set { _valueFontSizeMultiplier = value; InvalidateVisual(); } }
//        public double UnitFontSizeScale { get => _unitFontSizeScale; set { _unitFontSizeScale = value; InvalidateVisual(); } }
//        public double ValueUnitVerticalSpacing { get => _valueUnitVerticalSpacing; set { _valueUnitVerticalSpacing = value; InvalidateVisual(); } }
//        public double ValueMinFontSize { get => _valueMinFontSize; set { _valueMinFontSize = value; InvalidateVisual(); } }
//        public double UnitMinFontSize { get => _unitMinFontSize; set { _unitMinFontSize = value; InvalidateVisual(); } }
//        public Color ValueTextColor { get => _valueTextColor; set { _valueTextColor = value; InvalidateVisual(); } }
//        public Color UnitTextColor { get => _unitTextColor; set { _unitTextColor = value; InvalidateVisual(); } }
//        public NeedleStyle NeedleStyle { get => _needleStyle; set { _needleStyle = value; InvalidateVisual(); } }
//        public int NeedleTransparency { get => _needleTransparency; set { _needleTransparency = value; InvalidateVisual(); } }
//        public double NeedleTipMultiplier { get => _needleTipMultiplier; set { _needleTipMultiplier = value; InvalidateVisual(); } }
//        public double NeedleTailMultiplier { get => _needleTailMultiplier; set { _needleTailMultiplier = value; InvalidateVisual(); } }
//        public double NeedleTailSplitDistanceMultiplier { get => _needleTailSplitDistanceMultiplier; set { _needleTailSplitDistanceMultiplier = value; InvalidateVisual(); } }
//        public double NeedleShoulderDistanceMultiplier { get => _needleShoulderDistanceMultiplier; set { _needleShoulderDistanceMultiplier = value; InvalidateVisual(); } }
//        public double NeedleShoulderWidthMultiplier { get => _needleShoulderWidthMultiplier; set { _needleShoulderWidthMultiplier = value; InvalidateVisual(); } }
//        public double NeedleTailWidthMultiplier { get => _needleTailWidthMultiplier; set { _needleTailWidthMultiplier = value; InvalidateVisual(); } }
//        public double NeedleHighlightWidth { get => _needleHighlightWidth; set { _needleHighlightWidth = value; InvalidateVisual(); } }
//        public double NeedleShadowOffsetMultiplier { get => _needleShadowOffsetMultiplier; set { _needleShadowOffsetMultiplier = value; InvalidateVisual(); } }
//        public Color NeedleColor1 { get => _needleColor1; set { _needleColor1 = value; InvalidateVisual(); } }
//        public Color NeedleColor2 { get => _needleColor2; set { _needleColor2 = value; InvalidateVisual(); } }
//        public Color NeedleHighlightColor1 { get => _needleHighlightColor1; set { _needleHighlightColor1 = value; InvalidateVisual(); } }
//        public Color NeedleHighlightColor2 { get => _needleHighlightColor2; set { _needleHighlightColor2 = value; InvalidateVisual(); } }
//        public Color NeedleShadowColor { get => _needleShadowColor; set { _needleShadowColor = value; InvalidateVisual(); } }
//        public double BlockyNeedleWidthMultiplier { get => _blockyNeedleWidthMultiplier; set { _blockyNeedleWidthMultiplier = value; InvalidateVisual(); } }
//        public double ClassicNeedleBaseWidthMultiplier { get => _classicNeedleBaseWidthMultiplier; set { _classicNeedleBaseWidthMultiplier = value; InvalidateVisual(); } }
//        public double OrnateDiamondSizeMultiplier { get => _ornateDiamondSizeMultiplier; set { _ornateDiamondSizeMultiplier = value; InvalidateVisual(); } }
//        public double OrnateCircleTailRadiusMultiplier { get => _ornateCircleTailRadiusMultiplier; set { _ornateCircleTailRadiusMultiplier = value; InvalidateVisual(); } }
//        public double ArrowheadSizeMultiplier { get => _arrowheadSizeMultiplier; set { _arrowheadSizeMultiplier = value; InvalidateVisual(); } }
//        public double DualLineGapMultiplier { get => _dualLineGapMultiplier; set { _dualLineGapMultiplier = value; InvalidateVisual(); } }
//        public double KiteTailSizeMultiplier { get => _kiteTailSizeMultiplier; set { _kiteTailSizeMultiplier = value; InvalidateVisual(); } }
//        public double IndicatorTipWidthMultiplier { get => _indicatorTipWidthMultiplier; set { _indicatorTipWidthMultiplier = value; InvalidateVisual(); } }
//        public double IndicatorTipLengthMultiplier { get => _indicatorTipLengthMultiplier; set { _indicatorTipLengthMultiplier = value; InvalidateVisual(); } }
//        public Color IndicatorHubColor { get => _indicatorHubColor; set { _indicatorHubColor = value; InvalidateVisual(); } }
//        public Color IndicatorHubHighlightColor { get => _indicatorHubHighlightColor; set { _indicatorHubHighlightColor = value; InvalidateVisual(); } }
//        public double HubSizeMultiplier { get => _hubSizeMultiplier; set { _hubSizeMultiplier = value; InvalidateVisual(); } }
//        public double HubMinSize { get => _hubMinSize; set { _hubMinSize = value; InvalidateVisual(); } }
//        public Color HubColor1 { get => _hubColor1; set { _hubColor1 = value; InvalidateVisual(); } }
//        public Color HubColor2 { get => _hubColor2; set { _hubColor2 = value; InvalidateVisual(); } }
//        public Color HubShadowColor { get => _hubShadowColor; set { _hubShadowColor = value; InvalidateVisual(); } }
//        public Color HubHighlightColor { get => _hubHighlightColor; set { _hubHighlightColor = value; InvalidateVisual(); } }
//        public Color OuterBorderColor { get => _outerBorderColor; set { _outerBorderColor = value; InvalidateVisual(); } }
//        public double OuterBorderWidth { get => _outerBorderWidth; set { _outerBorderWidth = value; InvalidateVisual(); } }
//        public Color OuterShadowColor { get => _outerShadowColor; set { _outerShadowColor = value; InvalidateVisual(); } }
//        public Color InnerShadowColor { get => _innerShadowColor; set { _innerShadowColor = value; InvalidateVisual(); } }
//        public Color TextShadowColor { get => _textShadowColor; set { _textShadowColor = value; InvalidateVisual(); } }
//        public Color GlassEffectCenterColor { get => _glassEffectCenterColor; set { _glassEffectCenterColor = value; InvalidateVisual(); } }
//        public Color GlassEffectOuterColor { get => _glassEffectOuterColor; set { _glassEffectOuterColor = value; InvalidateVisual(); } }
//        public Rect GlassEffectRect { get => _glassEffectRect; set { _glassEffectRect = value; InvalidateVisual(); } }
//        #endregion

//        public SpeedometerControl() { Width = 340; Height = 340; }

//        #region --- WPF Drawing Helpers ---
//        private static Color WithAlpha(Color c, int a) => Color.FromArgb((byte)a, c.R, c.G, c.B);

//        private StreamGeometry PolygonGeometry(Point[] pts, bool filled, bool closed)
//        {
//            var sg = new StreamGeometry();
//            using (var ctx = sg.Open())
//            {
//                ctx.BeginFigure(pts[0], filled, closed);
//                for (int i = 1; i < pts.Length; i++) ctx.LineTo(pts[i], true, false);
//            }
//            return sg;
//        }

//        private StreamGeometry LineGeometry(Point p1, Point p2)
//        {
//            var sg = new StreamGeometry();
//            using (var ctx = sg.Open()) { ctx.BeginFigure(p1, false, false); ctx.LineTo(p2, true, false); }
//            return sg;
//        }

//        private StreamGeometry MultiLineGeometry(Point p1, Point p2, Point p3, Point p4)
//        {
//            var sg = new StreamGeometry();
//            using (var ctx = sg.Open())
//            {
//                ctx.BeginFigure(p1, false, false);
//                ctx.LineTo(p2, true, false);
//                ctx.LineTo(p3, true, false);
//                ctx.LineTo(p4, true, false);
//            }
//            return sg;
//        }

//        private StreamGeometry CurveGeometry(Point[] pts)
//        {
//            var sg = new StreamGeometry();
//            using (var ctx = sg.Open())
//            {
//                ctx.BeginFigure(pts[0], false, false);
//                for (int i = 0; i < pts.Length - 1; i++)
//                {
//                    Point p0 = pts[Math.Max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.Min(pts.Length - 1, i + 2)];
//                    double t = 0.5 / 3.0;
//                    ctx.BezierTo(
//                        new Point(p1.X + (p2.X - p0.X) * t, p1.Y + (p2.Y - p0.Y) * t),
//                        new Point(p2.X - (p3.X - p1.X) * t, p2.Y - (p3.Y - p1.Y) * t),
//                        p2, true, false);
//                }
//            }
//            return sg;
//        }

//        private LinearGradientBrush CreateLinearGradient(Rect rect, Color c1, Color c2, double angle)
//        {
//            double rad = angle * Math.PI / 180.0;
//            double dx = Math.Cos(rad), dy = Math.Sin(rad);
//            double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2;
//            double halfLen = Math.Abs(dx) * (rect.Width / 2) + Math.Abs(dy) * (rect.Height / 2);
//            var b = new LinearGradientBrush();
//            b.StartPoint = new Point(cx - dx * halfLen, cy - dy * halfLen);
//            b.EndPoint = new Point(cx + dx * halfLen, cy + dy * halfLen);
//            b.MappingMode = BrushMappingMode.Absolute;
//            b.GradientStops.Add(new GradientStop(c1, 0));
//            b.GradientStops.Add(new GradientStop(c2, 1));
//            return b;
//        }

//        private RadialGradientBrush CreateRadialGradient(Rect rect, Color centerColor, Color surroundColor, double focusScale)
//        {
//            double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2;
//            double r = Math.Min(rect.Width, rect.Height) / 2;
//            var b = new RadialGradientBrush();
//            b.Center = new Point(cx, cy);
//            b.GradientOrigin = new Point(cx, cy);
//            b.RadiusX = r; b.RadiusY = r;
//            b.MappingMode = BrushMappingMode.Absolute;
//            b.GradientStops.Add(new GradientStop(centerColor, 0.0));
//            if (focusScale > 0 && focusScale < 1) b.GradientStops.Add(new GradientStop(centerColor, focusScale));
//            b.GradientStops.Add(new GradientStop(surroundColor, 1.0));
//            return b;
//        }

//        private FormattedText FormatText(string text, string fontFamily, double size, bool bold, Color color)
//        {
//            var tf = new Typeface(new FontFamily(fontFamily), FontStyles.Normal, bold ? FontWeights.Bold : FontWeights.Normal, FontStretches.Normal);
//            return new FormattedText(text, System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight, tf, size, new SolidColorBrush(color), 1.0);
//        }

//        private void DrawArc(DrawingContext g, Pen pen, Rect rect, double startAngle, double sweepAngle)
//        {
//            if (Math.Abs(sweepAngle) < 0.001) return;
//            double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2;
//            double rx = rect.Width / 2, ry = rect.Height / 2;
//            double sRad = startAngle * Math.PI / 180.0;
//            double eRad = (startAngle + sweepAngle) * Math.PI / 180.0;
//            Point sp = new Point(cx + rx * Math.Cos(sRad), cy + ry * Math.Sin(sRad));
//            Point ep = new Point(cx + rx * Math.Cos(eRad), cy + ry * Math.Sin(eRad));
//            var sg = new StreamGeometry();
//            using (var ctx = sg.Open())
//            {
//                ctx.BeginFigure(sp, false, false);
//                ctx.ArcTo(ep, new Size(rx, ry), 0, Math.Abs(sweepAngle) > 180, sweepAngle > 0 ? SweepDirection.Clockwise : SweepDirection.Counterclockwise, true, false);
//            }
//            g.DrawGeometry(null, pen, sg);
//        }

//        private static Rect Inflate(Rect r, double dx, double dy) => new Rect(r.X - dx, r.Y - dy, r.Width + 2 * dx, r.Height + 2 * dy);
//        #endregion

//        #region --- Drawing Methods ---
//        protected override void OnRender(DrawingContext g)
//        {
//            base.OnRender(g);
//            g.DrawRectangle(new SolidColorBrush(BackColor), null, new Rect(0, 0, ActualWidth, ActualHeight));

//            var bounds = new Rect(0, 0, ActualWidth, ActualHeight);
//            double baseSize = Math.Min(bounds.Width, bounds.Height);
//            _scale = baseSize / 340.0;
//            if (_scale <= 0) return;

//            double size = baseSize - GaugePadding * 2 * _scale;
//            if (size <= 8 * _scale) return;

//            double left = bounds.Left + (bounds.Width - size) / 2;
//            double top = bounds.Top + (bounds.Height - size) / 2;
//            var dialRect = new Rect(left, top, size, size);

//            DrawOuterShadow(g, dialRect);
//            DrawFace(g, dialRect);
//            DrawBezel(g, dialRect);
//            DrawInnerBezelShadow(g, dialRect);
//            DrawZones(g, dialRect);
//            DrawTicks(g, dialRect);
//            DrawNeedle(g, dialRect);
//            DrawValueLabel(g, dialRect);
//            DrawThinBorder(g, dialRect);
//            DrawGlassEffect(g, dialRect);
//        }

//        private void DrawOuterShadow(DrawingContext g, Rect rect)
//        {
//            var shadowRect = Inflate(rect, rect.Width * 0.03, rect.Height * 0.03);
//            var eg = new EllipseGeometry(shadowRect);
//            var brush = CreateRadialGradient(shadowRect, OuterShadowColor, WithAlpha(OuterShadowColor, 0), 0.85);
//            g.DrawGeometry(brush, null, eg);
//        }

//        private void DrawFace(DrawingContext g, Rect rect)
//        {
//            var eg = new EllipseGeometry(rect);
//            var brush = CreateRadialGradient(rect, DialColor1, DialColor2, 0.7);
//            g.DrawGeometry(brush, null, eg);
//        }

//        private void DrawBezel(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            double w = Math.Max(4 * _scale, r * BezelWidthMultiplier);
//            var rr = Inflate(rect, -w / 2, -w / 2);
//            var eg = new EllipseGeometry(rr);

//            g.DrawGeometry(CreateLinearGradient(rect, _bezelColor1, _bezelColor2, 45), null, eg);
//            g.DrawGeometry(CreateLinearGradient(rect, _bezelHighlightColor, Colors.Transparent, 225), null, eg);
//            g.DrawGeometry(CreateLinearGradient(rect, Colors.Transparent, _bezelShadowColor, 45), null, eg);
//        }

//        private void DrawInnerBezelShadow(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            double w = Math.Max(4 * _scale, r * BezelWidthMultiplier);
//            var sr = Inflate(rect, -w * 0.9, -w * 0.9);

//            var outerEG = new EllipseGeometry(rect);
//            var innerEG = new EllipseGeometry(sr);
//            var combined = new CombinedGeometry(GeometryCombineMode.Exclude, outerEG, innerEG);
//            var brush = CreateRadialGradient(rect, InnerShadowColor, WithAlpha(InnerShadowColor, 0), 0);
//            g.DrawGeometry(brush, null, combined);
//        }

//        private void DrawGlassEffect(DrawingContext g, Rect rect)
//        {
//            var eff = GlassEffectRect;
//            var hr = new Rect(rect.Left + rect.Width * eff.X, rect.Top + rect.Height * eff.Y, rect.Width * eff.Width, rect.Height * eff.Height);
//            var eg = new EllipseGeometry(hr);
//            var brush = CreateRadialGradient(hr, GlassEffectCenterColor, GlassEffectOuterColor, 0.5);
//            g.DrawGeometry(brush, null, eg);
//        }

//        private void DrawZones(DrawingContext g, Rect rect)
//        {
//            double gs = SpanForRange(MinValue, ZoneGreenEndValue);
//            double ys = SpanForRange(ZoneGreenEndValue, ZoneRedStartValue);
//            double rs = SpanForRange(ZoneRedStartValue, MaxValue);
//            double r = rect.Width * 0.5;
//            double bw = r * BezelWidthMultiplier;
//            double zt = Math.Max(ZoneMinThickness * _scale, r * ZoneThicknessMultiplier);
//            double ti = bw + DialPadding * _scale + (zt / 2);
//            var zr = Inflate(rect, -ti, -ti);

//            var pG = new Pen(new SolidColorBrush(ZoneGreenColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
//            var pY = new Pen(new SolidColorBrush(ZoneYellowColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
//            var pR = new Pen(new SolidColorBrush(ZoneRedColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };

//            if (gs > 0) DrawArc(g, pG, zr, ScaleStartAngle, gs);
//            if (ys > 0) DrawArc(g, pY, zr, ScaleStartAngle + gs, ys);
//            if (rs > 0) DrawArc(g, pR, zr, ScaleStartAngle + gs + ys, rs);
//        }

//        private void DrawTicks(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double vr = Math.Max(1, MaxValue - MinValue);
//            int M = (MajorTickStep > 0) ? MajorTickStep : NiceNumber((float)(vr / Math.Max(1, DesiredTickLabelCount)));
//            int m = Math.Max(1, M / Math.Max(1, MinorTicksPerMajor));
//            double bw = r * BezelWidthMultiplier;
//            double zt = Math.Max(ZoneMinThickness * _scale, r * ZoneThicknessMultiplier);
//            double ot = bw + DialPadding * _scale + zt + TickZonePadding * _scale;
//            double Mtl = r * MajorTickLengthMultiplier;
//            double mtl = r * MinorTickLengthMultiplier;
//            double Mit = ot + Mtl;
//            double mit = ot + mtl;
//            double fs = Math.Max(TickLabelMinFontSize, r * TickLabelFontSizeMultiplier); // NO _scale on MinFontSize

//            var Mp = new Pen(new SolidColorBrush(MajorTickColor), MajorTickWidth * _scale);
//            var mp = new Pen(new SolidColorBrush(MinorTickColor), MinorTickWidth * _scale);

//            for (int v = (int)(Math.Ceiling(MinValue / m) * m); v <= (int)(Math.Floor(MaxValue / m) * m); v += m)
//            {
//                bool iM = (v % M == 0);
//                g.DrawLine(iM ? Mp : mp, PointOnCircle(c, r - ot, v), PointOnCircle(c, r - (iM ? Mit : mit), v));
//            }

//            for (int v = (int)(Math.Ceiling(MinValue / M) * M); v <= MaxValue; v += M)
//                DrawLabelAtValue(g, c, r, v, Mit, fs);

//            DrawLabelAtValue(g, c, r, (int)MinValue, Mit, fs);
//            DrawLabelAtValue(g, c, r, (int)MaxValue, Mit, fs);
//        }

//        private void DrawLabelAtValue(DrawingContext g, Point c, double r, int v, double t, double fs)
//        {
//            string l = v.ToString();
//            var ft = FormatText(l, TickLabelFontFamily, fs, true, Colors.Black);
//            var s = new Size(ft.Width, ft.Height);
//            double lci = t + TickLabelSpacing * _scale + (s.Height / 2);
//            var p = PointOnCircle(c, r - lci, v);

//            g.DrawText(FormatText(l, TickLabelFontFamily, fs, true, TextShadowColor), new Point(p.X - s.Width / 2 + 1 * _scale, p.Y - s.Height / 2 + 1 * _scale));
//            g.DrawText(FormatText(l, TickLabelFontFamily, fs, true, TickLabelColor), new Point(p.X - s.Width / 2, p.Y - s.Height / 2));
//        }

//        private void DrawValueLabel(DrawingContext g, Rect rect)
//        {
//            string vt = ((int)_value).ToString();
//            string ut = _unitLabel;
//            double r = rect.Width * 0.5;
//            var bc = new Point(rect.Left + rect.Width * ValuePosition.X, rect.Top + rect.Height * ValuePosition.Y);
//            double fsv = Math.Max(ValueMinFontSize, r * ValueFontSizeMultiplier); // NO _scale on MinFontSize
//            double fsu = Math.Max(UnitMinFontSize, fsv * UnitFontSizeScale); // NO _scale on MinFontSize

//            var vft = FormatText(vt, ValueFontFamily, fsv, true, Colors.Black);
//            var uft = FormatText(ut, ValueFontFamily, fsu, false, Colors.Black);

//            // Add padding to emulate WinForms text measurement so -12 spacing works correctly
//            var vs = new Size(vft.Width, vft.Height + 4 * _scale);
//            var us = new Size(uft.Width, uft.Height + 4 * _scale);

//            double tbh = vs.Height + us.Height + ValueUnitVerticalSpacing * _scale;
//            double vty = bc.Y - tbh / 2;
//            double uty = vty + vs.Height + ValueUnitVerticalSpacing * _scale;

//            g.DrawText(FormatText(vt, ValueFontFamily, fsv, true, ValueTextColor), new Point(bc.X - vs.Width / 2, vty));
//            g.DrawText(FormatText(ut, ValueFontFamily, fsu, false, UnitTextColor), new Point(bc.X - us.Width / 2, uty));
//        }

//        private void DrawThinBorder(DrawingContext g, Rect rect)
//        {
//            var pen = new Pen(new SolidColorBrush(OuterBorderColor), OuterBorderWidth * _scale);
//            var center = new Point(rect.X + rect.Width / 2, rect.Y + rect.Height / 2);
//            g.DrawEllipse(null, pen, center, rect.Width / 2, rect.Height / 2);
//        }
//        #endregion

//        #region --- Needle Drawing Logic ---
//        private void DrawNeedle(DrawingContext g, Rect rect)
//        {
//            switch (NeedleStyle)
//            {
//                case NeedleStyle.ModernIndicator: DrawNeedle_ModernIndicator(g, rect); break;
//                case NeedleStyle.ClassicTapered: DrawNeedle_ClassicTapered(g, rect); break;
//                case NeedleStyle.ClassicWide: DrawNeedle_ClassicWide(g, rect); break;
//                case NeedleStyle.OrnateDiamond: DrawNeedle_OrnateDiamond(g, rect); break;
//                case NeedleStyle.ModernSleek: DrawNeedle_ModernSleek(g, rect); break;
//                case NeedleStyle.ModernCutout: DrawNeedle_ModernCutout(g, rect); break;
//                case NeedleStyle.ModernDualLine: DrawNeedle_ModernDualLine(g, rect); break;
//                case NeedleStyle.Arrowhead: DrawNeedle_Arrowhead(g, rect); break;
//                case NeedleStyle.Broadhead: DrawNeedle_Broadhead(g, rect); break;
//                case NeedleStyle.CrossbowBolt: DrawNeedle_CrossbowBolt(g, rect); break;
//                case NeedleStyle.VintageThinWithTail: DrawNeedle_VintageThinWithTail(g, rect); break;
//                case NeedleStyle.VintageArtDeco: DrawNeedle_VintageArtDeco(g, rect); break;
//                case NeedleStyle.VintageCrescentTail: DrawNeedle_VintageCrescentTail(g, rect); break;
//                case NeedleStyle.VintageAviator: DrawNeedle_VintageAviator(g, rect); break;
//                case NeedleStyle.OrnateSpearTip: DrawNeedle_OrnateSpearTip(g, rect); break;
//                case NeedleStyle.OrnateFleurDeLis: DrawNeedle_OrnateFleurDeLis(g, rect); break;
//                case NeedleStyle.OrnateSword: DrawNeedle_OrnateSword(g, rect); break;
//                case NeedleStyle.CompassNorth: DrawNeedle_CompassNorth(g, rect); break;
//                case NeedleStyle.AnchorTail: DrawNeedle_AnchorTail(g, rect); break;
//                case NeedleStyle.Harpoon: DrawNeedle_Harpoon(g, rect); break;
//                case NeedleStyle.SciFiArrow: DrawNeedle_SciFiArrow(g, rect); break;
//                case NeedleStyle.SciFiDataSpike: DrawNeedle_SciFiDataSpike(g, rect); break;
//                case NeedleStyle.EnergyBlade: DrawNeedle_EnergyBlade(g, rect); break;
//                case NeedleStyle.SimplePin: DrawNeedle_SimplePin(g, rect); break;
//                case NeedleStyle.ModernThin:
//                default: DrawNeedle_ModernThin(g, rect); break;
//            }
//        }

//        private void DrawNeedleShadowAndFill(DrawingContext g, Geometry path, double angle, double radius)
//        {
//            double offset = radius * NeedleShadowOffsetMultiplier;
//            g.PushTransform(new TranslateTransform(offset, offset));
//            g.DrawGeometry(new SolidColorBrush(NeedleShadowColor), null, path);
//            g.Pop();

//            var bounds = path.Bounds;
//            var brush = CreateLinearGradient(bounds, WithAlpha(NeedleColor1, NeedleTransparency), WithAlpha(NeedleColor2, NeedleTransparency), angle + 90);
//            g.DrawGeometry(brush, null, path);
//        }

//        private void DrawNeedleShadowAndFill(DrawingContext g, Pen pen, Geometry path, double angle, double radius)
//        {
//            double offset = radius * NeedleShadowOffsetMultiplier;
//            g.PushTransform(new TranslateTransform(offset, offset));
//            g.DrawGeometry(null, new Pen(new SolidColorBrush(NeedleShadowColor), pen.Thickness), path);
//            g.Pop();
//            g.DrawGeometry(null, pen, path);
//        }

//        private void DrawNeedleHub(DrawingContext g, Point center, double radius)
//        {
//            double hr = Math.Max(HubMinSize * _scale, radius * HubSizeMultiplier);
//            var hrect = new Rect(center.X - hr, center.Y - hr, hr * 2, hr * 2);
//            var eg = new EllipseGeometry(hrect);

//            g.DrawGeometry(CreateLinearGradient(hrect, HubColor1, HubColor2, 45), null, eg);

//            var innerRect = Inflate(hrect, -2 * _scale, -2 * _scale);
//            g.DrawEllipse(null, new Pen(new SolidColorBrush(HubHighlightColor), 1 * _scale),
//                new Point(innerRect.X + innerRect.Width / 2, innerRect.Y + innerRect.Height / 2),
//                innerRect.Width / 2, innerRect.Height / 2);

//            g.DrawEllipse(null, new Pen(new SolidColorBrush(HubShadowColor), 2 * _scale),
//                new Point(hrect.X + hrect.Width / 2, hrect.Y + hrect.Height / 2),
//                hrect.Width / 2, hrect.Height / 2);
//        }

//        private void DrawNeedleHub_IndicatorStyle(DrawingContext g, Point center, double radius)
//        {
//            double hr = Math.Max(HubMinSize * _scale, radius * HubSizeMultiplier);
//            var hrect = new Rect(center.X - hr, center.Y - hr, hr * 2, hr * 2);
//            var eg = new EllipseGeometry(hrect);
//            g.DrawGeometry(new SolidColorBrush(IndicatorHubColor), null, eg);

//            var irect = Inflate(hrect, -hr * 0.1, -hr * 0.1);
//            var ieg = new EllipseGeometry(irect);
//            var brush = CreateRadialGradient(irect, IndicatorHubHighlightColor, Colors.Transparent, 0);
//            g.DrawGeometry(brush, null, ieg);
//        }

//        private void DrawNeedle_ModernIndicator(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

//            var linePen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale);
//            g.DrawLine(linePen, c, t);

//            double tl = r * IndicatorTipLengthMultiplier;
//            double tw = r * IndicatorTipWidthMultiplier;
//            var perp = GetPerpendicularVector(a);
//            var tb = PointOnCircle(c, r * NeedleTipMultiplier - tl, Value);
//            var p1 = new Point(t.X - perp.X * tw / 2, t.Y - perp.Y * tw / 2);
//            var p2 = new Point(t.X + perp.X * tw / 2, t.Y + perp.Y * tw / 2);
//            var p3 = new Point(tb.X + perp.X * tw / 2, tb.Y + perp.Y * tw / 2);
//            var p4 = new Point(tb.X - perp.X * tw / 2, tb.Y - perp.Y * tw / 2);

//            var path = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
//            g.DrawGeometry(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), null, path);

//            DrawNeedleHub_IndicatorStyle(g, c, r);
//        }

//        private void DrawNeedle_ModernThin(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var d = GetDirectionVector(a);
//            var p = new Point(-d.Y, d.X);
//            var t = new Point(c.X + d.X * (r * NeedleTipMultiplier), c.Y + d.Y * (r * NeedleTipMultiplier));
//            var sl = new Point(c.X + d.X * (r * NeedleShoulderDistanceMultiplier) - p.X * (r * NeedleShoulderWidthMultiplier), c.Y + d.Y * (r * NeedleShoulderDistanceMultiplier) - p.Y * (r * NeedleShoulderWidthMultiplier));
//            var sr = new Point(c.X + d.X * (r * NeedleShoulderDistanceMultiplier) + p.X * (r * NeedleShoulderWidthMultiplier), c.Y + d.Y * (r * NeedleShoulderDistanceMultiplier) + p.Y * (r * NeedleShoulderWidthMultiplier));
//            var tl = new Point(c.X - d.X * (r * NeedleTailSplitDistanceMultiplier) - p.X * (r * NeedleTailWidthMultiplier), c.Y - d.Y * (r * NeedleTailSplitDistanceMultiplier) - p.Y * (r * NeedleTailWidthMultiplier));
//            var tr = new Point(c.X - d.X * (r * NeedleTailSplitDistanceMultiplier) + p.X * (r * NeedleTailWidthMultiplier), c.Y - d.Y * (r * NeedleTailSplitDistanceMultiplier) + p.Y * (r * NeedleTailWidthMultiplier));
//            var tc = new Point(c.X - d.X * (r * NeedleTailMultiplier), c.Y - d.Y * (r * NeedleTailMultiplier));

//            var path = PolygonGeometry(new[] { t, sr, tr, tc, tl, sl }, true, true);
//            DrawNeedleShadowAndFill(g, path, a, r);

//            var hp = PolygonGeometry(new[] { sl, t, sr }, false, false);
//            var lgb = CreateLinearGradient(path.Bounds, NeedleHighlightColor1, NeedleHighlightColor2, a);
//            g.DrawGeometry(null, new Pen(lgb, NeedleHighlightWidth * _scale), hp);

//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_SimplePin(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

//            var path = LineGeometry(c, t);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), path, a, r);

//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_ClassicTapered(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double bw = r * ClassicNeedleBaseWidthMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
//            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

//            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
//            DrawNeedleShadowAndFill(g, path, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_ClassicWide(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var d = GetDirectionVector(a);
//            var p = new Point(-d.Y, d.X);
//            double bw = r * ClassicNeedleBaseWidthMultiplier;
//            double tw = bw * 0.2;
//            var tl = new Point(c.X + d.X * (r * NeedleTipMultiplier) - p.X * tw / 2, c.Y + d.Y * (r * NeedleTipMultiplier) - p.Y * tw / 2);
//            var tr = new Point(c.X + d.X * (r * NeedleTipMultiplier) + p.X * tw / 2, c.Y + d.Y * (r * NeedleTipMultiplier) + p.Y * tw / 2);
//            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
//            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

//            var path = PolygonGeometry(new[] { tr, br, bl, tl }, true, true);
//            DrawNeedleShadowAndFill(g, path, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_OrnateDiamond(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double ds = r * OrnateDiamondSizeMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var mp = PointOnCircle(c, r * NeedleTipMultiplier - ds, Value);
//            var sl = new Point(mp.X - p.X * ds / 2, mp.Y - p.Y * ds / 2);
//            var sr = new Point(mp.X + p.X * ds / 2, mp.Y + p.Y * ds / 2);
//            var bp = PointOnCircle(c, r * NeedleTipMultiplier - ds * 2, Value);

//            var linePath = LineGeometry(c, bp);
//            var polyPath = PolygonGeometry(new[] { t, sr, bp, sl }, true, true);
//            var combined = new GeometryGroup();
//            combined.Children.Add(linePath);
//            combined.Children.Add(polyPath);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), combined, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_OrnateCircleTail(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double bw = r * ClassicNeedleBaseWidthMultiplier * 0.5;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
//            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

//            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
//            DrawNeedleShadowAndFill(g, path, a, r);

//            double tr = r * OrnateCircleTailRadiusMultiplier;
//            var tp = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
//            var trect = new Rect(tp.X - tr, tp.Y - tr, tr * 2, tr * 2);
//            g.DrawEllipse(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), null,
//                new Point(tp.X, tp.Y), tr, tr);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_ModernTriangle(DrawingContext g, Rect rect) => DrawNeedle_ClassicTapered(g, rect);

//        private void DrawNeedle_ModernDualLine(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double gap = r * DualLineGapMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var p1s = new Point(c.X - p.X * gap, c.Y - p.Y * gap);
//            var p1e = new Point(t.X - p.X * gap, t.Y - p.Y * gap);
//            var p2s = new Point(c.X + p.X * gap, c.Y + p.Y * gap);
//            var p2e = new Point(t.X + p.X * gap, t.Y + p.Y * gap);

//            var pen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale);
//            g.DrawLine(pen, p1s, p1e);
//            g.DrawLine(pen, p2s, p2e);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_ModernCutout(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double bw = r * BlockyNeedleWidthMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var p1 = new Point(t.X - p.X * bw / 4, t.Y - p.Y * bw / 4);
//            var p2 = new Point(t.X + p.X * bw / 4, t.Y + p.Y * bw / 4);
//            var p3 = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);
//            var p4 = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
//            var cp1 = PointOnCircle(c, r * 0.5, Value);
//            var cp2 = PointOnCircle(c, r * 0.3, Value);
//            var cp3 = new Point(cp2.X + p.X * bw / 4, cp2.Y + p.Y * bw / 4);
//            var cp4 = new Point(cp2.X - p.X * bw / 4, cp2.Y - p.Y * bw / 4);

//            var outerPath = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
//            var innerPath = PolygonGeometry(new[] { cp1, cp3, cp4 }, true, true);
//            var combined = new CombinedGeometry(GeometryCombineMode.Exclude, outerPath, innerPath);
//            DrawNeedleShadowAndFill(g, combined, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_VintageThinWithTail(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var tip = PointOnCircle(c, r * NeedleTipMultiplier, Value);

//            var linePath = LineGeometry(c, tip);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), linePath, a, r);

//            var perp = GetPerpendicularVector(a);
//            double ts = r * KiteTailSizeMultiplier;
//            var te = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
//            var p1 = new Point(te.X - perp.X * ts / 2, te.Y - perp.Y * ts / 2);
//            var p2 = new Point(te.X + perp.X * ts / 2, te.Y + perp.Y * ts / 2);

//            var tailPath = PolygonGeometry(new[] { c, p2, p1 }, true, true);
//            DrawNeedleShadowAndFill(g, tailPath, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_VintageArtDeco(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double bw = r * ClassicNeedleBaseWidthMultiplier;

//            var p1 = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var p2 = PointOnCircle(c, r * 0.6, Value);
//            var p3 = new Point(p2.X + p.X * bw * 0.2, p2.Y + p.Y * bw * 0.2);
//            var p4 = new Point(p2.X - p.X * bw * 0.2, p2.Y - p.Y * bw * 0.2);
//            var p5 = PointOnCircle(c, r * 0.5, Value);
//            var p6 = new Point(p5.X + p.X * bw * 0.4, p5.Y + p.Y * bw * 0.4);
//            var p7 = new Point(p5.X - p.X * bw * 0.4, p5.Y - p.Y * bw * 0.4);
//            var p8 = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);
//            var p9 = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);

//            var path = PolygonGeometry(new[] { p1, p3, p6, p8, p9, p7, p4 }, true, true);
//            DrawNeedleShadowAndFill(g, path, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_VintageCrescentTail(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            DrawNeedle_ClassicTapered(g, rect);
//            double tr = r * OrnateCircleTailRadiusMultiplier * 1.5;
//            var tp = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
//            g.DrawEllipse(new SolidColorBrush(BackColor), null, new Point(tp.X, tp.Y), tr, tr);
//        }

//        private void DrawNeedle_OrnateSpearTip(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            double ss = r * ArrowheadSizeMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var boh = PointOnCircle(c, r * NeedleTipMultiplier - ss, Value);
//            var b1 = PointOnCircle(boh, ss * 0.8, Value, 150);
//            var b2 = PointOnCircle(boh, ss * 0.8, Value, -150);

//            var linePath = LineGeometry(c, boh);
//            var polyPath = PolygonGeometry(new[] { t, b2, boh, b1 }, true, true);
//            var combined = new GeometryGroup();
//            combined.Children.Add(linePath);
//            combined.Children.Add(polyPath);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), combined, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_OrnateFleurDeLis(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

//            var linePath = LineGeometry(c, t);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), linePath, a, r);

//            double ts = r * KiteTailSizeMultiplier * 1.5;
//            var tb = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
//            var p1 = PointOnCircle(tb, ts * 0.5, Value, 180);
//            var p2 = PointOnCircle(tb, ts, Value, 180 + 90);
//            var p3 = PointOnCircle(tb, ts, Value, 180 - 90);

//            var curvePath = CurveGeometry(new[] { p2, p1, p3 });
//            g.DrawGeometry(null, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), curvePath);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_OrnateSword(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double bw = r * ClassicNeedleBaseWidthMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var m1 = PointOnCircle(c, r * 0.6, Value);
//            var m2 = PointOnCircle(c, r * 0.5, Value);
//            var h1 = new Point(m2.X + p.X * bw / 2, m2.Y + p.Y * bw / 2);
//            var h2 = new Point(m2.X - p.X * bw / 2, m2.Y - p.Y * bw / 2);

//            var path = MultiLineGeometry(t, m1, h1, h2);
//            var path2 = LineGeometry(m2, c);
//            var combined = new GeometryGroup();
//            combined.Children.Add(path);
//            combined.Children.Add(path2);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), combined, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_SciFiArrow(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            double hs = r * ArrowheadSizeMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var p2 = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value, -2);
//            var p3 = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value, 2);
//            var p4 = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);

//            var path = PolygonGeometry(new[] { t, p3, p4, p2 }, true, true);
//            DrawNeedleShadowAndFill(g, path, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_SciFiDataSpike(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var p1 = PointOnCircle(c, r * 0.6, Value, 2);
//            var p2 = PointOnCircle(c, r * 0.6, Value, -2);
//            var p3 = PointOnCircle(c, r * 0.3, Value, 4);
//            var p4 = PointOnCircle(c, r * 0.3, Value, -4);

//            var path = PolygonGeometry(new[] { t, p1, p3, c, p4, p2 }, true, true);
//            DrawNeedleShadowAndFill(g, path, MapValueToAngle(Value), r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_EnergyBlade(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double bw = r * BlockyNeedleWidthMultiplier * 0.5;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
//            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

//            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
//            var bounds = path.Bounds;
//            var brush = new RadialGradientBrush();
//            brush.Center = new Point(bounds.X + bounds.Width / 2, bounds.Y + bounds.Height / 2);
//            brush.GradientOrigin = brush.Center;
//            brush.RadiusX = Math.Max(bounds.Width, bounds.Height) / 2;
//            brush.RadiusY = brush.RadiusX;
//            brush.MappingMode = BrushMappingMode.Absolute;
//            brush.GradientStops.Add(new GradientStop(Colors.White, 0));
//            brush.GradientStops.Add(new GradientStop(WithAlpha(NeedleColor1, NeedleTransparency), 1));
//            g.DrawGeometry(brush, null, path);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_ModernSleek(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var s1 = new Point(c.X + p.X * r * 0.05, c.Y + p.Y * r * 0.05);
//            var s2 = new Point(c.X - p.X * r * 0.05, c.Y - p.Y * r * 0.05);
//            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);

//            var path = CurveGeometry(new[] { tail, s2, t, s1, tail });
//            DrawNeedleShadowAndFill(g, path, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_Arrowhead(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            double hs = r * ArrowheadSizeMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var boh = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
//            var p = GetPerpendicularVector(a);
//            var p1 = new Point(boh.X - p.X * hs / 2, boh.Y - p.Y * hs / 2);
//            var p2 = new Point(boh.X + p.X * hs / 2, boh.Y + p.Y * hs / 2);

//            var linePath = LineGeometry(c, boh);
//            var polyPath = PolygonGeometry(new[] { t, p2, p1 }, true, true);
//            var combined = new GeometryGroup();
//            combined.Children.Add(linePath);
//            combined.Children.Add(polyPath);
//            DrawNeedleShadowAndFill(g, combined, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_Broadhead(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            double hs = r * ArrowheadSizeMultiplier * 1.5;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var n = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
//            var p = GetPerpendicularVector(a);
//            var b1 = new Point(n.X + p.X * hs * 0.4, n.Y + p.Y * hs * 0.4);
//            var b2 = new Point(n.X - p.X * hs * 0.4, n.Y - p.Y * hs * 0.4);
//            var back = PointOnCircle(c, r * NeedleTipMultiplier - hs * 1.2, Value);

//            var linePath = LineGeometry(c, back);
//            var polyPath = PolygonGeometry(new[] { t, b1, back, b2 }, true, true);
//            var combined = new GeometryGroup();
//            combined.Children.Add(linePath);
//            combined.Children.Add(polyPath);
//            DrawNeedleShadowAndFill(g, combined, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_CrossbowBolt(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            double hs = r * ArrowheadSizeMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var boh = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
//            var p = GetPerpendicularVector(a);
//            var p1 = new Point(boh.X - p.X * hs / 3, boh.Y - p.Y * hs / 3);
//            var p2 = new Point(boh.X + p.X * hs / 3, boh.Y + p.Y * hs / 3);
//            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
//            var f1 = new Point(tail.X - p.X * hs / 2, tail.Y - p.Y * hs / 2);
//            var f2 = new Point(tail.X + p.X * hs / 2, tail.Y + p.Y * hs / 2);

//            var path = PolygonGeometry(new[] { t, p2, f2, f1, p1 }, true, true);
//            DrawNeedleShadowAndFill(g, path, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_VintageAviator(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
//            var p = GetPerpendicularVector(a);
//            double w = r * 0.05;
//            var p1 = new Point(t.X - p.X * w, t.Y - p.Y * w);
//            var p2 = new Point(t.X + p.X * w, t.Y + p.Y * w);
//            var p3 = new Point(tail.X + p.X * w * 2, tail.Y + p.Y * w * 2);
//            var p4 = new Point(tail.X - p.X * w * 2, tail.Y - p.Y * w * 2);

//            var path = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
//            DrawNeedleShadowAndFill(g, path, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_Harpoon(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            double hs = r * ArrowheadSizeMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var n = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
//            var b1 = PointOnCircle(n, hs * 0.5, Value, 150);
//            var b2 = PointOnCircle(n, hs * 0.5, Value, -150);

//            var mainLine = LineGeometry(c, t);
//            var barb1 = LineGeometry(b1, n);
//            var barb2 = LineGeometry(n, b2);
//            var combined = new GeometryGroup();
//            combined.Children.Add(mainLine);
//            combined.Children.Add(barb1);
//            combined.Children.Add(barb2);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), combined, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_CompassNorth(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double s = r * ClassicNeedleBaseWidthMultiplier / 2;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
//            var p1 = new Point(c.X - p.X * s, c.Y - p.Y * s);
//            var p2 = new Point(c.X + p.X * s, c.Y + p.Y * s);

//            var halfPath = PolygonGeometry(new[] { t, p2, c, p1 }, true, true);
//            g.DrawGeometry(new SolidColorBrush(WithAlpha(NeedleColor2, NeedleTransparency)), null, halfPath);

//            var fullPath = PolygonGeometry(new[] { t, p2, tail, p1 }, true, false);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), fullPath, a, r);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_AnchorTail(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            DrawNeedle_SimplePin(g, rect);
//            double ts = r * KiteTailSizeMultiplier * 1.5;
//            var tb = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
//            var te = PointOnCircle(tb, ts * 0.5, Value, 180);
//            var p1 = PointOnCircle(te, ts, Value, 180 + 90);
//            var p2 = PointOnCircle(te, ts, Value, 180 - 90);

//            var path = MultiLineGeometry(tb, te, p1, p2);
//            var pen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 4 * _scale)
//            { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
//            g.DrawGeometry(null, pen, path);
//            DrawNeedleHub(g, c, r);
//        }

//        private void DrawNeedle_SciFiHollow(DrawingContext g, Rect rect)
//        {
//            double r = rect.Width * 0.5;
//            var c = new Point(rect.Left + r, rect.Top + r);
//            double a = MapValueToAngle(Value);
//            var p = GetPerpendicularVector(a);
//            double bw = r * BlockyNeedleWidthMultiplier;
//            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
//            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
//            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

//            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
//            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), path, a, r);
//            DrawNeedleHub(g, c, r);
//        }
//        #endregion

//        #region --- Helper Methods ---
//        private double MapValueToAngle(double v)
//        {
//            double r = MaxValue - MinValue;
//            return r <= 0 ? ScaleStartAngle : ScaleStartAngle + (Clamp(v, MinValue, MaxValue) - MinValue) / r * ScaleSweepAngle;
//        }

//        private Point PointOnCircle(Point c, double r, double v)
//        {
//            double a = MapValueToAngle(v);
//            double rad = DegToRad(a);
//            return new Point(c.X + Math.Cos(rad) * r, c.Y + Math.Sin(rad) * r);
//        }

//        private Point PointOnCircle(Point c, double r, double v, double angleOffset)
//        {
//            double a = MapValueToAngle(v) + angleOffset;
//            double rad = DegToRad(a);
//            return new Point(c.X + Math.Cos(rad) * r, c.Y + Math.Sin(rad) * r);
//        }

//        private static double Clamp(double v, double min, double max) => Math.Max(min, Math.Min(max, v));

//        private double SpanForRange(double from, double to)
//        {
//            double t = MaxValue - MinValue;
//            return t <= 0 ? 0 : (Clamp(to, MinValue, MaxValue) - Clamp(from, MinValue, MaxValue)) / t * ScaleSweepAngle;
//        }

//        private static double DegToRad(double deg) => (Math.PI / 180.0) * deg;

//        private static int NiceNumber(float raw)
//        {
//            if (raw <= 0) return 1;
//            double exp = Math.Floor(Math.Log10(raw));
//            double p = Math.Pow(10.0, exp);
//            double n = raw / p, nf;
//            if (n <= 1.0) nf = 1.0;
//            else if (n <= 2.0) nf = 2.0;
//            else if (n <= 5.0) nf = 5.0;
//            else nf = 10.0;
//            return Math.Max(1, (int)(nf * p));
//        }

//        private Point GetDirectionVector(double a)
//        {
//            double rad = DegToRad(a);
//            return new Point(Math.Cos(rad), Math.Sin(rad));
//        }

//        private Point GetPerpendicularVector(double a)
//        {
//            double rad = DegToRad(a);
//            return new Point(-Math.Sin(rad), Math.Cos(rad));
//        }
//        #endregion
//    }
//}



















using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Media;

namespace SpeedoMeter
{
    public enum NeedleStyle
    {
        ModernIndicator, ModernThin, ModernBlocky, ModernSleek, ModernCutout,
        ModernDualLine, ClassicTapered, ClassicWide, Arrowhead, Broadhead,
        CrossbowBolt, VintageThinWithTail, VintageArtDeco, VintageCrescentTail,
        VintageAviator, OrnateDiamond, OrnateSpearTip, OrnateFleurDeLis,
        OrnateSword, CompassNorth, AnchorTail, Harpoon, SciFiArrow,
        SciFiDataSpike, EnergyBlade, SimplePin, KiteTail
    }

#if RELEASE
    [DebuggerStepThrough]
#endif
    public partial class SpeedometerControl : FrameworkElement
    {
        private double _scale = 1.0;

        #region --- Backing Fields ---
        private double _value = 0d;
        private double _minValue = 0d;
        private double _maxValue = 450d;
        private string _unitLabel = "M/min";
        private double _scaleStartAngle = 135d;
        private double _scaleSweepAngle = 270d;
        private int _gaugePadding = 10;
        private double _dialPadding = 1d;
        private double _tickZonePadding = 5d;
        private double _tickLabelSpacing = 7d;
        private Point _valuePosition = new Point(0.5, 0.85);
        private double _bezelWidthMultiplier = 0.08d;
        private Color _dialColor1 = Colors.White;
        private Color _dialColor2 = Color.FromRgb(224, 224, 224);
        private Color _bezelColor1 = Colors.White;
        private Color _bezelColor2 = Colors.White;
        private Color _bezelHighlightColor = Colors.White;
        private Color _bezelShadowColor = Colors.White;
        private double _zoneGreenEndValue = 100d;
        private double _zoneRedStartValue = 250d;
        private Color _zoneGreenColor = Color.FromRgb(0, 200, 83);
        private Color _zoneYellowColor = Color.FromRgb(255, 193, 7);
        private Color _zoneRedColor = Color.FromRgb(244, 67, 54);
        private double _zoneThicknessMultiplier = 0.02d;
        private double _zoneMinThickness = 2d;
        private int _majorTickStep = 50;
        private int _desiredTickLabelCount = 8;
        private int _minorTicksPerMajor = 5;
        private double _majorTickLengthMultiplier = 0.09d;
        private double _minorTickLengthMultiplier = 0.05d;
        private double _majorTickWidth = 5d;
        private double _minorTickWidth = 2d;
        private string _tickLabelFontFamily = "Segoe UI";
        private double _tickLabelFontSizeMultiplier = 0.05d;
        private double _tickLabelMinFontSize = 10d;
        private Color _tickLabelColor = Color.FromArgb(220, 60, 60, 60);
        private Color _majorTickColor = Color.FromArgb(220, 60, 60, 60);
        private Color _minorTickColor = Color.FromArgb(160, 60, 60, 60);
        private string _valueFontFamily = "Segoe UI";
        private double _valueFontSizeMultiplier = 0.1d;
        private double _unitFontSizeScale = 0.4d;
        private double _valueUnitVerticalSpacing = -12d;
        private double _valueMinFontSize = 18d;
        private double _unitMinFontSize = 10d;
        private Color _valueTextColor = Color.FromArgb(220, 40, 40, 40);
        private Color _unitTextColor = Color.FromArgb(180, 80, 80, 80);
        private NeedleStyle _needleStyle = NeedleStyle.ModernThin;
        private int _needleTransparency = 180;
        private double _needleTipMultiplier = 0.75d;
        private double _needleTailMultiplier = 0.20d;
        private double _needleTailSplitDistanceMultiplier = 0.24d;
        private double _needleShoulderDistanceMultiplier = 0.08d;
        private double _needleShoulderWidthMultiplier = 0.055d;
        private double _needleTailWidthMultiplier = 0.03d;
        private double _needleHighlightWidth = 2.0d;
        private double _needleShadowOffsetMultiplier = 0.02d;
        private Color _needleColor1 = Colors.Red;
        private Color _needleColor2 = Colors.Red;
        private Color _needleHighlightColor1 = Color.FromArgb(200, 255, 255, 255);
        private Color _needleHighlightColor2 = Color.FromArgb(0, 255, 255, 255);
        private Color _needleShadowColor = Color.FromArgb(72, 0, 0, 0);
        private double _blockyNeedleWidthMultiplier = 0.1d;
        private double _classicNeedleBaseWidthMultiplier = 0.15d;
        private double _ornateDiamondSizeMultiplier = 0.1d;
        private double _ornateCircleTailRadiusMultiplier = 0.08d;
        private double _arrowheadSizeMultiplier = 0.1d;
        private double _dualLineGapMultiplier = 0.02d;
        private double _kiteTailSizeMultiplier = 0.1d;
        private double _indicatorTipWidthMultiplier = 0.05d;
        private double _indicatorTipLengthMultiplier = 0.1d;
        private Color _indicatorHubColor = Color.FromRgb(40, 40, 40);
        private Color _indicatorHubHighlightColor = Color.FromRgb(100, 100, 100);
        private double _hubSizeMultiplier = 0.12d;
        private double _hubMinSize = 12d;
        private Color _hubColor1 = Color.FromRgb(224, 224, 224);
        private Color _hubColor2 = Colors.Transparent;
        private Color _hubShadowColor = Color.FromArgb(50, 0, 0, 0);
        private Color _hubHighlightColor = Color.FromArgb(150, 255, 255, 255);
        private Color _outerBorderColor = Color.FromArgb(120, 80, 80, 80);
        private double _outerBorderWidth = 1.5d;
        private Color _outerShadowColor = Color.FromArgb(50, 0, 0, 0);
        private Color _innerShadowColor = Color.FromArgb(100, 0, 0, 0);
        private Color _textShadowColor = Color.FromArgb(30, 0, 0, 0);
        private Color _glassEffectCenterColor = Colors.Transparent;
        private Color _glassEffectOuterColor = Color.FromArgb(0, 255, 255, 255);
        private Rect _glassEffectRect = new Rect(0.1, 0.05, 0.8, 0.4);
        #endregion

        public Color BackColor { get; set; } = Colors.White;

        #region --- Properties ---
        [Category("1. Gauge Core")] public double Value { get => _value; set { _value = Clamp(value, _minValue, _maxValue); InvalidateVisual(); } }
        public double MinValue { get => _minValue; set { _minValue = value; if (_maxValue < _minValue) _maxValue = _minValue; _value = Clamp(_value, _minValue, _maxValue); InvalidateVisual(); } }
        public double MaxValue { get => _maxValue; set { _maxValue = Math.Max(value, _minValue); _value = Clamp(_value, _minValue, _maxValue); InvalidateVisual(); } }
        public string UnitLabel { get => _unitLabel; set { _unitLabel = value ?? ""; InvalidateVisual(); } }
        public double ScaleStartAngle { get => _scaleStartAngle; set { _scaleStartAngle = value; InvalidateVisual(); } }
        public double ScaleSweepAngle { get => _scaleSweepAngle; set { _scaleSweepAngle = value; InvalidateVisual(); } }
        public int GaugePadding { get => _gaugePadding; set { _gaugePadding = value; InvalidateVisual(); } }
        public double DialPadding { get => _dialPadding; set { _dialPadding = value; InvalidateVisual(); } }
        public double TickZonePadding { get => _tickZonePadding; set { _tickZonePadding = value; InvalidateVisual(); } }
        public double TickLabelSpacing { get => _tickLabelSpacing; set { _tickLabelSpacing = value; InvalidateVisual(); } }
        public Point ValuePosition { get => _valuePosition; set { _valuePosition = value; InvalidateVisual(); } }
        public double BezelWidthMultiplier { get => _bezelWidthMultiplier; set { _bezelWidthMultiplier = value; InvalidateVisual(); } }
        public Color DialColor1 { get => _dialColor1; set { _dialColor1 = value; InvalidateVisual(); } }
        public Color DialColor2 { get => _dialColor2; set { _dialColor2 = value; InvalidateVisual(); } }
        public Color BezelColor1 { get => _bezelColor1; set { _bezelColor1 = value; InvalidateVisual(); } }
        public Color BezelColor2 { get => _bezelColor2; set { _bezelColor2 = value; InvalidateVisual(); } }
        public Color BezelHighlightColor { get => _bezelHighlightColor; set { _bezelHighlightColor = value; InvalidateVisual(); } }
        public Color BezelShadowColor { get => _bezelShadowColor; set { _bezelShadowColor = value; InvalidateVisual(); } }
        public double ZoneGreenEndValue { get => _zoneGreenEndValue; set { _zoneGreenEndValue = value; InvalidateVisual(); } }
        public double ZoneRedStartValue { get => _zoneRedStartValue; set { _zoneRedStartValue = value; InvalidateVisual(); } }
        public Color ZoneGreenColor { get => _zoneGreenColor; set { _zoneGreenColor = value; InvalidateVisual(); } }
        public Color ZoneYellowColor { get => _zoneYellowColor; set { _zoneYellowColor = value; InvalidateVisual(); } }
        public Color ZoneRedColor { get => _zoneRedColor; set { _zoneRedColor = value; InvalidateVisual(); } }
        public double ZoneThicknessMultiplier { get => _zoneThicknessMultiplier; set { _zoneThicknessMultiplier = value; InvalidateVisual(); } }
        public double ZoneMinThickness { get => _zoneMinThickness; set { _zoneMinThickness = value; InvalidateVisual(); } }
        public int MajorTickStep { get => _majorTickStep; set { _majorTickStep = value; InvalidateVisual(); } }
        public int DesiredTickLabelCount { get => _desiredTickLabelCount; set { _desiredTickLabelCount = value; InvalidateVisual(); } }
        public int MinorTicksPerMajor { get => _minorTicksPerMajor; set { _minorTicksPerMajor = value; InvalidateVisual(); } }
        public double MajorTickLengthMultiplier { get => _majorTickLengthMultiplier; set { _majorTickLengthMultiplier = value; InvalidateVisual(); } }
        public double MinorTickLengthMultiplier { get => _minorTickLengthMultiplier; set { _minorTickLengthMultiplier = value; InvalidateVisual(); } }
        public double MajorTickWidth { get => _majorTickWidth; set { _majorTickWidth = value; InvalidateVisual(); } }
        public double MinorTickWidth { get => _minorTickWidth; set { _minorTickWidth = value; InvalidateVisual(); } }
        public string TickLabelFontFamily { get => _tickLabelFontFamily; set { _tickLabelFontFamily = value; InvalidateVisual(); } }
        public double TickLabelFontSizeMultiplier { get => _tickLabelFontSizeMultiplier; set { _tickLabelFontSizeMultiplier = value; InvalidateVisual(); } }
        public double TickLabelMinFontSize { get => _tickLabelMinFontSize; set { _tickLabelMinFontSize = value; InvalidateVisual(); } }
        public Color TickLabelColor { get => _tickLabelColor; set { _tickLabelColor = value; InvalidateVisual(); } }
        public Color MajorTickColor { get => _majorTickColor; set { _majorTickColor = value; InvalidateVisual(); } }
        public Color MinorTickColor { get => _minorTickColor; set { _minorTickColor = value; InvalidateVisual(); } }
        public string ValueFontFamily { get => _valueFontFamily; set { _valueFontFamily = value; InvalidateVisual(); } }
        public double ValueFontSizeMultiplier { get => _valueFontSizeMultiplier; set { _valueFontSizeMultiplier = value; InvalidateVisual(); } }
        public double UnitFontSizeScale { get => _unitFontSizeScale; set { _unitFontSizeScale = value; InvalidateVisual(); } }
        public double ValueUnitVerticalSpacing { get => _valueUnitVerticalSpacing; set { _valueUnitVerticalSpacing = value; InvalidateVisual(); } }
        public double ValueMinFontSize { get => _valueMinFontSize; set { _valueMinFontSize = value; InvalidateVisual(); } }
        public double UnitMinFontSize { get => _unitMinFontSize; set { _unitMinFontSize = value; InvalidateVisual(); } }
        public Color ValueTextColor { get => _valueTextColor; set { _valueTextColor = value; InvalidateVisual(); } }
        public Color UnitTextColor { get => _unitTextColor; set { _unitTextColor = value; InvalidateVisual(); } }
        public NeedleStyle NeedleStyle { get => _needleStyle; set { _needleStyle = value; InvalidateVisual(); } }
        public int NeedleTransparency { get => _needleTransparency; set { _needleTransparency = value; InvalidateVisual(); } }
        public double NeedleTipMultiplier { get => _needleTipMultiplier; set { _needleTipMultiplier = value; InvalidateVisual(); } }
        public double NeedleTailMultiplier { get => _needleTailMultiplier; set { _needleTailMultiplier = value; InvalidateVisual(); } }
        public double NeedleTailSplitDistanceMultiplier { get => _needleTailSplitDistanceMultiplier; set { _needleTailSplitDistanceMultiplier = value; InvalidateVisual(); } }
        public double NeedleShoulderDistanceMultiplier { get => _needleShoulderDistanceMultiplier; set { _needleShoulderDistanceMultiplier = value; InvalidateVisual(); } }
        public double NeedleShoulderWidthMultiplier { get => _needleShoulderWidthMultiplier; set { _needleShoulderWidthMultiplier = value; InvalidateVisual(); } }
        public double NeedleTailWidthMultiplier { get => _needleTailWidthMultiplier; set { _needleTailWidthMultiplier = value; InvalidateVisual(); } }
        public double NeedleHighlightWidth { get => _needleHighlightWidth; set { _needleHighlightWidth = value; InvalidateVisual(); } }
        public double NeedleShadowOffsetMultiplier { get => _needleShadowOffsetMultiplier; set { _needleShadowOffsetMultiplier = value; InvalidateVisual(); } }
        public Color NeedleColor1 { get => _needleColor1; set { _needleColor1 = value; InvalidateVisual(); } }
        public Color NeedleColor2 { get => _needleColor2; set { _needleColor2 = value; InvalidateVisual(); } }
        public Color NeedleHighlightColor1 { get => _needleHighlightColor1; set { _needleHighlightColor1 = value; InvalidateVisual(); } }
        public Color NeedleHighlightColor2 { get => _needleHighlightColor2; set { _needleHighlightColor2 = value; InvalidateVisual(); } }
        public Color NeedleShadowColor { get => _needleShadowColor; set { _needleShadowColor = value; InvalidateVisual(); } }
        public double BlockyNeedleWidthMultiplier { get => _blockyNeedleWidthMultiplier; set { _blockyNeedleWidthMultiplier = value; InvalidateVisual(); } }
        public double ClassicNeedleBaseWidthMultiplier { get => _classicNeedleBaseWidthMultiplier; set { _classicNeedleBaseWidthMultiplier = value; InvalidateVisual(); } }
        public double OrnateDiamondSizeMultiplier { get => _ornateDiamondSizeMultiplier; set { _ornateDiamondSizeMultiplier = value; InvalidateVisual(); } }
        public double OrnateCircleTailRadiusMultiplier { get => _ornateCircleTailRadiusMultiplier; set { _ornateCircleTailRadiusMultiplier = value; InvalidateVisual(); } }
        public double ArrowheadSizeMultiplier { get => _arrowheadSizeMultiplier; set { _arrowheadSizeMultiplier = value; InvalidateVisual(); } }
        public double DualLineGapMultiplier { get => _dualLineGapMultiplier; set { _dualLineGapMultiplier = value; InvalidateVisual(); } }
        public double KiteTailSizeMultiplier { get => _kiteTailSizeMultiplier; set { _kiteTailSizeMultiplier = value; InvalidateVisual(); } }
        public double IndicatorTipWidthMultiplier { get => _indicatorTipWidthMultiplier; set { _indicatorTipWidthMultiplier = value; InvalidateVisual(); } }
        public double IndicatorTipLengthMultiplier { get => _indicatorTipLengthMultiplier; set { _indicatorTipLengthMultiplier = value; InvalidateVisual(); } }
        public Color IndicatorHubColor { get => _indicatorHubColor; set { _indicatorHubColor = value; InvalidateVisual(); } }
        public Color IndicatorHubHighlightColor { get => _indicatorHubHighlightColor; set { _indicatorHubHighlightColor = value; InvalidateVisual(); } }
        public double HubSizeMultiplier { get => _hubSizeMultiplier; set { _hubSizeMultiplier = value; InvalidateVisual(); } }
        public double HubMinSize { get => _hubMinSize; set { _hubMinSize = value; InvalidateVisual(); } }
        public Color HubColor1 { get => _hubColor1; set { _hubColor1 = value; InvalidateVisual(); } }
        public Color HubColor2 { get => _hubColor2; set { _hubColor2 = value; InvalidateVisual(); } }
        public Color HubShadowColor { get => _hubShadowColor; set { _hubShadowColor = value; InvalidateVisual(); } }
        public Color HubHighlightColor { get => _hubHighlightColor; set { _hubHighlightColor = value; InvalidateVisual(); } }
        public Color OuterBorderColor { get => _outerBorderColor; set { _outerBorderColor = value; InvalidateVisual(); } }
        public double OuterBorderWidth { get => _outerBorderWidth; set { _outerBorderWidth = value; InvalidateVisual(); } }
        public Color OuterShadowColor { get => _outerShadowColor; set { _outerShadowColor = value; InvalidateVisual(); } }
        public Color InnerShadowColor { get => _innerShadowColor; set { _innerShadowColor = value; InvalidateVisual(); } }
        public Color TextShadowColor { get => _textShadowColor; set { _textShadowColor = value; InvalidateVisual(); } }
        public Color GlassEffectCenterColor { get => _glassEffectCenterColor; set { _glassEffectCenterColor = value; InvalidateVisual(); } }
        public Color GlassEffectOuterColor { get => _glassEffectOuterColor; set { _glassEffectOuterColor = value; InvalidateVisual(); } }
        public Rect GlassEffectRect { get => _glassEffectRect; set { _glassEffectRect = value; InvalidateVisual(); } }
        #endregion

        public SpeedometerControl() { Width = 340; Height = 340; }

        #region --- WPF Drawing Helpers ---
        private static Color WithAlpha(Color c, int a) => Color.FromArgb((byte)a, c.R, c.G, c.B);
        private StreamGeometry PolygonGeometry(Point[] pts, bool filled, bool closed) { var sg = new StreamGeometry(); using (var ctx = sg.Open()) { ctx.BeginFigure(pts[0], filled, closed); for (int i = 1; i < pts.Length; i++) ctx.LineTo(pts[i], true, false); } return sg; }
        private StreamGeometry LineGeometry(Point p1, Point p2) { var sg = new StreamGeometry(); using (var ctx = sg.Open()) { ctx.BeginFigure(p1, false, false); ctx.LineTo(p2, true, false); } return sg; }
        private StreamGeometry MultiLineGeometry(Point p1, Point p2, Point p3, Point p4) { var sg = new StreamGeometry(); using (var ctx = sg.Open()) { ctx.BeginFigure(p1, false, false); ctx.LineTo(p2, true, false); ctx.LineTo(p3, true, false); ctx.LineTo(p4, true, false); } return sg; }
        private StreamGeometry CurveGeometry(Point[] pts) { var sg = new StreamGeometry(); using (var ctx = sg.Open()) { ctx.BeginFigure(pts[0], false, false); for (int i = 0; i < pts.Length - 1; i++) { Point p0 = pts[Math.Max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.Min(pts.Length - 1, i + 2)]; double t = 0.5 / 3.0; ctx.BezierTo(new Point(p1.X + (p2.X - p0.X) * t, p1.Y + (p2.Y - p0.Y) * t), new Point(p2.X - (p3.X - p1.X) * t, p2.Y - (p3.Y - p1.Y) * t), p2, true, false); } } return sg; }
        private LinearGradientBrush CreateLinearGradient(Rect rect, Color c1, Color c2, double angle) { double rad = angle * Math.PI / 180.0; double dx = Math.Cos(rad), dy = Math.Sin(rad); double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2; double halfLen = Math.Abs(dx) * (rect.Width / 2) + Math.Abs(dy) * (rect.Height / 2); var b = new LinearGradientBrush(); b.StartPoint = new Point(cx - dx * halfLen, cy - dy * halfLen); b.EndPoint = new Point(cx + dx * halfLen, cy + dy * halfLen); b.MappingMode = BrushMappingMode.Absolute; b.GradientStops.Add(new GradientStop(c1, 0)); b.GradientStops.Add(new GradientStop(c2, 1)); return b; }
        private RadialGradientBrush CreateRadialGradient(Rect rect, Color centerColor, Color surroundColor, double focusScale) { double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2; double r = Math.Min(rect.Width, rect.Height) / 2; var b = new RadialGradientBrush(); b.Center = new Point(cx, cy); b.GradientOrigin = new Point(cx, cy); b.RadiusX = r; b.RadiusY = r; b.MappingMode = BrushMappingMode.Absolute; b.GradientStops.Add(new GradientStop(centerColor, 0.0)); if (focusScale > 0 && focusScale < 1) b.GradientStops.Add(new GradientStop(centerColor, focusScale)); b.GradientStops.Add(new GradientStop(surroundColor, 1.0)); return b; }
        private FormattedText FormatText(string text, string fontFamily, double size, bool bold, Color color) { var tf = new Typeface(new FontFamily(fontFamily), FontStyles.Normal, bold ? FontWeights.Bold : FontWeights.Normal, FontStretches.Normal); return new FormattedText(text, System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight, tf, size, new SolidColorBrush(color), 1.0); }
        private void DrawArc(DrawingContext g, Pen pen, Rect rect, double startAngle, double sweepAngle) { if (Math.Abs(sweepAngle) < 0.001) return; double cx = rect.X + rect.Width / 2, cy = rect.Y + rect.Height / 2; double rx = rect.Width / 2, ry = rect.Height / 2; double sRad = startAngle * Math.PI / 180.0; double eRad = (startAngle + sweepAngle) * Math.PI / 180.0; Point sp = new Point(cx + rx * Math.Cos(sRad), cy + ry * Math.Sin(sRad)); Point ep = new Point(cx + rx * Math.Cos(eRad), cy + ry * Math.Sin(eRad)); var sg = new StreamGeometry(); using (var ctx = sg.Open()) { ctx.BeginFigure(sp, false, false); ctx.ArcTo(ep, new Size(rx, ry), 0, Math.Abs(sweepAngle) > 180, sweepAngle > 0 ? SweepDirection.Clockwise : SweepDirection.Counterclockwise, true, false); } g.DrawGeometry(null, pen, sg); }
        private static Rect Inflate(Rect r, double dx, double dy) => new Rect(r.X - dx, r.Y - dy, r.Width + 2 * dx, r.Height + 2 * dy);
        #endregion

        #region --- Drawing Methods ---
        protected override void OnRender(DrawingContext g)
        {
            base.OnRender(g);
            g.DrawRectangle(new SolidColorBrush(BackColor), null, new Rect(0, 0, ActualWidth, ActualHeight));

            var bounds = new Rect(0, 0, ActualWidth, ActualHeight);
            double baseSize = Math.Min(bounds.Width, bounds.Height);
            _scale = baseSize / 340.0;
            if (_scale <= 0) return;

            double size = baseSize - GaugePadding * 2 * _scale;
            if (size <= 8 * _scale) return;

            double left = bounds.Left + (bounds.Width - size) / 2;
            double top = bounds.Top + (bounds.Height - size) / 2;
            var dialRect = new Rect(left, top, size, size);

            DrawOuterShadow(g, dialRect);
            DrawFace(g, dialRect);
            DrawBezel(g, dialRect);
            DrawInnerBezelShadow(g, dialRect);
            DrawZones(g, dialRect);
            DrawTicks(g, dialRect);
            DrawNeedle(g, dialRect);
            DrawValueLabel(g, dialRect);
            DrawThinBorder(g, dialRect);
            DrawGlassEffect(g, dialRect);
        }

        private void DrawOuterShadow(DrawingContext g, Rect rect) { var shadowRect = Inflate(rect, rect.Width * 0.03, rect.Height * 0.03); var eg = new EllipseGeometry(shadowRect); var brush = CreateRadialGradient(shadowRect, OuterShadowColor, WithAlpha(OuterShadowColor, 0), 0.85); g.DrawGeometry(brush, null, eg); }
        private void DrawFace(DrawingContext g, Rect rect) { var eg = new EllipseGeometry(rect); var brush = CreateRadialGradient(rect, DialColor1, DialColor2, 0.7); g.DrawGeometry(brush, null, eg); }
        private void DrawBezel(DrawingContext g, Rect rect) { double r = rect.Width * 0.5; double w = Math.Max(4 * _scale, r * BezelWidthMultiplier); var rr = Inflate(rect, -w / 2, -w / 2); var eg = new EllipseGeometry(rr); g.DrawGeometry(CreateLinearGradient(rect, _bezelColor1, _bezelColor2, 45), null, eg); g.DrawGeometry(CreateLinearGradient(rect, _bezelHighlightColor, Colors.Transparent, 225), null, eg); g.DrawGeometry(CreateLinearGradient(rect, Colors.Transparent, _bezelShadowColor, 45), null, eg); }
        private void DrawInnerBezelShadow(DrawingContext g, Rect rect) { double r = rect.Width * 0.5; double w = Math.Max(4 * _scale, r * BezelWidthMultiplier); var sr = Inflate(rect, -w * 0.9, -w * 0.9); var outerEG = new EllipseGeometry(rect); var innerEG = new EllipseGeometry(sr); var combined = new CombinedGeometry(GeometryCombineMode.Exclude, outerEG, innerEG); var brush = CreateRadialGradient(rect, InnerShadowColor, WithAlpha(InnerShadowColor, 0), 0); g.DrawGeometry(brush, null, combined); }
        private void DrawGlassEffect(DrawingContext g, Rect rect) { var eff = GlassEffectRect; var hr = new Rect(rect.Left + rect.Width * eff.X, rect.Top + rect.Height * eff.Y, rect.Width * eff.Width, rect.Height * eff.Height); var eg = new EllipseGeometry(hr); var brush = CreateRadialGradient(hr, GlassEffectCenterColor, GlassEffectOuterColor, 0.5); g.DrawGeometry(brush, null, eg); }
        private void DrawZones(DrawingContext g, Rect rect) { double gs = SpanForRange(MinValue, ZoneGreenEndValue); double ys = SpanForRange(ZoneGreenEndValue, ZoneRedStartValue); double rs = SpanForRange(ZoneRedStartValue, MaxValue); double r = rect.Width * 0.5; double bw = r * BezelWidthMultiplier; double zt = Math.Max(ZoneMinThickness * _scale, r * ZoneThicknessMultiplier); double ti = bw + DialPadding * _scale + (zt / 2); var zr = Inflate(rect, -ti, -ti); var pG = new Pen(new SolidColorBrush(ZoneGreenColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round }; var pY = new Pen(new SolidColorBrush(ZoneYellowColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round }; var pR = new Pen(new SolidColorBrush(ZoneRedColor), zt) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round }; if (gs > 0) DrawArc(g, pG, zr, ScaleStartAngle, gs); if (ys > 0) DrawArc(g, pY, zr, ScaleStartAngle + gs, ys); if (rs > 0) DrawArc(g, pR, zr, ScaleStartAngle + gs + ys, rs); }

        private void DrawTicks(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double vr = Math.Max(1, MaxValue - MinValue);

            // Dynamically adjust the desired label count based on scale to prevent overlap on small controls
            double effectiveDesiredCount = DesiredTickLabelCount * _scale;
            int M = (MajorTickStep > 0) ? MajorTickStep : NiceNumber((float)(vr / Math.Max(1, effectiveDesiredCount)));

            int m = Math.Max(1, M / Math.Max(1, MinorTicksPerMajor));
            double bw = r * BezelWidthMultiplier;
            double zt = Math.Max(ZoneMinThickness * _scale, r * ZoneThicknessMultiplier);
            double ot = bw + DialPadding * _scale + zt + TickZonePadding * _scale;
            double Mtl = r * MajorTickLengthMultiplier;
            double mtl = r * MinorTickLengthMultiplier;
            double Mit = ot + Mtl;
            double mit = ot + mtl;

            // Keep MinFontSize unscaled so it remains readable
            double fs = Math.Max(TickLabelMinFontSize, r * TickLabelFontSizeMultiplier);

            var Mp = new Pen(new SolidColorBrush(MajorTickColor), MajorTickWidth * _scale);
            var mp = new Pen(new SolidColorBrush(MinorTickColor), MinorTickWidth * _scale);

            for (int v = (int)(Math.Ceiling(MinValue / m) * m); v <= (int)(Math.Floor(MaxValue / m) * m); v += m)
            {
                bool iM = (v % M == 0);
                g.DrawLine(iM ? Mp : mp, PointOnCircle(c, r - ot, v), PointOnCircle(c, r - (iM ? Mit : mit), v));
            }

            for (int v = (int)(Math.Ceiling(MinValue / M) * M); v <= MaxValue; v += M)
                DrawLabelAtValue(g, c, r, v, Mit, fs);

            DrawLabelAtValue(g, c, r, (int)MinValue, Mit, fs);
            DrawLabelAtValue(g, c, r, (int)MaxValue, Mit, fs);
        }

        private void DrawLabelAtValue(DrawingContext g, Point c, double r, int v, double t, double fs)
        {
            string l = v.ToString();
            var ft = FormatText(l, TickLabelFontFamily, fs, true, Colors.Black);
            var s = new Size(ft.Width, ft.Height);
            double lci = t + TickLabelSpacing * _scale + (s.Height / 2);
            var p = PointOnCircle(c, r - lci, v);

            g.DrawText(FormatText(l, TickLabelFontFamily, fs, true, TextShadowColor), new Point(p.X - s.Width / 2 + 1 * _scale, p.Y - s.Height / 2 + 1 * _scale));
            g.DrawText(FormatText(l, TickLabelFontFamily, fs, true, TickLabelColor), new Point(p.X - s.Width / 2, p.Y - s.Height / 2));
        }

        private void DrawValueLabel(DrawingContext g, Rect rect)
        {
            string vt = ((int)_value).ToString();
            string ut = _unitLabel;
            double r = rect.Width * 0.5;
            var bc = new Point(rect.Left + rect.Width * ValuePosition.X, rect.Top + rect.Height * ValuePosition.Y);

            // Keep MinFontSize unscaled so it remains readable
            double fsv = Math.Max(ValueMinFontSize, r * ValueFontSizeMultiplier);
            double fsu = Math.Max(UnitMinFontSize, fsv * UnitFontSizeScale);

            var vft = FormatText(vt, ValueFontFamily, fsv, true, Colors.Black);
            var uft = FormatText(ut, ValueFontFamily, fsu, false, Colors.Black);

            // Add padding to emulate WinForms text measurement so -12 spacing works correctly
            var vs = new Size(vft.Width, vft.Height + 4 * _scale);
            var us = new Size(uft.Width, uft.Height + 4 * _scale);

            double tbh = vs.Height + us.Height + ValueUnitVerticalSpacing * _scale;
            double vty = bc.Y - tbh / 2;
            double uty = vty + vs.Height + ValueUnitVerticalSpacing * _scale;

            g.DrawText(FormatText(vt, ValueFontFamily, fsv, true, ValueTextColor), new Point(bc.X - vs.Width / 2, vty));
            g.DrawText(FormatText(ut, ValueFontFamily, fsu, false, UnitTextColor), new Point(bc.X - us.Width / 2, uty));
        }

        private void DrawThinBorder(DrawingContext g, Rect rect) { var pen = new Pen(new SolidColorBrush(OuterBorderColor), OuterBorderWidth * _scale); var center = new Point(rect.X + rect.Width / 2, rect.Y + rect.Height / 2); g.DrawEllipse(null, pen, center, rect.Width / 2, rect.Height / 2); }
        #endregion

        #region --- Needle Drawing Logic ---
        private void DrawNeedle(DrawingContext g, Rect rect)
        {
            switch (NeedleStyle)
            {
                case NeedleStyle.ModernIndicator: DrawNeedle_ModernIndicator(g, rect); break;
                case NeedleStyle.ClassicTapered: DrawNeedle_ClassicTapered(g, rect); break;
                case NeedleStyle.ClassicWide: DrawNeedle_ClassicWide(g, rect); break;
                case NeedleStyle.OrnateDiamond: DrawNeedle_OrnateDiamond(g, rect); break;
                case NeedleStyle.ModernSleek: DrawNeedle_ModernSleek(g, rect); break;
                case NeedleStyle.ModernCutout: DrawNeedle_ModernCutout(g, rect); break;
                case NeedleStyle.ModernDualLine: DrawNeedle_ModernDualLine(g, rect); break;
                case NeedleStyle.Arrowhead: DrawNeedle_Arrowhead(g, rect); break;
                case NeedleStyle.Broadhead: DrawNeedle_Broadhead(g, rect); break;
                case NeedleStyle.CrossbowBolt: DrawNeedle_CrossbowBolt(g, rect); break;
                case NeedleStyle.VintageThinWithTail: DrawNeedle_VintageThinWithTail(g, rect); break;
                case NeedleStyle.VintageArtDeco: DrawNeedle_VintageArtDeco(g, rect); break;
                case NeedleStyle.VintageCrescentTail: DrawNeedle_VintageCrescentTail(g, rect); break;
                case NeedleStyle.VintageAviator: DrawNeedle_VintageAviator(g, rect); break;
                case NeedleStyle.OrnateSpearTip: DrawNeedle_OrnateSpearTip(g, rect); break;
                case NeedleStyle.OrnateFleurDeLis: DrawNeedle_OrnateFleurDeLis(g, rect); break;
                case NeedleStyle.OrnateSword: DrawNeedle_OrnateSword(g, rect); break;
                case NeedleStyle.CompassNorth: DrawNeedle_CompassNorth(g, rect); break;
                case NeedleStyle.AnchorTail: DrawNeedle_AnchorTail(g, rect); break;
                case NeedleStyle.Harpoon: DrawNeedle_Harpoon(g, rect); break;
                case NeedleStyle.SciFiArrow: DrawNeedle_SciFiArrow(g, rect); break;
                case NeedleStyle.SciFiDataSpike: DrawNeedle_SciFiDataSpike(g, rect); break;
                case NeedleStyle.EnergyBlade: DrawNeedle_EnergyBlade(g, rect); break;
                case NeedleStyle.SimplePin: DrawNeedle_SimplePin(g, rect); break;
                case NeedleStyle.ModernThin:
                default: DrawNeedle_ModernThin(g, rect); break;
            }
        }

        private void DrawNeedleShadowAndFill(DrawingContext g, Geometry path, double angle, double radius)
        {
            double offset = radius * NeedleShadowOffsetMultiplier;
            g.PushTransform(new TranslateTransform(offset, offset));
            g.DrawGeometry(new SolidColorBrush(NeedleShadowColor), null, path);
            g.Pop();

            var bounds = path.Bounds;
            var brush = CreateLinearGradient(bounds, WithAlpha(NeedleColor1, NeedleTransparency), WithAlpha(NeedleColor2, NeedleTransparency), angle + 90);
            g.DrawGeometry(brush, null, path);
        }

        private void DrawNeedleShadowAndFill(DrawingContext g, Pen pen, Geometry path, double angle, double radius)
        {
            double offset = radius * NeedleShadowOffsetMultiplier;
            g.PushTransform(new TranslateTransform(offset, offset));
            g.DrawGeometry(null, new Pen(new SolidColorBrush(NeedleShadowColor), pen.Thickness), path);
            g.Pop();
            g.DrawGeometry(null, pen, path);
        }

        private void DrawNeedleHub(DrawingContext g, Point center, double radius)
        {
            double hr = Math.Max(HubMinSize * _scale, radius * HubSizeMultiplier);
            var hrect = new Rect(center.X - hr, center.Y - hr, hr * 2, hr * 2);
            var eg = new EllipseGeometry(hrect);

            g.DrawGeometry(CreateLinearGradient(hrect, HubColor1, HubColor2, 45), null, eg);

            var innerRect = Inflate(hrect, -2 * _scale, -2 * _scale);
            g.DrawEllipse(null, new Pen(new SolidColorBrush(HubHighlightColor), 1 * _scale),
                new Point(innerRect.X + innerRect.Width / 2, innerRect.Y + innerRect.Height / 2),
                innerRect.Width / 2, innerRect.Height / 2);

            g.DrawEllipse(null, new Pen(new SolidColorBrush(HubShadowColor), 2 * _scale),
                new Point(hrect.X + hrect.Width / 2, hrect.Y + hrect.Height / 2),
                hrect.Width / 2, hrect.Height / 2);
        }

        private void DrawNeedleHub_IndicatorStyle(DrawingContext g, Point center, double radius)
        {
            double hr = Math.Max(HubMinSize * _scale, radius * HubSizeMultiplier);
            var hrect = new Rect(center.X - hr, center.Y - hr, hr * 2, hr * 2);
            var eg = new EllipseGeometry(hrect);
            g.DrawGeometry(new SolidColorBrush(IndicatorHubColor), null, eg);

            var irect = Inflate(hrect, -hr * 0.1, -hr * 0.1);
            var ieg = new EllipseGeometry(irect);
            var brush = CreateRadialGradient(irect, IndicatorHubHighlightColor, Colors.Transparent, 0);
            g.DrawGeometry(brush, null, ieg);
        }

        private void DrawNeedle_ModernIndicator(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

            var linePen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale);
            g.DrawLine(linePen, c, t);

            double tl = r * IndicatorTipLengthMultiplier;
            double tw = r * IndicatorTipWidthMultiplier;
            var perp = GetPerpendicularVector(a);
            var tb = PointOnCircle(c, r * NeedleTipMultiplier - tl, Value);
            var p1 = new Point(t.X - perp.X * tw / 2, t.Y - perp.Y * tw / 2);
            var p2 = new Point(t.X + perp.X * tw / 2, t.Y + perp.Y * tw / 2);
            var p3 = new Point(tb.X + perp.X * tw / 2, tb.Y + perp.Y * tw / 2);
            var p4 = new Point(tb.X - perp.X * tw / 2, tb.Y - perp.Y * tw / 2);

            var path = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
            g.DrawGeometry(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), null, path);

            DrawNeedleHub_IndicatorStyle(g, c, r);
        }

        private void DrawNeedle_ModernThin(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var d = GetDirectionVector(a);
            var p = new Point(-d.Y, d.X);
            var t = new Point(c.X + d.X * (r * NeedleTipMultiplier), c.Y + d.Y * (r * NeedleTipMultiplier));
            var sl = new Point(c.X + d.X * (r * NeedleShoulderDistanceMultiplier) - p.X * (r * NeedleShoulderWidthMultiplier), c.Y + d.Y * (r * NeedleShoulderDistanceMultiplier) - p.Y * (r * NeedleShoulderWidthMultiplier));
            var sr = new Point(c.X + d.X * (r * NeedleShoulderDistanceMultiplier) + p.X * (r * NeedleShoulderWidthMultiplier), c.Y + d.Y * (r * NeedleShoulderDistanceMultiplier) + p.Y * (r * NeedleShoulderWidthMultiplier));
            var tl = new Point(c.X - d.X * (r * NeedleTailSplitDistanceMultiplier) - p.X * (r * NeedleTailWidthMultiplier), c.Y - d.Y * (r * NeedleTailSplitDistanceMultiplier) - p.Y * (r * NeedleTailWidthMultiplier));
            var tr = new Point(c.X - d.X * (r * NeedleTailSplitDistanceMultiplier) + p.X * (r * NeedleTailWidthMultiplier), c.Y - d.Y * (r * NeedleTailSplitDistanceMultiplier) + p.Y * (r * NeedleTailWidthMultiplier));
            var tc = new Point(c.X - d.X * (r * NeedleTailMultiplier), c.Y - d.Y * (r * NeedleTailMultiplier));

            var path = PolygonGeometry(new[] { t, sr, tr, tc, tl, sl }, true, true);
            DrawNeedleShadowAndFill(g, path, a, r);

            var hp = PolygonGeometry(new[] { sl, t, sr }, false, false);
            var lgb = CreateLinearGradient(path.Bounds, NeedleHighlightColor1, NeedleHighlightColor2, a);
            g.DrawGeometry(null, new Pen(lgb, NeedleHighlightWidth * _scale), hp);

            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_SimplePin(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

            var path = LineGeometry(c, t);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), path, a, r);

            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_ClassicTapered(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double bw = r * ClassicNeedleBaseWidthMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
            DrawNeedleShadowAndFill(g, path, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_ClassicWide(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var d = GetDirectionVector(a);
            var p = new Point(-d.Y, d.X);
            double bw = r * ClassicNeedleBaseWidthMultiplier;
            double tw = bw * 0.2;
            var tl = new Point(c.X + d.X * (r * NeedleTipMultiplier) - p.X * tw / 2, c.Y + d.Y * (r * NeedleTipMultiplier) - p.Y * tw / 2);
            var tr = new Point(c.X + d.X * (r * NeedleTipMultiplier) + p.X * tw / 2, c.Y + d.Y * (r * NeedleTipMultiplier) + p.Y * tw / 2);
            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

            var path = PolygonGeometry(new[] { tr, br, bl, tl }, true, true);
            DrawNeedleShadowAndFill(g, path, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_OrnateDiamond(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double ds = r * OrnateDiamondSizeMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var mp = PointOnCircle(c, r * NeedleTipMultiplier - ds, Value);
            var sl = new Point(mp.X - p.X * ds / 2, mp.Y - p.Y * ds / 2);
            var sr = new Point(mp.X + p.X * ds / 2, mp.Y + p.Y * ds / 2);
            var bp = PointOnCircle(c, r * NeedleTipMultiplier - ds * 2, Value);

            var linePath = LineGeometry(c, bp);
            var polyPath = PolygonGeometry(new[] { t, sr, bp, sl }, true, true);
            var combined = new GeometryGroup();
            combined.Children.Add(linePath);
            combined.Children.Add(polyPath);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), combined, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_OrnateCircleTail(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double bw = r * ClassicNeedleBaseWidthMultiplier * 0.5;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
            DrawNeedleShadowAndFill(g, path, a, r);

            double tr = r * OrnateCircleTailRadiusMultiplier;
            var tp = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
            var trect = new Rect(tp.X - tr, tp.Y - tr, tr * 2, tr * 2);
            g.DrawEllipse(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), null,
                new Point(tp.X, tp.Y), tr, tr);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_ModernTriangle(DrawingContext g, Rect rect) => DrawNeedle_ClassicTapered(g, rect);

        private void DrawNeedle_ModernDualLine(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double gap = r * DualLineGapMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var p1s = new Point(c.X - p.X * gap, c.Y - p.Y * gap);
            var p1e = new Point(t.X - p.X * gap, t.Y - p.Y * gap);
            var p2s = new Point(c.X + p.X * gap, c.Y + p.Y * gap);
            var p2e = new Point(t.X + p.X * gap, t.Y + p.Y * gap);

            var pen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale);
            g.DrawLine(pen, p1s, p1e);
            g.DrawLine(pen, p2s, p2e);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_ModernCutout(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double bw = r * BlockyNeedleWidthMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var p1 = new Point(t.X - p.X * bw / 4, t.Y - p.Y * bw / 4);
            var p2 = new Point(t.X + p.X * bw / 4, t.Y + p.Y * bw / 4);
            var p3 = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);
            var p4 = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
            var cp1 = PointOnCircle(c, r * 0.5, Value);
            var cp2 = PointOnCircle(c, r * 0.3, Value);
            var cp3 = new Point(cp2.X + p.X * bw / 4, cp2.Y + p.Y * bw / 4);
            var cp4 = new Point(cp2.X - p.X * bw / 4, cp2.Y - p.Y * bw / 4);

            var outerPath = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
            var innerPath = PolygonGeometry(new[] { cp1, cp3, cp4 }, true, true);
            var combined = new CombinedGeometry(GeometryCombineMode.Exclude, outerPath, innerPath);
            DrawNeedleShadowAndFill(g, combined, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_VintageThinWithTail(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var tip = PointOnCircle(c, r * NeedleTipMultiplier, Value);

            var linePath = LineGeometry(c, tip);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), linePath, a, r);

            var perp = GetPerpendicularVector(a);
            double ts = r * KiteTailSizeMultiplier;
            var te = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
            var p1 = new Point(te.X - perp.X * ts / 2, te.Y - perp.Y * ts / 2);
            var p2 = new Point(te.X + perp.X * ts / 2, te.Y + perp.Y * ts / 2);

            var tailPath = PolygonGeometry(new[] { c, p2, p1 }, true, true);
            DrawNeedleShadowAndFill(g, tailPath, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_VintageArtDeco(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double bw = r * ClassicNeedleBaseWidthMultiplier;

            var p1 = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var p2 = PointOnCircle(c, r * 0.6, Value);
            var p3 = new Point(p2.X + p.X * bw * 0.2, p2.Y + p.Y * bw * 0.2);
            var p4 = new Point(p2.X - p.X * bw * 0.2, p2.Y - p.Y * bw * 0.2);
            var p5 = PointOnCircle(c, r * 0.5, Value);
            var p6 = new Point(p5.X + p.X * bw * 0.4, p5.Y + p.Y * bw * 0.4);
            var p7 = new Point(p5.X - p.X * bw * 0.4, p5.Y - p.Y * bw * 0.4);
            var p8 = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);
            var p9 = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);

            var path = PolygonGeometry(new[] { p1, p3, p6, p8, p9, p7, p4 }, true, true);
            DrawNeedleShadowAndFill(g, path, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_VintageCrescentTail(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            DrawNeedle_ClassicTapered(g, rect);
            double tr = r * OrnateCircleTailRadiusMultiplier * 1.5;
            var tp = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
            g.DrawEllipse(new SolidColorBrush(BackColor), null, new Point(tp.X, tp.Y), tr, tr);
        }

        private void DrawNeedle_OrnateSpearTip(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            double ss = r * ArrowheadSizeMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var boh = PointOnCircle(c, r * NeedleTipMultiplier - ss, Value);
            var b1 = PointOnCircle(boh, ss * 0.8, Value, 150);
            var b2 = PointOnCircle(boh, ss * 0.8, Value, -150);

            var linePath = LineGeometry(c, boh);
            var polyPath = PolygonGeometry(new[] { t, b2, boh, b1 }, true, true);
            var combined = new GeometryGroup();
            combined.Children.Add(linePath);
            combined.Children.Add(polyPath);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), combined, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_OrnateFleurDeLis(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);

            var linePath = LineGeometry(c, t);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), linePath, a, r);

            double ts = r * KiteTailSizeMultiplier * 1.5;
            var tb = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
            var p1 = PointOnCircle(tb, ts * 0.5, Value, 180);
            var p2 = PointOnCircle(tb, ts, Value, 180 + 90);
            var p3 = PointOnCircle(tb, ts, Value, 180 - 90);

            var curvePath = CurveGeometry(new[] { p2, p1, p3 });
            g.DrawGeometry(null, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), curvePath);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_OrnateSword(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double bw = r * ClassicNeedleBaseWidthMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var m1 = PointOnCircle(c, r * 0.6, Value);
            var m2 = PointOnCircle(c, r * 0.5, Value);
            var h1 = new Point(m2.X + p.X * bw / 2, m2.Y + p.Y * bw / 2);
            var h2 = new Point(m2.X - p.X * bw / 2, m2.Y - p.Y * bw / 2);

            var path = MultiLineGeometry(t, m1, h1, h2);
            var path2 = LineGeometry(m2, c);
            var combined = new GeometryGroup();
            combined.Children.Add(path);
            combined.Children.Add(path2);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), combined, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_SciFiArrow(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            double hs = r * ArrowheadSizeMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var p2 = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value, -2);
            var p3 = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value, 2);
            var p4 = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);

            var path = PolygonGeometry(new[] { t, p3, p4, p2 }, true, true);
            DrawNeedleShadowAndFill(g, path, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_SciFiDataSpike(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var p1 = PointOnCircle(c, r * 0.6, Value, 2);
            var p2 = PointOnCircle(c, r * 0.6, Value, -2);
            var p3 = PointOnCircle(c, r * 0.3, Value, 4);
            var p4 = PointOnCircle(c, r * 0.3, Value, -4);

            var path = PolygonGeometry(new[] { t, p1, p3, c, p4, p2 }, true, true);
            DrawNeedleShadowAndFill(g, path, MapValueToAngle(Value), r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_EnergyBlade(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double bw = r * BlockyNeedleWidthMultiplier * 0.5;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
            var bounds = path.Bounds;
            var brush = new RadialGradientBrush();
            brush.Center = new Point(bounds.X + bounds.Width / 2, bounds.Y + bounds.Height / 2);
            brush.GradientOrigin = brush.Center;
            brush.RadiusX = Math.Max(bounds.Width, bounds.Height) / 2;
            brush.RadiusY = brush.RadiusX;
            brush.MappingMode = BrushMappingMode.Absolute;
            brush.GradientStops.Add(new GradientStop(Colors.White, 0));
            brush.GradientStops.Add(new GradientStop(WithAlpha(NeedleColor1, NeedleTransparency), 1));
            g.DrawGeometry(brush, null, path);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_ModernSleek(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var s1 = new Point(c.X + p.X * r * 0.05, c.Y + p.Y * r * 0.05);
            var s2 = new Point(c.X - p.X * r * 0.05, c.Y - p.Y * r * 0.05);
            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);

            var path = CurveGeometry(new[] { tail, s2, t, s1, tail });
            DrawNeedleShadowAndFill(g, path, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_Arrowhead(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            double hs = r * ArrowheadSizeMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var boh = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
            var p = GetPerpendicularVector(a);
            var p1 = new Point(boh.X - p.X * hs / 2, boh.Y - p.Y * hs / 2);
            var p2 = new Point(boh.X + p.X * hs / 2, boh.Y + p.Y * hs / 2);

            var linePath = LineGeometry(c, boh);
            var polyPath = PolygonGeometry(new[] { t, p2, p1 }, true, true);
            var combined = new GeometryGroup();
            combined.Children.Add(linePath);
            combined.Children.Add(polyPath);
            DrawNeedleShadowAndFill(g, combined, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_Broadhead(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            double hs = r * ArrowheadSizeMultiplier * 1.5;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var n = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
            var p = GetPerpendicularVector(a);
            var b1 = new Point(n.X + p.X * hs * 0.4, n.Y + p.Y * hs * 0.4);
            var b2 = new Point(n.X - p.X * hs * 0.4, n.Y - p.Y * hs * 0.4);
            var back = PointOnCircle(c, r * NeedleTipMultiplier - hs * 1.2, Value);

            var linePath = LineGeometry(c, back);
            var polyPath = PolygonGeometry(new[] { t, b1, back, b2 }, true, true);
            var combined = new GeometryGroup();
            combined.Children.Add(linePath);
            combined.Children.Add(polyPath);
            DrawNeedleShadowAndFill(g, combined, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_CrossbowBolt(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            double hs = r * ArrowheadSizeMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var boh = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
            var p = GetPerpendicularVector(a);
            var p1 = new Point(boh.X - p.X * hs / 3, boh.Y - p.Y * hs / 3);
            var p2 = new Point(boh.X + p.X * hs / 3, boh.Y + p.Y * hs / 3);
            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
            var f1 = new Point(tail.X - p.X * hs / 2, tail.Y - p.Y * hs / 2);
            var f2 = new Point(tail.X + p.X * hs / 2, tail.Y + p.Y * hs / 2);

            var path = PolygonGeometry(new[] { t, p2, f2, f1, p1 }, true, true);
            DrawNeedleShadowAndFill(g, path, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_VintageAviator(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
            var p = GetPerpendicularVector(a);
            double w = r * 0.05;
            var p1 = new Point(t.X - p.X * w, t.Y - p.Y * w);
            var p2 = new Point(t.X + p.X * w, t.Y + p.Y * w);
            var p3 = new Point(tail.X + p.X * w * 2, tail.Y + p.Y * w * 2);
            var p4 = new Point(tail.X - p.X * w * 2, tail.Y - p.Y * w * 2);

            var path = PolygonGeometry(new[] { p1, p2, p3, p4 }, true, true);
            DrawNeedleShadowAndFill(g, path, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_Harpoon(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            double hs = r * ArrowheadSizeMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var n = PointOnCircle(c, r * NeedleTipMultiplier - hs, Value);
            var b1 = PointOnCircle(n, hs * 0.5, Value, 150);
            var b2 = PointOnCircle(n, hs * 0.5, Value, -150);

            var mainLine = LineGeometry(c, t);
            var barb1 = LineGeometry(b1, n);
            var barb2 = LineGeometry(n, b2);
            var combined = new GeometryGroup();
            combined.Children.Add(mainLine);
            combined.Children.Add(barb1);
            combined.Children.Add(barb2);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 3 * _scale), combined, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_CompassNorth(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double s = r * ClassicNeedleBaseWidthMultiplier / 2;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var tail = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
            var p1 = new Point(c.X - p.X * s, c.Y - p.Y * s);
            var p2 = new Point(c.X + p.X * s, c.Y + p.Y * s);

            var halfPath = PolygonGeometry(new[] { t, p2, c, p1 }, true, true);
            g.DrawGeometry(new SolidColorBrush(WithAlpha(NeedleColor2, NeedleTransparency)), null, halfPath);

            var fullPath = PolygonGeometry(new[] { t, p2, tail, p1 }, true, false);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), fullPath, a, r);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_AnchorTail(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            DrawNeedle_SimplePin(g, rect);
            double ts = r * KiteTailSizeMultiplier * 1.5;
            var tb = PointOnCircle(c, r * NeedleTailMultiplier, Value, 180);
            var te = PointOnCircle(tb, ts * 0.5, Value, 180);
            var p1 = PointOnCircle(te, ts, Value, 180 + 90);
            var p2 = PointOnCircle(te, ts, Value, 180 - 90);

            var path = MultiLineGeometry(tb, te, p1, p2);
            var pen = new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 4 * _scale)
            { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
            g.DrawGeometry(null, pen, path);
            DrawNeedleHub(g, c, r);
        }

        private void DrawNeedle_SciFiHollow(DrawingContext g, Rect rect)
        {
            double r = rect.Width * 0.5;
            var c = new Point(rect.Left + r, rect.Top + r);
            double a = MapValueToAngle(Value);
            var p = GetPerpendicularVector(a);
            double bw = r * BlockyNeedleWidthMultiplier;
            var t = PointOnCircle(c, r * NeedleTipMultiplier, Value);
            var bl = new Point(c.X - p.X * bw / 2, c.Y - p.Y * bw / 2);
            var br = new Point(c.X + p.X * bw / 2, c.Y + p.Y * bw / 2);

            var path = PolygonGeometry(new[] { t, br, bl }, true, true);
            DrawNeedleShadowAndFill(g, new Pen(new SolidColorBrush(WithAlpha(NeedleColor1, NeedleTransparency)), 2 * _scale), path, a, r);
            DrawNeedleHub(g, c, r);
        }
        #endregion

        #region --- Helper Methods ---
        private double MapValueToAngle(double v) { double r = MaxValue - MinValue; return r <= 0 ? ScaleStartAngle : ScaleStartAngle + (Clamp(v, MinValue, MaxValue) - MinValue) / r * ScaleSweepAngle; }
        private Point PointOnCircle(Point c, double r, double v) { double a = MapValueToAngle(v); double rad = DegToRad(a); return new Point(c.X + Math.Cos(rad) * r, c.Y + Math.Sin(rad) * r); }
        private Point PointOnCircle(Point c, double r, double v, double angleOffset) { double a = MapValueToAngle(v) + angleOffset; double rad = DegToRad(a); return new Point(c.X + Math.Cos(rad) * r, c.Y + Math.Sin(rad) * r); }
        private static double Clamp(double v, double min, double max) => Math.Max(min, Math.Min(max, v));
        private double SpanForRange(double from, double to) { double t = MaxValue - MinValue; return t <= 0 ? 0 : (Clamp(to, MinValue, MaxValue) - Clamp(from, MinValue, MaxValue)) / t * ScaleSweepAngle; }
        private static double DegToRad(double deg) => (Math.PI / 180.0) * deg;
        private static int NiceNumber(float raw) { if (raw <= 0) return 1; double exp = Math.Floor(Math.Log10(raw)); double p = Math.Pow(10.0, exp); double n = raw / p, nf; if (n <= 1.0) nf = 1.0; else if (n <= 2.0) nf = 2.0; else if (n <= 5.0) nf = 5.0; else nf = 10.0; return Math.Max(1, (int)(nf * p)); }
        private Point GetDirectionVector(double a) { double rad = DegToRad(a); return new Point(Math.Cos(rad), Math.Sin(rad)); }
        private Point GetPerpendicularVector(double a) { double rad = DegToRad(a); return new Point(-Math.Sin(rad), Math.Cos(rad)); }
        #endregion
    }
}