﻿//using SpeedoMeter;
//using System;
//using System.Diagnostics;
//using System.Windows;
//using System.Windows.Threading;

//namespace WPF.Client
//{
//    /// <summary>
//    /// Interaction logic for MainWindow.xaml
//    /// </summary>
//    public partial class MainWindow : Window
//    {
//        private PerformanceCounter performanceCounter;
//        private DispatcherTimer timer;

//        public MainWindow()
//        {
//            InitializeComponent();
//        }

//        private void Grid_Loaded(object sender, RoutedEventArgs e)
//        {
//            try
//            {
//                // Initialize performance counter for total CPU usage
//                performanceCounter = new PerformanceCounter("Processor Information", "% Processor Performance", "_Total");

//                // First call always returns 0, so we call it once to initialize
//                performanceCounter.NextValue();

//                // Use DispatcherTimer for WPF to safely update UI controls on the UI thread
//                timer = new DispatcherTimer();
//                timer.Interval = TimeSpan.FromMilliseconds(1000); // 1000ms = 1 second
//                timer.Tick += Timer_Tick;
//                timer.Start();
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Failed to initialize Performance Counter. Ensure you are running as Administrator if needed.\n\nError: {ex.Message}");
//            }
//        }

//        private void Timer_Tick(object? sender, EventArgs e)
//        {
//            if (performanceCounter != null)
//            {
//                // Get the current CPU value
//                float value = performanceCounter.NextValue();

//                // Update the WPF Speedometer Control
//                speedometerControl1.Value = value;
//            }
//        }
//    }
//}













using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Threading;

namespace WPF.Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private PerformanceCounter performanceCounter;
        private DispatcherTimer timer;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                // Initialize the performance counter
                performanceCounter = new PerformanceCounter("Processor Information", "% Processor Performance", "_Total");

                // First call always returns 0, so we call it once to initialize
                performanceCounter.NextValue();

                // DispatcherTimer is required in WPF to update UI elements safely from the UI thread
                timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromMilliseconds(1000); // Update every 1 second
                timer.Tick += Timer_Tick;
                timer.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to initialize Performance Counter.\nEnsure you have permissions.\n\nError: {ex.Message}");
            }
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (performanceCounter != null)
            {
                // Get the current CPU value
                float value = performanceCounter.NextValue();

                // Update BOTH the large and small speedometers simultaneously
                speedometerControl1.Value = value;
                speedometerControl2.Value = value;
            }
        }
    }
}