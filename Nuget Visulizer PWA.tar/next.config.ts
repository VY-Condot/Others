import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Standalone output for Azure App Service / container deployment
  output: "standalone",
  // TypeScript checking (kept relaxed for dev speed)
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Azure-compatible server settings
  serverExternalPackages: ["@prisma/client"],
  // Allow cross-origin for Azure preview domains
  allowedDevOrigins: ["*.azurewebsites.net", "*.trafficmanager.net"],
  // Headers for Azure deployment
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
        ],
      },
    ];
  },
};

export default nextConfig;
