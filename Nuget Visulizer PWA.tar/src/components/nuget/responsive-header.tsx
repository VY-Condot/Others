"use client";

import { useState } from "react";
import {
  PackageSearch,
  FileCode2,
  Github,
  Save,
  History,
  GitCompare,
  MessageSquare,
  Bug,
  Command,
  Menu,
  X,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { ThemeToggle } from "@/components/nuget/theme-toggle";
import { ShareButton } from "@/components/nuget/share-button";
import { cn } from "@/lib/utils";
import type { AuditResult } from "@/lib/audit";

interface Props {
  result: AuditResult | null;
  saving: boolean;
  onSave: () => void;
  onOpenHistory: () => void;
  onOpenDiff: () => void;
  onOpenFeedback: () => void;
  onOpenPalette: () => void;
  onOpenShortcuts: () => void;
}

export function ResponsiveHeader({
  result,
  saving,
  onSave,
  onOpenHistory,
  onOpenDiff,
  onOpenFeedback,
  onOpenPalette,
  onOpenShortcuts,
}: Props) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navActions = [
    { label: "API docs", icon: FileCode2, href: "https://learn.microsoft.com/en-us/nuget/api/overview", external: true },
    { label: "Advisories", icon: Github, href: "https://github.com/advisories?query=type%3Areviewed+ecosystem%3Anuget", external: true },
  ];

  const toolActions = [
    ...(result ? [{ label: "Save", icon: saving ? Loader2 : Save, onClick: onSave, disabled: saving, spinning: saving }] : []),
    { label: "History", icon: History, onClick: onOpenHistory },
    { label: "Diff", icon: GitCompare, onClick: onOpenDiff },
    { label: "Feedback", icon: MessageSquare, onClick: onOpenFeedback },
  ];

  return (
    <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-3 sm:px-6 lg:px-8 h-14 flex items-center gap-2 sm:gap-3">
        {/* Logo + Brand — shrinkable, never scatters */}
        <div className="flex items-center gap-2 shrink-0 min-w-0">
          <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5 shrink-0">
            <PackageSearch className="h-4 w-4 text-white" />
          </div>
          <div className="leading-tight min-w-0 hidden xs:block">
            <h1 className="text-sm font-semibold truncate">NuGet Auditor</h1>
            <p className="text-[10px] text-muted-foreground hidden sm:block">parse · visualize · audit</p>
          </div>
        </div>

        {/* Status badge — desktop only */}
        <Badge variant="outline" className="hidden lg:inline-flex text-[10px] gap-1 shrink-0">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
          nuget.org v3 API
        </Badge>

        {/* Desktop actions — hidden on mobile */}
        <div className="ml-auto hidden md:flex items-center gap-1.5">
          {navActions.map((a) => (
            <Button key={a.label} asChild variant="ghost" size="sm" className="text-xs">
              <a href={a.href} target="_blank" rel="noreferrer noopener">
                <a.icon className="h-3.5 w-3.5" /> {a.label}
              </a>
            </Button>
          ))}
          {result && <ShareButton result={result} />}
          {toolActions.map((a) => (
            <Button
              key={a.label}
              variant="outline"
              size="sm"
              className="text-xs gap-1.5"
              onClick={a.onClick}
              disabled={a.disabled}
            >
              <a.icon className={cn("h-3.5 w-3.5", a.spinning && "animate-spin")} />
              <span className="hidden lg:inline">{a.label}</span>
            </Button>
          ))}
          <Button
            variant="outline"
            size="sm"
            className="text-xs gap-1.5"
            onClick={onOpenPalette}
            title="Command palette (Cmd+K)"
          >
            <Command className="h-3.5 w-3.5" />
            <kbd className="hidden lg:inline font-mono text-[10px] text-muted-foreground">⌘&nbsp;K</kbd>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-xs"
            onClick={onOpenShortcuts}
            aria-label="Keyboard shortcuts"
            title="Keyboard shortcuts (?)"
          >
            <kbd className="font-mono text-[10px]">?</kbd>
          </Button>
          <ThemeToggle />
        </div>

        {/* Mobile: condensed actions + menu button */}
        <div className="ml-auto flex md:hidden items-center gap-1">
          {result && <ShareButton result={result} />}
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={onOpenPalette}
            title="Command palette"
          >
            <Command className="h-3.5 w-3.5" />
          </Button>
          <ThemeToggle />
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Mobile menu sheet */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="right" className="w-[280px] sm:w-[320px]">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <PackageSearch className="h-4 w-4" />
              Menu
            </SheetTitle>
          </SheetHeader>
          <div className="mt-4 space-y-1">
            {toolActions.map((a) => (
              <button
                key={a.label}
                onClick={() => { a.onClick(); setMobileOpen(false); }}
                disabled={a.disabled}
                className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-muted/60 transition-colors text-left"
              >
                <a.icon className={cn("h-4 w-4 text-muted-foreground", a.spinning && "animate-spin")} />
                {a.label}
              </button>
            ))}
            <div className="h-px bg-border my-2" />
            {navActions.map((a) => (
              <a
                key={a.label}
                href={a.href}
                target="_blank"
                rel="noreferrer noopener"
                className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-muted/60 transition-colors"
              >
                <a.icon className="h-4 w-4 text-muted-foreground" />
                {a.label}
                <X className="h-3 w-3 ml-auto opacity-40" />
              </a>
            ))}
            <div className="h-px bg-border my-2" />
            <button
              onClick={() => { onOpenPalette(); setMobileOpen(false); }}
              className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-muted/60 transition-colors text-left"
            >
              <Command className="h-4 w-4 text-muted-foreground" />
              Command palette
            </button>
          </div>
          <div className="mt-6 pt-4 border-t">
            <Badge variant="outline" className="text-[10px] gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              nuget.org v3 API
            </Badge>
          </div>
        </SheetContent>
      </Sheet>
    </header>
  );
}
