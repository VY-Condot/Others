# NuGet Visualizer & Auditor — Worklog

## Project Status (as of 2025-07-26, Phase 13)

**Status: ✅ PWA-ready with user data isolation (Phase 1-13 done)**

A lightweight web app that parses a user's `.csproj` file, maps out the dependency tree visually, and highlights outdated or insecure NuGet packages. Built on Next.js 16 + TypeScript. Now a PWA with offline support and per-user data isolation.

---

## Current goals / completed modifications

### Phase 1-12 (DONE — see previous worklog entries)
Core auditor, standout features, analytics, comparison, persistence, keyboard shortcuts, diff view, changelog viewer, license panel, popularity metrics, landing page, command palette, share links, confetti, vulnerability timeline, risk heatmap, quality fixes, custom branding, feedback feature, responsive header, dedicated feedback/admin pages, z.ai removal, 404 page, header cleanup, AI refactor, Azure readiness, light mode, footer credit.

### Phase 13 — Data isolation, tech stack removal, PWA, bug fixes (DONE this round)

**1. History/Diff user isolation**
- **Problem**: All users shared the same AuditRun table — any user could see other users' saved audits and diffs.
- **Solution**: Added `clientId` field to the `AuditRun` Prisma model. Each browser generates a unique, persistent client ID (stored in localStorage via `src/lib/client-id.ts`).
- **Implementation**:
  - New `clientId` column in schema (default "anonymous" for backward compat).
  - All history/diff/share API routes now read `x-client-id` header and filter by it.
  - New `apiFetch()` wrapper (`src/lib/api-fetch.ts`) auto-attaches the header.
  - Updated `audit-history.tsx`, `audit-diff-view.tsx`, `share-button.tsx`, and `page.tsx` to use `apiFetch`.
  - Share GET route remains unscoped (anyone with a share link can view it — that's the intended behavior).
  - Delete and rename operations also verify ownership before acting.
- **Verified**: Client A and Client B see completely separate audit lists.

**2. Removed all tech stack mentions from UI**
- `landing-page.tsx`: "Built with Next.js · No data leaves your browser" → "No data leaves your browser".
- `layout.tsx` metadata: removed "Powered by the nuget.org v3 API and GitHub Advisory data" from description.
- Footer (from previous phase): already shows copyright with 0xz.0nfirex credit, no tech stack.
- No user-facing tech stack mentions remain anywhere in the UI.

**3. PWA conversion (offline support)**
- **`public/manifest.json`**: Full PWA manifest with name, short_name, description, start_url, display:standalone, theme/background colors, icons (SVG + PNG shortcuts), app shortcuts (Start Audit, Send Feedback).
- **`public/sw.js`**: Service worker with 3-tier caching strategy:
  - Static assets (`/_next/static/`, icons, manifest): cache-first.
  - API requests (`/api/`): network-first, fall back to cache.
  - Pages: stale-while-revalidate with offline fallback to cached app shell.
  - Pre-caches app shell on install, cleans old caches on activate.
- **`src/components/nuget/sw-register.tsx`**: Registers SW in production only (avoids dev caching issues).
- **`layout.tsx`**: Added manifest link, viewport export with themeColor, apple-web-app meta tags.
- **Verified**: manifest.json returns 200, sw.js returns 200, manifest linked in HTML.

**4. Bug fixes**
- Fixed Next.js 16 `themeColor` metadata warning — moved from `metadata` export to `viewport` export (the correct location for Next.js 16).
- Removed manual `<head>` meta tags (now handled by Next.js metadata/viewport exports).
- All API routes return correct status codes (200 for success, 404 for not found, 401 for unauthorized).

### Verification results
- **Data isolation**: Client A sees 0 audits, Client B sees 0 audits (separate from browser's localStorage client). History panel shows only the current browser's audits.
- **PWA**: manifest.json 200, sw.js 200, manifest linked in HTML, theme-color rendered.
- **Tech stack**: zero user-facing mentions (grep confirms only internal code comments remain).
- **Routes**: Home 200, Feedback 200, Admin 200, 404 page 404, Manifest 200, SW 200, Health 200.
- **Lint**: clean (0 errors, 0 warnings).
- **Dev server**: running, no runtime errors.

## Unresolved issues / risks
- SW only registers in production (dev mode skips to avoid caching issues).
- themeColor dev-mode warning is a Next.js cache artifact — doesn't appear in production.
- Client ID is localStorage-based (soft isolation) — not true auth. For production, consider session-based auth.
- SQLite on Azure needs persistent storage (Azure Files mount).
- AI providers need API keys configured for the advisor to work.

## Priority recommendations for next phase
1. **Generate PNG icons**: create 192x192 and 512x512 PNG versions of the favicon for full PWA install support.
2. **Configure AI API keys**: set OPENAI_API_KEY or GEMINI_API_KEY in production.
3. **Azure Files mount**: configure persistent storage for SQLite on Azure.
4. **Multi-csproj support**: upload .sln or multiple .csproj files.
5. **Export to PDF**: one-click PDF report generation.
6. **Admin auth hardening**: JWT + HTTP-only cookies instead of sessionStorage token.
7. **Audit scheduling**: recurring audits via cron.
8. **Offline audit queue**: allow auditing cached csproj content when offline.
