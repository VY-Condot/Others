"use client";

import { GlobalLayout } from "@/components/nuget/global-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  FileCode2,
  ShieldCheck,
  GitGraph,
  Bot,
  Terminal,
  BarChart3,
  Github,
  Boxes,
  Award,
  History,
  Keyboard,
} from "lucide-react";

const DOCS = [
  {
    icon: FileCode2,
    title: "Getting Started",
    sections: [
      { h: "Upload your .csproj", p: "Drag & drop a .csproj file, paste the XML content, or click 'Load sample' to try the tool with a demo project. The file is parsed locally in your browser — no data is sent to the server until you click 'Audit dependencies'." },
      { h: "Run the audit", p: "Click the 'Audit dependencies' button. The tool fetches package metadata from the nuget.org v3 registration API for each PackageReference in your .csproj. This typically takes 1-3 seconds depending on the number of packages." },
      { h: "Read the results", p: "The dashboard shows a health score (A-F grade), stats cards (total/outdated/vulnerable/deprecated), and detailed tables for vulnerabilities, outdated packages, and all packages. Use the tabs to switch between views." },
    ],
  },
  {
    icon: ShieldCheck,
    title: "Vulnerability Auditing",
    sections: [
      { h: "How vulnerabilities are detected", p: "The tool fetches the NuGet registration index for each package, which includes a top-level 'vulnerabilities' array sourced from the GitHub Advisory database. Each vulnerability has a severity (low/moderate/high/critical), an affected version range (e.g., '[,6.35.0)'), and an advisory URL." },
      { h: "Version range matching", p: "Your declared package version is checked against each vulnerability's affected range using semver range matching. If your version falls within the range, the vulnerability is flagged with the appropriate severity badge." },
      { h: "What to do about vulnerabilities", p: "Click any vulnerability row to see the advisory details. The tool suggests the latest stable version as a fix. Use the Upgrade & Export tab to generate a shell script or PowerShell script with all the `dotnet add package` commands needed to upgrade." },
    ],
  },
  {
    icon: GitGraph,
    title: "Force-Directed Graph",
    sections: [
      { h: "What it shows", p: "The force-directed graph visualizes your dependency tree as an interactive network. The root node (your project) sits at the center, with direct dependencies radiating outward and transitive dependencies on the outer ring." },
      { h: "Node colors", p: "Green nodes are up-to-date and secure. Blue nodes are outdated (newer version available). Red nodes have known vulnerabilities. The severity is shown as a dot color (yellow=low, orange=moderate, red=high, dark red=critical)." },
      { h: "Interactions", p: "Drag nodes to reposition them (the physics simulation adapts). Scroll to zoom. Click a node to see its package details. Use the Pause/Play, Reset View, and Re-layout buttons to control the simulation." },
    ],
  },
  {
    icon: Bot,
    title: "AI Remediation Advisor",
    sections: [
      { h: "How it works", p: "Click 'Get AI plan' to send a compact summary of your audit to an AI model (OpenAI GPT or Google Gemini). The AI analyzes your packages, vulnerabilities, and outdated versions, then generates a prioritized remediation plan in Markdown." },
      { h: "What you get", p: "The plan includes: (1) Critical/high vulnerabilities to fix immediately, (2) Moderate/low vulnerabilities, (3) Major-version outdated packages, (4) Deprecated packages. Each item includes a ready-to-run `dotnet add package` command and breaking-change warnings." },
      { h: "Provider configuration", p: "The AI provider is configured server-side via environment variables. The tool automatically falls back to the other provider (OpenAI ↔ Gemini) if the primary fails." },
    ],
  },
  {
    icon: Terminal,
    title: "Upgrade & Export Toolkit",
    sections: [
      { h: "Bash vs PowerShell", p: "Toggle between Bash (.sh) and PowerShell (.ps1) script formats. The Bash version uses `set -euo pipefail` and echo; the PowerShell version uses `$ErrorActionPreference = 'Stop'` and `Write-Host` with green coloring." },
      { h: "Patched .csproj", p: "The 'Patched csproj' tab shows your original .csproj with all Version attributes bumped to the latest stable releases. Copy or download it as a ready-to-use file." },
      { h: "Markdown report", p: "The 'Markdown report' tab generates a full audit report with summary tables, vulnerability details, and package lists — perfect for attaching to a pull request or compliance review." },
    ],
  },
  {
    icon: BarChart3,
    title: "Analytics Dashboard",
    sections: [
      { h: "Status distribution donut", p: "Shows the proportion of up-to-date (green), outdated (blue), and vulnerable (red) packages. Hover any slice to see the package names in that category." },
      { h: "Health radar", p: "Five-axis radar chart assessing: Freshness (% up-to-date), Security (weighted by vulnerability severity), Stability (% non-deprecated), Compliance (% resolved from live API), and Modernity (% on latest major version)." },
      { h: "Version gap bar chart", p: "Horizontal bar chart showing how many major versions behind each outdated package is, ranked from most behind to least." },
    ],
  },
  {
    icon: Github,
    title: "GitHub Repository Scanner",
    sections: [
      { h: "How to scan a repo", p: "Navigate to the GitHub Scanner page, paste a repository URL (e.g., https://github.com/owner/repo), optionally select a branch/tag, and click Scan. The tool fetches the repository tree via the GitHub API and finds all .csproj files." },
      { h: "Rate limits", p: "Without a GitHub token, the API allows 60 requests/hour per IP. With a personal access token (public read access), you get 5,000/hour. Add your token in the 'GitHub Token' field on the scan page." },
      { h: "Inline auditing", p: "Click 'Audit' on any project to run the audit inline — no page redirect. Click 'Audit All' to bulk-audit every project with progress tracking. Results show inline with health score, charts, tables, and AI advisor." },
    ],
  },
  {
    icon: Boxes,
    title: "Version Drift Matrix",
    sections: [
      { h: "What is version drift?", p: "When different projects in a solution reference different versions of the same package, it's called 'version drift'. This is a common cause of runtime errors in .NET when assemblies with mismatched versions are loaded." },
      { h: "How to use the matrix", p: "After scanning a repo with multiple .csproj files, click 'Drift Matrix'. The grid shows packages as rows and projects as columns. Rows with different versions across projects are highlighted in red with a 'DRIFT' badge." },
    ],
  },
  {
    icon: Award,
    title: "Badge Generator (Viral Loop)",
    sections: [
      { h: "Create a badge", p: "After running an audit, click the 'Badge' button. You'll see a shields.io-compatible SVG badge showing your project's health grade (e.g., 'NuGet audit: B · 89/100')." },
      { h: "Embed in your README", p: "Copy the Markdown snippet and paste it into your GitHub README. The badge links back to the NuGet Auditor, so every visitor who sees it can discover the tool." },
    ],
  },
  {
    icon: History,
    title: "Audit History & Diff",
    sections: [
      { h: "Save audits", p: "Click 'Save' in the header to store the current audit. Saved audits are isolated per-browser (using a client ID) — other users can't see your data." },
      { h: "Compare audits", p: "Click 'Diff' to compare two saved audits side-by-side. The diff shows packages that were added, removed, upgraded, downgraded, or had vulnerabilities fixed/introduced." },
      { h: "Share audits", p: "Click 'Share' to generate a shareable URL. Anyone with the link can view the audit result — no login required." },
    ],
  },
  {
    icon: Keyboard,
    title: "Keyboard Shortcuts",
    sections: [
      { h: "Navigation", p: "Press g then t/v/o/a/p/u to jump to Tree/Vulnerabilities/Outdated/Analytics/All Packages/Upgrade tabs. Press ? to toggle the shortcuts help dialog." },
      { h: "Command palette", p: "Press Cmd+K (Mac) or Ctrl+K (Windows) to open the command palette. Search for any action and press Enter to execute." },
      { h: "Quick actions", p: "Press s to save, h to open history, n to start a new audit, / to focus the search filter." },
    ],
  },
];

export function DocsPage() {
  return (
    <GlobalLayout>
      <main className="flex-1 mx-auto w-full max-w-4xl px-4 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <FileCode2 className="h-6 w-6 text-primary" />
            Documentation
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Complete guide to every feature in the NuGet Visualizer & Auditor.
          </p>
        </div>

        <div className="space-y-4">
          {DOCS.map((doc, i) => (
            <Card key={i}>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <doc.icon className="h-4 w-4 text-primary" />
                  {doc.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {doc.sections.map((s, j) => (
                  <div key={j}>
                    <h4 className="text-sm font-semibold mb-1">{s.h}</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{s.p}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick links */}
        <Card className="bg-gradient-to-br from-primary/5 to-purple-500/5 border-primary/20">
          <CardContent className="pt-5">
            <p className="text-sm font-semibold mb-2">Quick Links</p>
            <div className="flex flex-wrap gap-2">
              <a href="/faq" className="text-xs px-3 py-1.5 border rounded-md hover:bg-muted transition-colors">FAQ</a>
              <a href="/blog" className="text-xs px-3 py-1.5 border rounded-md hover:bg-muted transition-colors">Blog</a>
              <a href="/scan" className="text-xs px-3 py-1.5 border rounded-md hover:bg-muted transition-colors">GitHub Scanner</a>
              <a href="/matrix" className="text-xs px-3 py-1.5 border rounded-md hover:bg-muted transition-colors">Drift Matrix</a>
              <a href="/feedback" className="text-xs px-3 py-1.5 border rounded-md hover:bg-muted transition-colors">Send Feedback</a>
            </div>
          </CardContent>
        </Card>
      </main>
    </GlobalLayout>
  );
}
