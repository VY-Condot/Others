"use client";

import { GlobalLayout } from "@/components/nuget/global-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronDown, ChevronUp, HelpCircle, Search } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const FAQS = [
  {
    q: "What is the NuGet Visualizer & Auditor?",
    a: "It's a free online tool that parses your .csproj file, visualizes your NuGet dependency tree, and audits each package for security vulnerabilities, outdated versions, and license compliance. No signup required — just paste your .csproj XML or upload a file.",
  },
  {
    q: "Do I need to sign up or create an account?",
    a: "No. The NuGet Auditor requires no signup, no login, and stores no personal data. Your .csproj content is parsed locally in your browser. The only external API calls are to nuget.org for package metadata and GitHub Advisories for vulnerability data.",
  },
  {
    q: "How does the vulnerability scanning work?",
    a: "The tool fetches vulnerability data from the NuGet v3 registration API, which includes entries from the GitHub Advisory database. Each declared package version is checked against the affected version ranges using semantic versioning (semver) range matching. If your declared version falls within an affected range, it's flagged with the appropriate severity (low, moderate, high, critical).",
  },
  {
    q: "Can I use this tool offline?",
    a: "Yes. The application is a Progressive Web App (PWA) with a service worker that caches the app shell. However, live NuGet API data (package versions, vulnerabilities, download counts) requires an internet connection. A bundled fallback dataset covers ~18 common packages for offline use.",
  },
  {
    q: "Is my data shared with anyone?",
    a: "No. Audit data is isolated per-browser using a client ID. Shared audit links are opt-in and only accessible via the generated URL. Feedback submissions are stored in a local SQLite database and are only viewable by the admin (token-gated).",
  },
  {
    q: "What is the health score and how is it calculated?",
    a: "The health score is a 0-100 composite grade based on: vulnerability severity (critical=-60, high=-35, moderate=-18, low=-8), outdated ratio (up to -25 based on % of outdated packages), deprecation count (-4 each), and additional vulnerable packages (-6 each beyond the first). Grades: A (90+), B (75+), C (60+), D (40+), F (<40).",
  },
  {
    q: "Can I scan a GitHub repository directly?",
    a: "Yes! Navigate to the GitHub Scanner page, paste a repository URL, and the tool will scan the repo tree for .csproj files via the GitHub API (no cloning needed). You can select specific branches/tags and audit individual projects or all projects at once.",
  },
  {
    q: "What is the Version Drift Matrix?",
    a: "When you have multiple .csproj files (e.g., from a solution), the Drift Matrix shows a grid where rows are packages and columns are projects. It highlights cases where different projects use different versions of the same package — a common cause of runtime errors in .NET.",
  },
  {
    q: "How does the AI Remediation Advisor work?",
    a: "The AI advisor sends a compact summary of your audit results to an LLM (OpenAI GPT or Google Gemini, configured server-side). The AI generates a prioritized remediation plan with copy-ready `dotnet add package` commands and breaking-change callouts. The advisor auto-falls back to the other provider if one fails.",
  },
  {
    q: "Can I embed a health score badge in my README?",
    a: "Yes! Click the 'Badge' button after running an audit. You'll get a shields.io-compatible SVG badge showing your project's grade (e.g., 'NuGet audit: B · 89/100'). Copy the Markdown or HTML snippet and paste it into your GitHub README. Every badge links back to the auditor — spreading the word.",
  },
  {
    q: "What programming languages and frameworks does this support?",
    a: "The tool parses MSBuild-format .csproj files (XML), which are used by all .NET projects including .NET Core, .NET 5/6/7/8, ASP.NET Core, Blazor, MAUI, and more. It does not currently support packages.config (legacy NuGet format) or other ecosystems (npm, pip, etc.).",
  },
  {
    q: "Is the tool open source?",
    a: "The tool is free to use. The source code is available for inspection. Contact the developer (0xz.0nfirex) for licensing inquiries or contribution opportunities.",
  },
];

export function FaqPage() {
  const [open, setOpen] = useState<number | null>(0);
  const [query, setQuery] = useState("");

  const filtered = FAQS.filter(
    (f) => f.q.toLowerCase().includes(query.toLowerCase()) || f.a.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <GlobalLayout>
      <main className="flex-1 mx-auto w-full max-w-3xl px-4 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <HelpCircle className="h-6 w-6 text-primary" />
            Frequently Asked Questions
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Everything you need to know about auditing NuGet packages with our tool.
          </p>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search questions..."
            className="w-full pl-9 pr-4 py-2.5 rounded-lg border bg-background text-sm"
          />
        </div>

        {/* FAQ items */}
        <div className="space-y-2">
          {filtered.map((faq, i) => (
            <Card key={i} className="overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full text-left p-4 hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-semibold">{faq.q}</h3>
                  {open === i ? <ChevronUp className="h-4 w-4 text-muted-foreground shrink-0" /> : <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />}
                </div>
              </button>
              {open === i && (
                <div className="px-4 pb-4 animate-fade-up">
                  <p className="text-sm text-muted-foreground leading-relaxed">{faq.a}</p>
                </div>
              )}
            </Card>
          ))}
          {filtered.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-8">No questions match "{query}"</p>
          )}
        </div>

        {/* Still have questions? */}
        <Card className="bg-gradient-to-br from-primary/5 to-purple-500/5 border-primary/20">
          <CardContent className="pt-5 text-center">
            <p className="text-sm font-semibold">Still have questions?</p>
            <p className="text-xs text-muted-foreground mt-1 mb-3">Submit feedback or a bug report — we'll get back to you.</p>
            <a href="/feedback" className="inline-flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm">
              Send Feedback →
            </a>
          </CardContent>
        </Card>
      </main>
    </GlobalLayout>
  );
}
