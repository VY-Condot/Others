"use client";

import { GlobalLayout } from "@/components/nuget/global-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, ArrowRight, ShieldAlert, TrendingUp, Zap, BookOpen, GitBranch, Package } from "lucide-react";

const POSTS = [
  {
    title: "How to Audit NuGet Packages for Security Vulnerabilities in 2025",
    excerpt: "A complete guide to scanning your .NET projects for known CVEs, understanding severity levels, and generating remediation plans with copy-ready dotnet commands.",
    date: "2025-07-28",
    readTime: "8 min",
    icon: ShieldAlert,
    color: "text-red-500",
    tags: ["Security", "NuGet", "Vulnerabilities"],
    content: [
      "Every .NET project depends on dozens — sometimes hundreds — of NuGet packages. Each one is a potential attack surface. In this guide, we'll walk through how to audit your dependencies for known vulnerabilities using the NuGet Visualizer & Auditor.",
      "The tool fetches vulnerability data from the GitHub Advisory database (embedded in the NuGet v3 registration API). Each package version is checked against affected ranges using semver matching. If your declared version falls within an affected range, it's flagged with a severity badge (low, moderate, high, or critical).",
      "Once you've identified vulnerable packages, the AI Remediation Advisor can generate a prioritized upgrade plan. The plan includes copy-ready `dotnet add package` commands and flags known breaking changes for major version bumps.",
    ],
  },
  {
    title: "Understanding NuGet Version Drift in Multi-Project Solutions",
    excerpt: "Version drift occurs when different projects in a solution reference different versions of the same package. Learn why this is dangerous and how to detect it.",
    date: "2025-07-26",
    readTime: "6 min",
    icon: GitBranch,
    color: "text-blue-500",
    tags: ["Best Practices", "Multi-Project", "Versioning"],
    content: [
      "In modern .NET development, solutions often contain multiple projects — a web API, a background worker, a shared library, test projects. Each has its own .csproj file with its own PackageReference entries.",
      "When Project A references Newtonsoft.Json 13.0.1 and Project B references 12.0.3, you have version drift. At runtime, the .NET assembly loader may load the wrong version, causing MissingMethodException or TypeLoadException.",
      "The NuGet Auditor's Drift Matrix visualizes this as a grid: rows are packages, columns are projects. Rows with different versions are highlighted in red. Fix drift by aligning all projects to the same version — the Upgrade & Export toolkit generates the commands for you.",
    ],
  },
  {
    title: "5 Tips for Keeping Your .NET Dependencies Healthy",
    excerpt: "Practical tips for maintaining secure, up-to-date NuGet packages without breaking your build. Includes automation strategies and CI/CD integration ideas.",
    date: "2025-07-24",
    readTime: "5 min",
    icon: TrendingUp,
    color: "text-emerald-500",
    tags: ["Tips", "Automation", "CI/CD"],
    content: [
      "1. Audit regularly. Run the NuGet Auditor before every release. The health score gives you a single metric to track over time — aim for an 'A' grade (90+).",
      "2. Pin major versions. Use version ranges like [8.0.0,9.0.0) in your .csproj to allow patch updates but prevent surprise major bumps.",
      "3. Watch for deprecations. NuGet marks packages as deprecated when they're no longer maintained. The auditor flags these with an amber badge — plan a migration before the package disappears entirely.",
      "4. Automate with scripts. Use the 'Copy all commands' button to generate a shell script, then run it in your CI/CD pipeline before merging PRs.",
      "5. Share your score. Embed the health score badge in your README. It shows users you take security seriously — and spreads the word about the tool.",
    ],
  },
  {
    title: "How the AI Remediation Advisor Works Under the Hood",
    excerpt: "A technical deep-dive into the flexible AI provider architecture that powers the advisor — supporting both OpenAI and Gemini with automatic fallback.",
    date: "2025-07-22",
    readTime: "7 min",
    icon: Zap,
    color: "text-purple-500",
    tags: ["AI", "Architecture", "Deep Dive"],
    content: [
      "The AI Remediation Advisor uses a flexible provider abstraction that supports both OpenAI (ChatGPT) and Google Gemini. The active provider is configured via the AI_PROVIDER environment variable.",
      "When you click 'Get AI plan', the tool sends a compact audit summary (not the full .csproj) to the server. The server constructs a system prompt that instructs the AI to act as a senior .NET security advisor, then routes the request to the configured provider via direct REST API calls — no SDK dependency.",
      "If the primary provider fails (rate limit, timeout, API error), the tool automatically falls back to the other provider. The response is streamed back to the client with a typing effect for a premium UX feel.",
    ],
  },
  {
    title: "From .csproj to Security Report: The Parsing Pipeline Explained",
    excerpt: "Learn how the tool parses MSBuild XML, resolves package metadata from nuget.org, matches vulnerabilities, and builds the dependency tree — all in under 2 seconds.",
    date: "2025-07-20",
    readTime: "6 min",
    icon: Package,
    color: "text-orange-500",
    tags: ["Technical", "Parsing", "NuGet API"],
    content: [
      "The .csproj parser uses the browser's built-in DOMParser to parse the MSBuild XML. It handles both attribute-form (<PackageReference Include='X' Version='Y' />) and child-element-form (<PackageReference Include='X'><Version>Y</Version></PackageReference>) entries.",
      "For each package, the tool fetches the NuGet v3 registration index (a single gzipped JSON document containing all versions, dependencies, and vulnerabilities). Results are cached in-memory for 10 minutes to avoid redundant API calls.",
      "Vulnerability matching uses semver range parsing. NuGet ranges like '[,6.35.0)' are normalized and checked against the coerced declared version. The audit runs with concurrency 6 — 6 packages are fetched in parallel, keeping the total audit time under 2 seconds for typical projects.",
    ],
  },
  {
    title: "Why We Built a Force-Directed Graph for Dependency Visualization",
    excerpt: "Traditional tree views are great for hierarchy, but dependencies form a graph. Learn why we chose a physics-based force simulation and how it helps spot risky patterns.",
    date: "2025-07-18",
    readTime: "4 min",
    icon: BookOpen,
    color: "text-indigo-500",
    tags: ["Design", "Visualization", "Graph"],
    content: [
      "Dependency trees are actually graphs — the same transitive dependency can appear under multiple direct dependencies. A traditional tree view duplicates these nodes, making it hard to see the full picture.",
      "Our force-directed graph uses a custom Canvas-based physics simulation (no external library). Coulomb repulsion prevents nodes from overlapping, Hooke spring attraction keeps connected packages close, and collision detection ensures labels are readable.",
      "The result is an interactive, living visualization where you can drag nodes, zoom in on clusters, and immediately spot 'hub' packages (highly connected) and 'orphan' packages (disconnected from the main graph). Red nodes with high connectivity are your biggest risks.",
    ],
  },
];

export function BlogPage() {
  return (
    <GlobalLayout>
      <main className="flex-1 mx-auto w-full max-w-4xl px-4 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-primary" />
            Blog
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Articles and guides on NuGet security, .NET dependency management, and keeping your projects safe.
          </p>
        </div>

        {/* Blog posts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {POSTS.map((post, i) => (
            <Card key={i} className="hover:shadow-lg transition-shadow cursor-pointer group h-full flex flex-col">
              <CardContent className="pt-5 flex flex-col flex-1">
                <div className="flex items-center gap-2 mb-3">
                  <div className={cn("rounded-lg bg-muted/40 p-2", "group-hover:scale-110 transition-transform")}>
                    <post.icon className={cn("h-5 w-5", post.color)} />
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {post.readTime}
                  </div>
                  <span className="text-[10px] text-muted-foreground ml-auto">{post.date}</span>
                </div>
                <h3 className="text-sm font-semibold mb-1.5 group-hover:text-primary transition-colors">{post.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed flex-1">{post.excerpt}</p>
                <div className="flex items-center gap-1.5 mt-3 flex-wrap">
                  {post.tags.map((t) => (
                    <Badge key={t} variant="outline" className="text-[9px]">{t}</Badge>
                  ))}
                </div>
                <div className="flex items-center gap-1 mt-3 text-xs text-primary font-medium">
                  Read more <ArrowRight className="h-3 w-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Newsletter CTA */}
        <Card className="bg-gradient-to-br from-primary/5 to-purple-500/5 border-primary/20">
          <CardContent className="pt-5 text-center">
            <p className="text-sm font-semibold">Want more .NET security tips?</p>
            <p className="text-xs text-muted-foreground mt-1 mb-3">Bookmark this page — we publish new articles regularly.</p>
            <div className="flex justify-center gap-2">
              <a href="/docs" className="text-xs px-4 py-2 border rounded-md hover:bg-muted transition-colors">Read Docs</a>
              <a href="/faq" className="text-xs px-4 py-2 border rounded-md hover:bg-muted transition-colors">View FAQ</a>
            </div>
          </CardContent>
        </Card>
      </main>
    </GlobalLayout>
  );
}

import { cn } from "@/lib/utils";
