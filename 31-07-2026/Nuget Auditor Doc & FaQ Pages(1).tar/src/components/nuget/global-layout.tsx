"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  PackageSearch,
  Github,
  GitCompare,
  FileCode2,
  History,
  Save,
  MessageSquare,
  Command,
  Menu,
  X,
  Loader2,
  ShieldCheck,
  Bot,
  Terminal,
  Network,
  ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { ThemeToggle } from "@/components/nuget/theme-toggle";
import { ShareButton } from "@/components/nuget/share-button";
import { cn } from "@/lib/utils";
import type { AuditResult } from "@/lib/audit";

interface GlobalLayoutProps {
  children: React.ReactNode;
  result?: AuditResult | null;
  saving?: boolean;
  onSave?: () => void;
  onOpenHistory?: () => void;
  onOpenDiff?: () => void;
  onOpenPalette?: () => void;
}

const INTERNAL_LINKS = [
  { label: "Home", href: "/", icon: PackageSearch },
  { label: "GitHub Scan", href: "/scan", icon: Github },
  { label: "Drift Matrix", href: "/matrix", icon: GitCompare },
];

const EXTERNAL_LINKS = [
  { label: "API docs", href: "https://learn.microsoft.com/en-us/nuget/api/overview", icon: FileCode2 },
  { label: "Advisories", href: "https://github.com/advisories?query=type%3Areviewed+ecosystem%3Anuget", icon: Github },
];

const APP_VERSION = process.env.NEXT_PUBLIC_APP_VERSION || "1.0.0";

export function GlobalLayout({
  children,
  result,
  saving,
  onSave,
  onOpenHistory,
  onOpenDiff,
  onOpenPalette,
}: GlobalLayoutProps) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isActive = (href: string) => {
    if (href === "/") return pathname === "/";
    return pathname?.startsWith(href);
  };

  const toolActions = [
    ...(result && onSave ? [{ label: "Save", icon: saving ? Loader2 : Save, onClick: onSave, disabled: saving, spinning: saving }] : []),
    ...(onOpenHistory ? [{ label: "History", icon: History, onClick: onOpenHistory }] : []),
    ...(onOpenDiff ? [{ label: "Diff", icon: GitCompare, onClick: onOpenDiff }] : []),
    { label: "Feedback", icon: MessageSquare, href: "/feedback" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header — exact match to original ResponsiveHeader */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-3 sm:px-6 lg:px-8 h-14 flex items-center gap-2 sm:gap-3">
          {/* Logo + Brand */}
          <Link href="/" className="flex items-center gap-2 shrink-0 min-w-0">
            <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5 shrink-0">
              <PackageSearch className="h-4 w-4 text-white" />
            </div>
            <div className="leading-tight min-w-0 hidden xs:block">
              <h1 className="text-sm font-semibold truncate">NuGet Auditor</h1>
              <p className="text-[10px] text-muted-foreground hidden sm:block">parse · visualize · audit</p>
            </div>
          </Link>

          {/* Status badge — desktop only */}
          <Badge variant="outline" className="hidden lg:inline-flex text-[10px] gap-1 shrink-0">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
            nuget.org v3 API
          </Badge>

          {/* Desktop actions */}
          <div className="ml-auto hidden md:flex items-center gap-1.5">
            {INTERNAL_LINKS.map((a) => (
              <Button key={a.label} asChild variant="ghost" size="sm" className="text-xs">
                <Link href={a.href} className={cn(isActive(a.href) && "text-primary")}>
                  <a.icon className="h-3.5 w-3.5" /> {a.label}
                </Link>
              </Button>
            ))}
            {EXTERNAL_LINKS.map((a) => (
              <Button key={a.label} asChild variant="ghost" size="sm" className="text-xs">
                <a href={a.href} target="_blank" rel="noreferrer noopener">
                  <a.icon className="h-3.5 w-3.5" /> {a.label}
                </a>
              </Button>
            ))}
            {result && <ShareButton result={result} />}
            {toolActions.map((a) =>
              a.href ? (
                <Button key={a.label} asChild variant="outline" size="sm" className="text-xs gap-1.5">
                  <Link href={a.href}>
                    <a.icon className="h-3.5 w-3.5" />
                    <span className="hidden lg:inline">{a.label}</span>
                  </Link>
                </Button>
              ) : (
                <Button key={a.label} variant="outline" size="sm" className="text-xs gap-1.5" onClick={a.onClick} disabled={a.disabled}>
                  <a.icon className={cn("h-3.5 w-3.5", a.spinning && "animate-spin")} />
                  <span className="hidden lg:inline">{a.label}</span>
                </Button>
              ),
            )}
            {onOpenPalette && (
              <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={onOpenPalette} title="Command palette (Cmd+K)">
                <Command className="h-3.5 w-3.5" />
                <kbd className="hidden lg:inline font-mono text-[10px] text-muted-foreground">⌘&nbsp;K</kbd>
              </Button>
            )}
            <ThemeToggle />
          </div>

          {/* Mobile: condensed + menu */}
          <div className="ml-auto flex md:hidden items-center gap-1">
            {result && <ShareButton result={result} />}
            {onOpenPalette && (
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={onOpenPalette}>
                <Command className="h-3.5 w-3.5" />
              </Button>
            )}
            <ThemeToggle />
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setMobileOpen(true)} aria-label="Open menu">
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="right" className="w-[280px] sm:w-[320px]">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <PackageSearch className="h-4 w-4" />
              Menu
            </SheetTitle>
          </SheetHeader>
          <div className="mt-4 space-y-1">
            {INTERNAL_LINKS.map((a) => (
              <Link key={a.label} href={a.href} onClick={() => setMobileOpen(false)}
                className={cn("w-full flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-muted/60 transition-colors", isActive(a.href) && "bg-primary/5 text-primary")}>
                <a.icon className="h-4 w-4 text-muted-foreground" />
                {a.label}
              </Link>
            ))}
            <div className="h-px bg-border my-2" />
            {toolActions.map((a) =>
              a.href ? (
                <Link key={a.label} href={a.href} onClick={() => setMobileOpen(false)}
                  className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-muted/60 transition-colors">
                  <a.icon className="h-4 w-4 text-muted-foreground" />
                  {a.label}
                </Link>
              ) : (
                <button key={a.label} onClick={() => { a.onClick(); setMobileOpen(false); }} disabled={a.disabled}
                  className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-muted/60 transition-colors text-left">
                  <a.icon className={cn("h-4 w-4 text-muted-foreground", a.spinning && "animate-spin")} />
                  {a.label}
                </button>
              ),
            )}
            <div className="h-px bg-border my-2" />
            {EXTERNAL_LINKS.map((a) => (
              <a key={a.label} href={a.href} target="_blank" rel="noreferrer noopener"
                className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-muted/60 transition-colors">
                <a.icon className="h-4 w-4 text-muted-foreground" />
                {a.label}
                <X className="h-3 w-3 ml-auto opacity-40" />
              </a>
            ))}
            {onOpenPalette && (
              <button onClick={() => { onOpenPalette(); setMobileOpen(false); }}
                className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-muted/60 transition-colors text-left">
                <Command className="h-4 w-4 text-muted-foreground" />
                Command palette
              </button>
            )}
          </div>
          <div className="mt-6 pt-4 border-t">
            <Badge variant="outline" className="text-[10px] gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              nuget.org v3 API
            </Badge>
          </div>
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer — exact match to original main page footer */}
      <footer className="relative border-t bg-gradient-to-b from-muted/20 to-muted/40 overflow-hidden mt-auto">
        <div className="absolute -top-px left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
        <div className="absolute -bottom-20 -right-20 h-40 w-40 rounded-full bg-primary/5 blur-3xl pointer-events-none" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 p-1.5">
                  <PackageSearch className="h-4 w-4 text-white" />
                </div>
                <span className="font-bold text-sm">NuGet Auditor</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Parse, visualize, and audit your .NET dependencies. No signup, no data stored.
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold mb-3 uppercase tracking-wide text-muted-foreground">Resources</p>
              <ul className="space-y-2 text-xs">
                <li><Link href="/scan" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><Github className="h-3 w-3" /> GitHub Scanner</Link></li>
                <li><Link href="/matrix" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><GitCompare className="h-3 w-3" /> Drift Matrix</Link></li>
                <li><Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><FileCode2 className="h-3 w-3" /> FAQ</Link></li>
                <li><Link href="/docs" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><FileCode2 className="h-3 w-3" /> Documentation</Link></li>
                <li><Link href="/blog" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><FileCode2 className="h-3 w-3" /> Blog</Link></li>
                <li><a href="https://learn.microsoft.com/en-us/nuget/" target="_blank" rel="noreferrer noopener" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><ExternalLink className="h-3 w-3" /> NuGet docs ↗</a></li>
                <li><a href="https://github.com/advisories" target="_blank" rel="noreferrer noopener" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"><Github className="h-3 w-3" /> Advisories ↗</a></li>
              </ul>
            </div>
            <div>
              <p className="text-xs font-semibold mb-3 uppercase tracking-wide text-muted-foreground">Features</p>
              <ul className="space-y-2 text-xs text-muted-foreground">
                <li className="flex items-center gap-1.5"><ShieldCheck className="h-3 w-3 text-emerald-500" /> CVE vulnerability auditing</li>
                <li className="flex items-center gap-1.5"><Network className="h-3 w-3 text-blue-500" /> Force-directed graph</li>
                <li className="flex items-center gap-1.5"><Bot className="h-3 w-3 text-purple-500" /> AI remediation advisor</li>
                <li className="flex items-center gap-1.5"><Terminal className="h-3 w-3 text-orange-500" /> Upgrade script generator</li>
              </ul>
            </div>
            <div>
              <p className="text-xs font-semibold mb-3 uppercase tracking-wide text-muted-foreground">Privacy</p>
              <ul className="space-y-2 text-xs text-muted-foreground">
                <li className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> No signup required</li>
                <li className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Parsed locally in browser</li>
                <li className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> No tracking, no cookies</li>
              </ul>
            </div>
          </div>
          <div className="mt-6 pt-4 border-t flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-muted-foreground">
            <p>© {new Date().getFullYear()} NuGet Visualizer &amp; Auditor v{APP_VERSION}. Developed by <span className="font-semibold text-foreground">0xz.0nfirex</span>. All rights reserved.</p>
            <p className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              All systems operational
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
