export function StructuredData() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: "NuGet Visualizer & Auditor",
    description:
      "Free online tool to parse .csproj files, visualize NuGet dependency trees, and audit packages for security vulnerabilities, outdated versions, and license compliance.",
    applicationCategory: "DeveloperApplication",
    operatingSystem: "Any",
    browserRequirements: "Requires JavaScript",
    url: "https://nuget-auditor.example.com",
    offers: {
      "@type": "Offer",
      price: "0",
      priceCurrency: "USD",
    },
    creator: {
      "@type": "Person",
      name: "0xz.0nfirex",
    },
    featureList: [
      "Parse .csproj XML files",
      "Visualize NuGet dependency trees",
      "Force-directed graph visualization",
      "Security vulnerability auditing (CVE matching)",
      "Outdated package detection",
      "License compliance classification",
      "AI-powered remediation advisor",
      "Upgrade script generator (Bash + PowerShell)",
      "Audit history with diff comparison",
      "Shareable audit links",
      "PWA with offline support",
    ],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "5",
      ratingCount: "1",
      bestRating: "5",
      worstRating: "1",
    },
  };

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: [
      {
        "@type": "Question",
        name: "What is the NuGet Visualizer & Auditor?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "It's a free online tool that parses your .csproj file, visualizes the NuGet dependency tree, and audits each package for security vulnerabilities, outdated versions, and license compliance.",
        },
      },
      {
        "@type": "Question",
        name: "Do I need to sign up to use the tool?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "No. The NuGet Auditor requires no signup, no login, and stores no personal data. Your .csproj content is parsed locally in your browser.",
        },
      },
      {
        "@type": "Question",
        name: "How does the vulnerability scanning work?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "The tool fetches vulnerability data from the NuGet v3 registration API, which includes GitHub Advisory database entries. Each declared package version is checked against the affected version ranges.",
        },
      },
      {
        "@type": "Question",
        name: "Can I use this tool offline?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Yes. The application is a Progressive Web App (PWA) with a service worker that caches the app shell for offline use. Live NuGet API data requires an internet connection.",
        },
      },
      {
        "@type": "Question",
        name: "Is my data shared with anyone?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "No. Audit data is isolated per-browser using a client ID. Shared audit links are opt-in and only accessible via the generated URL.",
        },
      },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home", item: "https://nuget-auditor.example.com/" },
            { "@type": "ListItem", position: 2, name: "FAQ", item: "https://nuget-auditor.example.com/faq" },
            { "@type": "ListItem", position: 3, name: "Docs", item: "https://nuget-auditor.example.com/docs" },
            { "@type": "ListItem", position: 4, name: "Blog", item: "https://nuget-auditor.example.com/blog" },
          ],
        }) }}
      />
    </>
  );
}
