import type { Metadata } from "next";
import { DocsPage } from "@/components/nuget/pages/docs-page";

export const metadata: Metadata = {
  title: "Documentation — NuGet Auditor",
  description: "Complete documentation for the NuGet Visualizer & Auditor. Learn how to scan .csproj files, read audit reports, use the force-directed graph, generate upgrade scripts, and more.",
  keywords: ["NuGet Auditor docs", "csproj parser documentation", "NuGet audit guide", ".NET dependency scanner help"],
  alternates: { canonical: "/docs" },
  openGraph: {
    title: "Documentation — NuGet Auditor",
    description: "Complete guide to using the NuGet Visualizer & Auditor for dependency security.",
  },
};

export default function Page() {
  return <DocsPage />;
}
