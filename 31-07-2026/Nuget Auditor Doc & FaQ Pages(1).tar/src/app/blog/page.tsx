import type { Metadata } from "next";
import { BlogPage } from "@/components/nuget/pages/blog-page";

export const metadata: Metadata = {
  title: "Blog — NuGet Auditor",
  description: "Articles and guides on NuGet package security, .NET dependency management, and keeping your projects safe from vulnerabilities.",
  keywords: ["NuGet security blog", ".NET dependency management", "NuGet vulnerability articles", "csproj security tips"],
  alternates: { canonical: "/blog" },
  openGraph: {
    title: "Blog — NuGet Auditor",
    description: "Expert articles on NuGet security, .NET dependencies, and vulnerability management.",
  },
};

export default function Page() {
  return <BlogPage />;
}
