import type { Metadata } from "next";
import { FaqPage } from "@/components/nuget/pages/faq-page";

export const metadata: Metadata = {
  title: "FAQ — NuGet Auditor",
  description: "Frequently asked questions about the NuGet Visualizer & Auditor. Learn how to audit .csproj files, check for vulnerabilities, and keep your .NET projects secure.",
  keywords: ["NuGet FAQ", "csproj audit questions", "NuGet vulnerability scanner FAQ", ".NET security tool help"],
  alternates: { canonical: "/faq" },
  openGraph: {
    title: "FAQ — NuGet Auditor",
    description: "Answers to common questions about auditing NuGet packages for vulnerabilities and outdated versions.",
  },
};

export default function Page() {
  return <FaqPage />;
}
